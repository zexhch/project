<?php

use Illuminate\Support\Str;

return [
    'domain' => env('HORIZON_DOMAIN'),
    'path' => env('HORIZON_PATH', 'horizon'),
    'use' => 'default',
    'prefix' => env('HORIZON_PREFIX', Str::slug((string) env('APP_NAME', 'biscuit-factory'), '_').'_horizon:'),
    'middleware' => ['web', 'auth'],
    'waits' => [
        'redis:default' => 60,
    ],
    'trim' => [
        'recent' => 60,
        'pending' => 60,
        'completed' => 60,
        'recent_failed' => 10080,
        'failed' => 10080,
        'monitored' => 10080,
    ],
    'silenced' => [],
    'metrics' => [
        'trim_snapshots' => [
            'job' => 24,
            'queue' => 24,
        ],
    ],
    'fast_termination' => false,
    'memory_limit' => (int) env('HORIZON_MASTER_MEMORY_LIMIT', 128),
    'defaults' => [
        'supervisor-1' => [
            'connection' => 'redis',
            'queue' => ['default', 'notifications', 'reports'],
            'balance' => 'auto',
            'autoScalingStrategy' => 'time',
            'maxProcesses' => (int) env('HORIZON_DEFAULT_MAX_PROCESSES', 5),
            'maxTime' => 0,
            'maxJobs' => 0,
            'memory' => (int) env('HORIZON_DEFAULT_WORKER_MEMORY', 256),
            'tries' => 3,
            'timeout' => (int) env('HORIZON_DEFAULT_TIMEOUT', 120),
            'nice' => 0,
        ],
        'supervisor-imports' => [
            'connection' => 'redis',
            'queue' => ['imports', 'exports'],
            'balance' => 'simple',
            'maxProcesses' => (int) env('HORIZON_IMPORT_MAX_PROCESSES', 2),
            'maxTime' => 0,
            'maxJobs' => 50,
            'memory' => (int) env('HORIZON_IMPORT_WORKER_MEMORY', 384),
            'tries' => 1,
            'timeout' => (int) env('HORIZON_IMPORT_TIMEOUT', 1800),
            'nice' => 5,
        ],
    ],
    'environments' => [
        'production' => [
            'supervisor-1' => [
                'maxProcesses' => (int) env('HORIZON_PRODUCTION_MAX_PROCESSES', 5),
                'balanceMaxShift' => 1,
                'balanceCooldown' => 3,
            ],
            'supervisor-imports' => [
                'maxProcesses' => (int) env('HORIZON_PRODUCTION_IMPORT_MAX_PROCESSES', 1),
            ],
        ],
        'local' => [
            'supervisor-1' => [
                'maxProcesses' => (int) env('HORIZON_LOCAL_MAX_PROCESSES', 3),
            ],
            'supervisor-imports' => [
                'maxProcesses' => (int) env('HORIZON_LOCAL_IMPORT_MAX_PROCESSES', 1),
            ],
        ],
    ],
];
