<?php

return [
    'item_images' => [
        'disk' => env('ITEM_IMAGE_DISK', 'public'),
        'max_file_kb' => (int) env('ITEM_IMAGE_MAX_KB', 8192),
        'max_pixels' => (int) env('ITEM_IMAGE_MAX_PIXELS', 25000000),
        'max_dimension' => (int) env('ITEM_IMAGE_MAX_DIMENSION', 1600),
        'thumbnail_dimension' => (int) env('ITEM_IMAGE_THUMBNAIL_DIMENSION', 320),
        'gallery_max_files' => (int) env('ITEM_IMAGE_GALLERY_MAX_FILES', 10),
        'archive_max_kb' => (int) env('ITEM_IMAGE_ARCHIVE_MAX_KB', 51200),
        'archive_max_files' => (int) env('ITEM_IMAGE_ARCHIVE_MAX_FILES', 1000),
    ],
];
