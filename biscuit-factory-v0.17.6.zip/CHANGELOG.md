# Journal des modifications

Toutes les évolutions notables du projet sont consignées dans ce fichier.

Le format suit les principes de **Keep a Changelog** et le versionnement sémantique.

## [0.17.6] - 2026-07-18

### Observabilité du déploiement

- Marqueurs horodatés `START`, `END`, `SLOW`, `WAIT` et `FAIL` pour toutes les phases et commandes d’installation Windows/Linux.
- Journaux complets, chronométrages structurés, résumé JSON Windows et alias `latest-*` dans `storage/logs/installer`.
- Rapport des opérations les plus lentes via `installation-report-windows.cmd` et `scripts/installation-report.sh`.
- Capture automatique de l’état Compose, de `docker stats` et des logs des services principaux après un échec.
- Seuil des commandes lentes configurable avec `-SlowCommandSeconds` ou `--slow-command-seconds`.

### Corrections d’exploitation

- Healthcheck Docker Nginx déplacé vers une route statique `/nginx-health`, indépendante des traitements Laravel.
- Attente liveness/readiness instrumentée avec progression et timeout individuel adapté à la readiness.
- Déplacement du `ApplicationModuleSeeder` vers un chemin conforme PSR-4 et sensible à la casse Linux.
- Vérification idempotente du lien `public/storage` avant appel à `storage:link`.

## [0.17.5] - 2026-07-18

### Allocation optimisée des ressources

- Limites CPU, mémoire, réservation mémoire et PID définies par service dans les configurations locale et production.
- Profil équilibré configurable depuis `.env`, sans modification des fichiers Compose.
- Réglages PostgreSQL adaptés à la mémoire du conteneur : buffers, cache estimé, mémoire de maintenance, WAL et concurrence d’E/S.
- Redis plafonné avec persistance `appendfsync everysec` et politique `noeviction` afin de protéger jobs, sessions et files.
- Horizon rendu configurable par environnement pour les processus, la mémoire des workers et les timeouts.
- OPcache production optimisé avec désactivation de la validation des timestamps.
- Avertissements de capacité dans les précontrôles Docker Desktop et nouveau rapport de consommation Windows/Linux.

## [0.17.4] - 2026-07-17

### Stabilisation Docker Desktop

- Intégration définitive des corrections validées manuellement pendant la recette v0.17.3.
- Exclusion de `public/storage` et du répertoire temporaire de santé du contexte BuildKit, puis recréation idempotente du lien au démarrage.
- Healthcheck Horizon porté à 45 secondes avec période de démarrage, et healthchecks Horizon/Reverb alignés dans la configuration de production.
- Pool PHP-FPM dimensionné à 10 workers avec recyclage périodique afin de réduire les saturations observées.
- Scripts d’installation Windows/Linux ajustés pour reconstruire tous les services PHP avant le redéploiement.

### Corrections fonctionnelles

- Correction du bloc Blade de la page Qualité, couvrant `/quality`, `/quality/non-conformities` et `/quality/plans`.
- Conversion arrondie et typée des durées d’arrêt afin d’accepter les secondes décimales retournées par Carbon 3.
- Consolidation de la clé primaire réflexive `item_categories`, de la permission `stocks.approve`, de Tinker 3 et du timeout Composer.
- Ajout de tests de non-régression et du validateur `scripts/validate-corrective-0.17.4.php`.

## [0.17.3] - 2026-07-17

### Refonte UX/UI prioritaire

- Nouveau shell applicatif avec barre latérale sombre organisée par workflow, en-tête allégé, recherche globale, langue, thème, notifications et profil.
- Composants Blade réutilisables pour les cartes KPI, sections opérationnelles et graphiques afin d’harmoniser tous les modules.
- Refonte des tableaux de bord principal, Stocks, Production, Ventes et Facturation/Finance, avec hiérarchie visuelle, accès rapides, alertes et tableaux compacts.
- Graphiques SVG natifs de type courbe, barres, barres horizontales et donut, sans service tiers ni nouvelle dépendance JavaScript.
- Styles responsive, mode sombre, RTL, navigation clavier, réduction des animations et adaptation mobile/tablette.

### Performance de navigation

- Chargement asynchrone des compteurs de tâches et d’alertes après l’affichage de la page.
- Cache court des tableaux de bord et du workflow afin d’éviter les recalculs SQL identiques à chaque navigation.
- Cache en mémoire des rôles et permissions pendant la requête afin de supprimer les lectures répétées.
- Suppression des requêtes de favoris et de notifications depuis le rendu initial de l’en-tête.
- Validation statique dédiée de la refonte via `scripts/validate-ui.php`.

## [0.17.2] - 2026-07-17

### Unités et conditionnements dynamiques

- Gestion hiérarchique par article avec unité de base, unité parente, facteur vers le parent et facteur calculé vers la base.
- Rôles d’unité configurables pour achat, vente, production et inventaire, avec unités fractionnables et règles d’arrondi.
- Poids net/brut, tare, dimensions, volume, code-barres et période de validité par conditionnement.
- Recalcul transactionnel des descendants, prévention des cycles, blocage des suppressions utilisées et historisation de chaque changement.
- Conversion automatique et gel du facteur sur les devis, commandes, tarifs, réceptions, livraisons, retours, recettes et mouvements concernés.
- Décomposition lisible du stock, par exemple `2 PAL + 3 CT`, tout en conservant l’unité de base comme source de vérité.

### Images des articles

- Image principale PNG nommée avec le code article, par exemple `PF-BIS-180.png`.
- Galerie PNG séquentielle, miniatures, redimensionnement, limites de poids/pixels et import groupé ZIP.
- Renommage automatique lors d’un changement de code, remplacement contrôlé et suppression des fichiers devenus orphelins.
- Affichage des miniatures dans le référentiel article et la recherche globale.

### Imports et aide contextuelle

- Import/export CSV/XLSX des conditionnements avec modèle téléchargeable, prévisualisation et contrôles métier.
- Glossaire FR/EN/AR des sigles métier et page d’aide centralisée.
- Tooltips accessibles au clavier, au mobile et au RTL sur les champs des formulaires, avec description, format et exemple.
- Données de démonstration : paquet de 180 g, carton de 24 paquets et palette de 36 cartons.
- Tests de régression et validateur autonome `scripts/validate-packaging.php`.

## [0.17.1] - 2026-07-17

### Documents commerciaux et identité légale

- Ajout du RC, NIF, NIS, AI, activité, banque, agence, numéro de compte et logo sur la fiche société.
- Ajout du NIS et de l’AI aux clients et fournisseurs, avec création, modification, affichage, recherche globale et imports/exports CSV/XLSX.
- Nouveau gabarit A4 pour factures, bons de livraison et autres documents commerciaux, inspiré du modèle opérationnel fourni par l’utilisateur.
- Affichage du numéro de ligne, de la référence, de la quantité, du prix unitaire HT, du taux de TVA et du montant HT.
- Totaux HT, remise, TVA, TTC, solde et conversion du montant en lettres en FR/EN/AR.
- Affichage configurable des prix sur les bons de livraison, avec prix visibles par défaut.
- Logo société téléversable, coordonnées bancaires et zones cachet/signature.

### Cohérence applicative

- Mise à jour des fiches client/fournisseur, exports historiques, recherche globale et données de démonstration.
- Normalisation des prix HT lorsque les tarifs source sont saisis TTC.
- Calcul des remises et taxes des livraisons/réceptions à partir des lignes d’origine.
- Tests de régression et validateur autonome `scripts/validate-legal-printing.php`.
- Documentation de configuration et procédure de mise à niveau Windows/Linux.

## [0.17.0] - 2026-07-17

### Planification industrielle

- Nouveau module `planning` activable avec plan directeur de production issu des commandes clients confirmées.
- Calcul chronologique des besoins nets avec stock libéré non périmé, réservations, stock de sécurité et réceptions attendues.
- Explosion des recettes approuvées en besoins matières, détection des conversions manquantes et des pénuries.
- Ordonnancement par produit, ligne, cadence, temps de changement de série, équipes et maintenances planifiées.
- Choix automatique de la ligne la moins chargée et détection des surcharges ou des produits sans capacité configurée.
- Scénarios de variation de demande, capacité et stock de sécurité, avec indicateurs comparatifs.
- Approbation bloquée par les conflits critiques puis génération transactionnelle des ordres de fabrication liés au plan.

### Performance industrielle

- Configuration des capacités produit/ligne et visualisation des machines critiques.
- Calcul historisé du TRS/OEE par ligne et période à partir des équipes, arrêts, productions et quantités acceptées.
- Consolidation des disponibilités, performances et taux qualité, avec commande planifiée quotidienne.
- Intégration dans « Mes tâches », le workflow Production, les permissions, les rôles et les notifications existantes.

### Qualité et portabilité

- Calculs portables PostgreSQL/SQLite et contrôles de concurrence sur les plans et créations d’OF.
- Tests fonctionnels, validateur autonome, traductions FR/EN/AR et documentation de mise à niveau.

## [0.16.0] - 2026-07-17

### Imports et exports

- Nouveau module `productivity` pour les échanges de données et les outils de productivité.
- Imports CSV UTF-8 et XLSX des articles, clients et fournisseurs avec modèles téléchargeables.
- Prévisualisation ligne par ligne, contrôles de colonnes, validation métier et modes `UPDATE`, `SKIP` ou `FAIL`.
- Traitements asynchrones des imports et exports sur des files Horizon dédiées, avec limite de 10 000 lignes par import, notifications et rapport XLSX des erreurs.
- Exports CSV/XLSX privés et protection contre l’injection de formules dans les fichiers CSV.

### Productivité utilisateur

- Recherche globale sur articles, clients, fournisseurs, devis et commandes, filtrée par permissions et modules actifs.
- Favoris et raccourcis personnels avec accès rapide dans l’en-tête.
- Actions groupées auditées d’activation, désactivation et restauration sur 1 000 codes maximum.
- Duplication contrôlée des devis, commandes clients, demandes d’achat et commandes fournisseurs avec nouvelle numérotation légale.

### Sécurité et qualité

- Double contrôle des permissions Productivité et des permissions métier source, y compris dans les jobs Horizon.
- Aucun état opérationnel, réservation, livraison, réception ou validation n’est recopié lors d’une duplication.
- Traitement déterministe des lignes d’import par blocs, sans saut lié aux UUID ou au changement de statut.
- Validateur autonome, tests de régression, traductions FR/EN/AR et documentation de mise à niveau.

## [0.15.0] - 2026-07-17

### Gouvernance financière

- Périodes comptables mensuelles avec génération annuelle, clôture, réouverture motivée et contrôle des opérations financières.
- Numérotation légale configurable et transactionnelle pour douze types de documents commerciaux et financiers.
- Approbations multi-niveaux des factures selon la société, le montant, la devise, le rôle, la permission et le quorum.
- Soumission, rejet, correction et nouvelle soumission des factures avec intégration à « Mes tâches ».
- Annulation des factures par avoir de contrepartie et traçabilité de la contre-écriture.

### Gouvernance documentaire

- Modèles imprimables A4 configurables par société, document et langue.
- Impression des devis, commandes clients, bons de livraison, demandes d'achat, commandes fournisseurs, réceptions, factures, avoirs et règlements.
- Historique immuable des créations, modifications, impressions, décisions et annulations.
- Numérotation commerciale généralisée aux nouveaux devis, commandes, livraisons, demandes d'achat et réceptions.
- Contrôles de concurrence PostgreSQL sur les séquences, approbations et versions.

### Qualité

- Migration compatible PostgreSQL et SQLite, données d'exemple non intrusives, tests fonctionnels et validateur autonome.
- Documentation fonctionnelle et procédure de mise à niveau depuis la v0.14.0.

## [0.14.0] - 2026-07-16

### Sécurité

- Politique de mots de passe configurable : longueur, complexité, durée de validité et changement forcé.
- Verrouillage temporaire des comptes après échecs répétés, limitation par adresse IP et déverrouillage administratif.
- Historisation des connexions, déconnexions, échecs, changements de mot de passe et révocations de sessions.
- Gestion des sessions actives par utilisateur et révocation administrative ciblée.
- Identifiant de corrélation HTTP, sévérité et métadonnées structurées dans le journal d’audit.
- Commande `security:audit` et scripts équivalents Windows/Linux.

### Exploitation

- Nouveau module `operations` avec page Administration → Sécurité et exploitation.
- Supervision consolidée de la base, des migrations, du cache, de Redis, du stockage, des files et des sauvegardes.
- Sauvegardes PostgreSQL manuelles ou planifiées, avec option d’inclure les fichiers privés, empreinte SHA-256 et téléchargement protégé.
- Historique des sauvegardes, notification de succès/échec et rétention configurable.
- Instantanés de santé toutes les cinq minutes et purge planifiée des anciens audits, sessions, sauvegardes et instantanés.
- Volume partagé de stockage privé dans `compose.prod.yaml` afin que le scheduler et l’application accèdent aux mêmes sauvegardes.
- Restauration sécurisée des dumps historiques et archives ZIP applicatives, avec SHA-256, mode maintenance, arrêt des workers, transaction PostgreSQL et invalidation des sessions.
- Commande `operations:post-restore` pour nettoyer les données d’exécution et réconcilier l’historique des sauvegardes.

### Durcissement

- Chiffrement des sessions activé par défaut et paramètres de cookies explicités.
- En-têtes Nginx renforcés et signature serveur masquée.
- Client `postgresql-client-17` ajouté à l’image applicative et contrôlé avant `pg_dump`, afin de rester compatible avec PostgreSQL 17.
- Tests de régression sécurité/exploitation et documentation de mise à niveau.

## [0.13.2] - 2026-07-16

### Ajouté

- Parcours complet d’installation Docker Desktop avec PowerShell 5.1 et PowerShell 7.
- Lanceurs `.cmd` pour l’installation, le healthcheck et la validation destructive.
- Scripts Windows de précontrôle, installation, contrôle de santé et validation de release.
- Sauvegarde PostgreSQL et documentaire Windows avec `docker cp`, sans redirection binaire risquée.
- Restauration contrôlée de la base et de `storage/app`, suivie des migrations, de la synchronisation des modules et des sondes.
- Documentation dédiée `docs/WINDOWS.md` et guide de mise à niveau.

### Modifié

- La validation statique contrôle désormais la présence des scripts Windows et leur syntaxe lorsqu’un runtime PowerShell est disponible.
- Le packaging exclut le répertoire local `backups`.
- Le démarrage rapide documente séparément Windows et Linux.

### Sécurité

- Les suppressions de volumes nécessitent `-ConfirmReset`, la variable `BISCUIT_FACTORY_CONFIRM_RESET=YES` ou la saisie explicite de `RESET`.
- Les restaurations nécessitent `-ConfirmRestore`, la variable `BISCUIT_FACTORY_CONFIRM_RESTORE=YES` ou la saisie explicite de `RESTORE`.

## [0.13.1] - 2026-07-16

### Stabilisation du déploiement

- Endpoints publics minimalistes `/health/live` et `/health/ready` avec codes HTTP 200/503 adaptés aux sondes Docker et reverse proxies.
- Nouvelle commande `app:doctor` contrôlant la configuration, PostgreSQL, les migrations, le cache, le stockage, Redis et le registre des modules.
- Contrôle d'écriture réel sur le cache et le stockage avec nettoyage automatique des sondes temporaires.
- Détection des migrations non appliquées et des manifestes de modules non synchronisés.
- Nouveau validateur statique sans Docker pour PHP, Bash, JSON, manifestes, reporting, assets et cohérence de version.
- Pré-contrôle Docker vérifiant Compose, l'environnement, les secrets par défaut et l'espace disque disponible.
- Installation initiale idempotente avec options `--fresh`, `--no-seed` et `--skip-healthcheck`.
- Validation destructive explicite d'une installation neuve via `scripts/validate-installation.sh`.
- Contrôle de santé enrichi pour l'application, Horizon, MinIO et Mailpit.
- Tests de régression dédiés aux endpoints et au diagnostic applicatif.

## [0.13.0] - 2026-07-16

### Tableaux de bord et rapports avancés

- Nouveau module `reports` activable, avec permissions, routes et migrations dédiées.
- Huit familles de rapports : synthèse de direction, ventes, achats, production, stocks, qualité, maintenance et finance.
- Indicateurs consolidés, tendances mensuelles et tableaux de classement filtrables par société, site et période.
- Tableau de bord adapté automatiquement au rôle principal et aux modules autorisés.
- Exports CSV UTF-8 protégés contre les formules de tableur et vues imprimables utilisables pour la génération PDF depuis le navigateur.
- Programmation quotidienne, hebdomadaire ou mensuelle sur périodes relatives.
- Stockage privé des fichiers, historique des exécutions, téléchargement autorisé et notifications applicatives.
- Commande `reports:run-schedules` planifiée toutes les cinq minutes avec verrouillage distribué, revalidation des droits et purge des anciens fichiers.
- Validateur autonome du reporting, documentation, traductions FR/EN/AR et tests fonctionnels dédiés.

## [0.12.0] - 2026-07-16

### Modularisation technique

- Dix domaines décrits par des manifestes versionnés dans `app/Modules`.
- Routes web séparées par module et chargées par un registre central compatible avec le cache des routes.
- Migrations métier déplacées physiquement dans chaque module, avec conservation de leurs noms historiques et chargement automatique.
- Registre persistant avec état, version, empreinte, dates d’activation et graphe de dépendances.
- Modules socles obligatoires et contrôles bloquants lors de l’activation ou de la désactivation.
- Verrouillage déterministe du graphe lors des changements d’état et cache partagé invalidé après chaque synchronisation.
- Middleware empêchant l’accès direct aux routes et référentiels d’un module désactivé.
- Navigation, tableau de bord, tâches, alertes et traitements planifiés filtrés selon l’état des modules.
- Écran Administration → Modules, permissions dédiées et audit des changements.
- Commandes `module:sync`, `module:list`, `module:enable`, `module:disable` et `module:diagnose`.
- Validateur autonome `scripts/validate-modules.php` pour les manifestes, cycles, routes, permissions, traductions et migrations.
- Tests de synchronisation, dépendances, blocage des routes et rattachement des référentiels.
- Guide de mise à niveau, manuel d’exploitation et validation de release enrichie.


## [0.11.0] - 2026-07-16

### Pilotage du workflow

- Nouveau tableau **Mes tâches** calculé directement depuis les documents métier, sans double saisie ni table de tâches parallèle.
- Priorisation critique, haute ou normale, filtres par domaine, report individuel et masquage réversible.
- Centre d’alertes consolidant stocks faibles, lots proches de péremption, factures échues, budgets dépassés, qualité et maintenance en retard.
- Notifications quotidiennes sans doublon via `workflow:notify-alerts` et rafraîchissement horaire planifié.

### Parcours guidé et traçabilité

- Action **Étape suivante** sur les devis, commandes, livraisons, achats, réceptions, OF, contrôles qualité, non-conformités, maintenance et factures.
- Ouverture directe de la section opérationnelle concernée, y compris les formulaires repliés et les règlements clients/fournisseurs.
- Timeline unifiée combinant transitions de statut et journal d’audit.
- Enregistrement automatique des créations et changements de statut sur les documents principaux.

### Ergonomie et temps réel

- Compteurs de tâches, alertes et notifications dans la navigation.
- Cloche de notifications avec lecture individuelle ou globale.
- Mise à jour par Laravel Reverb/WebSocket avec repli par interrogation toutes les 60 secondes.
- Tableau de bord enrichi des tâches prioritaires, traductions FR/EN/AR et styles responsive/RTL.
- Migration dédiée, tests fonctionnels, manuel du module et guide de mise à niveau.

## [0.10.1] - 2026-07-16

### Stabilisation de la facturation

- Verrouillage déterministe des factures lors de la comptabilisation et de l’annulation des règlements afin de réduire les risques de concurrence et d’interblocage.
- Vérification systématique de la société, du tiers, de la devise et du compte financier au niveau du service métier, indépendamment des contrôles d’interface.
- Rechargement explicite des relations de facture avant recalcul pour éviter les soldes obsolètes après création d’un avoir ou changement de règlement.
- Recalcul par lots des factures ouvertes et rafraîchissement horaire automatique des statuts échus.
- Application effective du paramètre société `allow_unallocated_payments` lors de la comptabilisation.
- Index complémentaires et contraintes PostgreSQL non bloquantes sur les valeurs financières dérivées.

### Audit et exploitation

- Nouvelle commande `finance:audit-ledger` pour contrôler totaux, avoirs, règlements, soldes, statuts et cohérence des ventilations.
- Option `--repair` limitée à la reconstruction des montants dérivés, sans création, suppression ou réaffectation de règlements.
- Nouvelle commande `finance:refresh-overdue`, filtrable par société.
- Intégration de l’audit financier dans `scripts/validate-release.sh` et nouvelle cible `make audit`.
- Tests de régression sur les relations chargées, les échéances, les incohérences multi-sociétés et la réparation contrôlée.
- Migrations rendues compatibles SQLite pour permettre l’exécution réelle de la suite de tests, sans retirer les contraintes PostgreSQL de production.

## [0.10.0] - 2026-07-16

### Facturation clients

- Génération d’une facture brouillon depuis chaque livraison comptabilisée, sur les quantités réellement expédiées.
- Émission, échéance calculée selon les conditions client, lignes HT/taxes/TTC et liens vers commande et livraison.
- Avoirs clients imputés sur le solde, historique des règlements et registre manuel des relances.
- Statuts `DRAFT`, `ISSUED`, `PARTIALLY_PAID`, `PAID` et `OVERDUE` recalculés automatiquement.

### Facturation fournisseurs

- Enregistrement depuis une réception comptabilisée et conservation du numéro fournisseur.
- Rapprochement commande/réception/facture, calcul de l’écart et acceptation explicite au-delà de la tolérance configurée.
- Avoirs fournisseurs approuvés et imputés sur les dettes ouvertes.

### Règlements et trésorerie

- Comptes de trésorerie configurables par société, devise et type banque/caisse.
- Règlements clients et fournisseurs en brouillon puis comptabilisation contrôlée.
- Ventilation d’un règlement sur plusieurs factures et règlements successifs sur une même facture.
- Contrôles du tiers, de la devise, du montant ventilé et du solde disponible.
- Annulation auditée d’un règlement comptabilisé sans suppression, avec restitution automatique des soldes.
- Balances âgées clients et fournisseurs avec seuils configurables.

### Workflow, données et qualité

- Points d’entrée de facturation ajoutés directement sur les livraisons et réceptions.
- Menu Finance enrichi tout en conservant la navigation repliable par workflow.
- Référentiels FR/EN/AR pour comptes, modes de règlement, motifs d’avoir et canaux de relance.
- Migration dédiée, données de démonstration, tests fonctionnels, documentation du module et guide de mise à niveau.

## [0.9.1] - 2026-07-16

### Navigation et ergonomie

- Barre latérale réorganisée selon le workflow réel : pilotage, ventes, achats, stocks, production, qualité, maintenance, finance, paramétrage et administration.
- Groupes repliables, ouverture automatique du groupe actif et filtrage intégral par permissions.
- Référentiels techniques déplacés en bas du menu pour alléger le parcours quotidien.
- Compatibilité conservée avec Select2, DataTables, mode sombre, responsive et arabe RTL.

### Contrôle de gestion

- Centres de coûts par société et site, responsables, types et méthodes d’imputation configurables.
- Rattachement des lignes de production et machines aux centres de coûts.
- Taux horaires historisés par type, devise et période de validité.
- Simulations multi-produits basées sur les recettes approuvées, sans modification des données de référence.
- Hypothèses de variation matières, conversion et frais généraux avec calcul du coût, du chiffre d’affaires et de la marge.
- Budgets annuels ou mensuels par centre et catégorie, réalisés recalculés depuis les coûts réels de production et de maintenance.
- Analyse des marges par client et produit avec priorité au coût réel et repli sur le coût théorique.
- Approbation et verrouillage des scénarios, approbation des budgets et audit des opérations.

### Données, tests et documentation

- Cinq nouvelles tables de contrôle de gestion et rattachement facultatif des lignes et machines aux centres de coûts.
- Référentiels FR/AR/EN pour les types de centres, méthodes d’imputation, taux et catégories budgétaires.
- Données de démonstration pour deux centres, deux taux, un budget et un scénario de référence.
- Nouvelle suite de tests fonctionnels du contrôle de gestion.
- Correction du verrou `package-lock.json` pour rendre `npm ci` reproductible.
- Manuel du module et guide de mise à niveau vers la v0.9.1.

## [0.9.0] - 2026-07-16

### Recettes

- Écrans complets de création et de consultation des recettes avec recherche, filtres, Select2 et DataTables.
- Versions brouillon, duplication, rendement, validité, gamme et notes.
- Composition en matières, emballages et semi-finis avec quantités, unités, pertes prévues et ingrédients facultatifs.
- Approbation contrôlée, gel des versions approuvées et archivage de la version précédente.
- Navigation par onglets et divulgation progressive pour conserver des pages légères.

### Prix de revient

- Coût théorique séparant matières, emballages, main-d’œuvre, machines, énergie, sous-traitance, frais indirects et autres coûts.
- Charges configurables par quantité, montant fixe ou pourcentage du sous-total.
- Valorisation matière au CUMP courant, conversions d’unité et alertes de calcul incomplet.
- Saisie des charges réelles sur l’OF et comparaison standard/réel.
- Coût réel calculé depuis les sorties de stock valorisées et la quantité conforme.
- Historique des calculs et affectation automatique du coût réel à l’entrée en stock du lot fini.

### Production et ergonomie

- Besoins matière incluant désormais les pertes prévues de la recette.
- Sélection FEFO dans tous les emplacements actifs de l’entrepôt source.
- Coût des sorties de stock figé au moment de la comptabilisation.
- Refonte des écrans OF avec indicateurs compacts, étapes visuelles et actions contextuelles.
- Traductions françaises, anglaises et arabes avec RTL.

### Données, tests et documentation

- Trois nouvelles tables : `recipe_cost_components`, `production_cost_entries` et `cost_calculations`.
- Données de démonstration complétées pour tous les ingrédients et emballages de la recette biscuit chocolat.
- Tests du versionnement, de l’approbation, des coûts théoriques, des coûts réels et de la valorisation du lot fini.
- Manuel Recettes enrichi, nouveau manuel Prix de revient et guide de mise à niveau v0.9.0.
- Conservation des correctifs manuels Docker/PostgreSQL/permissions validés sur Windows.

## [0.8.0] - 2026-07-16

### Ajouté

- Fiches clients, contacts, groupes, canaux, conditions de paiement, plafond de crédit et qualification.
- Tarifs de vente HT/TTC par client, groupe, canal ou portée générale, avec périodes, priorité et paliers de quantité.
- Moteur de résolution des prix par spécificité et conservation des prix/remises/taxes dans les documents.
- Devis, envoi, acceptation et conversion en commande sans recalcul historique.
- Commandes clients directes ou issues d’un devis, soumission, confirmation et annulation contrôlée.
- Réservation atomique multi-lots dans l’entrepôt de la commande, limitée aux lots libérés, non périmés et ordonnée en FEFO.
- Préparation de livraisons totales ou partielles avec protection contre la double affectation d’une réservation.
- Comptabilisation des expéditions avec sortie de stock, consommation des réservations et mise à jour des reliquats.
- Traçabilité lot de produit fini → bon de livraison → commande → client.
- Retours clients par lot expédié, nouveau lot de quarantaine, coût historique et contrôle qualité automatique.
- Profils `SALES_MANAGER` et `SALES`, permissions, audit, référentiels FR/EN/AR et exports CSV protégés.
- Données de démonstration : client, contact, tarif à deux paliers, devis, commande et plan qualité des retours.

### Ergonomie

- Navigation horizontale propre au module Ventes.
- Écrans de création repliés par défaut et champs facultatifs placés dans « Options avancées ».
- Résumés compacts, indicateurs sobres et parcours visuel des commandes en quatre étapes.
- Actions principales adaptées à l’état du document ; annulation reléguée dans un menu secondaire.
- Filtrage automatique des clients et entrepôts par société.
- Mise en page responsive et RTL des nouveaux composants, sans surcharge des pages métier.
- Tableau de bord allégé : indicateurs opérationnels prioritaires, accès rapides et compteurs de référentiels repliables selon les permissions.
- Suppression contrôlée des lignes de devis, commandes et tarifs en brouillon avec recalcul automatique.
- Traductions anglaises et arabes complétées pour les validations du module Qualité.

### Sécurité et intégrité

- Verrouillage transactionnel des commandes, soldes, réservations, affectations, livraisons et retours.
- Séparation entre validation commerciale et comptabilisation du stock.
- Blocage des lots en quarantaine, bloqués ou périmés lors de la réservation.
- Contrôle des surlivraisons, doubles affectations et retours supérieurs aux quantités réellement expédiées.
- Retours obligatoirement dirigés vers un emplacement de quarantaine et jamais remis en vente automatiquement.
- Conservation des correctifs Windows/Docker/PostgreSQL issus des démarrages réels précédents.

### Documentation et tests

- Manuel `docs/modules/12-VENTES-LIVRAISONS.md` avec scénario complet reproductible.
- Guide `docs/modules/13-ERGONOMIE-APPLICATION.md` pour uniformiser les prochains écrans.
- Guide de mise à niveau `docs/UPGRADE_0.8.md` avec commandes PowerShell.
- Tests des tarifs, permissions, réservations FEFO, livraisons partielles, stock, retours et contrôles qualité.

## [0.7.0] - 2026-07-16

### Ajouté

- Fiches fournisseurs, contacts, articles fournis, unités d’achat, conversions, délais et minimums de commande.
- Qualification des fournisseurs et évaluations périodiques sur la qualité, les délais, les conditions commerciales et le service.
- Demandes d’achat avec soumission, approbation, lignes, priorités et fournisseurs suggérés.
- Consultations multi-fournisseurs, comparaison des offres et création d’une commande depuis l’offre retenue.
- Tarifs d’achat approuvés par fournisseur, devise, mode HT/TTC, période, priorité et paliers de quantité.
- Commandes d’achat directes ou issues d’une offre, calcul des montants, soumission et approbation.
- Réceptions partielles, quantités acceptées/refusées, lots fournisseur, péremption et rattachement au bon de livraison.
- Comptabilisation atomique des réceptions avec mouvement de stock, coût moyen, quarantaine et planification qualité.
- Retours fournisseurs atomiques, contrôlés par réception, lot, emplacement et stock disponible.
- Exports CSV protégés des fournisseurs et commandes.
- Profils `PURCHASING_MANAGER` et `BUYER`, permissions dédiées et référentiels configurables.
- Données de démonstration cohérentes avec le manuel Achats.

### Interface

- Select2 4.0.13 appliqué aux listes déroulantes de toute l’application.
- DataTables 2.3.8 et Responsive 3.0.8 appliqués aux tableaux de toute l’application.
- Détection des tableaux paginés par Laravel et des tableaux de saisie afin d’éviter une double pagination.
- Réinitialisation des widgets après les mises à jour Livewire.
- Traductions FR/EN/AR, prise en charge RTL, thèmes clair/sombre et styles Tabler/Bootstrap 5.

### Sécurité et intégrité

- Validation croisée société, fournisseur, site, entrepôt, emplacement et taxe.
- Interdiction de soumettre une commande à un fournisseur non approuvé ou sous le minimum de commande.
- Verrouillage transactionnel des quantités demandées, commandées, reçues et retournées.
- Contrôle des conversions d’unité, dates de lot, surlivraisons et retours excédentaires.
- Séparation entre création/édition, approbation achats et comptabilisation de stock.
- Audit des transitions et notifications diffusées seulement après validation des transactions.

### Documentation et tests

- Manuel `docs/modules/10-ACHATS-FOURNISSEURS.md` avec scénario complet reproductible.
- Guide `docs/modules/11-INTERFACE-SELECT2-DATATABLES.md` pour les utilisateurs et développeurs.
- Guide de mise à niveau `docs/UPGRADE_0.7.md`, incluant les commandes Windows et les corrections manuelles conservées.
- Tests des tarifs par palier, permissions, qualification fournisseur, réceptions, retours, stock, lots et qualité.

## [0.6.0] - 2026-07-15

### Ajouté

- Plans de contrôle qualité versionnés, avec périmètre par article, catégorie, ligne et étape.
- Paramètres numériques, booléens ou textuels, limites, cibles, méthodes, séquence et criticité.
- Points critiques HACCP : dangers, limites critiques, surveillance, correction et vérification.
- Contrôles qualité avec résultats par critère et soumission pour décision indépendante.
- Libération, blocage ou rejet des lots avec historique des décisions et audit.
- Non-conformités, analyse de cause, disposition, actions correctives/préventives et vérification d’efficacité.
- Pièces jointes privées et téléchargement soumis à la permission `quality.view`.
- Création automatique des contrôles applicables lors des réceptions et fins de production.
- Tableau de bord qualité, registre des contrôles et registre des non-conformités.
- Exports CSV protégés des contrôles et non-conformités.
- Référentiels qualité configurables et données de démonstration cohérentes avec le manuel.
- Interface française, anglaise et arabe RTL.

### Sécurité et intégrité

- Séparation des permissions de saisie (`quality.update`) et de décision (`quality.approve`).
- Interdiction de libérer un lot lorsqu’un critère critique est non conforme.
- Blocage automatique du lot pour les décisions défavorables et non-conformités majeures/critiques.
- FEFO limité aux lots libérés et non périmés.
- Impossible de contourner le contrôle qualité par un changement manuel de statut du lot lorsqu’un plan approuvé s’applique.
- Clôture d’une non-conformité seulement après analyse, disposition et vérification de toutes les actions.

### Documentation et tests

- Manuel complet `docs/modules/09-QUALITE-HACCP.md` avec exemples reproductibles.
- Guide de mise à niveau `docs/UPGRADE_0.6.md`.
- Tests des permissions, critères critiques, décisions, blocage des lots, CAPA et garde-fou FEFO.

## [0.5.1] - 2026-07-15

### Corrigé

- Compatibilité Laravel 13 avec `laravel/tinker` 3.x.
- Ajout du verrou `composer.lock` pour une installation reproductible.
- Délai Composer porté à 1 800 secondes pour Docker Desktop sous Windows.
- Échappement de la variable PHP du contrôle de santé Reverb dans Docker Compose.
- Création explicite de la clé primaire des catégories avant leur relation parent/enfant sous PostgreSQL.
- Affectation de `stocks.approve` par code dans le seeder des rôles et permissions.

### Validation

- Ajout de tests de régression sur les catégories hiérarchiques et le rôle Magasinier.
- Le script de validation contrôle désormais Composer, le fichier verrou, une migration/initialisation complète et les tests.
- Procédure Windows détaillée avec les correctifs issus du premier démarrage réel.

## [0.5.0] - 2026-07-15

### Ajouté

- Déclaration et chronométrage serveur des arrêts par ligne, machine, cause et impact.
- Ordres de maintenance préventifs, correctifs et inspections.
- Affectation, priorités, planification, démarrage et clôture des interventions.
- Journal des actions, constats, résultats et coûts.
- Consommation FEFO des pièces de rechange avec sortie de stock atomique.
- Génération quotidienne des ordres préventifs sans doublon ouvert.
- Notifications des utilisateurs autorisés après génération du préventif.
- Tableau de bord MTBF, MTTR, disponibilité, pannes, arrêts actifs et échéances.
- Profils Responsable maintenance et Technicien maintenance.
- Données de démonstration : stock de pièces, intervention et arrêt historique.
- Tests des accès, durées, génération préventive et indicateurs.
- Huit fiches de documentation fonctionnelle couvrant tous les modules livrés.

### Sécurité et intégrité

- Permissions serveur sur chaque opération maintenance.
- Calcul des durées, coûts de pièces et changements d’état côté serveur.
- Sorties de pièces et mise à jour des soldes dans une transaction unique.
- Audit des créations, démarrages et clôtures d’intervention.

### Limites connues

- Les contrôles qualité et la sécurité alimentaire constituent la prochaine version métier.
- Les tests Laravel/PostgreSQL doivent être rejoués sur une machine Docker.

## [0.4.0] - 2026-07-15

### Ajouté
- Ordres de fabrication issus de recettes versionnées approuvées.
- Calcul proportionnel des besoins matière.
- Consommations atomiques de lots selon FEFO au démarrage.
- Déclaration des quantités produites, acceptées, rejetées et des pertes.
- Génération du lot de produit fini avec péremption calculée.
- Entrée automatique du produit fini en quarantaine et traçabilité stock/OF.
- Écrans de pilotage et permissions de production.

### Limites connues
- Les contrôles qualité détaillés et la libération automatique sont prévus dans un module ultérieur.

## [0.3.0] - 2026-07-15

### Ajouté

- Tableau de stock par article, lot, entrepôt et emplacement.
- Réceptions, sorties et transferts avec cycle brouillon/comptabilisé.
- Registre `stock_balances` mis à jour atomiquement et verrouillé contre les écritures concurrentes.
- Gestion des lots, fabrication, péremption et changement de statut audité.
- Sélection des lots par ordre FEFO et service d’allocation réutilisable.
- Inventaires avec gel du théorique, comptage à l’aveugle, calcul des écarts et ajustement automatique.
- Alertes de stock minimum et de péremption selon un délai configurable.
- Coût moyen pondéré et conservation du coût pendant les transferts.
- Données de démonstration pour quatre lots et leurs soldes initiaux.
- Tests de permissions, de réception atomique et d’interdiction du stock négatif.
- Guide de mise à niveau `docs/UPGRADE_0.3.md`.

### Sécurité et intégrité

- Validation croisée article/lot, emplacements distincts et quantités positives.
- Interdiction du stock négatif par défaut, contrôlée par paramètre dynamique.
- Permissions séparées pour consulter, créer, modifier et comptabiliser.
- Audit des comptabilisations et changements de statut des lots.

### Limites connues

- Chaque formulaire crée actuellement une ligne de mouvement ; le modèle et le service acceptent déjà plusieurs lignes.
- Les recettes et ordres de fabrication complets seront livrés en v0.4.0.
- Les tests Laravel et Docker doivent être rejoués sur une machine équipée de PHP/Docker.

## [0.2.0] - 2026-07-15

### Ajouté

- Intégration officielle du template Tabler 1.4 avec les icônes Tabler.
- Navigation latérale responsive organisée par modules.
- Mode clair/sombre mémorisé dans le navigateur.
- Interface complète français, arabe RTL et anglais.
- Moteur de CRUD Livewire mutualisé avec recherche, pagination, validation et autorisations serveur.
- Écrans de gestion pour :
  - sociétés, sites, entrepôts et emplacements ;
  - unités, catégories et articles ;
  - lignes de production, machines, équipes et horaires ;
  - utilisateurs, rôles et permissions ;
  - langues, devises, taxes, paramètres et listes de valeurs.
- Modèles Eloquent et relations manquantes pour les référentiels administrables.
- Seeder séparé et rejouable pour les listes de valeurs dynamiques.
- Audit atomique des créations, modifications et suppressions, y compris les rôles et permissions affectés.
- Consultation en lecture seule du journal d’audit.
- Notifications Reverb après changement d’un référentiel.
- Tests fonctionnels des accès et des opérations CRUD principales.
- Script `scripts/validate-release.sh` pour rejouer la validation complète sur la machine cible.
- `package-lock.json` pour des builds frontend reproductibles.

### Sécurité

- Vérification de permission sur chaque page et chaque action CRUD.
- Protection du compte connecté, des rôles système, des valeurs système et de la langue par défaut.
- Blocage explicite des suppressions de données encore référencées.
- Validation des clés étrangères et des contraintes d’unicité côté serveur.

### Modifié

- Tableau de bord et page de connexion adaptés à Tabler.
- Documentation, feuille de route et rapport de validation mis à jour.

### Limites connues

- Les transactions opérationnelles de stock seront livrées en v0.3.0.
- Les recettes et ordres de fabrication complets seront livrés en v0.4.0.
- La construction Docker et les tests PHPUnit doivent être rejoués sur une machine équipée de Docker.

## [0.1.0] - 2026-07-14

### Ajouté

- Socle Laravel 13 avec Blade et Livewire 4.
- Environnement Docker Compose :
  - PHP-FPM ;
  - Nginx ;
  - PostgreSQL ;
  - Redis ;
  - Horizon ;
  - Scheduler ;
  - Laravel Reverb ;
  - Vite ;
  - MinIO ;
  - Mailpit ;
  - Adminer.
- Authentification par session.
- Gestion initiale des rôles et permissions.
- Profils initiaux : administrateur, direction, production, opérateur, magasinier, qualité, commercial, finance et livreur.
- Schéma opérationnel initial pour les lots, mouvements de stock, ordres de fabrication, consommations, sorties et pertes.
- Schéma maintenance initial pour les causes d’arrêt, plans préventifs, ordres d’intervention, arrêts, actions et pièces.
- Listes de valeurs et statuts configurables via `reference_values`.
- Référentiels dynamiques :
  - sociétés ;
  - langues ;
  - devises ;
  - taxes ;
  - sites ;
  - entrepôts et emplacements ;
  - unités ;
  - catégories d’articles ;
  - articles ;
  - lignes de production ;
  - machines ;
  - recettes versionnées ;
  - gammes et étapes de fabrication.
- Données de démonstration pour une ligne, un entrepôt, des matières, un biscuit et une recette.
- Interface trilingue français, arabe et anglais.
- Prise en charge RTL pour l’arabe.
- Premier tableau de bord Livewire.
- Mise à jour temps réel par Reverb avec repli par polling.
- Notifications en base préparées.
- Journal d’audit préparé.
- Documentation technique et fonctionnelle initiale.
- Scripts d’initialisation, de sauvegarde et de restauration.

### Sécurité

- Aucun secret réel inclus dans l’archive.
- Compte administrateur de démonstration configurable via `.env`.
- Accès Horizon limité aux administrateurs en environnement non local.
- Conteneurs et ports documentés.

### Limites connues

- Cette version constitue le socle technique et les référentiels initiaux.
- Les écrans CRUD complets seront ajoutés dans les versions suivantes.
- MinIO est conservé comme service S3 local optionnel ; le stockage Laravel reste interchangeable.
