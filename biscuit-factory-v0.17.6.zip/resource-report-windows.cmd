@echo off
call "%~dp0scripts\windows\resource-report.cmd" %*
exit /b %errorlevel%
