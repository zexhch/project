<?php

use App\Http\Middleware\ApplySecuritySessionPolicy;
use App\Http\Middleware\AttachCorrelationId;
use App\Http\Middleware\EnsureModuleEnabled;
use App\Http\Middleware\EnsurePasswordCurrent;
use App\Http\Middleware\EnsurePermission;
use App\Http\Middleware\EnsureResourceModuleEnabled;
use App\Http\Middleware\SetLocale;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        channels: __DIR__.'/../routes/channels.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->web(prepend: [
            ApplySecuritySessionPolicy::class,
        ]);

        $middleware->web(append: [
            AttachCorrelationId::class,
            SetLocale::class,
            EnsurePasswordCurrent::class,
        ]);

        $middleware->alias([
            'permission' => EnsurePermission::class,
            'module' => EnsureModuleEnabled::class,
            'resource.module' => EnsureResourceModuleEnabled::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })
    ->create();
