# Architecture technique

## Vue d’ensemble

```mermaid
flowchart LR
    U[Utilisateur] --> N[Nginx]
    N --> A[Laravel PHP-FPM]
    N --> R[Laravel Reverb]
    A --> P[(PostgreSQL)]
    A --> D[(Redis)]
    A --> S[Stockage local / S3]
    H[Horizon] --> D
    H --> P
    C[Scheduler] --> A
    V[Vite] --> U
```

## Responsabilités

- **Nginx** : HTTP, fichiers publics et proxy WebSocket.
- **Laravel** : règles métier, sécurité, Blade, Livewire et API futures.
- **Tabler** : design system responsive basé sur Bootstrap 5, compatible RTL.
- **Select2 et DataTables** : recherche dans les listes et tableaux, affichage responsive et intégration Livewire.
- **PostgreSQL** : données transactionnelles et traçabilité.
- **Redis** : cache, sessions techniques, files et diffusion.
- **Horizon** : supervision des traitements asynchrones.
- **Scheduler** : alertes, échéances, maintenance et agrégats.
- **Reverb** : notifications et tableaux de bord temps réel.
- **MinIO/S3** : documents, photos, certificats et pièces jointes.
- **Mailpit** : réception des emails de développement.

## Principes d’architecture

- Modularité métier.
- Référentiels configurables.
- Transactions pour les opérations critiques.
- Journalisation des changements sensibles.
- Événements métier après validation transactionnelle.
- Traitements lourds placés en file.
- Aucun calcul de stock fiable basé uniquement sur une colonne mutable.
- Compatibilité multi-société et multi-site dès le modèle.

## Administration v0.2.0

Les référentiels simples utilisent un composant Livewire mutualisé :

```text
Route protégée
→ MasterDataRegistry (champs, colonnes, module)
→ MasterDataManager (validation et transaction)
→ modèle Eloquent
→ audit_logs
→ DashboardUpdated / Reverb
```

Le registre ne remplace pas les services métier : les flux de stock et de production utilisent des services transactionnels dédiés dans les versions suivantes.

Les sélecteurs métier lisent leurs options dans `reference_values` (`item_type`, `line_status`, `machine_type`, types de sites et d’entrepôts, etc.). Le code ne contient que les valeurs techniques indispensables et les valeurs initiales sont fournies par `ReferenceDataSeeder`.

## Stocks v0.3.0

Les contrôleurs créent des documents en brouillon. `StockPostingService` est l’unique point de comptabilisation : il verrouille le mouvement et les soldes concernés dans une transaction PostgreSQL, contrôle les quantités et met à jour `stock_balances`. `FefoService` répartit une sortie automatique sur les lots libérés les plus proches de leur péremption. `InventoryService` fige un instantané, enregistre le comptage et produit un mouvement d’ajustement auditable.

Les événements temps réel ne sont diffusés qu’après validation de la transaction. Les permissions distinguent consultation, création, modification et comptabilisation.

## Qualité v0.6.0

`QualityInspectionPlanner` recherche les plans approuvés applicables à l’article, sa catégorie, l’étape et la ligne. Il crée sans doublon les contrôles déclenchés par une réception ou une fin de production. `QualityInspectionService` évalue les résultats, verrouille le contrôle et le lot pendant la décision, inscrit l’historique et crée l’écart éventuel dans une même transaction.

`FefoService` et `StockController` constituent un second garde-fou : un lot non libéré, périmé ou soumis à un plan sans décision conforme ne peut pas être consommé ou libéré manuellement. Les documents qualité sont enregistrés sur le disque privé et téléchargés uniquement via une route autorisée.

## Achats v0.7.0

`PurchasePricingService` résout le tarif approuvé applicable par fournisseur, article, unité, date, priorité et palier de quantité. Il calcule les montants HT/TTC, remises et taxes sans faire confiance aux totaux du navigateur.

`PurchasingWorkflowService` porte les transitions sensibles. Il verrouille les documents et quantités, puis délègue toute entrée ou sortie physique à `StockPostingService`. Une réception valide ainsi dans une même transaction la commande, le lot en quarantaine, le mouvement, le solde, le coût moyen et la planification du contrôle qualité. Les événements temps réel et notifications sont différés après le commit.

L’initialisation de Select2 et DataTables est centralisée dans `resources/js/app.js`. Les formulaires et tableaux Blade n’embarquent pas de script propre. Les hooks Livewire et un observateur DOM réappliquent les widgets aux fragments remplacés.

## Ventes v0.8.0

`SalesPricingService` résout les tarifs approuvés selon la spécificité client, groupe, canal ou portée générale, puis la priorité et le palier de quantité. Les calculs HT/TTC et les valeurs appliquées sont figés dans les lignes de devis et de commande.

`StockReservationService` verrouille les soldes éligibles, réserve le disponible par FEFO et maintient séparément quantité physique, quantité réservée, quantité affectée à une livraison et quantité consommée. `SalesWorkflowService` porte les transitions des devis, commandes, livraisons et retours. Une expédition transforme atomiquement les affectations en sorties de stock ; un retour crée un lot distinct en quarantaine et déclenche le plan qualité `CUSTOMER_RETURN`.

Les composants ergonomiques restent centralisés dans `resources/css/app.scss` et `resources/js/app.js`. Les pages métier utilisent divulgation progressive, résumés compacts et actions contextuelles, sans script local.

## Contrôle de gestion v0.9.1

`WorkflowNavigation` centralise la navigation métier et filtre chaque entrée selon les permissions. Les groupes suivent le parcours opérationnel : pilotage, ventes, achats, stocks, production, qualité, maintenance, finance, paramétrage et administration.

`ManagementControlService` calcule les scénarios, actualise les budgets et agrège les marges. Les taux sont historisés par centre de coûts ; les lignes de production et machines peuvent être affectées à un centre. Les budgets réels sont dérivés des calculs de coûts de production et des ordres de maintenance terminés. Les analyses de marge utilisent le dernier coût réel disponible, avec repli explicite sur le coût théorique.

### Domaine Finance et facturation

`BillingController` orchestre les écrans et validations HTTP. `BillingService` porte les transactions de génération, émission, rapprochement, avoir, comptabilisation, annulation, recalcul des soldes et balance âgée. Les documents sources restent dans les domaines Ventes et Achats et sont reliés sans duplication aux factures.

## Modularisation technique v0.12.0

```text
app/Modules/<Domaine>/module.php
→ ModuleRegistry
→ ModuleRouteLoader
→ middleware module:<code>
→ routes et migrations du domaine
```

Les manifestes constituent la source versionnée de la topologie. Le registre persistant conserve uniquement l’état d’exploitation et les empreintes. Les routes de tous les domaines sont enregistrées même lorsque le domaine est désactivé afin que `route:cache` reste stable ; le middleware renvoie 404 avant le contrôleur.

Les migrations métier suivent la même frontière et résident dans le dossier du module. Leur horodatage historique reste global, ce qui conserve l’ordre inter-domaines et la compatibilité avec les bases déjà migrées.

`WorkflowNavigation`, `WorkflowInboxService`, le tableau de bord et les traitements planifiés consultent le même registre. Les ressources administrées par la route générique sont rattachées à leur propriétaire via `MasterDataRegistry::applicationModule`. Les dépendances sont vérifiées avant chaque changement d’état et les opérations sont inscrites dans `audit_logs`.


## Reporting v0.13.0

Le module `reports` lit les tables métier à travers `ReportingService`. Il ne duplique pas les écritures opérationnelles. `ReportCatalog` filtre les rapports selon les permissions et les modules actifs. Les exports immédiats sont diffusés en flux ; les exports programmés sont stockés sur un disque privé et référencés par `report_runs`.

Le dashboard utilise `RoleDashboardService` pour sélectionner une vue adaptée au rôle, sans contourner les permissions effectives. Les programmations sont exécutées par le scheduler avec un verrou distribué par programmation.


## Santé et disponibilité v0.13.1

`SystemHealthService` centralise les contrôles de configuration, base, migrations, cache, stockage, Redis et modules. Les sondes HTTP exposent un résultat minimal en production ; la commande `app:doctor` fournit le diagnostic détaillé aux exploitants.
