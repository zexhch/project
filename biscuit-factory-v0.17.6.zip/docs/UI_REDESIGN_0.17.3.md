# Refonte UX/UI — Biscuit Factory v0.17.3

## Objectif

La v0.17.3 rapproche l'application d'un ERP SaaS industriel moderne sans modifier les règles métier de la v0.17.2. La priorité est donnée à la lisibilité, à la vitesse d'affichage initiale et à la cohérence entre modules.

## Shell applicatif

- barre latérale sombre organisée selon le workflow métier ;
- en-tête compact avec recherche globale, contexte, langue, thème, notifications et utilisateur ;
- navigation responsive avec menu repliable sur mobile ;
- conservation des traductions FR/EN/AR, du RTL et du mode sombre.

## Composants communs

- `x-kpi-card` : indicateur, tendance, progression et lien métier ;
- `x-dashboard-chart` : courbe, barres, barres horizontales ou donut ;
- `x-dashboard-section` : section uniforme pour tâches, alertes et listes ;
- classes `bf-dashboard-grid`, `bf-table-card`, `bf-stat-strip` et `bf-progress-list`.

## Tableaux de bord refondus

### Pilotage

Activité quotidienne, répartition opérationnelle, tâches prioritaires, alertes, activité récente, accès rapides et vue adaptée au rôle.

### Stocks

Quantités totales/réservées/disponibles, valeur, références critiques, péremptions FEFO, mouvements, répartition par catégorie et lots.

### Production

OF planifiés/en cours/terminés, quantités produites et rejetées, taux de réalisation et de qualité, arrêts, charge par ligne et tendance de sortie.

### Ventes

Valeur des commandes, livraisons, facturation, encaissements, factures échues, statuts des commandes et principaux clients.

### Facturation et finance

Créances, dettes, documents non facturés, retard client, taux hors retard, facturation, encaissements et balance âgée.

## Graphiques

Les graphiques sont rendus par le code local dans `resources/js/app.js` sous forme SVG. Aucune donnée n'est envoyée à un service externe et aucune bibliothèque graphique supplémentaire n'est nécessaire.

## Performance

- le menu ne calcule plus l'ensemble des tâches avant de rendre la page ;
- les badges sont chargés après affichage et actualisés toutes les 60 secondes ;
- le workflow et les agrégats de tableaux de bord sont mis en cache pendant 30 secondes ;
- les rôles et permissions sont mémorisés pendant la requête ;
- les notifications et favoris ne déclenchent plus de requêtes dans le rendu initial de l'en-tête.

## Limites de cette corrective

La refonte prioritaire couvre les écrans de pilotage les plus utilisés. Les formulaires et écrans secondaires conservent leur structure métier actuelle, mais bénéficient du nouveau shell et des styles communs. Leur harmonisation détaillée pourra être poursuivie après la recette fonctionnelle.
