# Mise à niveau vers la version 0.13.2

La version 0.13.2 ajoute un parcours complet de déploiement et d'exploitation sous Windows. Elle ne contient aucune nouvelle migration métier.

## Mise à niveau d'une installation existante

1. Sauvegarder la base et `storage/app`.
2. Déployer l'archive v0.13.2 sans remplacer le fichier `.env` existant.
3. Sous Windows, exécuter :

```powershell
.\scripts\windows\init.cmd -NoSeed
```

4. Contrôler la pile :

```powershell
.\healthcheck-windows.cmd
```

Le script applique les éventuelles migrations restantes, synchronise les modules, vide les caches et redémarre les services.

## Nouveaux fichiers principaux

- `install-windows.cmd`
- `healthcheck-windows.cmd`
- `validate-installation-windows.cmd`
- `scripts/windows/common.ps1`
- `scripts/windows/preflight.ps1`
- `scripts/windows/init.ps1`
- `scripts/windows/healthcheck.ps1`
- `scripts/windows/validate-installation.ps1`
- `scripts/windows/validate-release.ps1`
- `scripts/windows/backup.ps1`
- `scripts/windows/restore.ps1`
- `docs/WINDOWS.md`

Aucune donnée existante n'est supprimée sauf utilisation explicite de `-Fresh -ConfirmReset`.
