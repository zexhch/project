# Mise à niveau vers la version 0.5.1

Cette version corrige le premier démarrage Docker/PostgreSQL de la version 0.5.0.

## Mise à niveau

```bash
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-progress
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan migrate --force
docker compose up -d
```

Une installation neuve peut être validée avec :

```bash
docker compose run --rm app php artisan migrate:fresh --seed --force
docker compose run --rm app php artisan test
```

`migrate:fresh` supprime les données et ne doit être utilisé que pour une installation neuve ou une base de test.
