# Mise à niveau vers Biscuit Factory v0.17.6

La v0.17.6 ajoute le diagnostic chronométré du déploiement et corrige plusieurs anomalies d’exploitation détectées pendant la recette Docker Desktop.

## Procédure Windows

1. Sauvegarder la base et les documents.
2. Extraire l’archive v0.17.6 dans un nouveau dossier.
3. Copier le fichier `.env` de la version précédente.
4. Exécuter sans `-Fresh` :

```powershell
.\install-windows.cmd -SlowCommandSeconds 15
.\installation-report-windows.cmd
```

Les données des volumes Docker sont conservées.

## Diagnostic d’un blocage

Les marqueurs sont écrits immédiatement dans `storage/logs/installer`. La dernière commande avec `START` sans terminaison indique précisément l’opération en cours. Le rapport final classe les phases et commandes par durée.

Documentation détaillée : `docs/INSTALLATION_TRACING.md`.

## Corrections complémentaires

- healthcheck Docker Nginx déplacé vers `/nginx-health`, réponse statique indépendante de Laravel et PostgreSQL ;
- attente readiness instrumentée avec progression et timeout individuel de requête porté à 25 secondes ;
- chemin du `ApplicationModuleSeeder` corrigé pour respecter PSR-4 et la casse Linux ;
- création du lien `public/storage` rendue idempotente et silencieuse lorsqu’il existe déjà ;
- capture automatique de `docker compose ps`, `docker stats` et des logs principaux après un échec.
