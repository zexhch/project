# Mise à niveau vers la v0.16.0

## Depuis la v0.15.0

Sauvegarder l’environnement avant toute mise à niveau.

### Windows / Docker Desktop

```powershell
.\scripts\windows\backup.cmd
.\install-windows.cmd
```

### Linux

```bash
bash scripts/backup.sh
bash scripts/init.sh
```

Les scripts exécutent les migrations, la synchronisation des modules, les caches et les contrôles de santé.

## Migration ajoutée

Le module `productivity` crée :

- `data_import_jobs` ;
- `data_import_rows` ;
- `data_export_runs` ;
- `user_workspace_links` ;
- `bulk_operation_runs`.

La migration ne modifie ni ne supprime les données des versions antérieures.

## Après la mise à niveau

```bash
php artisan module:sync
php artisan module:diagnose --fail-on-error
php artisan productivity:prune --days=30
```

Vérifier dans Horizon que le superviseur `supervisor-imports` écoute les files `imports` et `exports`.

## Validation recommandée

1. Télécharger un modèle articles CSV et XLSX.
2. Prévisualiser un fichier contenant une ligne valide et une ligne invalide.
3. Confirmer un import valide et vérifier la notification finale.
4. Exporter les articles en CSV et XLSX.
5. Dupliquer un devis et vérifier le nouveau numéro et le statut brouillon.
6. Exécuter une action groupée sur un article de test.
7. Tester la recherche globale et un favori.

Sous Windows Docker Desktop :

```powershell
.\validate-installation-windows.cmd -ConfirmReset
```

Cette commande est destructive pour les volumes de l’environnement de test.
