# Feuille de route

## 0.1.0 — Socle

- Docker.
- Laravel, Blade et Livewire.
- PostgreSQL et Redis.
- Reverb, Horizon et Scheduler.
- Authentification.
- Rôles et permissions.
- Référentiels de départ.
- Schéma initial production, stock et maintenance.
- Documentation.

## 0.2.0 — Administration et référentiels — livré

- Interface Tabler responsive, mode sombre et RTL.
- CRUD sociétés, sites, entrepôts, emplacements et paramètres.
- CRUD utilisateurs, rôles et permissions.
- CRUD langues, devises, taxes et listes de valeurs.
- CRUD articles, unités et catégories.
- CRUD lignes, machines et équipes.
- Audit atomique et autorisations par action.

## 0.3.0 — Stocks et lots — livré

- Réceptions.
- Mouvements.
- Transferts.
- Inventaires.
- FEFO.
- Alertes.
- Comptabilisation atomique, contrôle du stock négatif et coût moyen.

## 0.4.0 — Recettes et production — livré

- Recettes versionnées.
- Gammes.
- Ordres de fabrication.
- Consommations et sorties.
- Lots de produits finis.
- Pertes.

## 0.5.0 — Arrêts et maintenance — livré

- Chronométrage des arrêts.
- Préventif et correctif.
- Ordres d’intervention.
- Pièces de rechange.
- MTBF, MTTR et disponibilité.
- Plans préventifs, actions, pièces, coûts et notifications.
- Documentation dédiée de tous les modules livrés.

## 0.5.1 — Stabilisation Docker/PostgreSQL — livré

- Compatibilité Laravel 13/Tinker 3.
- Installation Composer verrouillée et adaptée à Docker Desktop.
- Correctifs PostgreSQL des catégories hiérarchiques.
- Correctifs des rôles et permissions lors du seeding.
- Tests de régression d'installation.

## 0.6.0 — Qualité et sécurité alimentaire — livré

- Plans de contrôle versionnés et paramètres mesurables.
- Points critiques HACCP et surveillance.
- Contrôles de réception, de fabrication, de produit fini et de stockage.
- Décisions de libération, blocage et rejet des lots.
- Non-conformités, analyse de cause et actions CAPA.
- Pièces jointes privées, audit, alertes et permissions dédiées.
- Garde qualité intégré à FEFO, aux réceptions et à la production.
- Documentation avec exemples reproductibles.

## 0.7.0 — Achats et ergonomie des données — livré

- Fournisseurs, contacts, articles fournisseur et évaluations.
- Demandes d’achat, consultations et sélection d’offre.
- Tarifs d’achat avec périodes, priorités et paliers.
- Commandes d’achat, approbation et suivi des reliquats.
- Réceptions partielles, lots en quarantaine et contrôles qualité automatiques.
- Retours fournisseurs et mouvements de stock atomiques.
- Select2 et DataTables dans toute l’application, avec Livewire, RTL et thèmes.
- Documentation avec exemples reproductibles.

## 0.8.0 — Ventes, livraisons et ergonomie — livré

- Clients, contacts, groupes, canaux et qualification commerciale.
- Tarifs de vente par client, groupe ou canal, périodes, priorités et paliers.
- Devis, acceptation et conversion en commande.
- Commandes clients avec confirmation et réservation atomique FEFO.
- Livraisons totales ou partielles, affectation des lots et sorties de stock.
- Traçabilité lot → livraison → client.
- Retours clients en quarantaine et contrôle qualité automatique.
- Parcours visuels allégés, actions contextuelles et options avancées repliables.
- Documentation et données de démonstration reproductibles.

## 0.9.0 — Recettes et cœur du prix de revient — livré

- Interface complète des recettes et de leurs versions.
- Composition matières, emballages et semi-finis avec unités et pertes prévues.
- Rendement, validité, gamme, duplication, approbation et gel des versions utilisées.
- Coûts théoriques depuis les recettes et gammes.
- Coûts réels depuis les consommations, temps, pertes et productions conformes.
- Matières, emballages, main-d’œuvre, machines, énergie et frais indirects configurables.
- Historique des calculs, valorisation du lot fini et analyse de l’écart standard/réel.
- Sélection FEFO multi-emplacements dans l’entrepôt de production.

## 0.9.1 — Contrôle de gestion avancé — livré

- Centres de coûts et taux horaires historisés.
- Simulations multi-scénarios sans modifier la recette approuvée.
- Budgets de production et analyse des écarts par période, ligne et centre.
- Marges par article, client et commande à partir des tarifs réellement appliqués.

## 0.10.0 — Facturation et règlements — livré

- Factures clients générées depuis les livraisons comptabilisées.
- Avoirs, échéances, relances et balance âgée des clients.
- Règlements clients complets ou partiels : une facture peut recevoir plusieurs règlements successifs.
- Affectation détaillée des règlements : un règlement peut solder une ou plusieurs factures et chaque facture conserve le détail de ses affectations.
- Solde restant calculé à partir du total de la facture, des avoirs et des affectations de règlements validées.
- Statuts distincts `ISSUED`, `PARTIALLY_PAID`, `PAID` et `OVERDUE`, sans modifier le montant historique de la facture.
- Annulation d’un règlement par contre-écriture auditée ; aucun règlement comptabilisé ne sera supprimé silencieusement.
- Devises, dates de valeur, modes de règlement, références bancaires, caisse et rapprochement.
- Factures fournisseurs et rapprochement commande/réception/facture.

## 0.10.1 — Stabilisation facturation — livré

- Rafraîchissement automatique des échéances.
- Audit du grand livre auxiliaire et réparation contrôlée des valeurs dérivées.
- Verrouillage déterministe des règlements et protections multi-sociétés.
- Index et contraintes complémentaires PostgreSQL.
- Tests de régression et validation de release renforcée.

## 0.11.0 — Workflow et ergonomie avancés — livré

- Tableau « Mes tâches » dérivé des documents et validations en attente.
- Actions « Étape suivante » et timeline unifiée des documents.
- Notifications, compteurs métier et rafraîchissement temps réel/polling.
- Alertes opérationnelles et financières consolidées.
- Report, masquage réversible et centre de notifications.

## 0.12.0 — Modularisation technique — livré

- Activation et désactivation contrôlée des domaines métier.
- Manifestes, routes, navigation, permissions et migrations regroupés par module ; services métier conservés dans leurs espaces de domaine.
- Dépendances explicites entre Ventes, Achats, Stocks, Production, Qualité, Maintenance et Finance.
- Écran d’administration et diagnostics des modules.

## 0.13.0 — Tableaux de bord et rapports avancés — livré

- Tableaux de bord adaptés aux rôles et permissions.
- Rapports ventes, achats, production, stocks, qualité, maintenance et finance.
- Filtres multi-société/site/période, exports CSV et vues imprimables.
- Rapports programmés, fichiers privés, historique et notifications.

## 0.13.1 — Stabilisation du déploiement — livré

- Sondes liveness/readiness.
- Diagnostic `app:doctor`.
- Validation statique sans Docker et pré-contrôle de l’environnement.
- Installation initiale idempotente et validation destructive explicite.
- Contrôles de santé des services et tests de régression associés.

## 0.13.2 — Déploiement Windows — livré

- Installation et mise à niveau pilotées par PowerShell 5.1/7.
- Lanceurs CMD sans modification permanente de la stratégie d’exécution.
- Précontrôle Docker Desktop, moteur Linux, ports, disque et secrets.
- Healthcheck et validation destructive complète sous Windows.
- Sauvegarde et restauration PostgreSQL/documentaire sécurisées.
- Documentation Windows et guide de mise à niveau dédiés.

## 0.14.0 — Sécurité et exploitation — livré

- Politique de mots de passe configurable, verrouillage et changement forcé.
- Sessions actives et révocation ciblée.
- Sauvegardes planifiées PostgreSQL et fichiers privés.
- Journal d’audit renforcé, corrélation et rétention.
- Page de supervision technique et instantanés de santé.
- Scripts d’audit de sécurité Windows et Linux.

## 0.15.0 — Gouvernance financière et documentaire — livré

- Périodes comptables, clôtures et réouvertures contrôlées.
- Numérotation légale configurable par société et type de document.
- Approbations multi-niveaux des factures avec seuils, rôles, permissions et quorum.
- Annulations et contre-documents auditables.
- Modèles imprimables FR/EN/AR et historique immuable des versions.

## 0.16.0 — Imports, exports et productivité — livré

- Imports CSV/XLSX des articles, clients et fournisseurs avec prévisualisation.
- Modèles téléchargeables, rapports d’erreurs et traitements Horizon dédiés.
- Exports privés CSV/XLSX et rétention planifiée.
- Actions groupées auditées, duplication contrôlée et nouvelle numérotation.
- Recherche globale, favoris et raccourcis personnels.

## 0.17.0 — Planification industrielle avancée — livré

- Plan directeur depuis les commandes clients et calcul chronologique des besoins nets.
- MRP des recettes, pénuries matières, réceptions prévues et stock de sécurité.
- Capacités produit/ligne, équipes, maintenance, changements de série et ordonnancement.
- Scénarios de charge, approbation et génération des ordres de fabrication.
- TRS/OEE historisé par ligne et période.

## 0.17.1 — Documents légaux et identité commerciale — corrective MVP

- Identité légale complète des sociétés, clients et fournisseurs : RC, NIF, NIS et AI.
- Logo, activité, coordonnées bancaires et compte bancaire configurables par société.
- Factures et bons de livraison A4 enrichis, avec prix HT paramétrables sur les BL.
- TVA, totaux HT/TTC, montant en lettres, cachet et signature.
- Données légales intégrées aux imports/exports, à la recherche globale et aux données de démonstration.

## 0.17.2 — Conditionnements, images et aide contextuelle — corrective MVP

- Hiérarchie dynamique des unités et conditionnements par article.
- Conversions figées sur les documents et utilisées par les flux métier.
- Images PNG principales et galeries normalisées par code article.
- Import/export des conditionnements et import groupé d’images.
- Tooltips accessibles et glossaire FR/EN/AR centralisé.

## 0.17.3 — Refonte UX/UI et performance — corrective MVP

- Shell global moderne et composants visuels réutilisables.
- Tableaux de bord principal, Stocks, Production, Ventes et Finance enrichis.
- Graphiques SVG natifs sans dépendance frontend supplémentaire.
- Chargement asynchrone des badges et cache court des indicateurs.
- Responsive, mode sombre, RTL et accessibilité clavier conservés.

## 0.17.4 — Stabilisation Docker Desktop — corrective MVP

- Corrections Qualité intégrées dans le code source.
- Healthchecks Horizon et Reverb consolidés pour Docker Desktop.
- Pool PHP-FPM renforcé et artefacts runtime exclus du build.
- Durées d’arrêt Carbon converties de manière déterministe.
- Tests et validation statique des correctifs de recette.

## 0.17.6 — Diagnostic chronométré du déploiement — corrective MVP

- marqueurs immédiats par phase et commande ;
- rapport des opérations lentes et journal complet ;
- capture automatique après échec ;
- healthcheck Nginx statique ;
- conformité PSR-4 Linux et lien storage idempotent.

## 0.17.5 — Allocation des ressources Docker — corrective MVP

- CPU, mémoire, réservations et PID plafonnés par service.
- PostgreSQL, Redis, Horizon et OPcache dimensionnés selon leur rôle.
- Variables de réglage centralisées dans `.env`.
- Rapport de consommation et alertes de capacité Docker Desktop.

## Versions ultérieures

- 0.18.0 : traçabilité, conformité, allergènes et gestion documentaire qualité.
- 0.19.0 : API, webhooks et intégrations.
- 0.20.0 : performance, PWA et mobilité atelier.
- 1.0.0-RC1 : stabilisation complète et préparation production.

