# Mise à niveau vers la v0.17.0

La v0.17.0 ajoute le module **Planification industrielle**.

## Windows / Docker Desktop

```powershell
.\install-windows.cmd

docker compose exec app php artisan migrate --force
docker compose exec app php artisan module:sync
docker compose exec app php artisan db:seed --class=RolePermissionSeeder --force
docker compose exec app php artisan optimize:clear
```

## Linux

```bash
docker compose up -d --build
docker compose exec app php artisan migrate --force
docker compose exec app php artisan module:sync
docker compose exec app php artisan db:seed --class=RolePermissionSeeder --force
docker compose exec app php artisan optimize:clear
```

## Vérifications

- Ouvrir **Production → Planification industrielle**.
- Confirmer au moins une commande client puis créer un plan couvrant sa date de livraison.
- Calculer les besoins et vérifier les onglets demandes, matières, capacité et conflits.
- Approuver uniquement un plan sans conflit critique, puis générer les ordres de fabrication.
- Calculer le TRS/OEE dans l’écran dédié.

## Compatibilité

La migration est cumulative : une installation neuve peut déployer directement la v0.17.0. La mise à niveau conserve les OF, stocks, recettes et documents existants.
