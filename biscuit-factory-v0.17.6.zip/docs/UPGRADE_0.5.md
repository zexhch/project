# Mise à niveau vers la v0.5.0

## Sauvegarde

Exécuter `make backup`, vérifier l’archive et conserver l’ancienne application avec son `.env`.

## Installation

Extraire la v0.5.0 dans un nouveau dossier, recopier uniquement `.env`, puis :

```bash
docker compose build
docker compose up -d postgres redis
docker compose run --rm app composer install
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --force
docker compose up -d
```

Le seeder est rejouable : il complète les statuts, paramètres, rôles et données de démonstration sans supprimer les données existantes.

## Scheduler

Vérifier que le service `scheduler` est actif. La commande suivante doit fonctionner :

```bash
docker compose exec app php artisan maintenance:generate-orders
```

## Validation

```bash
bash scripts/validate-release.sh
```

Tester ensuite un arrêt court, une intervention et la consommation d’une pièce. Le retour arrière consiste à redémarrer l’ancienne version puis restaurer la sauvegarde vérifiée.
