# Déploiement et tests sous Windows

## Environnement pris en charge

- Windows 10 ou Windows 11 64 bits.
- Docker Desktop avec le moteur WSL 2.
- Conteneurs Linux activés dans Docker Desktop.
- Windows PowerShell 5.1 ou PowerShell 7.
- Au moins 4 Gio de mémoire attribués à Docker Desktop.
- Projet placé de préférence dans un dossier local comme `C:\Projects\biscuit-factory`, hors lecteur réseau.

Aucune installation locale de PHP, Composer, Node.js ou PostgreSQL n'est requise.

## Installation simple

Depuis PowerShell ou l'invite de commandes :

```powershell
Expand-Archive .\biscuit-factory-v0.17.6.zip -DestinationPath C:\Projects\biscuit-factory-v0.17.6
Set-Location C:\Projects\biscuit-factory-v0.17.6
.\install-windows.cmd
```

Le lanceur choisit automatiquement PowerShell 7 (`pwsh.exe`) lorsqu'il est installé, sinon Windows PowerShell 5.1. Il applique `ExecutionPolicy Bypass` uniquement au processus courant et ne modifie pas la stratégie globale de Windows.

## Options d'installation

Installation sans données de démonstration :

```powershell
.\install-windows.cmd -NoSeed
```

Installation sans contrôle de santé final :

```powershell
.\install-windows.cmd -SkipHealthcheck
```

Marquer comme lente toute commande dépassant 15 secondes :

```powershell
.\install-windows.cmd -SlowCommandSeconds 15
```

Après l'installation, afficher le classement des phases et commandes :

```powershell
.\installation-report-windows.cmd
```

Les marqueurs, chronométrages et transcriptions sont conservés dans `storage/logs/installer`. Voir `docs/INSTALLATION_TRACING.md`.

Réinitialisation complète de l'environnement de test :

```powershell
.\install-windows.cmd -Fresh -ConfirmReset
```

`-Fresh` supprime les volumes PostgreSQL, Redis, MinIO et Mailpit du projet. Ne jamais l'utiliser sur un environnement contenant des données à conserver.

## Scripts disponibles

| Action | Commande Windows |
|---|---|
| Précontrôle Docker Desktop | `.\scripts\windows\preflight.cmd` |
| Installation ou mise à niveau | `.\scripts\windows\init.cmd` |
| Rapport de la dernière installation | `.\installation-report-windows.cmd` |
| Contrôle de santé | `.\healthcheck-windows.cmd` |
| Validation statique | `powershell -ExecutionPolicy Bypass -File .\scripts\windows\validate-static.ps1` |
| Validation complète de release | `.\scripts\windows\validate-release.cmd` |
| Réinstallation et tests destructifs | `.\validate-installation-windows.cmd -ConfirmReset` |
| Sauvegarde | `.\scripts\windows\backup.cmd` |
| Restauration | `.\scripts\windows\restore.cmd ...` |

## Validation complète de l'installation neuve

À exécuter uniquement sur le Docker de test :

```powershell
.\validate-installation-windows.cmd -ConfirmReset
```

Cette commande :

1. supprime les volumes du projet ;
2. reconstruit l'image PHP ;
3. installe les dépendances Composer ;
4. exécute toutes les migrations et les seeders ;
5. compile les assets avec `npm ci` ;
6. lance les tests Laravel ;
7. contrôle les modules, la finance, le workflow et le reporting ;
8. lance Pint et les sondes de santé.

## Sauvegarde sous Windows

```powershell
.\scripts\windows\backup.cmd
```

Les fichiers sont créés dans `backups` :

- `database_YYYYMMDD_HHMMSS.dump` ;
- `storage_YYYYMMDD_HHMMSS.tar.gz` ;
- `backup_YYYYMMDD_HHMMSS.sha256`.

Un autre dossier peut être indiqué :

```powershell
.\scripts\windows\backup.cmd -BackupDirectory D:\Backups\BiscuitFactory
```

Le dump PostgreSQL est écrit dans le conteneur puis copié avec `docker cp`. Cette méthode évite la corruption binaire que peut provoquer une redirection `>` dans Windows PowerShell 5.1.

## Restauration sous Windows

```powershell
.\scripts\windows\restore.cmd `
  -DatabaseDump .\backups\database_20260716_220000.dump `
  -StorageArchive .\backups\storage_20260716_220000.tar.gz `
  -ConfirmRestore
```

La restauration vérifie les empreintes disponibles, place l’application en maintenance, arrête les traitements asynchrones, restaure PostgreSQL de façon atomique, invalide les sessions, synchronise les modules puis lance le contrôle de santé. Une archive ZIP téléchargée depuis l’application peut être restaurée directement avec `-DatabaseDump` et son empreinte via `-ExpectedSha256`.

## Accès après démarrage

| Service | URL |
|---|---|
| Application | http://localhost:8080 |
| Mailpit | http://localhost:8025 |
| Adminer | http://localhost:8082 |
| MinIO | http://localhost:9001 |
| Vite | http://localhost:5173 |

## Dépannage Windows

### Docker Desktop n'est pas démarré

Le précontrôle affiche une erreur sur `docker version`. Démarrer Docker Desktop et attendre que l'état « Engine running » soit visible.

### Docker utilise les conteneurs Windows

Les images du projet sont Linux. Dans le menu Docker Desktop, sélectionner **Switch to Linux containers** si cette option apparaît.

### Un port est déjà utilisé

Le précontrôle signale les ports occupés. Identifier le processus :

```powershell
Get-NetTCPConnection -State Listen | Where-Object LocalPort -in 8080,5173,5433,8025,8082,9000,9001
```

Arrêter l'ancienne pile avec :

```powershell
docker compose down
```

### Le montage du projet est lent

Avec le moteur WSL 2, les performances sont généralement meilleures lorsque le projet se trouve dans le système de fichiers WSL. Pour un premier test, un dossier local `C:\Projects` reste compatible et plus simple à manipuler.

### Les scripts `.ps1` sont bloqués

Utiliser les fichiers `.cmd`, qui démarrent PowerShell avec une stratégie limitée au processus :

```powershell
.\install-windows.cmd
```

Aucune modification permanente de `Set-ExecutionPolicy` n'est nécessaire.

## Audit de sécurité v0.14.0

Après l’installation ou une modification de `.env` :

```powershell
.\security-audit-windows.cmd
```

Pour une sortie JSON exploitable par un outil de supervision :

```powershell
.\security-audit-windows.cmd -Json
```

La v0.14.0 reconstruit l’image PHP avec `postgresql-client-17`, aligné sur le serveur PostgreSQL 17 utilisé par Docker Compose. Cet alignement est contrôlé avant chaque sauvegarde planifiée.
