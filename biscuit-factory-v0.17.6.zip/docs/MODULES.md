# Modules fonctionnels

## Modules du produit cible

1. Administration et sécurité.
2. Paramétrage de la société.
3. Articles, unités et conversions.
4. Fournisseurs et achats.
5. Stocks, lots et inventaires.
6. Recettes et gammes.
7. Planification de production.
8. Exécution de production.
9. Lignes, machines et équipes.
10. Arrêts et maintenance.
11. Qualité et sécurité alimentaire.
12. Conditionnement.
13. Clients, ventes et livraisons.
14. Facturation et règlements, avec échéances, avoirs, règlements partiels, affectations et soldes clients.
15. Coûts de revient et contrôle de gestion.
16. Ressources humaines opérationnelles.
17. Notifications et tableaux de bord.
18. Audit, documents et reporting.

## État de la version 0.14.0

- Socle technique : disponible.
- Authentification : disponible.
- Rôles, permissions et utilisateurs : écrans CRUD disponibles.
- Référentiels : écrans CRUD, recherche, pagination et validation disponibles.
- Organisation : sociétés, sites, entrepôts et emplacements administrables.
- Catalogue : unités, catégories et articles administrables.
- Ressources de production : lignes, machines et équipes administrables.
- Paramètres : langues, devises, taxes, paramètres et listes de valeurs administrables.
- Dashboard : indicateurs opérationnels et tâches prioritaires disponibles.
- Temps réel : Reverb/WebSocket actif pour le dashboard et la boîte de travail, avec repli par polling.
- Audit : créations, modifications et suppressions enregistrées atomiquement et consultables en lecture seule.
- Stocks et lots : réceptions, sorties, transferts, lots, FEFO et alertes disponibles.
- Inventaires : gel du stock, comptage à l’aveugle, écarts et ajustements disponibles.
- Recettes : écrans complets de création, versionnement, duplication, composition, rendement, gamme et approbation disponibles.
- Production : besoins avec pertes prévues, consommations FEFO multi-emplacements, lots finis et pertes disponibles.
- Prix de revient : calculs théoriques et réels, charges configurables, valorisation du lot fini, historique et écarts disponibles.
- Contrôle de gestion : centres de coûts, taux historisés, simulations, budgets, écarts et marges par client/produit disponibles.
- Maintenance : arrêts, préventif/correctif, interventions, pièces, coûts et indicateurs disponibles.
- Qualité : plans de contrôle, HACCP, inspections, décisions sur les lots et pièces jointes disponibles.
- Non-conformités : analyse de cause, disposition, actions CAPA, vérification et clôture disponibles.
- Achats : fournisseurs, demandes, offres, tarifs, commandes, réceptions et retours disponibles.
- Ventes : clients, tarifs, devis, commandes, réservations FEFO, livraisons partielles et retours disponibles.
- Facturation clients : génération depuis livraison, émission, échéances, avoirs, relances et balance âgée disponibles.
- Facturation fournisseurs : saisie depuis réception, rapprochement commande/réception/facture et avoirs disponibles.
- Règlements : paiements partiels ou complets, ventilation multi-factures, comptes de trésorerie et annulation auditée disponibles.
- Stabilisation financière : échéances rafraîchies automatiquement, audit du grand livre auxiliaire, réparation contrôlée et verrouillage déterministe disponibles.
- Workflow guidé : Mes tâches, alertes consolidées, étapes suivantes, timelines, notifications et compteurs de navigation disponibles.
- Modularisation : manifestes par domaine, routes séparées, dépendances, activation/désactivation, gardes d’accès, écran d’administration et diagnostics disponibles.
- Reporting : huit rapports transverses, dashboards par rôle, filtres multi-société/site, exports et programmations disponibles.
- Sécurité et exploitation : politique de mots de passe, verrouillage, sessions révocables, supervision, sauvegardes planifiées et rétention disponibles.
- Ergonomie : Select2 et DataTables appliqués globalement, avec parcours allégés, divulgation progressive, responsive et RTL.
- Documentation fonctionnelle : une fiche détaillée par module dans `docs/modules/`.
- Transactions complètes : ajoutées progressivement par module.
