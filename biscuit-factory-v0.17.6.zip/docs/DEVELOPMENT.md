# Développement

## Principes

- Une fonctionnalité métier doit inclure migration, modèle, autorisation, service, interface, tests et documentation.
- Les contrôleurs restent fins.
- Les transactions sont portées par des services métier.
- Les événements sont émis après validation des transactions.
- Les traitements longs passent par Horizon.
- Les nombres monétaires ne doivent pas être calculés avec des flottants.
- Les listes déroulantes utilisent `form-select` et sont enrichies automatiquement par Select2.
- Les tableaux utilisent `table` et déclarent leur mode DataTables uniquement si la détection automatique ne convient pas.

## Qualité

```bash
docker compose exec app vendor/bin/pint --test
docker compose exec app php artisan test
```

## Versionnement

Chaque livraison modifie :

- `VERSION`
- `CHANGELOG.md`
- documentation impactée
- archive complète

## Migrations

Une migration déjà livrée ne doit pas être réécrite après utilisation en environnement partagé. Une nouvelle migration corrective doit être créée.

## Ajouter un référentiel simple

1. créer ou compléter le modèle Eloquent et ses relations ;
2. déclarer la ressource dans `app/Support/MasterDataRegistry.php` ;
3. associer la ressource à un module de permissions ;
4. ajouter les traductions dans `lang/{fr,en,ar}/admin.php` ;
5. ajouter les tests d’accès, validation et persistance.

Les flux transactionnels complexes ne doivent pas être ajoutés au registre générique.

## Select2 et DataTables

Ne pas initialiser localement jQuery, Select2 ou DataTables dans une vue. L’initialisation globale se trouve dans `resources/js/app.js` et couvre les fragments Livewire.

Pour exclure exceptionnellement un composant :

```html
<select class="form-select" data-select2="false"></select>
<table class="table" data-datatable="false"></table>
```

Pour un tableau paginé côté Laravel, utiliser `data-datatable-mode="server-rendered"`. Pour un tableau contenant des champs de saisie, utiliser `data-datatable-mode="form"`. Voir `docs/modules/11-INTERFACE-SELECT2-DATATABLES.md`.
