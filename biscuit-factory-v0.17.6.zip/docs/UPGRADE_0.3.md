# Mise à niveau de la v0.2.0 vers la v0.3.0

## Avant la mise à niveau

Créer et vérifier une sauvegarde complète avec `make backup`. Conserver l’archive v0.2.0 et son fichier `.env` jusqu’à validation de la nouvelle version.

## Installation

Extraire la v0.3.0 dans un nouveau dossier et recopier uniquement le `.env` de l’installation précédente. Ne pas recopier `vendor`, `node_modules` ou `public/build`.

```bash
docker compose build
docker compose up -d postgres redis
docker compose run --rm app composer install
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --force
docker compose up -d
```

La migration ajoute le registre `stock_balances`, les inventaires et leurs lignes. Le seeder complète les statuts configurables, les permissions et le paramètre `stock.expiry_alert_days` sans supprimer les données existantes.

## Validation

```bash
bash scripts/validate-release.sh
```

Vérifier ensuite qu’une réception en brouillon peut être comptabilisée, qu’une sortie supérieure au disponible est refusée et que l’écran Stocks affiche les soldes attendus.

## Retour arrière

Arrêter la v0.3.0, redémarrer la v0.2.0 avec son `.env`, puis restaurer la sauvegarde. Ne pas lancer de rollback de migration sur une base de production sans sauvegarde validée.
