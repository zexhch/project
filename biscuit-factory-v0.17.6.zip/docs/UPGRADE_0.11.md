# Mise à niveau vers la v0.11.0

## Prérequis

La base doit être en v0.10.1 et la sauvegarde de la base et du stockage doit être vérifiée.

## Installation

```bash
unzip biscuit-factory-v0.11.0.zip
cp .env.example .env   # uniquement pour une nouvelle installation
composer install --no-dev --optimize-autoloader
npm ci --no-audit --no-fund
npm run build
php artisan migrate --force
php artisan optimize:clear
php artisan optimize
```

Redémarrer ensuite l’application, Horizon, Reverb et le scheduler.

## Contrôles

```bash
php artisan test
php artisan workflow:notify-alerts
php artisan finance:refresh-overdue
php artisan finance:audit-ledger --fail-on-error
```

Vérifier avec plusieurs rôles : accès à **Mes tâches**, compteurs, report/masquage, étape suivante, timeline, lecture des notifications et actualisation temps réel.

## Retour arrière

Arrêter les workers, restaurer la sauvegarde puis redéployer la v0.10.1. Un `migrate:rollback --step=1` supprime uniquement `workflow_events` et `workflow_task_preferences`, mais la restauration complète reste la procédure recommandée.
