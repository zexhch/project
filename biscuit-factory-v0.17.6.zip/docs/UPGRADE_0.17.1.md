# Mise à niveau vers Biscuit Factory v0.17.1

La v0.17.1 est une corrective cumulative construite sur la v0.17.0. Elle ajoute les informations légales et bancaires, le logo société et les nouveaux modèles d’impression facture/bon de livraison.

## Avant la mise à niveau

1. Sauvegarder PostgreSQL et `storage/app`.
2. Conserver le fichier `.env` de l’installation.
3. Ne pas exécuter `docker compose down -v` sur une installation contenant des données à conserver.

## Windows / Docker Desktop

Extraire la v0.17.1 dans un nouveau dossier, recopier le `.env`, puis exécuter :

```powershell
.\install-windows.cmd
```

Contrôler ensuite :

```powershell
.\healthcheck-windows.cmd
docker compose exec app php artisan app:doctor
docker compose exec app php artisan test --filter=LegalDocumentPrintingTest
```

## Linux

```bash
cp /chemin/ancienne-version/.env .env
bash scripts/init.sh
bash scripts/healthcheck.sh
docker compose exec app php artisan test --filter=LegalDocumentPrintingTest
```

## Migrations ajoutées

- informations légales et bancaires des sociétés ;
- NIS et AI des clients ;
- NIS et AI des fournisseurs ;
- options d’impression des modèles documentaires.

Les migrations sont non destructives et conservent les données existantes.

## Configuration après migration

1. Compléter la société dans **Paramétrage → Sociétés**.
2. Téléverser le logo.
3. Compléter RC/NIF/NIS/AI sur les clients et fournisseurs.
4. Vérifier le modèle `BON DE LIVRAISON` dans **Finance → Gouvernance**.
5. Imprimer un BL et une facture de test.

## Retour arrière

Restaurer la sauvegarde réalisée avant mise à niveau. Ne pas utiliser uniquement `migrate:rollback` si des documents ont déjà été créés ou modifiés avec les nouveaux champs.
