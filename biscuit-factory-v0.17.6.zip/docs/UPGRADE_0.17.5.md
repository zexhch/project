# Mise à niveau vers Biscuit Factory v0.17.5

La v0.17.5 optimise l’allocation des ressources entre les services Docker sans modifier les données métier.

## Procédure Windows

1. Sauvegarder la base et les documents de la version précédente.
2. Extraire l’archive v0.17.5 dans un nouveau dossier local.
3. Copier l’ancien fichier `.env` dans ce dossier.
4. Les nouvelles variables de ressources sont facultatives : les valeurs par défaut de `compose.yaml` s’appliquent lorsqu’elles sont absentes.
5. Exécuter :

```powershell
.\install-windows.cmd
.\resource-report-windows.cmd
```

Ne pas utiliser `-Fresh` pour conserver les volumes existants.

## Docker Desktop

Attribuer idéalement au moteur Linux au moins 4 vCPU et 6 à 8 Gio de mémoire. Le précontrôle émet désormais un avertissement lorsque la capacité est inférieure.

## Points techniques

- limites CPU, mémoire, réservation et PID par service ;
- PostgreSQL ajusté à la mémoire du conteneur ;
- Redis plafonné sans éviction silencieuse ;
- processus Horizon configurables par environnement ;
- OPcache production optimisé ;
- rapport de consommation Windows/Linux.
