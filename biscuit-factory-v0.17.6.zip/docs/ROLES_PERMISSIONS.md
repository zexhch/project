# Rôles et permissions

## Rôles initiaux

| Code | Profil |
|---|---|
| `ADMINISTRATOR` | Administrateur |
| `MANAGEMENT` | Direction / Gérant |
| `PRODUCTION_MANAGER` | Responsable production |
| `PRODUCTION_OPERATOR` | Opérateur de production |
| `PURCHASING_MANAGER` | Responsable achats |
| `BUYER` | Acheteur |
| `WAREHOUSE_KEEPER` | Magasinier |
| `MAINTENANCE_MANAGER` | Responsable maintenance |
| `MAINTENANCE_TECHNICIAN` | Technicien maintenance |
| `QUALITY_MANAGER` | Responsable qualité |
| `SALES_MANAGER` | Responsable commercial |
| `SALES` | Commercial |
| `FINANCE` | Comptable / Finance |
| `DELIVERY_DRIVER` | Livreur |

## Modèle

Les permissions suivent la convention :

```text
module.action
```

Exemples :

```text
production.view
production.create
production.update
production.approve
maintenance.export
```

Un utilisateur peut cumuler plusieurs rôles. Les rôles système sont fournis par défaut, mais le modèle permet d’ajouter d’autres rôles.

Depuis la v0.2.0, les utilisateurs, rôles et permissions sont administrables dans l’interface. Les rôles système peuvent être renommés et leurs permissions adaptées, mais leur code technique et leur statut système sont protégés. Le compte connecté ne peut pas se désactiver, supprimer son propre compte ni retirer ses propres rôles.

## Principe de moindre privilège

Chaque écran et chaque action sensible doit vérifier une permission serveur. Le masquage d’un bouton dans Blade ne constitue jamais une sécurité suffisante.

Le composant d’administration contrôle séparément `view`, `create`, `update` et `delete` pour le module concerné.

Le module Qualité sépare particulièrement :

- `quality.create` : création d’un plan, point HACCP, contrôle ou écart ;
- `quality.update` : saisie des mesures, analyses et actions ;
- `quality.approve` : approbation du plan, décision sur le lot, vérification d’efficacité et clôture ;
- `quality.export` : extraction des registres.

Cette séparation permet de confier la mesure à un contrôleur tout en réservant la libération d’un lot au responsable qualité.

Le module Achats sépare également :

- `purchasing.create` et `purchasing.update` pour préparer les documents ;
- `purchasing.approve` pour qualifier un fournisseur, approuver une demande, un tarif ou une commande et retenir une offre ;
- `stocks.approve` pour comptabiliser une réception ou un retour qui modifie le registre de stock ;
- `purchasing.export` pour extraire les registres.

Le rôle `BUYER` ne possède pas `purchasing.approve`. Le rôle `PURCHASING_MANAGER` possède toutes les actions achats. Le magasinier peut créer les réceptions et dispose de `stocks.approve` pour les comptabiliser.

Le module Ventes sépare :

- `sales.create` et `sales.update` pour préparer clients, devis, commandes, livraisons et retours ;
- `sales.approve` pour approuver un tarif, confirmer ou annuler une commande ;
- `stocks.approve` pour comptabiliser une expédition ou un retour qui modifie le stock ;
- `sales.export` pour extraire clients et commandes.

Le rôle `SALES` ne possède pas `sales.approve`. Le rôle `SALES_MANAGER` dispose de toutes les actions commerciales. Le magasinier peut préparer les livraisons et comptabiliser les mouvements de stock.

Le module Recettes et prix de revient sépare :

- `production.create` et `production.update` pour préparer recettes, versions, ingrédients et charges de fabrication ;
- `production.approve` pour figer une version de recette et archiver le standard précédent ;
- `finance.view` pour consulter la vue consolidée des prix de revient ;
- `finance.create` pour enregistrer ou recalculer un instantané de coût.

Le rôle `FINANCE` reçoit également `catalog.view` et `production.view` afin de consulter les articles, recettes et OF qui justifient les calculs, sans pouvoir modifier les compositions.

Le module Facturation et règlements sépare :

- `finance.view` pour les registres, détails et balances âgées ;
- `finance.create` pour préparer factures et règlements ;
- `finance.update` pour le suivi des relances ;
- `finance.approve` pour émettre/approuver les documents, comptabiliser et annuler les règlements ;
- `finance.export` pour les extractions financières.

Le rôle `FINANCE` dispose de ces actions. Une annulation de règlement exige `finance.approve` et un motif obligatoire ; le règlement reste conservé.

## Gestion des modules v0.12.0

- `modules.view` : consulter le registre, l’état et les dépendances ;
- `modules.update` : synchroniser les manifestes et activer/désactiver un domaine.

Ces permissions sont attribuées au rôle `ADMINISTRATOR`. Les permissions métier restent nécessaires même lorsque le module correspondant est activé : l’état du module définit le périmètre déployé, tandis que le RBAC définit les actions autorisées à l’utilisateur.
