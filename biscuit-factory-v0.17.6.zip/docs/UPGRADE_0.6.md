# Mise à niveau vers la version 0.6.0

Cette mise à niveau conserve les données des versions précédentes. Effectuer une sauvegarde avant toute intervention.

## 1. Sauvegarde

Sous PowerShell, depuis le dossier du projet :

```powershell
docker compose exec postgres pg_dump -U biscuit biscuit_factory > ..\biscuit-factory-before-0.6.sql
Copy-Item .env ..\.env-before-0.6
```

Adapter l’utilisateur et la base aux valeurs de `.env` si elles ont été modifiées.

## 2. Remplacer les sources

Décompresser la v0.6.0 dans un nouveau dossier. Recopier uniquement le fichier `.env` et, si nécessaire, les fichiers privés de `storage/app/private`. Ne pas recopier `vendor`, `node_modules`, `public/hot` ni les caches.

## 3. Installer et migrer

```powershell
docker compose build
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-interaction --no-progress
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --class=RolePermissionSeeder --force
docker compose run --rm app php artisan db:seed --class=ReferenceDataSeeder --force
docker compose up -d
```

Pour ajouter ou réinitialiser uniquement les exemples livrés, exécuter en plus :

```powershell
docker compose run --rm app php artisan db:seed --class=DemoDataSeeder --force
```

Les seeders sont rejouables et conservent les identifiants existants.

## 4. Vérifier

```powershell
docker compose ps
docker compose run --rm app php artisan migrate:status
docker compose run --rm app php artisan test --filter=QualityWorkflowTest
Invoke-WebRequest http://localhost:8080/up
```

Dans l’application, ouvrir **Qualité > Plans de contrôle**, puis vérifier le plan `PCQ-PF-BIS-CHOC` et le point `CCP-CUISSON-01` si les données de démonstration ont été chargées.

## Compatibilité et comportement nouveau

- Les lots de produits finis restent créés en quarantaine.
- Une réception ou une fin de production crée automatiquement les contrôles correspondant aux plans approuvés.
- FEFO ignore désormais les lots en quarantaine, bloqués, rejetés ou périmés.
- Lorsqu’un plan approuvé s’applique, un changement manuel vers `RELEASED` exige un contrôle conforme avec décision `RELEASE`.
- Les fichiers qualité utilisent `QUALITY_FILESYSTEM_DISK=local` par défaut, restent privés et passent par une route autorisée pour être téléchargés.
