# Mise à niveau vers Biscuit Factory v0.17.3

La v0.17.3 est cumulative et doit être déployée à partir d'une sauvegarde vérifiée de la v0.17.2.

## Procédure Windows / Docker Desktop

1. Sauvegarder la base PostgreSQL et le stockage privé.
2. Extraire l'archive v0.17.3 dans un nouveau dossier local hors OneDrive.
3. Reprendre uniquement les valeurs nécessaires de l'ancien `.env` ; ne pas écraser le nouveau fichier `.env.example`.
4. Exécuter :

```powershell
.\install-windows.cmd
```

5. Contrôler l'état :

```powershell
docker compose ps
docker compose exec app php artisan migrate --force
docker compose exec app php artisan optimize:clear
docker compose exec app php artisan optimize
docker compose exec app php artisan app:doctor
```

## Assets

L'archive contient les assets Vite compilés. Aucun `npm install` n'est requis sur la machine de recette lorsque l'image Docker est construite depuis l'archive.

## Cache

Les compteurs de workflow et les tableaux de bord utilisent un cache de courte durée. Après une mise à niveau ou une modification de configuration :

```powershell
docker compose exec app php artisan optimize:clear
docker compose restart app nginx horizon scheduler reverb
```

## Contrôles fonctionnels prioritaires

- ouverture du tableau de bord principal ;
- navigation Stocks, Production, Ventes et Facturation ;
- affichage des quatre types de graphiques ;
- changement de langue FR/EN/AR et contrôle RTL ;
- mode sombre ;
- menu mobile ;
- chargement différé des badges tâches/alertes ;
- absence de régression sur création, validation et consultation des documents.

Aucune migration métier supplémentaire n'est introduite par cette corrective UI.
