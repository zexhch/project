# Mise à niveau vers Biscuit Factory v0.17.2

La v0.17.2 est une corrective cumulative construite sur la v0.17.1. Elle ajoute les conditionnements hiérarchiques, les images PNG des articles, l'import des conversions et l'aide contextuelle.

## Sauvegarde préalable

Sous Windows :

```powershell
.\scripts\windows\backup.cmd
```

Sous Linux :

```bash
bash scripts/backup.sh
```

## Mise à niveau Windows / Docker Desktop

1. Extraire la v0.17.2 dans un nouveau dossier hors OneDrive.
2. Recopier le fichier `.env` de l'installation précédente.
3. Lancer :

```powershell
.\install-windows.cmd
```

4. Contrôler :

```powershell
.\healthcheck-windows.cmd
docker compose exec app php artisan app:doctor
docker compose exec app php artisan test
```

## Mise à niveau Linux

```bash
cp /chemin/ancien/.env .env
bash scripts/init.sh
bash scripts/healthcheck.sh
docker compose exec app php artisan test
```

## Effet de la migration

- ajout des chemins d'images principales aux articles ;
- enrichissement de `item_unit_conversions` ;
- création de l'historique des conversions et de la galerie d'images ;
- création automatique d'une conversion de base facteur 1 pour chaque article existant ;
- conservation des anciennes conversions, sans réécriture des documents historiques.

## Vérifications fonctionnelles

1. Ouvrir un article et vérifier la conversion de base.
2. Créer `CT = 24 PAQ`, puis `PAL = 36 CT`.
3. Vérifier que le facteur palette vaut 864.
4. Créer une commande de 2 palettes et 3 cartons ; vérifier 1 800 unités de base.
5. Modifier le facteur carton et vérifier le recalcul de la palette.
6. Ajouter l'image principale ; vérifier le nom `<CODE>.png` et la miniature.
7. Télécharger puis prévisualiser le modèle d'import des conditionnements.
8. Ouvrir le glossaire et tester les tooltips au clavier.

## Retour arrière

Restaurer la sauvegarde complète de la base et des fichiers. Ne pas exécuter uniquement le `down` de la migration sur une base ayant déjà utilisé les nouveaux conditionnements.
