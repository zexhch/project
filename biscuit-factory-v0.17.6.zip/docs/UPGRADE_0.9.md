# Mise à niveau vers la version 0.9.0

La version ajoute les écrans complets de recettes, le prix de revient théorique et réel, ainsi que la consommation FEFO multi-emplacements en production.

## Sauvegarde préalable

Depuis PowerShell, dans le dossier de la version actuellement utilisée :

```powershell
docker compose exec postgres pg_dump -U biscuit -d biscuit_factory -Fc -f /tmp/biscuit-before-0.9.dump
docker compose cp postgres:/tmp/biscuit-before-0.9.dump .\biscuit-before-0.9.dump
```

Adaptez l’utilisateur et la base si votre `.env` utilise d’autres valeurs.

## Mise à niveau sous Windows

Conserver votre `.env`, remplacer les sources par celles de la v0.9.0, puis exécuter :

```powershell
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-interaction --no-progress
docker compose run --rm vite npm ci
docker compose run --rm vite npm run build
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --force
docker compose run --rm app php artisan optimize:clear
docker compose up -d
```

Ne lancez pas `migrate:fresh` sur une base contenant vos données.

## Vérifications

```powershell
docker compose ps
docker compose run --rm app php artisan test --filter=RecipeCostingWorkflowTest
docker compose logs --tail=100 app nginx horizon reverb
```

Vérifiez ensuite :

1. **Production → Recettes** affiche la recette de démonstration.
2. Les onglets Ingrédients, Gamme, Coûts et Historique s’ouvrent correctement.
3. **Production → Prix de revient** affiche un coût théorique non nul.
4. La création d’un OF propose uniquement les versions approuvées.
5. Select2 et DataTables fonctionnent dans les nouveaux écrans.

## Corrections précédentes conservées

- clé primaire PostgreSQL créée avant la clé étrangère récursive de `item_categories` ;
- permissions affectées par leur code dans `RolePermissionSeeder` ;
- variable `$s` échappée dans le contrôle de santé Compose ;
- délai Composer porté à 1 800 secondes et installation depuis `composer.lock`.
