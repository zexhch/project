# Mise à niveau vers la version 0.13.1

La version 0.13.1 stabilise l’installation et l’exploitation de la v0.13.0. Elle n’ajoute aucune table métier.

## Procédure

1. Sauvegarder la base et les fichiers privés.
2. Déployer l’archive v0.13.1 sans remplacer le fichier `.env` existant.
3. Exécuter :

```bash
docker compose build
docker compose run --rm app composer install --no-interaction --prefer-dist --no-progress
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan module:sync
docker compose run --rm app php artisan optimize:clear
docker compose up -d
bash scripts/healthcheck.sh
```

## Contrôles

```bash
docker compose exec -T app php artisan app:doctor
docker compose exec -T app php artisan module:diagnose --fail-on-error
docker compose exec -T app php artisan finance:audit-ledger --fail-on-error
```

Les endpoints `/health/live` et `/health/ready` sont publics mais ne renvoient que des états et codes techniques en production. Les messages détaillés sont réservés aux environnements local et testing.
