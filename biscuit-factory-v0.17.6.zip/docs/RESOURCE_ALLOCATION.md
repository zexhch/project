# Allocation des ressources Docker

## Objectif

La version 0.17.5 répartit explicitement CPU, mémoire et nombre de processus entre les services. Les limites sont configurables dans `.env` et ne nécessitent pas de modifier les fichiers Compose.

## Profil équilibré par défaut

Le profil livré vise Docker Desktop avec **au moins 4 vCPU et 6 à 8 Gio de RAM**.

| Service | CPU | Mémoire maximale | Rôle |
|---|---:|---:|---|
| `app` | 1,50 | 1 536 Mio | Requêtes PHP-FPM |
| `postgres` | 1,50 | 1 536 Mio | Base de données |
| `horizon` | 1,00 | 2 048 Mio | Jobs, imports, exports et rapports |
| `redis` | 0,50 | 512 Mio | Cache, sessions, files et broadcasting |
| `reverb` | 0,50 | 384 Mio | WebSockets |
| `nginx` | 0,25 | 128 Mio | HTTP et fichiers statiques |
| `scheduler` | 0,25 | 256 Mio | Tâches planifiées |
| `vite` | 1,00 | 768 Mio | Développement frontend uniquement |
| `minio` | 0,50 | 512 Mio | Stockage objet |

Les limites ne constituent pas une réservation totale immédiate. La mémoire réservée est inférieure à la limite afin de laisser Docker Desktop arbitrer les pics.

## Réglages associés

- PostgreSQL : `shared_buffers`, cache estimé, mémoire de maintenance, WAL et concurrence d’E/S adaptés au volume mémoire du conteneur.
- Redis : plafond mémoire explicite et politique `noeviction`, afin de ne pas supprimer silencieusement des jobs ou sessions.
- Horizon : nombre de processus local/production, mémoire par worker et timeouts configurables.
- PHP-FPM : pool à 10 workers avec recyclage après 500 requêtes.
- OPcache : validation des timestamps désactivée dans l’image de production.
- Tous les services principaux disposent d’un plafond de processus `pids_limit`.

## Ajustement recommandé

Pour une machine disposant de 8 vCPU et 12 Gio ou plus attribués à Docker Desktop :

```dotenv
APP_CPUS=2.50
APP_MEMORY_LIMIT=2560m
POSTGRES_CPUS=2.50
POSTGRES_MEMORY_LIMIT=2560m
POSTGRES_SHARED_BUFFERS=768MB
POSTGRES_EFFECTIVE_CACHE_SIZE=2048MB
HORIZON_CPUS=2.00
HORIZON_MEMORY_LIMIT_CONTAINER=3072m
HORIZON_PRODUCTION_MAX_PROCESSES=8
REDIS_MEMORY_LIMIT=768m
REDIS_MAXMEMORY=512mb
```

Pour une machine limitée à 4 vCPU et 6 Gio : conserver le profil par défaut et arrêter `vite`, `adminer` ou `mailpit` lorsqu’ils ne sont pas nécessaires.

## Contrôle

Sous Windows :

```powershell
.\resource-report-windows.cmd
```

Sous Linux/WSL :

```bash
bash scripts/resource-report.sh
```

Le rapport affiche les ressources visibles par Docker, l’état des services et la consommation instantanée.
