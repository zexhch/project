# Documents commerciaux et informations légales

## Périmètre

La v0.17.1 harmonise les modèles imprimables avec les informations utilisées sur les factures et bons de livraison algériens. Les mêmes données sont réutilisées par les devis, commandes, réceptions, avoirs et règlements afin d’éviter toute double saisie.

## Identité de la société

Configurer dans **Paramétrage → Sociétés** :

- raison sociale et activité ;
- adresse, téléphone et e-mail ;
- registre de commerce (RC) ;
- numéro d’identification fiscale (NIF) ;
- numéro d’identification statistique (NIS) ;
- article d’imposition (AI) ;
- banque, agence et numéro de compte ;
- logo PNG, JPEG ou WebP de 2 Mo maximum.

Le logo est enregistré dans le disque public Laravel. La commande `php artisan storage:link` est exécutée par les scripts d’installation.

## Identité des clients et fournisseurs

Les fiches client et fournisseur enregistrent et affichent :

- raison sociale ;
- RC ;
- NIF ;
- NIS ;
- AI ;
- coordonnées et adresses ;
- conditions de paiement et devise.

Ces colonnes sont disponibles dans les imports/exports CSV et XLSX ainsi que dans la recherche globale.

## Contenu des documents

Le gabarit A4 peut afficher :

- logo et identité complète de l’émetteur ;
- identité légale du client ou fournisseur ;
- banque et numéro de compte ;
- type, numéro, date et statut du document ;
- références internes : commande, livraison, réception, échéance, transporteur ;
- numéro de ligne, référence, désignation, quantité et unité ;
- prix unitaire HT, taux de TVA et montant HT ;
- total HT, remise, TVA, total TTC et solde ;
- montant TTC en toutes lettres ;
- conditions, zone cachet et signature.

## Bons de livraison avec ou sans prix

Le bon de livraison affiche les prix par défaut dans la v0.17.1. Le comportement reste configurable :

1. Ouvrir **Finance → Gouvernance → Modèles de documents**.
2. Choisir `BON DE LIVRAISON`.
3. Sélectionner **Afficher les montants**, **Masquer les montants** ou **Valeur par défaut**.
4. Activer ou désactiver séparément la TVA, les références internes, le statut et le montant en lettres.

La valeur par défaut du catalogue est **Afficher les montants**.

## Calculs imprimés

Pour chaque ligne :

```text
Prix unitaire HT = prix saisi / (1 + taux TVA) si le tarif est TTC
Montant brut HT = quantité × prix unitaire HT
Remise = montant brut HT × taux de remise
Montant HT = montant brut HT − remise
TVA = montant HT × taux de TVA
Montant TTC = montant HT + TVA
```

Pour le document :

```text
Total HT = somme des montants HT
Remise totale = somme des remises
TVA = somme des TVA de ligne
Total TTC = Total HT + TVA
Solde = Total TTC − avoirs − règlements validés
```

Le montant en lettres est généré avec l’extension PHP `intl`, en français, anglais ou arabe, avec gestion des dinars et centimes.

## Contrôles de recette

Le test `tests/Feature/LegalDocumentPrintingTest.php` vérifie :

- les champs légaux de la société et des tiers ;
- la conversion d’un montant DZD en lettres ;
- l’impression des prix, de la TVA et des totaux sur le BL ;
- l’impression de la facture et du montant en lettres ;
- la possibilité de masquer les prix du BL par modèle.

Le validateur autonome est exécutable sans Docker :

```bash
php scripts/validate-legal-printing.php
```
