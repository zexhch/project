# Mise à niveau vers la version 0.10.0

## Sauvegarde

```powershell
./scripts/backup.sh
```

## Mise à jour

Remplacer les fichiers applicatifs par ceux de l’archive 0.10.0, puis exécuter :

```powershell
docker compose build --no-cache app
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --no-interaction --prefer-dist --no-progress
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --force
docker compose run --rm vite sh -c "npm ci --no-audit --no-fund && npm run build"
docker compose up -d
```

## Contrôles

```powershell
docker compose exec app php artisan test --filter=BillingWorkflowTest
docker compose exec app vendor/bin/pint --test
docker compose ps
```

Vérifier ensuite :

1. le menu **Finance et contrôle de gestion → Facturation et règlements** ;
2. la présence du compte de démonstration `BANQUE-PRINCIPALE` ;
3. la génération d’une facture depuis une livraison comptabilisée ;
4. l’émission de la facture puis un règlement partiel ;
5. la ventilation d’un règlement sur deux factures ;
6. l’annulation auditée du règlement et le rétablissement des soldes ;
7. la saisie d’une relance client ;
8. la création et l’approbation d’une facture fournisseur avec rapprochement ;
9. les balances âgées clients et fournisseurs.

## Retour arrière

La migration `2026_07_16_050000_create_billing_and_payment_tables.php` peut être annulée par :

```powershell
docker compose run --rm app php artisan migrate:rollback --step=1
```

Cette opération supprime toutes les données de facturation et de règlement créées par la v0.10.0. Elle doit être exécutée uniquement après sauvegarde.
