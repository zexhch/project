# Notifications et temps réel

## Composants

- Laravel Events.
- Laravel Broadcasting.
- Laravel Reverb.
- Laravel Echo.
- Livewire.
- Redis.
- Horizon.

## Flux

```text
Transaction métier validée
→ événement Laravel
→ diffusion Reverb
→ écoute Livewire
→ rafraîchissement du composant
```

## Repli

Le tableau de bord utilise aussi `wire:poll.30s`. Les compteurs de workflow relisent leur résumé toutes les 60 secondes. En cas de coupure WebSocket, les données restent donc actualisées périodiquement.

## Canaux initiaux

- `private-dashboard`
- `private-users.{userId}`

## Événements diffusés

Depuis la v0.2.0, toute modification d’un référentiel diffuse `DashboardUpdated` avec uniquement la ressource, l’action et l’identifiant concernés. Depuis la v0.11.0, `WorkflowInboxUpdated` actualise la boîte de travail d’un utilisateur après report, masquage ou lecture d’une notification. Une panne temporaire de diffusion ne bloque pas la transaction validée et reste journalisée côté serveur.

- stock sous seuil ;
- péremption proche ;
- lot bloqué ;
- non-conformité ;
- ordre de fabrication modifié ;
- arrêt de ligne ;
- maintenance échue ;
- retard de livraison ;
- échéance financière.

## Sécurité

Les canaux privés sont autorisés dans `routes/channels.php`. Les données diffusées doivent rester minimales et ne jamais contenir de secrets.
