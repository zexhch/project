# Diagnostic chronométré des installations

La v0.17.6 instrumente les scripts d’installation Windows et Linux. Chaque phase et chaque commande reçoit un identifiant, une heure de début, une heure de fin, un statut et une durée.

## Lecture des marqueurs

Exemple :

```text
[2026-07-18 14:12:03.221][STEP-05][START] Installation des dependances Composer
[2026-07-18 14:12:03.238][CMD-018][START] docker compose run ... composer install ...
[2026-07-18 14:18:47.912][CMD-018][SLOW] code=0 duree=06:44.674 | docker compose run ...
[2026-07-18 14:18:47.930][STEP-05][END] Installation des dependances Composer | duree=06:44.709
```

États principaux :

- `START` : opération démarrée ;
- `END` : opération terminée normalement ;
- `SLOW` : commande terminée mais supérieure au seuil configuré ;
- `WAIT` : attente HTTP toujours en cours ;
- `FAIL` : opération en échec ;
- `SKIP` : opération volontairement ignorée.

La dernière ligne `START` sans ligne `END`, `SLOW` ou `FAIL` correspond à la commande actuellement bloquée.

## Windows

Installation avec le seuil par défaut de 30 secondes :

```powershell
.\install-windows.cmd
```

Seuil personnalisé :

```powershell
.\install-windows.cmd -SlowCommandSeconds 15
```

Pendant l’installation, suivre les marqueurs depuis un second terminal :

```powershell
Get-Content .\storage\logs\installer\latest-markers.log -Wait
```

`latest-markers.log` est mis à jour à la fin d’une installation. Pendant la toute première exécution, utiliser le fichier horodaté le plus récent :

```powershell
$log = Get-ChildItem .\storage\logs\installer\*-markers.log |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
Get-Content $log.FullName -Wait
```

Afficher le classement après l’installation :

```powershell
.\installation-report-windows.cmd
```

Ouvrir également le dossier des journaux :

```powershell
.\installation-report-windows.cmd -OpenLogFolder
```

## Linux

```bash
bash scripts/init.sh --slow-command-seconds 15
bash scripts/installation-report.sh
```

Suivi en direct :

```bash
tail -f "$(ls -1t storage/logs/installer/*-markers.log | head -1)"
```

## Fichiers produits

Les fichiers sont placés dans `storage/logs/installer` et ne sont pas inclus dans les archives de livraison :

- `*-markers.log` : marqueurs courts, écrits immédiatement ;
- `*-transcript.log` : sortie complète de l’installation ;
- `*-timings.csv` sous Windows ou `*-timings.tsv` sous Linux : données structurées ;
- `*-summary.json` sous Windows : résumé exploitable automatiquement ;
- alias `latest-*` : dernière exécution terminée.

En cas d’échec, le script ajoute automatiquement l’état Compose, un instantané `docker stats` et les dernières lignes des services principaux. Les arguments susceptibles de contenir un mot de passe, un secret, un jeton ou une clé sont masqués dans les marqueurs.
