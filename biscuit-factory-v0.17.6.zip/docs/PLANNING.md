# Planification industrielle

Le module v0.17.0 calcule un plan directeur à partir des commandes clients confirmées.

1. La demande ouverte est convertie dans l’unité de base.
2. Le stock libéré non périmé, les réceptions fournisseurs/production et le stock de sécurité déterminent chronologiquement le besoin net.
3. Les recettes approuvées sont explosées en besoins matières.
4. Les capacités produit/ligne et les équipes de travail déterminent les minutes requises et disponibles.
5. Les pénuries, recettes absentes, conversions manquantes et surcharges deviennent des conflits.
6. Après approbation, les créneaux génèrent des ordres de fabrication liés au plan.

Le calcul TRS/OEE consolide disponibilité, performance et qualité. Il est stocké par ligne et période pour conserver un historique reproductible.


## Prérequis de calcul

- commandes clients dans un statut confirmé ou en cours d'exécution ;
- recette approuvée pour chaque produit à fabriquer ;
- cadence produit/ligne renseignée ;
- unités et conversions cohérentes ;
- équipes de travail configurées pour une capacité calendaire précise.

Les conflits critiques empêchent l'approbation. Après correction des données de base, un nouveau calcul reconstruit les besoins et conflits de manière déterministe.
