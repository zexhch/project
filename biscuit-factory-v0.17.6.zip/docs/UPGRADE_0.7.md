# Mise à niveau vers la version 0.7.0

Cette procédure conserve les données des versions précédentes. Elle est adaptée à Docker Desktop sous Windows PowerShell.

## 1. Sauvegarder

Depuis le dossier de la version actuellement utilisée :

```powershell
docker compose exec postgres pg_dump -U biscuit biscuit_factory > ..\biscuit-factory-before-0.7.sql
Copy-Item .env ..\.env-before-0.7
```

Adapter le nom de l’utilisateur et de la base si les valeurs PostgreSQL ont été modifiées dans `.env`.

## 2. Remplacer les sources

Décompresser la v0.7.0 dans un nouveau dossier, puis recopier uniquement :

- le fichier `.env` ;
- les fichiers métier privés éventuellement présents sous `storage/app/private` ;
- les fichiers publics métier éventuellement présents sous `storage/app/public`.

Ne pas recopier `vendor`, `node_modules`, `public/build`, `public/hot`, `public/storage` ni les caches. Le lien `public/storage` sera recréé par Laravel.

## 3. Installer les dépendances

```powershell
docker compose build
docker compose up -d postgres redis minio minio-init mailpit
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-interaction --no-progress
docker compose run --rm vite npm ci
docker compose run --rm vite npm run build
```

La v0.7.0 utilise Select2 4.0.13, DataTables 2.3 et DataTables Responsive 3.0. `npm ci` doit utiliser le `package-lock.json` livré.

## 4. Migrer et mettre à jour les référentiels

```powershell
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --class=RolePermissionSeeder --force
docker compose run --rm app php artisan db:seed --class=ReferenceDataSeeder --force
docker compose run --rm app php artisan storage:link
docker compose up -d
```

Les deux seeders ajoutent les rôles Acheteur/Responsable achats et les statuts configurables. Ils ne réinitialisent pas les documents opérationnels.

Pour installer les exemples du manuel dans une base de développement uniquement :

```powershell
docker compose run --rm app php artisan db:seed --class=DemoDataSeeder --force
```

Ne pas lancer `DemoDataSeeder` dans une base de production existante : les documents `DA-DEMO-001`, `BC-DEMO-001` et `BR-DEMO-001` sont volontairement replacés dans leur état d’exemple.

## 5. Vérifier

```powershell
docker compose ps
docker compose run --rm app php artisan migrate:status
docker compose run --rm app php artisan test --filter=PurchasingWorkflowTest
Invoke-WebRequest http://localhost:8080/up
```

Dans l’application :

1. vérifier **Achats > Fournisseurs** ;
2. ouvrir une liste avec plusieurs options et confirmer la recherche Select2 ;
3. vérifier le tri et l’affichage responsive d’un tableau DataTables ;
4. si les données de démonstration sont présentes, ouvrir `BC-DEMO-001` et `BR-DEMO-001`.

## Correctifs antérieurs conservés

La livraison conserve explicitement les corrections issues du démarrage Windows réel :

- `laravel/tinker` 3.x et `composer.lock` ;
- délai Composer de 1 800 secondes ;
- variable Reverb échappée sous la forme `$$s` dans `compose.yaml` ;
- clé primaire de `item_categories` créée avant sa clé étrangère récursive sous PostgreSQL ;
- seeder des rôles utilisant les codes de permissions, sans confusion avec les UUID.

