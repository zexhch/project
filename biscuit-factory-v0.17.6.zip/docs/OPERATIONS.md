# Exploitation et diagnostic

## Sondes HTTP

- `/health/live` confirme que PHP/Laravel répond.
- `/health/ready` vérifie la configuration, PostgreSQL, les migrations, le cache, le stockage, Redis lorsque requis et la cohérence des modules.
- Une application non prête renvoie HTTP 503.

Exemple Docker Compose :

```yaml
healthcheck:
  test: ["CMD-SHELL", "curl -fsS http://localhost/health/ready >/dev/null"]
  interval: 30s
  timeout: 5s
  retries: 5
```

## Diagnostic CLI

```bash
php artisan app:doctor
php artisan app:doctor --json
php artisan app:doctor --fail-on-warning
```

Codes de sortie :

- `0` : prête ;
- `1` : contrôle bloquant ;
- `2` : avertissement avec `--fail-on-warning`.

## Scripts Linux/macOS

- `scripts/validate-static.sh` : contrôles sans Docker.
- `scripts/preflight.sh` : prérequis Docker et sécurité minimale de `.env`.
- `scripts/healthcheck.sh` : état des services et diagnostic applicatif.
- `scripts/validate-installation.sh` : réinstallation destructive et tests complets.
- `scripts/validate-release.sh` : validation de release sous Docker/PostgreSQL.


## Scripts Windows

- `scripts/windows/preflight.cmd` : prérequis Docker Desktop et configuration.
- `scripts/windows/init.cmd` : installation ou mise à niveau.
- `scripts/windows/healthcheck.cmd` : sondes HTTP et diagnostic Laravel.
- `scripts/windows/validate-installation.cmd` : réinstallation destructive et tests complets.
- `scripts/windows/validate-release.cmd` : validation de release sous Docker/PostgreSQL.
- `scripts/windows/backup.cmd` et `restore.cmd` : sauvegarde et restauration sécurisées.

Raccourcis à la racine : `install-windows.cmd`, `healthcheck-windows.cmd` et `validate-installation-windows.cmd`.

## Incidents fréquents

### Migrations en attente

```bash
docker compose exec -T app php artisan migrate --force
docker compose exec -T app php artisan module:sync
```

### Cache ou Redis indisponible

```bash
docker compose ps redis
docker compose logs --tail=200 redis app horizon
```

### Stockage non accessible

Vérifier les permissions de `storage`, `bootstrap/cache` et, si S3/MinIO est utilisé, les variables `AWS_*` et l’existence du bucket.

### Module incohérent

```bash
docker compose exec -T app php artisan module:diagnose --fail-on-error
docker compose exec -T app php artisan module:sync
```

## Sécurité et exploitation v0.14.0

### Audit de sécurité

```bash
php artisan security:audit
php artisan security:audit --json
```

Sous Windows :

```powershell
.\security-audit-windows.cmd
```

L’audit détecte notamment les secrets de démonstration, `APP_DEBUG` en production, les cookies non sécurisés, les sessions non chiffrées et les changements de mot de passe obligatoires.

### Sauvegardes applicatives

La page **Administration → Sécurité et exploitation** permet de lancer ou programmer une sauvegarde. Le scheduler exécute :

```bash
php artisan operations:run-backups
```

Une sauvegarde peut contenir :

- un dump PostgreSQL au format custom créé avec le client PostgreSQL 17 ;
- les fichiers privés de `storage/app/private` ;
- une empreinte SHA-256 enregistrée en base.

La restauration reste volontairement pilotée par les scripts `restore.sh` ou `scripts/windows/restore.cmd`, avec confirmation explicite. Les scripts acceptent le dump/document historique ou l’archive ZIP applicative, vérifient les empreintes disponibles et sécurisent la reprise en invalidant sessions, caches et travaux restaurés.

### Instantanés et rétention

```bash
php artisan operations:capture-health
php artisan operations:prune
```

Les instantanés sont exécutés toutes les cinq minutes. La purge quotidienne applique les durées configurées pour les audits, les sauvegardes, les sessions anciennes et les instantanés de santé.

### Mode maintenance

Linux :

```bash
bash scripts/maintenance.sh on
bash scripts/maintenance.sh off
```

Windows :

```powershell
.\maintenance-windows.cmd -Mode On
.\maintenance-windows.cmd -Mode Off
```

Le mode maintenance ne doit pas être activé depuis l’interface web afin de conserver un chemin de retour indépendant de l’application.
