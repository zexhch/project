# Mise à niveau vers la version 0.8.0

## Contenu

Cette version ajoute le module Ventes/Livraisons et les composants d’ergonomie communs. Elle conserve les données et les correctifs Windows/PostgreSQL des versions précédentes.

## Sauvegarde

Avant la mise à niveau :

```powershell
docker compose exec postgres pg_dump -U biscuit biscuit_factory > ..\biscuit-factory-before-0.8.sql
```

Ne pas utiliser `docker compose down -v`, qui supprimerait les volumes.

## Commandes PowerShell

Depuis le dossier de la v0.8.0 :

```powershell
Copy-Item .env.example .env -ErrorAction SilentlyContinue
docker compose build
docker compose up -d postgres redis minio minio-init mailpit
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-interaction --no-progress
docker compose run --rm vite npm ci
docker compose run --rm vite npm run build
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --class=RolePermissionSeeder --force
docker compose run --rm app php artisan db:seed --class=ReferenceDataSeeder --force
docker compose run --rm app php artisan optimize:clear
docker compose up -d
docker compose exec app php artisan test
```

Sur une base de développement vide, `php artisan migrate --seed` ajoute aussi les exemples clients et ventes. Sur une base réelle, ne lancez pas `DemoDataSeeder` ni `SalesDemoDataSeeder`.

## Vérifications

1. Ouvrir **Ventes** dans le menu.
2. Vérifier les rôles `SALES_MANAGER` et `SALES`.
3. Vérifier les permissions `sales.*` et `stocks.approve` des magasiniers.
4. Créer un client, un tarif et une commande de test.
5. Confirmer la commande et contrôler `stock_balances.reserved_quantity`.
6. Préparer puis comptabiliser une livraison partielle.
7. Créer un retour vers un emplacement ayant `quarantine = true`.
8. Vérifier la création du lot de retour et du contrôle `CUSTOMER_RETURN`.
9. Tester les écrans à largeur mobile, en thème sombre et en arabe RTL.

## Correctifs historiques conservés

- `laravel/tinker ^3.0` et `composer.lock` ;
- délai Composer de 1 800 secondes ;
- `$$s` dans le healthcheck Reverb de `compose.yaml` ;
- clé primaire PostgreSQL de `item_categories` créée avant sa relation parent ;
- affectation des permissions par code dans `RolePermissionSeeder` ;
- exclusion de `public/storage`, `.env`, `vendor` et `node_modules` lors de l’empaquetage.

## Retour arrière

Restaurer la sauvegarde PostgreSQL et reprendre l’archive v0.7.0. La migration 0.8 peut être annulée en développement avec `php artisan migrate:rollback`, mais un retour arrière de production doit utiliser la sauvegarde afin de préserver l’intégrité des mouvements.

