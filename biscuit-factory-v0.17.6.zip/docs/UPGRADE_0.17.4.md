# Mise à niveau vers Biscuit Factory v0.17.4

La v0.17.4 est une corrective cumulative de la v0.17.3. Elle intègre dans le livrable les corrections validées pendant la recette Docker Desktop.

## Correctifs intégrés

- correction du rendu Blade des pages Qualité ;
- healthcheck Horizon avec timeout de 45 secondes et période de démarrage ;
- healthcheck Reverb portable dans les fichiers Compose ;
- réglage du pool PHP-FPM à 10 workers pour limiter les saturations ;
- exclusion de `public/storage` et des fichiers de santé temporaires du contexte BuildKit ;
- création idempotente du lien `public/storage` au démarrage ;
- conversion déterministe des durées d’arrêt Carbon en secondes entières ;
- sécurisation des migrations, permissions et dépendances Composer déjà corrigées pendant la recette.

## Redéploiement Windows / Docker Desktop

1. Conserver l’ancien dossier v0.17.3 comme sauvegarde.
2. Extraire l’archive v0.17.4 dans un nouveau dossier local, hors OneDrive.
3. Copier uniquement le fichier `.env` de la v0.17.3 dans le nouveau dossier.
4. Vérifier que Docker Desktop utilise les conteneurs Linux.
5. Depuis PowerShell, dans le dossier v0.17.4, exécuter :

```powershell
.\install-windows.cmd
```

Le script reconstruit les services PHP `app`, `horizon`, `scheduler` et `reverb`, puis recrée la pile. Cette mise à niveau conserve les volumes PostgreSQL, Redis, MinIO et Mailpit. Ne pas utiliser `-Fresh` pour une mise à niveau normale.

## Contrôles après déploiement

```powershell
docker compose ps
docker compose exec app php artisan app:doctor
docker compose exec horizon php artisan horizon:status
```

Contrôler ensuite :

```powershell
curl.exe -I http://localhost:8080/quality
curl.exe -I http://localhost:8080/quality/non-conformities
curl.exe -I http://localhost:8080/quality/plans
```

Les routes protégées peuvent répondre par une redirection vers la connexion ; elles ne doivent plus répondre en erreur HTTP 500.

## Réinitialisation destructive

Uniquement pour une installation de recette neuve :

```powershell
.\install-windows.cmd -Fresh -ConfirmReset
```

Cette commande supprime les volumes et les données existantes.
