# Mise à niveau vers la version 0.9.1

## Sauvegarde

```powershell
./scripts/backup.sh
```

## Mise à jour

Remplacer les fichiers applicatifs par ceux de l’archive 0.9.1, puis exécuter :

```powershell
docker compose build --no-cache app

docker compose run --rm app composer install --no-interaction --prefer-dist --no-progress

docker compose run --rm app php artisan migrate --force

docker compose run --rm app php artisan db:seed --force

docker compose run --rm vite sh -c "npm ci --no-audit --no-fund && npm run build"

docker compose up -d
```

## Contrôles

```powershell
docker compose exec app php artisan test

docker compose exec app vendor/bin/pint --test

docker compose ps
```

Vérifier ensuite :

1. l’ouverture du menu **Finance et contrôle de gestion** ;
2. la présence des centres `CC-PROD` et `CC-MAINT` dans les données de démonstration ;
3. le rattachement de la ligne `LIGNE-01` et de la machine `FOUR-01` ;
4. le recalcul du scénario `SCN-BASE` ;
5. l’actualisation d’une ligne budgétaire ;
6. l’affichage des marges par client et produit.

## Retour arrière

La migration `2026_07_16_040000_create_management_control_tables.php` peut être annulée par :

```powershell
docker compose run --rm app php artisan migrate:rollback --step=1
```

Effectuer cette opération uniquement après sauvegarde. Elle supprime les données du module de contrôle de gestion.
