# Rapport de validation — v0.17.6

Date : 18 juillet 2026

## Périmètre

La v0.17.6 est une corrective cumulative de la v0.17.5. Elle instrumente les installations et corrige les contrôles d’exploitation sans modifier les règles métier du MVP.

## Contrôles intégrés

- cohérence de version entre `VERSION`, `README.md`, `CHANGELOG.md` et les 14 manifestes ;
- validation JSON des fichiers Composer et npm ;
- analyse syntaxique de tous les fichiers PHP ;
- validation des modules, routes, migrations et fonctions héritées ;
- validation spécifique de la refonte UI, des composants, traductions et types de graphiques ;
- compilation frontend Vite ;
- contrôle du manifeste SHA-256 de l'archive.

## Contrôles spécifiques v0.17.3

- composants KPI, graphique et section présents ;
- tableaux de bord principal, Stocks, Production, Ventes et Facturation refondus ;
- types `line`, `bar`, `horizontal-bar` et `donut` pris en charge ;
- chargement différé des badges de workflow ;
- caches de courte durée pour les agrégats ;
- cache en mémoire des permissions pendant la requête ;
- styles responsive, sombre et RTL ;
- documentation de mise à niveau et de conception UI.

## Contrôles spécifiques v0.17.4

- syntaxe Blade de la page Qualité ;
- timeout Horizon de 45 secondes et période de démarrage ;
- healthcheck TCP Reverb avec échappement Compose ;
- pool PHP-FPM à 10 workers ;
- exclusion BuildKit de `public/storage` et des fichiers de santé ;
- création du lien de stockage au démarrage ;
- arrondi et cast entier de `duration_seconds` ;
- cohérence de Tinker, Composer, `item_categories` et `stocks.approve`.

## Contrôles spécifiques v0.17.5

- limites CPU, mémoire, réservation et PID sur les services principaux ;
- cohérence entre limites de conteneur et réglages PostgreSQL/Redis/Horizon ;
- paramètres de ressources présents dans `.env.example` ;
- OPcache production sans validation des timestamps ;
- scripts de rapport de consommation Windows/Linux ;
- avertissements de capacité Docker Desktop.

## Contrôles spécifiques v0.17.6

- fonctions de traçage et de chronométrage Windows/Linux ;
- marqueurs immédiats, fichiers structurés et rapport de classement ;
- capture automatique du diagnostic après échec ;
- route statique `/nginx-health` utilisée par les healthchecks Compose ;
- timeout readiness adapté et progression visible ;
- chemin du seeder Administration conforme PSR-4 ;
- création idempotente de `public/storage`.

## Validation Docker Desktop requise

```powershell
.\validate-installation-windows.cmd -ConfirmReset
```

Cette commande est destructive pour les volumes de test. Elle doit être exécutée sur l'environnement Windows de recette afin de valider PostgreSQL, Redis, Horizon, Reverb, les migrations, les seeders, les tests Laravel et les sondes de santé.
