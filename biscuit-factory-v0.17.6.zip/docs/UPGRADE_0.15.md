# Mise à niveau vers Biscuit Factory v0.15.0

La v0.15.0 part de la baseline stable v0.14.0 et ajoute la gouvernance financière et documentaire.

## Sauvegarde obligatoire

### Windows

```powershell
.\scripts\windows\backup.cmd
```

### Linux

```bash
bash scripts/backup.sh
```

## Mise à niveau

Remplacer les fichiers applicatifs en conservant `.env`, puis exécuter :

```bash
docker compose up -d --build
docker compose exec app php artisan migrate --force
docker compose exec app php artisan db:seed --class=FinancialGovernanceSeeder --force
docker compose exec app php artisan module:sync
docker compose exec app php artisan optimize:clear
docker compose exec app php artisan app:doctor
```

Sous Windows, les mêmes commandes peuvent être lancées depuis PowerShell ou via `install-windows.cmd` sans option `-Fresh`.

## Contrôles

1. Ouvrir **Finance → Gouvernance**.
2. Vérifier les périodes de l'année courante et suivante.
3. Contrôler les séquences de chaque société.
4. Laisser les workflows d'exemple désactivés, puis configurer les circuits réels.
5. Imprimer un devis, une commande, un bon de livraison, une facture et un règlement.
6. Tester une clôture sur une base de test avant utilisation réelle.
7. Lancer :

```bash
bash scripts/validate-release.sh
```

## Compatibilité

- Les anciens numéros sont conservés.
- Les nouveaux documents utilisent les séquences v0.15.0.
- Les workflows d'exemple sont créés désactivés afin de ne pas modifier le comportement existant.
- Une installation neuve peut être réalisée directement avec l'archive v0.15.0 ; aucune version antérieure n'est requise.
