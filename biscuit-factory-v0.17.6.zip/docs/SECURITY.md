# Sécurité

## Mesures initiales

- Sessions Laravel.
- Mots de passe hachés.
- Protection CSRF.
- Autorisations serveur.
- Canaux WebSocket privés.
- Secrets uniquement dans `.env`.
- Base et Redis non exposés dans la configuration de production.
- En-têtes de sécurité Nginx.
- Journal d’audit actif pour chaque opération d’administration.
- Permissions vérifiées côté serveur pour l’affichage, la création, la modification et la suppression.
- Protections contre la suppression du compte courant et des référentiels système.
- Séparation entre saisie d’un résultat qualité et approbation d’une décision.
- Blocage serveur d’une libération malgré un échec critique.
- Pièces jointes qualité sur stockage privé, servies uniquement après autorisation.
- Garde FEFO excluant les lots non libérés ou périmés.
- Approbation achats séparée de la préparation des documents et de la comptabilisation du stock.
- Verrouillage des quantités de demande, commande, réception et retour pendant les transactions.
- Validation croisée société, fournisseur, entrepôt, emplacement, taxe, article et lot.
- Protection des exports CSV contre l’interprétation de formules par les tableurs.

## Avant production

- Changer tous les secrets.
- Désactiver `APP_DEBUG`.
- Utiliser HTTPS.
- Retirer Adminer et Mailpit.
- Restreindre les origines Reverb.
- Configurer les sauvegardes.
- Activer une politique de mot de passe.
- Ajouter la double authentification pour les profils sensibles.
- Réaliser une revue des permissions.
- Définir la durée de conservation des journaux.


## Sondes de santé

Les routes `/health/live` et `/health/ready` ne nécessitent pas d’authentification afin d’être utilisables par Docker et les répartiteurs de charge. En production, elles n’exposent ni exception, ni chemin, ni secret : seulement le statut et des codes techniques. Les détails sont disponibles via `php artisan app:doctor`.

## Politique de sécurité v0.14.0

La politique est administrable depuis **Administration → Sécurité et exploitation** :

- longueur et complexité minimales des mots de passe ;
- durée maximale de validité ;
- nombre d’échecs avant verrouillage ;
- durée du verrouillage ;
- durée d’inactivité des sessions ;
- conservation des audits et instantanés techniques.

Les nouveaux mots de passe définis par un administrateur imposent un changement lors de la prochaine connexion. Les mots de passe saisis ne sont jamais écrits dans les journaux d’audit.

## Sessions

Chaque utilisateur peut consulter et révoquer ses sessions depuis son menu de profil. Un administrateur disposant de `security.update` peut révoquer une session ou déverrouiller un compte depuis le centre d’exploitation.

## Audit

Les événements de sécurité enregistrent :

- l’utilisateur concerné ;
- l’adresse IP et le navigateur ;
- la sévérité ;
- un identifiant de corrélation par requête ;
- des métadonnées filtrées des secrets.

La commande `security:audit` contrôle l’environnement sans afficher les valeurs sensibles.
