# Mise à niveau vers la version 0.12.0

## Objet

La version 0.12.0 introduit un registre de modules applicatifs, des manifestes par domaine, des routes séparées, des dépendances explicites et une administration de l’activation fonctionnelle.

## Procédure

1. Sauvegarder la base et le stockage.
2. Déployer l’archive v0.12.0.
3. Installer les dépendances PHP et frontend depuis les fichiers de verrou.
4. Exécuter les migrations.
5. Actualiser les permissions et synchroniser les manifestes.
6. Vider les caches puis contrôler le registre.

```bash
docker compose run --rm app composer install --no-interaction --prefer-dist --no-progress
docker compose run --rm vite npm ci --no-audit --no-fund
docker compose run --rm vite npm run build
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --class=Database\\Seeders\\RolePermissionSeeder --force
docker compose run --rm app php artisan module:sync
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan module:diagnose --fail-on-error
docker compose up -d
```

L’écran de gestion est accessible dans **Administration → Modules de l’application** avec la permission `modules.view`. La modification nécessite `modules.update`.

## Dépendances livrées

| Module | Dépendances obligatoires |
|---|---|
| Pilotage et workflow | Aucune |
| Administration | Pilotage et workflow |
| Référentiels et paramétrage | Pilotage, Administration |
| Stocks | Référentiels |
| Production | Référentiels, Stocks |
| Qualité | Référentiels, Stocks |
| Maintenance | Référentiels, Stocks |
| Achats | Référentiels, Stocks |
| Ventes | Référentiels, Stocks |
| Finance | Référentiels, Production, Achats, Ventes |

Les trois modules socles ne peuvent pas être désactivés. Un module actif empêche la désactivation de ses dépendances. Un module ne peut pas être activé tant que toutes ses dépendances ne le sont pas.

## Effets d’une désactivation

- Les entrées du menu sont retirées.
- Les raccourcis et indicateurs correspondants sont retirés du tableau de bord.
- Les tâches et alertes du domaine ne sont plus générées.
- Les URL directes du module retournent une réponse 404.
- Les traitements planifiés propres au domaine sont ignorés.
- Les données existantes sont conservées et redeviennent accessibles après réactivation.
- Lorsque Qualité est désactivé, les nouveaux lots issus des réceptions, retours clients et fins de production sont libérés directement et aucun contrôle qualité automatique n’est créé.

## Organisation des migrations

Les migrations métier sont désormais rangées sous `app/Modules/<Domaine>/database/migrations` et chargées automatiquement. Leur nom n’a pas changé : Laravel reconnaît donc celles déjà exécutées lors d’une mise à niveau. Ne recopier aucun de ces fichiers dans `database/migrations`, sous peine de créer des doublons de noms.

## Retour arrière

Avant un retour vers la v0.11.0, réactiver les modules nécessaires et effectuer une sauvegarde. La table du registre peut rester en base sans perturber la version précédente. Ne pas supprimer les données métier lors d’une désactivation.
