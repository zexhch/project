# Unités, conditionnements, images et aide contextuelle

## Objectif

La v0.17.2 permet de gérer, pour chaque article, une hiérarchie de conditionnements indépendante des autres articles. Le stock reste enregistré dans l'unité de base ; chaque document conserve l'unité saisie et le facteur de conversion appliqué au moment de sa validation.

## Exemple de référence

Article `PF-BIS-180` : paquet de biscuits de 180 g.

| Unité | Parent | Facteur vers le parent | Facteur vers la base | Poids net |
|---|---|---:|---:|---:|
| `PAQ` | — | 1 | 1 | 0,180 kg |
| `CT` | `PAQ` | 24 | 24 | 4,320 kg |
| `PAL` | `CT` | 36 | 864 | 155,520 kg |

Ainsi, `2 PAL + 3 CT = 1 800 PAQ`. Le poids est une propriété logistique du conditionnement ; il ne transforme pas automatiquement une unité de comptage en kilogrammes dans les mouvements de stock.

## Configuration d'un conditionnement

Depuis **Référentiels → Articles → Unités et conditionnements**, renseigner :

- unité et unité parente ;
- facteur vers le parent ;
- code-barres propre au conditionnement ;
- poids net, brut et tare ;
- longueur, largeur, hauteur et volume calculé ;
- rôle par défaut : achat, vente, production ou inventaire ;
- autorisation des quantités fractionnaires et mode d'arrondi ;
- dates de validité et état actif.

Une seule unité active peut porter chacun des rôles par article. L'unité de base conserve toujours un facteur égal à 1.

## Règles d'intégrité

- les cycles de hiérarchie sont refusés ;
- un facteur nul ou négatif est refusé ;
- un code-barres ne peut pas être réutilisé sur un autre conditionnement ;
- le changement d'unité d'une conversion existante est interdit ;
- un parent actif ne peut pas être désactivé tant qu'il possède des enfants actifs ;
- une conversion déjà utilisée est désactivée au lieu d'être supprimée ;
- les descendants sont recalculés dans la même transaction lorsque le facteur parent change ;
- chaque création, modification, recalcul, désactivation ou suppression est historisé et audité.

## Utilisation par les modules

Les sélecteurs d'unités sont filtrés selon l'article. Le facteur vers l'unité de base est calculé par le référentiel de conditionnements, puis figé sur les lignes des documents pour conserver l'historique.

Les flux couverts comprennent notamment :

- devis, tarifs, commandes, livraisons et retours clients ;
- articles fournisseur, tarifs, demandes, consultations, commandes, réceptions et retours fournisseur ;
- recettes, consommations, sorties et pertes de production ;
- inventaires, valorisation, MRP et planification lorsqu'une unité métier est utilisée.

## Import et export

Le type d'échange **Conditionnements articles** accepte CSV UTF-8 et XLSX. Le parent doit être présent avant son enfant dans le fichier, sauf s'il existe déjà dans l'application.

Colonnes :

`article_code`, `unit_code`, `parent_unit_code`, `factor_to_parent`, `barcode`, `net_weight_kg`, `gross_weight_kg`, `tare_weight_kg`, `length_cm`, `width_cm`, `height_cm`, `purchasing_unit`, `sales_unit`, `production_unit`, `inventory_unit`, `fractional_allowed`, `rounding_mode`, `valid_from`, `valid_to`, `active`.

Un exemple est fourni dans `docs/templates/template-conditionnements-v0.17.2.csv` et le modèle XLSX est téléchargeable depuis le module Productivité.

## Images des articles

- image principale : `<CODE_ARTICLE>.png` ;
- galerie : `<CODE_ARTICLE>-01.png`, `<CODE_ARTICLE>-02.png`, etc. ;
- formats d'entrée acceptés : PNG, JPG et JPEG ;
- stockage final : PNG ;
- redimensionnement et miniature automatiques ;
- contrôle du poids du fichier et du nombre de pixels ;
- renommage automatique si le code article change ;
- remplacement et suppression contrôlés.

L'import groupé accepte une archive ZIP dont chaque image principale porte exactement le code article, par exemple `PF-BIS-180.png`. Les limites sont configurables dans `.env` avec les variables `ITEM_IMAGE_*`.

## Tooltips et glossaire

Les formulaires reçoivent automatiquement une aide contextuelle lorsque le nom du champ est répertorié dans `FieldHelp`. Chaque aide peut contenir une description, le format attendu et un exemple. Les tooltips sont utilisables à la souris, au clavier et sur mobile, avec prise en charge FR/EN/AR et RTL.

Le glossaire centralisé est accessible depuis **Aide → Glossaire** et explique notamment RC, NIF, NIS, AI, FEFO, FIFO, MRP, TRS/OEE, HT, TVA et TTC.
