# Base de données

## Convention générale

- PostgreSQL.
- Identifiants techniques UUID.
- Codes métier uniques et lisibles.
- Quantités : `NUMERIC(18,3)` ou `NUMERIC(18,6)`.
- Coûts : `NUMERIC(18,4)`.
- Montants : `NUMERIC(18,2)`.
- Dates et heures opérationnelles : timestamps.
- Suppression logique sur les articles.
- Contraintes de clés étrangères systématiques.

## Domaines déjà créés

### Sécurité

- `users`
- `roles`
- `permissions`
- `role_user`
- `permission_role`
- `audit_logs`
- `notifications`

Les rôles, permissions et valeurs de référence livrés par le produit portent un indicateur `system`. Cet indicateur protège leur identité technique tout en autorisant l’adaptation de leurs libellés et associations prévues.

### Paramétrage

- `languages`
- `currencies`
- `companies`
- `tax_rates`
- `system_settings`
- `reference_values` pour les listes et statuts configurables

### Sites et stockage

- `sites`
- `warehouses`
- `warehouse_locations`

### Articles

- `units`
- `unit_conversions`
- `item_categories`
- `items`
- `item_unit_conversions`

### Production

- `production_lines`
- `machines`
- `production_line_machines`
- `work_shifts`
- `recipes`
- `recipe_versions`
- `recipe_lines`
- `process_templates`
- `process_steps`
- `line_products`
- `production_orders`
- `production_consumptions`
- `production_outputs`
- `production_losses`
- `recipe_cost_components`
- `production_cost_entries`
- `cost_calculations`

`recipe_cost_components` décrit les charges théoriques de transformation d’une version de recette. `production_cost_entries` enregistre les charges réellement constatées sur un OF. `cost_calculations` conserve les instantanés théoriques et réels avec leur décomposition, leur rendement et leur coût unitaire.

### Contrôle de gestion

- `cost_centers`
- `cost_center_rates`
- `cost_scenarios`
- `cost_scenario_lines`
- `management_budgets`

Les centres de coûts sont rattachés à une société et peuvent être affectés aux lignes de production et aux machines. Les taux sont historisés par période. Les scénarios conservent leurs hypothèses et résultats par produit/recette. Les budgets stockent budget, réalisé et écart par exercice, période, catégorie et centre de coûts.

### Stocks

- `lots`
- `stock_movements`
- `stock_movement_lines`
- `stock_balances`
- `inventory_counts`
- `inventory_count_lines`

### Maintenance et arrêts

- `downtime_reasons`
- `maintenance_plans`
- `maintenance_work_orders`
- `production_downtimes`
- `maintenance_actions`
- `maintenance_parts`

### Qualité et HACCP

- `haccp_control_points`
- `quality_control_plans`
- `quality_control_plan_parameters`
- `quality_inspections`
- `quality_inspection_results`
- `quality_decisions`
- `quality_non_conformities`
- `quality_corrective_actions`
- `quality_attachments`

### Fournisseurs et achats

- `suppliers`
- `supplier_contacts`
- `supplier_items`
- `purchase_price_lists`
- `purchase_price_list_lines`
- `purchase_requisitions`
- `purchase_requisition_lines`
- `supplier_quotations`
- `supplier_quotation_lines`
- `purchase_orders`
- `purchase_order_lines`
- `goods_receipts`
- `goods_receipt_lines`
- `supplier_returns`
- `supplier_return_lines`
- `supplier_evaluations`

### Clients, ventes et livraisons

- `customers`
- `customer_contacts`
- `sales_price_lists`
- `sales_price_list_lines`
- `sales_quotations`
- `sales_quotation_lines`
- `sales_orders`
- `sales_order_lines`
- `stock_reservations`
- `delivery_notes`
- `delivery_note_lines`
- `delivery_allocations`
- `customer_returns`
- `customer_return_lines`

## Règle de stock

Le stock disponible est maintenu atomiquement lors de la comptabilisation des mouvements :

```text
Entrées validées - sorties validées - réservations actives
```

`stock_movements` et ses lignes constituent le journal opérationnel immuable. `stock_balances` est le registre courant verrouillé pendant chaque comptabilisation. Une transaction annulée ne modifie aucun des deux.

FEFO ne considère que les lots au statut `RELEASED`, non périmés et disposant d’une quantité non réservée. Les lots en quarantaine, bloqués ou rejetés restent visibles mais ne peuvent pas être consommés.

Pour la production, FEFO peut parcourir tous les emplacements actifs de l’entrepôt choisi. Chaque ligne de sortie conserve l’emplacement et le coût unitaire du lot consommé. Le coût réel du produit fini reste ainsi reproductible même si le CUMP évolue ensuite.

## Traçabilité prévue

```text
Lot fournisseur
→ réception fournisseur et commande d’achat
→ emplacement
→ consommation de production
→ ordre de fabrication
→ lot de produit fini
→ contrôle qualité et décision de lot
→ livraison
→ client
→ retour client éventuel
→ lot distinct en quarantaine et contrôle qualité
```

## Facturation et règlements

Tables principales :

- `financial_accounts` ;
- `customer_invoices`, `customer_invoice_lines`, `customer_credit_notes` ;
- `supplier_invoices`, `supplier_invoice_lines`, `supplier_credit_notes` ;
- `customer_payments`, `customer_payment_allocations`, `customer_payment_reminders` ;
- `supplier_payments`, `supplier_payment_allocations`.

Les liens uniques entre livraison et facture client, ainsi qu’entre réception et facture fournisseur, empêchent la double facturation. Les affectations sont distinctes des règlements afin de prendre en charge le partiel et le multi-factures. Les règlements comptabilisés annulés sont conservés avec motif, auteur et date.

## Registre des modules v0.12.0

Tables principales :

- `application_modules` : code, version, état, caractère socle, empreinte du manifeste et dates d’activation ;
- `application_module_dependencies` : graphe orienté des dépendances obligatoires.

La désactivation ne supprime aucune donnée métier. Les changements d’état sont historisés dans `audit_logs`.


## Reporting v0.13.0

- `report_schedules` conserve les programmations par utilisateur, le rapport, la fréquence, le périmètre et la prochaine échéance.
- `report_runs` conserve chaque exécution, son statut, sa période, son fichier privé et l’erreur éventuelle.
- Les indicateurs sont calculés à la demande depuis les tables métier ; aucune table de synthèse comptable parallèle n’est alimentée.
