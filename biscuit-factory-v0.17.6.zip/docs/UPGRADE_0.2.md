# Mise à niveau de la v0.1.0 vers la v0.2.0

## 1. Sauvegarder

```bash
bash scripts/backup.sh
```

Conserver également le fichier `.env` actuel hors du dossier remplacé.

## 2. Installer la nouvelle version

Extraire la v0.2.0 dans un nouveau dossier, puis recopier uniquement le `.env` de l’ancienne installation. Ne pas recopier `vendor`, `node_modules` ou `public/build`.

```bash
docker compose build
docker compose run --rm app composer install
docker compose run --rm vite npm ci
docker compose up -d
```

## 3. Mettre à jour la base

```bash
docker compose exec app php artisan migrate --force
docker compose exec app php artisan db:seed --class=RolePermissionSeeder --force
docker compose exec app php artisan db:seed --class=ReferenceDataSeeder --force
docker compose exec app php artisan optimize:clear
```

La migration v0.2.0 ajoute le marqueur `system` aux permissions. Les seeders identifient ensuite les permissions fournies par l’application et complètent les listes dynamiques sans supprimer les rôles personnalisés ni les utilisateurs.

## 4. Valider

```bash
docker compose exec app php artisan test
docker compose exec app vendor/bin/pint --test
bash scripts/healthcheck.sh
```

Vérifier ensuite : connexion administrateur, menu latéral, écran Sociétés, changement FR/AR/EN, RTL arabe et mode sombre.

## Retour arrière

Arrêter la v0.2.0, redémarrer le dossier v0.1.0 avec son `.env`, puis restaurer la sauvegarde créée à l’étape 1. Ne pas exécuter `migrate:rollback` sur une base de production sans sauvegarde validée.
