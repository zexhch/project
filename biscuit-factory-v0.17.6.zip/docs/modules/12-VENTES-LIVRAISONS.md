# Ventes, réservations et livraisons

## Objectif

Le module couvre le cycle commercial depuis le tarif jusqu’à la traçabilité de la livraison et du retour client :

```text
Client et conditions commerciales
→ devis
→ commande client
→ confirmation
→ réservation automatique FEFO
→ préparation d’une livraison totale ou partielle
→ expédition et sortie de stock
→ retour éventuel en quarantaine
→ contrôle qualité
```

Les prix, remises, taxes, conversions et adresses sont copiés dans le document. Une modification ultérieure du tarif ou de la fiche client ne modifie donc jamais une ancienne commande.

## Profils et permissions

| Profil | Responsabilités principales |
|---|---|
| Commercial | clients, devis, commandes et préparation commerciale |
| Responsable commercial | mêmes opérations, plus approbation des tarifs, confirmation et annulation des commandes |
| Magasinier | consultation, préparation physique et comptabilisation des expéditions/retours |
| Responsable qualité | contrôle et décision sur les lots issus de retours |
| Direction / Finance | consultation, approbation et export selon les permissions |

Permissions :

- `sales.view` : consulter les registres et documents ;
- `sales.create` : créer clients, devis, commandes, livraisons et retours ;
- `sales.update` : compléter les documents et lancer les réservations ;
- `sales.approve` : approuver les tarifs et confirmer/annuler les commandes ;
- `sales.export` : exporter les clients et commandes ;
- `stocks.approve` : comptabiliser une expédition ou un retour, car cette opération modifie le stock.

## Clients

La fiche client comprend :

- société propriétaire et code interne unique ;
- raison sociale et identifiants légaux ;
- groupe client et canal de vente ;
- devise, délai de paiement et plafond de crédit ;
- adresses de facturation et de livraison ;
- contacts et contact principal ;
- statut de qualification et historique commercial.

Le délai de paiement et le plafond de crédit prépareront la facturation. Dans le futur module financier, une facture pourra recevoir plusieurs règlements partiels ; son solde restera ouvert jusqu’à affectation de la totalité du montant dû.

Cycle de qualification :

```text
PROSPECT → APPROVED → SUSPENDED ou BLOCKED
```

Seul un client actif et approuvé peut avoir un devis envoyé ou une commande soumise.

## Tarifs de vente

Une liste de prix peut viser exactement un périmètre :

1. un client précis ;
2. un groupe de clients ;
3. un canal de vente ;
4. tous les clients si aucun périmètre n’est renseigné.

Le moteur cherche le prix dans cet ordre de spécificité, puis applique la priorité la plus faible et enfin le palier de quantité le plus élevé compatible.

Chaque palier enregistre : article, unité, facteur vers l’unité de stock, quantité minimale, prix unitaire, remise, taxe et marge cible informative.

Exemple livré : tarif `TV-DIST-2026` pour le groupe `DISTRIBUTOR`.

| Article | Quantité minimale | Prix HT |
|---|---:|---:|
| `PF-BIS-CHOC` | 0 kg | 420 DZD/kg |
| `PF-BIS-CHOC` | 100 kg | 395 DZD/kg |

Une ligne de 60 kg utilise 420 DZD/kg. Une ligne de 100 kg utilise 395 DZD/kg.

## Devis

1. Créer le devis et renseigner les informations essentielles.
2. Ajouter les articles. Laisser le prix vide pour utiliser le tarif applicable. Une ligne erronée peut être retirée tant que le devis reste en brouillon ; les totaux sont recalculés immédiatement.
3. Marquer le devis comme envoyé.
4. Enregistrer son acceptation.
5. Convertir le devis accepté en commande brouillon.

Cycle :

```text
DRAFT → SENT → ACCEPTED → CONVERTED
                 └──────→ REJECTED / EXPIRED
```

La conversion recopie les lignes et conditions sans recalculer les anciens prix.

## Commande et réservation

Une commande directe ou issue d’un devis suit le cycle :

```text
DRAFT → SUBMITTED → CONFIRMED
                    ↓
          PARTIALLY_RESERVED → RESERVED
                    ↓
          PARTIALLY_DELIVERED → DELIVERED
```

La confirmation déclenche la réservation automatique :

- uniquement dans l’entrepôt de la commande ;
- uniquement dans les emplacements actifs non placés en quarantaine ;
- uniquement pour les lots `RELEASED` et non périmés ;
- dans l’ordre FEFO, donc la péremption la plus proche en premier ;
- sous verrou transactionnel pour empêcher une double réservation concurrente.

Le stock physique ne diminue pas lors de la réservation. Le champ `reserved_quantity` réduit uniquement la quantité disponible. Une annulation libère les réservations non affectées à une livraison préparée.

Avant soumission, les lignes d’une commande brouillon peuvent être retirées sans recréer le document. Cette correction est auditée et recalcule les montants.

## Livraison partielle

Depuis la commande, sélectionner seulement les quantités expédiées aujourd’hui. Le système transforme les réservations en affectations de lots et crée un bon de livraison `PICKED`.

La comptabilisation du bon :

- vérifie à nouveau les réservations et les lots ;
- crée une sortie de stock `ISSUE` par lot et emplacement ;
- diminue le stock physique et le stock réservé dans la même transaction ;
- met à jour les quantités livrées de chaque ligne ;
- fait évoluer la commande vers `PARTIALLY_DELIVERED` ou `DELIVERED` ;
- conserve le coût moyen du lot dans l’affectation de livraison ;
- enregistre l’audit et actualise le tableau de bord après validation.

Une livraison préparée ne peut pas consommer une réservation déjà affectée à un autre bon.

## Retour client

Un retour est saisi depuis une livraison comptabilisée et par affectation de lot. La quantité totale retournée ne peut jamais dépasser la quantité expédiée, après déduction des retours déjà comptabilisés.

La comptabilisation :

1. impose un emplacement de quarantaine dans l’entrepôt de la livraison ;
2. crée un nouveau lot de retour distinct du lot commercial initial ;
3. conserve dans ses attributs le lot source et l’affectation de livraison ;
4. crée une entrée de stock valorisée au coût de l’expédition ;
5. planifie un contrôle `CUSTOMER_RETURN` depuis le plan `PCQ-RETOUR-CLIENT` ;
6. maintient le lot au statut `QUARANTINE` jusqu’à la décision qualité.

Un retour n’est jamais remis automatiquement dans le stock vendable.

## Exemple reproductible

Après `php artisan migrate --seed` :

1. Ouvrir **Ventes > Clients** et consulter `CLI-DIST-001 — Distribution El Bahja`.
2. Ouvrir **Ventes > Tarifs de vente** puis `TV-DIST-2026` et ses deux paliers.
3. Consulter le devis `DEV-DEMO-001`, déjà envoyé, puis l’accepter et le convertir si souhaité.
4. Ouvrir la commande `CV-DEMO-001`, soumise pour 60 kg de `PF-BIS-CHOC`.
5. Cliquer sur **Confirmer et réserver** : les 60 kg sont affectés au lot libéré `LOT-BISCUIT-DEMO`.
6. Préparer une livraison de 20 kg, puis la comptabiliser avec un compte ayant `stocks.approve`.
7. Vérifier que la commande est partiellement livrée et que 40 kg restent réservés.
8. Depuis le bon de livraison, créer un retour de 5 kg vers `QUARANTAINE`.
9. Comptabiliser le retour et ouvrir le contrôle qualité automatiquement créé.

Ne pas rejouer `SalesDemoDataSeeder` sur une base de production : il remet les documents d’exemple dans leur état initial.

## Contrôles principaux

- cohérence société, client, site, entrepôt, devise et taxe ;
- un seul périmètre par liste de prix ;
- dates de validité et priorité des tarifs ;
- quantités et facteurs de conversion strictement positifs ;
- prix HT/TTC et devise identiques entre tarif et document ;
- transitions de statut protégées côté serveur ;
- réservation sans stock négatif ni lot bloqué/périmé ;
- absence de double affectation d’une réservation ;
- livraison limitée au solde commandé et réservé ;
- retour limité au détail réellement expédié ;
- quarantaine et contrôle qualité obligatoires pour les retours.

## Tables principales

- `customers`, `customer_contacts` ;
- `sales_price_lists`, `sales_price_list_lines` ;
- `sales_quotations`, `sales_quotation_lines` ;
- `sales_orders`, `sales_order_lines` ;
- `stock_reservations` ;
- `delivery_notes`, `delivery_note_lines`, `delivery_allocations` ;
- `customer_returns`, `customer_return_lines`.
