# Productivité, imports et échanges de données

## Objectif

Le module `productivity` accélère les opérations répétitives sans dupliquer les données métier. Il s’appuie sur les articles, leurs conditionnements, les clients, les fournisseurs et les documents existants.

## Fonctions livrées

- import CSV UTF-8 ou XLSX des articles, clients, fournisseurs et conditionnements d’articles ;
- modèles CSV/XLSX téléchargeables ;
- prévisualisation ligne par ligne avant toute écriture ;
- modes `UPDATE`, `SKIP` et `FAIL` pour les enregistrements existants ;
- rapport XLSX des lignes invalides ou échouées ;
- traitements Horizon sur les files `imports` et `exports`, avec notification de fin ou d’échec ;
- export CSV/XLSX des mêmes référentiels ;
- actions groupées d’activation, désactivation et restauration ;
- duplication contrôlée des devis, commandes clients, demandes d’achat et commandes fournisseurs ;
- recherche globale dans les articles, tiers et documents autorisés ;
- favoris et raccourcis individuels.

## Workflow d’import

1. Sélection du type de données et, si nécessaire, de la société.
2. Téléchargement du modèle attendu.
3. Chargement du fichier et choix du comportement sur les doublons.
4. Prévisualisation et validation de chaque ligne.
5. Correction du fichier si des erreurs sont détectées.
6. Confirmation explicite de l’import.
7. Traitement asynchrone par Horizon.
8. Notification et consultation du bilan final.

Aucune ligne invalide n’est écrite. L’option d’arrêt à la première erreur permet d’interrompre un traitement confirmé si une anomalie apparaît pendant la persistance.

## Conditionnements d’articles

Le catalogue `item-packagings` importe la hiérarchie unité parente/facteur, les données logistiques, codes-barres, rôles achat/vente/production/inventaire, périodes de validité et états. Le parent doit être importé avant son enfant. La persistance passe par le même service métier que l’interface afin d’appliquer les contrôles de cycle, d’unicité et d’historisation.

## Sécurité

Le droit `productivity.*` ne remplace jamais les permissions du domaine source :

- articles : `catalog.view` / `catalog.update` ;
- clients : `sales.view` / `sales.update` ;
- fournisseurs : `purchasing.view` / `purchasing.update`.

Ces permissions sont revérifiées à l’ouverture, à la prévisualisation, à l’export et dans les jobs Horizon. Les fichiers sont stockés sur le disque privé `local`.

## Règles techniques

- 10 000 lignes maximum par import ;
- traitement par blocs de 250 lignes ;
- 1 000 codes maximum par action groupée ;
- protection des exports CSV contre les formules ;
- lecture/écriture XLSX native via `ZipArchive`, sans bibliothèque externe ;
- les duplications génèrent un nouveau numéro légal et remettent le document au statut brouillon ;
- aucune réservation, livraison, réception ou validation n’est recopiée.

## Exploitation

```bash
php artisan productivity:process-import <uuid>
php artisan productivity:prune --days=30
```

Les files `imports` et `exports` disposent de leur propre superviseur Horizon afin de ne pas bloquer les notifications, rapports ou traitements métier.
