# Gouvernance financière et documentaire

## Objectif

Le module Finance encadre les documents commerciaux et financiers sans créer de registre parallèle. Il ajoute les périodes comptables, la numérotation légale, les circuits d'approbation, les contre-documents, les modèles imprimables et l'historique immuable des versions.

## Périmètre documentaire

- devis et commandes clients ;
- bons de livraison ;
- demandes d'achat, commandes fournisseurs et bons de réception ;
- factures et avoirs clients/fournisseurs ;
- règlements clients/fournisseurs.

## Périodes comptables

Chaque société dispose de périodes mensuelles. Une période peut être ouverte, clôturée ou rouverte avec motif et permission dédiée. La création, l'émission, l'approbation, l'annulation et la comptabilisation des documents financiers sont refusées sur une période clôturée.

La clôture conserve un instantané des éléments de contrôle. Une clôture forcée est réservée aux utilisateurs autorisés et reste auditée.

## Numérotation légale

Les séquences sont définies par société et type de document. Elles acceptent les variables `{COMPANY}`, `{PREFIX}`, `{YEAR}`, `{YY}`, `{MONTH}` et `{NUMBER}`, avec remise à zéro annuelle, mensuelle ou jamais. L'attribution est transactionnelle et verrouillée afin d'éviter les doublons en concurrence.

## Approbations multi-niveaux

Un workflow de facture client ou fournisseur peut être configuré par société, devise et seuil. Chaque niveau définit :

- l'ordre de passage ;
- une permission et éventuellement un rôle ;
- le nombre minimal de validations ;
- une plage de montant.

Une facture soumise reste `PENDING_APPROVAL` jusqu'à la dernière validation. Un rejet la place à l'état `REJECTED` et autorise une nouvelle soumission après correction.

## Annulations et contre-écritures

Une facture émise ne peut pas être supprimée. Son annulation produit un avoir de contrepartie, une fiche d'annulation et une révision immuable. Une facture ayant déjà reçu un règlement ne peut pas être annulée directement.

## Modèles et impression

Les modèles sont configurables par société, type de document et langue. Ils contrôlent le titre, l'en-tête, les conditions, le pied de page, les informations société et les blocs de signature. Les vues A4 sont imprimables en PDF depuis le navigateur.

## Historique

Les créations, modifications, impressions, soumissions, décisions et annulations créent des révisions numérotées contenant un instantané JSON du document et de ses lignes. Le journal d'audit demeure la source des événements techniques et de sécurité.

## Permissions

- `finance.view` : consultation de la gouvernance et des impressions financières ;
- `finance.create` : création des paramètres et documents ;
- `finance.update` : périodes, séquences, modèles et workflows ;
- `finance.approve` : décisions, clôtures et réouvertures ;
- permissions Ventes/Achats correspondantes pour imprimer leurs documents.
