# Recettes et production

## Utilisateurs

- Responsable production : crée les recettes, prépare les versions et planifie les OF.
- Direction ou utilisateur autorisé : approuve les versions de recette.
- Opérateur : démarre et termine les OF.
- Magasinier et qualité : suivent les lots, mouvements et contrôles générés.

## Créer une recette

1. Ouvrir **Production → Recettes**.
2. Cliquer sur **Nouvelle recette**.
3. Saisir un code, un nom et sélectionner le produit fini.
4. Créer la première version avec la quantité de référence et le rendement attendu.
5. Dans l’onglet **Ingrédients**, ajouter les matières, emballages ou semi-finis.
6. Dans l’onglet **Gamme**, sélectionner le processus et définir la période de validité.
7. Vérifier l’onglet **Coûts**, puis approuver la version.

Une version approuvée est figée. Pour modifier la formule, utiliser **Dupliquer**, corriger la nouvelle version brouillon, puis l’approuver. L’ancienne version devient archivée et les OF existants continuent de la référencer.

## Exemple reproductible

La base de démonstration fournit `REC-BIS-CHOC`, version 1 :

- lot de référence : 100 kg ;
- rendement attendu : 96 % ;
- matières : farine, sucre, matière grasse, cacao et sel ;
- emballages : film et cartons ;
- gamme : pesée, pétrissage, façonnage, cuisson, refroidissement, contrôle, conditionnement et stockage.

Pour préparer une version 2, dupliquer la version 1, modifier par exemple le cacao, vérifier le nouveau prix de revient, puis faire approuver la version.

## Exécuter un ordre de fabrication

1. Ouvrir **Production → Ordres de fabrication**.
2. Créer un OF depuis une version approuvée.
3. Choisir l’entrepôt source et démarrer.
4. Le système sélectionne automatiquement, pour chaque ingrédient, les emplacements et lots libérés selon FEFO.
5. Saisir les charges réelles utiles avant la clôture.
6. Déclarer le lot fini, la quantité produite et les rejets.
7. Le conforme entre en quarantaine, un contrôle qualité est créé et le prix de revient réel est affecté au lot.

## Règles de gestion

- Seules les versions `APPROVED` alimentent un nouvel OF.
- Les besoins sont proportionnels à la quantité conforme prévue, au rendement attendu et au pourcentage de perte de chaque ligne.
- Une même matière ne peut apparaître qu’une fois dans une version.
- FEFO ignore les lots en quarantaine, bloqués, rejetés ou périmés.
- Les consommations et entrées de stock sont atomiques.
- La quantité conforme est la quantité produite moins les rejets.
- Les versions utilisées et les coûts figés ne sont jamais recalculés silencieusement.

## Tables et permissions

Tables principales : `recipes`, `recipe_versions`, `recipe_lines`, `process_templates`, `process_steps`, `production_orders`, `production_consumptions`, `production_outputs` et `production_losses`.

Permissions : `production.view`, `production.create`, `production.update` et `production.approve`.
