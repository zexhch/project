# Prix de revient

## Objectif

Le module calcule deux valeurs complémentaires :

- **théorique** : standard estimé depuis la version de recette et les CUMP courants ;
- **réel** : coût constaté depuis les lots effectivement consommés, les charges saisies et la quantité conforme produite.

## Coût théorique

Pour chaque ingrédient :

```text
Quantité valorisée = quantité recette × (1 + perte prévue %) × conversion vers l’unité de stock
Coût ingrédient = quantité valorisée × CUMP courant
```

Les charges de transformation acceptent trois modes :

- `QUANTITY` : quantité × coût unitaire, par exemple 8 heures × 600 DZD ;
- `FIXED` : montant fixe par lot ;
- `PERCENTAGE` : pourcentage du sous-total, généralement pour les frais indirects.

La quantité conforme théorique tient compte du rendement :

```text
Sortie conforme attendue = quantité de référence × rendement attendu %
Prix de revient théorique = coût théorique total ÷ sortie conforme attendue
```

## Coût réel

Au démarrage de l’OF, chaque ligne de sortie mémorise le CUMP du lot et de l’emplacement consommés. Les évolutions futures du stock ne changent donc pas le coût historique.

Avant de terminer l’OF, l’utilisateur peut saisir : heures de main-d’œuvre, heures machine, énergie, sous-traitance, frais indirects ou autres charges. À la clôture :

```text
Prix de revient réel = matières et emballages consommés + charges réelles
                       ─────────────────────────────────────────────────
                                  quantité conforme produite
```

Ce prix est enregistré dans l’historique et utilisé comme coût d’entrée du lot fini.

## Exemple Biscuit chocolat

La recette de démonstration contient :

- 55 kg de farine, 20 kg de sucre, 12 kg de matière grasse, 10 kg de cacao et 3 kg de sel ;
- 2 kg de film et 50 cartons ;
- 8 unités de main-d’œuvre à 600 DZD ;
- 3 unités machine à 1 200 DZD ;
- 120 unités d’énergie à 15 DZD ;
- 5 % de frais indirects.

Les valeurs sont pédagogiques et doivent être adaptées aux unités, tarifs et consommations réels de l’usine.

## Alertes et contrôles

- Un CUMP absent produit une alerte visible et un montant nul pour la ligne concernée.
- Une conversion d’unité absente empêche de valoriser correctement la quantité et déclenche une alerte.
- Une charge dans une devise différente n’est pas additionnée silencieusement.
- Les charges réelles deviennent non modifiables lorsque l’OF est terminé.
- Un recalcul crée un nouvel instantané ; il n’efface pas l’historique.

## Tables et permissions

- `recipe_cost_components` : charges standard de la version ;
- `production_cost_entries` : charges réelles de l’OF ;
- `cost_calculations` : instantanés et détail des calculs.

La préparation des charges suit `production.update`. La consultation et l’enregistrement des calculs suivent les permissions `finance.*`.
