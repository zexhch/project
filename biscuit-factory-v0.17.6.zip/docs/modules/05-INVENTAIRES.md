# Inventaires

## Workflow

1. Créer un inventaire pour un entrepôt.
2. Geler le théorique : les lignes article/lot/emplacement sont copiées.
3. Effectuer le comptage, éventuellement à l’aveugle.
4. Enregistrer toutes les quantités comptées.
5. Comptabiliser : les écarts produisent un mouvement d’ajustement.

## Règles

- Le gel ne modifie jamais le stock.
- Toutes les lignes doivent être comptées avant validation.
- Les écarts nuls ne créent aucune ligne de mouvement.
- L’ajustement et le passage à `POSTED` appartiennent à la même transaction.
- L’inventaire comptabilisé devient une pièce de traçabilité non modifiable.

## Tables et permissions

`inventory_counts`, `inventory_count_lines`, puis journal stock. Permissions `stocks.*`.
