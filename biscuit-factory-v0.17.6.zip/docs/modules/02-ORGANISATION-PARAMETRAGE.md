# Organisation et paramétrage

## Périmètre

Sociétés, sites, entrepôts, emplacements, langues, devises, taxes, paramètres système et listes de référence.

## Règles

- Le modèle accepte plusieurs sociétés, sites et entrepôts.
- Les valeurs initiales Algérie/DZD/FR-AR-EN sont des données modifiables.
- L’arabe active automatiquement la mise en page RTL.
- Les paramètres sont typés (`string`, `integer`, `decimal`, `boolean`).
- Les statuts métier sont traduits dans `reference_values` et non dans le code d’interface.
- Une donnée référencée ne peut pas être supprimée ; elle peut être désactivée.

## Tables et permissions

`companies`, `sites`, `warehouses`, `warehouse_locations`, `languages`, `currencies`, `tax_rates`, `system_settings`, `reference_values`. Accès via `settings.*`.
