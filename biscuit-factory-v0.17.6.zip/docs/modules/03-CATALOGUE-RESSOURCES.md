# Catalogue et ressources de production

## Périmètre

Unités, conversions, catégories, articles, lignes, machines et équipes de travail.

## Règles

- Chaque article possède une unité de base et un type configurable.
- La gestion par lot et la péremption se règlent article par article.
- Le stock minimum et la durée de vie alimentent les alertes et les dates de lot.
- Une ligne peut comporter plusieurs machines ordonnées et marquées critiques.
- Les capacités sont exprimées avec une unité explicite.
- Les articles et ressources utilisés sont désactivés plutôt que supprimés.

## Tables et permissions

`units`, `unit_conversions`, `item_categories`, `items`, `production_lines`, `machines`, `production_line_machines`, `work_shifts`. Permissions `catalog.*` et `production.*`.
