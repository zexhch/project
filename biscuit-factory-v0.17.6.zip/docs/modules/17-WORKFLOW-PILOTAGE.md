# Workflow, tâches et alertes

## Objectif

La v0.11.0 transforme les statuts existants en boîte de travail opérationnelle. Les tâches sont calculées depuis les documents métier : aucune tâche ne duplique ni ne remplace le devis, la commande, l’OF, le contrôle ou la facture source.

## Parcours utilisateur

1. L’utilisateur ouvre **Pilotage → Mes tâches**.
2. Les éléments autorisés par ses permissions sont classés par priorité et échéance.
3. L’action **Ouvrir** mène au document et à son **Étape suivante**.
4. La timeline affiche les transitions de statut et les événements d’audit.
5. Une tâche peut être reportée de 1, 3, 7 ou 14 jours, ou masquée puis restaurée.

## Domaines couverts

- Ventes : devis, commandes, réservations, livraisons et encaissements.
- Achats : demandes, validations, consultations, commandes et réceptions.
- Production : lancement et clôture des ordres de fabrication.
- Qualité : mesures, décisions, non-conformités et CAPA.
- Maintenance : lancement et clôture des interventions.
- Finance : émission/approbation des factures et règlements.

## Alertes

Le centre d’alertes consolide les lots proches de péremption, stocks sous seuil, factures échues, dépassements budgétaires, échéances qualité et maintenance. `workflow:notify-alerts` transforme les alertes actives en notifications quotidiennes sans doublon.

## Temps réel

Les compteurs écoutent les canaux privés `users.{id}` et `dashboard`. En cas d’indisponibilité de Reverb, le résumé est relu toutes les 60 secondes ; le parcours reste utilisable sans WebSocket.

## Données

- `workflow_events` : événements de création et transitions de statut.
- `workflow_task_preferences` : reports et masquages propres à chaque utilisateur.
- Les notifications utilisent la table Laravel existante.

## Permissions

L’accès à la boîte de travail requiert `dashboard.view`. Chaque tâche exige en plus la permission réelle de lecture et d’action du domaine concerné. Les actions métier restent protégées par leurs middlewares existants.

## Exploitation

```bash
php artisan workflow:notify-alerts
php artisan schedule:work
```
