# Module 15 — Contrôle de gestion

## Objectif

Le module transforme les coûts de revient de la production en outils de pilotage : centres de coûts, taux historisés, simulations, budgets, écarts et marges commerciales.

## Accès

Menu **Finance et contrôle de gestion → Contrôle de gestion**.

Permissions utilisées :

- `finance.view` : consultation ;
- `finance.create` : création des centres, taux, scénarios et budgets ;
- `finance.update` : rattachement des ressources, recalculs et modification des hypothèses ;
- `finance.approve` : approbation des scénarios et budgets.

## 1. Centres de coûts

Un centre de coûts appartient à une société et peut être limité à un site. Il possède :

- un code et un nom ;
- un type configurable ;
- une méthode d’imputation configurable ;
- un responsable ;
- des lignes de production et machines rattachées ;
- un historique de taux horaires.

Les types, méthodes d’imputation et types de taux sont gérés dans les listes de valeurs. Aucune valeur métier n’est codée en dur dans les formulaires.

### Taux historisés

Chaque taux comporte un type, un montant, une devise et une période de validité. La création d’une nouvelle période ne modifie pas les taux historiques.

## 2. Simulations de coûts

Une simulation permet de tester une hypothèse sans modifier une recette approuvée.

Pour chaque produit, l’utilisateur saisit :

- la quantité prévue ;
- le prix de vente unitaire ;
- une version de recette, ou laisse l’application sélectionner la dernière version approuvée ;
- les variations de matières, conversion et frais généraux.

Le moteur reprend le coût théorique unitaire, applique les variations par famille et calcule :

- coût unitaire simulé ;
- chiffre d’affaires prévisionnel ;
- coût prévisionnel ;
- marge et taux de marge.

Un scénario doit être recalculé avant approbation. Une fois approuvé, ses hypothèses sont verrouillées.

## 3. Budgets et écarts

Une ligne budgétaire est définie par :

- société ;
- centre de coûts facultatif ;
- exercice et période mensuelle ou annuelle ;
- catégorie de coût ;
- montant budgété.

Le réalisé est recalculé depuis les données existantes :

- calculs de coûts réels des ordres de fabrication ;
- coûts de main-d’œuvre et pièces des ordres de maintenance terminés ;
- rattachement des lignes et machines aux centres de coûts.

L’écart est calculé comme `budget - réalisé`. Un montant négatif signale un dépassement.

## 4. Analyse des marges

La vue d’ensemble calcule les marges par client et par produit à partir des commandes commerciales non annulées.

Règle de coût :

1. dernier coût réel disponible du produit ;
2. à défaut, dernier coût théorique enregistré ;
3. à défaut, coût nul avec absence de coût visible dans les données sources.

Pour une commande partiellement livrée, la quantité livrée nette des retours est utilisée. Sinon, la quantité commandée est utilisée comme estimation.

## Workflow recommandé

1. Créer les centres de coûts.
2. Rattacher les lignes de production et les machines.
3. Saisir les taux horaires avec leurs dates de validité.
4. Créer le budget annuel ou mensuel.
5. Produire et enregistrer les coûts réels.
6. Actualiser les budgets pour calculer les écarts.
7. Créer des simulations avant une évolution de prix ou de recette.
8. Analyser les marges par client et produit.

## Tables

- `cost_centers`
- `cost_center_rates`
- `cost_scenarios`
- `cost_scenario_lines`
- `management_budgets`

Les tables `production_lines` et `machines` reçoivent également une référence facultative vers `cost_centers`.
