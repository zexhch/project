# Documentation fonctionnelle par module

Chaque fiche décrit le périmètre livré, les utilisateurs, le workflow, les règles de gestion, les données et les permissions.

1. [Administration et sécurité](01-ADMINISTRATION-SECURITE.md)
2. [Organisation et paramétrage](02-ORGANISATION-PARAMETRAGE.md)
3. [Catalogue et ressources](03-CATALOGUE-RESSOURCES.md)
4. [Stocks et lots](04-STOCKS-LOTS.md)
5. [Inventaires](05-INVENTAIRES.md)
6. [Recettes et production](06-RECETTES-PRODUCTION.md)
7. [Arrêts et maintenance](07-ARRETS-MAINTENANCE.md)
8. [Temps réel, alertes et audit](08-TEMPS-REEL-AUDIT.md)
9. [Qualité, HACCP et non-conformités](09-QUALITE-HACCP.md)
10. [Achats et fournisseurs](10-ACHATS-FOURNISSEURS.md)
11. [Interface Select2 et DataTables](11-INTERFACE-SELECT2-DATATABLES.md)
12. [Ventes, réservations et livraisons](12-VENTES-LIVRAISONS.md)
13. [Ergonomie et parcours utilisateur](13-ERGONOMIE-APPLICATION.md)
14. [Prix de revient](14-PRIX-DE-REVIENT.md)
15. [Contrôle de gestion](15-CONTROLE-GESTION.md)
16. [Facturation et règlements](16-FACTURATION-REGLEMENTS.md)
17. [Workflow, tâches et alertes](17-WORKFLOW-PILOTAGE.md)
18. [Modularisation technique](18-MODULARISATION.md)
19. [Rapports et pilotage](19-RAPPORTS-PILOTAGE.md)
20. [Gouvernance financière et documentaire](20-GOUVERNANCE-DOCUMENTAIRE.md)
21. [Productivité, imports et échanges](21-PRODUCTIVITE-ECHANGES.md)

Les référentiels, seuils et statuts sont administrables. Les codes système utilisés par les workflows doivent rester stables ; leurs libellés FR/EN/AR restent configurables.
