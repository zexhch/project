# Arrêts et maintenance

## Arrêts

Un utilisateur choisit ligne, machine éventuelle, cause et niveau d’impact. Le démarrage mémorise l’heure et place la machine à l’arrêt. La clôture calcule `duration_seconds` côté serveur et rétablit la disponibilité si aucun autre arrêt n’est actif.

## Interventions

1. Créer ou générer un ordre préventif/correctif.
2. Affecter l’équipement, la priorité, l’échéance et l’intervenant.
3. Démarrer l’intervention ; la machine passe en maintenance.
4. Journaliser chaque action et son résultat.
5. Consommer les pièces : une sortie FEFO est comptabilisée dans le stock.
6. Clôturer avec constat, cause, résolution et coût de main-d’œuvre.

## Préventif et alertes

La commande `maintenance:generate-orders`, planifiée chaque jour à 05:00, génère un seul ordre ouvert par plan arrivé à échéance et calcule l’échéance suivante. Les fenêtres d’alerte et d’indicateurs sont configurables.

## Indicateurs

- MTTR : durée totale des arrêts non planifiés / nombre de pannes.
- MTBF : temps disponible / nombre de pannes.
- Disponibilité : `(période - arrêts non planifiés) / période`.

## Tables et permissions

`downtime_reasons`, `production_downtimes`, `maintenance_plans`, `maintenance_work_orders`, `maintenance_actions`, `maintenance_parts`. Permissions `maintenance.*`.
