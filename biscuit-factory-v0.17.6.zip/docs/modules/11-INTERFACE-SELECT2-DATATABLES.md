# Interface Select2 et DataTables

## Objectif

Depuis la v0.7.0, les listes déroulantes et tableaux de l’application bénéficient d’un comportement homogène :

- Select2 pour rechercher rapidement une option dans les formulaires ;
- DataTables pour rechercher, trier, paginer et adapter les tableaux aux petits écrans ;
- libellés français, anglais et arabe ;
- thèmes clair/sombre et mise en page RTL ;
- réinitialisation automatique après une mise à jour Livewire.

## Comportement automatique

Tout élément suivant est enrichi automatiquement :

```html
<select class="form-select">...</select>
<table class="table">...</table>
```

Select2 affiche la recherche à partir de huit options, ou immédiatement avec :

```html
<select class="form-select" data-select2-search="true">...</select>
```

Un composant particulier peut être exclu :

```html
<select class="form-select" data-select2="false">...</select>
<table class="table" data-datatable="false">...</table>
```

## Modes DataTables

| Mode | Comportement |
|---|---|
| `client` | recherche, tri, pagination, nombre de lignes et informations côté navigateur |
| `server-rendered` | tri visuel et responsive, sans doubler la pagination Laravel |
| `form` | tableau de saisie, sans pagination, recherche ni tri |

Le mode est détecté automatiquement : présence d’une pagination Laravel, puis présence de champs de formulaire. Il peut être imposé :

```html
<table class="table" data-datatable-mode="server-rendered">
```

Options utiles :

```html
<table
    class="table"
    data-datatable-page-length="50"
    data-datatable-ordering="false"
    data-datatable-responsive="false"
>
```

Les lignes vides utilisant un `colspan` ne sont pas initialisées afin de préserver les états vides Blade.

## Livewire

Les widgets sont détruits avant le retrait d’un fragment Livewire et réinitialisés après le morphing. Un observateur DOM sert de garde-fou pour les composants ajoutés dynamiquement.

Un composant JavaScript spécifique peut demander une réinitialisation :

```javascript
document.dispatchEvent(new CustomEvent('biscuit-factory:refresh-ui', {
    detail: { root: document.querySelector('#mon-composant') },
}));
```

Select2 retransmet ses changements au champ HTML natif afin que les formulaires classiques et Livewire reçoivent la valeur.

## Traductions et accessibilité

Les textes sont fournis par `lang/{fr,en,ar}/ui.php` puis exposés au frontend par le layout principal. La direction provient de l’attribut `dir` du document.

Les libellés et éléments `<label>` restent obligatoires : Select2 et DataTables améliorent l’interaction mais ne remplacent pas la structure accessible du formulaire ou du tableau.

## Dépendances

- jQuery 3.7 ;
- Select2 4.0.13, conservé pour la compatibilité avec Node.js 22 utilisé dans Docker ;
- DataTables 2.3 avec intégration Bootstrap 5 ;
- extension DataTables Responsive 3.0.

Après toute modification frontend :

```powershell
docker compose run --rm vite npm ci
docker compose run --rm vite npm run build
```

Le dossier `public/build` compilé est inclus dans l’archive ; `node_modules` ne l’est pas.

