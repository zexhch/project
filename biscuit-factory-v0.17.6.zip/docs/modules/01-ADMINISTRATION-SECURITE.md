# Administration et sécurité

## Objectif et écrans

Gérer les comptes, rôles, permissions et consulter le journal d’audit. Les écrans sont accessibles depuis la navigation Administration.

## Workflow

1. Créer un utilisateur actif et choisir sa langue.
2. Affecter un ou plusieurs rôles.
3. Adapter les permissions des rôles si nécessaire.
4. Contrôler les changements dans le journal d’audit.

## Règles

- L’authentification repose sur une session sécurisée et un mot de passe haché.
- Toutes les routes métier vérifient une permission côté serveur.
- Le compte connecté ne peut pas se supprimer ni retirer son propre accès.
- Les identités techniques des rôles et permissions système sont protégées.
- Les créations, modifications, suppressions et validations sensibles sont auditées.

## Permissions

`users.*` gère utilisateurs, rôles et permissions ; `settings.*` gère le paramétrage. Les actions disponibles sont `view`, `create`, `update`, `delete`, `approve` et `export`.

## Tables

`users`, `roles`, `permissions`, `role_user`, `permission_role`, `audit_logs`.
