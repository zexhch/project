# Achats et fournisseurs

## Objectif

Le module couvre le cycle allant de l’expression du besoin jusqu’à la réception, au contrôle qualité et au retour éventuel au fournisseur :

```text
Demande d’achat
→ consultation de plusieurs fournisseurs
→ sélection d’une offre
→ commande d’achat
→ réception en quarantaine
→ mouvement de stock et contrôle qualité
→ retour fournisseur éventuel
→ évaluation du fournisseur
```

Les prix, quantités, conversions, taxes et coûts sont enregistrés sur les documents afin de préserver l’historique, même si un tarif change ensuite.

## Utilisateurs et permissions

| Profil | Responsabilités principales |
|---|---|
| Acheteur | fournisseurs, demandes, offres, tarifs et préparation des commandes |
| Responsable achats | mêmes opérations, plus approbation des demandes, tarifs, fournisseurs et commandes |
| Magasinier | consultation des commandes, création des réceptions et comptabilisation du stock |
| Responsable qualité | contrôles de réception et décision de libération, blocage ou rejet du lot |
| Direction / Finance | consultation, validation selon les rôles et export |

Permissions utilisées :

- `purchasing.view` : consulter les registres et documents ;
- `purchasing.create` : créer fournisseurs, demandes, offres, commandes, réceptions et retours ;
- `purchasing.update` : ajouter les contacts, articles, lignes et évaluations ;
- `purchasing.approve` : approuver les documents et retenir une offre ;
- `purchasing.export` : exporter les fournisseurs et commandes ;
- `stocks.approve` : comptabiliser une réception ou un retour, car cette action modifie le stock.

## Fiche fournisseur

Une fiche comporte notamment :

- société propriétaire et code interne unique ;
- raison sociale, identifiants fiscal et commercial ;
- pays, devise, délai de paiement et Incoterm ;
- délai d’approvisionnement et minimum de commande ;
- contacts ;
- articles fournis, références fournisseur et unités d’achat ;
- facteur de conversion vers l’unité de stock ;
- historique des commandes, tarifs et évaluations.

### Cycle de qualification

| Statut | Utilisation |
|---|---|
| `PROSPECT` | fournisseur créé mais non encore qualifié |
| `APPROVED` | fournisseur autorisé pour la soumission d’une commande |
| `SUSPENDED` | fournisseur temporairement suspendu |
| `BLOCKED` | fournisseur bloqué et désactivé |

Une commande ne peut être soumise que si le fournisseur est actif et `APPROVED`. Le minimum de commande est contrôlé côté serveur.

## Tarifs d’achat

Une liste de prix définit :

- fournisseur et société ;
- devise ;
- prix HT ou TTC ;
- priorité ;
- période de validité ;
- article et unité d’achat ;
- quantité minimale du palier ;
- prix, remise, taxe et délai indicatif.

Seul un tarif `APPROVED` et valide à la date de commande peut être appliqué. Pour un même article et une même unité, le moteur choisit d’abord la liste ayant la meilleure priorité, puis le palier de quantité le plus élevé qui ne dépasse pas la quantité commandée.

Exemple livré :

| Article | Quantité minimale | Prix unitaire |
|---|---:|---:|
| `MP-FARINE` | 0 kg | 62 DZD |
| `MP-FARINE` | 1 000 kg | 60 DZD |

Une commande de 800 kg utilise 62 DZD/kg. Une commande de 1 000 kg utilise 60 DZD/kg.

## Demandes et consultations

### Demande d’achat

1. Créer la demande avec la société, le site, la date de besoin et la priorité.
2. Ajouter les articles, quantités, unités et éventuellement un fournisseur suggéré.
3. Soumettre la demande.
4. Faire approuver la demande par un utilisateur autorisé.

Une demande vide ne peut pas être soumise. Une offre ne peut être ajoutée qu’après approbation.

### Offre fournisseur

Pour chaque fournisseur consulté, enregistrer :

- référence et date de l’offre ;
- date limite de validité ;
- devise et taux de change ;
- mode HT/TTC ;
- conditions de paiement et délai de livraison ;
- prix, remise et taxe de chaque ligne.

Une ligne de demande ne peut apparaître qu’une fois dans la même offre. La quantité proposée ne peut pas dépasser la quantité demandée. Au moment de retenir une offre, le système verrouille les lignes et interdit de commander plus que le solde restant de la demande.

La sélection crée une commande brouillon et recopie les conditions commerciales. L’offre passe à `SELECTED` et la demande à `ORDERED`.

## Commande d’achat

Une commande peut provenir d’une offre ou être créée directement. Elle est toujours créée en brouillon.

```text
DRAFT → SUBMITTED → APPROVED → PARTIALLY_RECEIVED → RECEIVED
```

Sur une commande directe, laisser le prix vide permet d’utiliser automatiquement le tarif applicable. La devise et le mode HT/TTC du tarif doivent correspondre à la commande.

Le calcul d’une ligne est effectué côté serveur :

```text
brut = quantité × prix unitaire
remise = brut × taux de remise
base HT = brut - remise
taxe = base HT × taux de taxe
total = base HT + taxe
```

Pour un prix TTC, la base HT et la taxe sont extraites du montant TTC. Le prix net, la remise, la taxe et le total sont enregistrés dans la ligne.

## Réception fournisseur

Une réception est rattachée à une commande approuvée ou partiellement reçue.

1. Choisir l’emplacement de destination de l’entrepôt de la commande.
2. Saisir la date et le numéro du bon de livraison fournisseur.
3. Pour chaque ligne, saisir les quantités acceptée et refusée.
4. Pour un article géré par lot, saisir le lot fournisseur et ses dates.
5. Enregistrer la réception brouillon.
6. Faire comptabiliser la réception par un utilisateur ayant `stocks.approve`.

La comptabilisation est atomique :

- verrouillage de la réception, de la commande et des lignes ;
- contrôle du solde restant et de la conversion d’unité ;
- création ou contrôle du lot ;
- création du mouvement de stock `RECEIPT` ;
- mise à jour du stock et du coût moyen pondéré ;
- mise à jour des quantités reçues et du statut de commande ;
- création du contrôle qualité de réception applicable ;
- audit et notification du tableau de bord après validation de la transaction.

Les lots achetés sont créés au statut `QUARANTINE`. Ils ne deviennent utilisables par FEFO qu’après une décision qualité de libération. Une réception déjà comptabilisée ne peut pas être comptabilisée une seconde fois.

## Retours fournisseurs

Un retour est créé depuis une réception comptabilisée. La quantité retournée ne peut pas dépasser la quantité acceptée encore disponible après les retours précédents.

La comptabilisation :

- contrôle le lien réception/article/lot ;
- vérifie le stock disponible dans l’emplacement choisi ;
- crée une sortie de stock `ISSUE` ;
- met à jour la quantité retournée de la commande ;
- inscrit l’audit dans la même transaction.

## Évaluation du fournisseur

Une évaluation couvre une période unique et quatre axes notés de 0 à 100 :

- qualité ;
- respect des délais ;
- conditions commerciales ;
- service.

Le score global est la moyenne des quatre axes. L’historique reste visible sur la fiche fournisseur.

## Exemple reproductible

Les données de démonstration correspondent aux exemples du présent manuel :

1. Ouvrir **Achats > Fournisseurs** et consulter `FOU-MINO-DZ — Minoterie Atlas`.
2. Ouvrir **Achats > Tarifs d’achat** et vérifier `TA-MINO-2026` et ses paliers farine.
3. Ouvrir la demande `DA-DEMO-001` pour comparer `OFF-DEMO-ATLAS` et `OFF-DEMO-AGRO`.
4. Ouvrir la commande `BC-DEMO-001`, approuvée pour 1 000 kg de farine et 500 kg de sucre.
5. Ouvrir la réception brouillon `BR-DEMO-001`, prévue pour 250 kg de farine dans `QUARANTAINE`.
6. Comptabiliser la réception avec un compte disposant de `stocks.approve`.
7. Vérifier le lot `LOT-FARINE-ACHAT-DEMO`, son solde de 250 kg et le contrôle de réception créé depuis `PCQ-MP-FARINE`.
8. Faire saisir les résultats qualité puis prendre la décision de lot dans le module Qualité.

Ne pas rejouer `DemoDataSeeder` dans une base de production : il remet les documents d’exemple dans leur état démonstratif.

## Principaux contrôles et erreurs

- fournisseur, entrepôt, site, tarif et taxe cohérents avec la société ;
- unité d’achat assortie d’un facteur de conversion positif ;
- validité et priorité des tarifs ;
- quantités strictement positives et absence de surcommande ;
- somme acceptée/refusée limitée au reste à livrer ;
- motif obligatoire en cas de refus ;
- lot obligatoire pour les articles gérés par lot ;
- péremption obligatoire pour les articles concernés et postérieure à la fabrication ;
- emplacement rattaché à l’entrepôt du document ;
- stock négatif interdit lors d’un retour ;
- protection de toutes les transitions par permission serveur et audit.

## Tables principales

- `suppliers`, `supplier_contacts`, `supplier_items` ;
- `purchase_price_lists`, `purchase_price_list_lines` ;
- `purchase_requisitions`, `purchase_requisition_lines` ;
- `supplier_quotations`, `supplier_quotation_lines` ;
- `purchase_orders`, `purchase_order_lines` ;
- `goods_receipts`, `goods_receipt_lines` ;
- `supplier_returns`, `supplier_return_lines` ;
- `supplier_evaluations`.

