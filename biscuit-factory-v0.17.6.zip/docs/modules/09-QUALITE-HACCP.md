# Qualité, HACCP et non-conformités

## Objectif

Le module assure la conformité depuis la réception jusqu’au stockage du produit fini. Il relie chaque résultat à l’article, au lot, à l’ordre de fabrication, à la ligne et au plan utilisé. Les décisions restent historisées même si un plan est remplacé par une nouvelle version.

## Rôles et permissions

| Action | Permission | Profil recommandé |
|---|---|---|
| Consulter les registres et télécharger une pièce jointe | `quality.view` | Production, magasin, qualité, direction |
| Créer un plan, un point HACCP, un contrôle ou une non-conformité | `quality.create` | Contrôleur ou responsable qualité |
| Saisir les résultats, analyses et actions | `quality.update` | Contrôleur, propriétaire de l’action |
| Approuver un plan, décider sur un lot, vérifier une action et clôturer | `quality.approve` | Responsable qualité |
| Exporter les données | `quality.export` | Responsable qualité, direction |

La saisie et la décision utilisent deux permissions différentes afin de permettre le principe des quatre yeux.

## Plans de contrôle

Un plan est identifié par un `code` et une `version`. Il peut s’appliquer :

- à un article précis ;
- à une catégorie d’articles ;
- à tous les articles ;
- à une ligne de production ;
- à une étape : réception, en cours, produit fini ou stockage ;
- à une période de validité.

Le plan commence en `DRAFT`. Ses paramètres restent modifiables jusqu’à l’approbation. L’approbation retire automatiquement l’ancienne version approuvée portant le même code.

Chaque paramètre définit un type (`NUMERIC`, `BOOLEAN`, `TEXT` ou `SELECT`), une unité, une méthode, une séquence et son caractère obligatoire ou critique. Un paramètre numérique peut préciser minimum, cible et maximum. Un paramètre booléen ou texte utilise une valeur attendue.

## HACCP

Un point critique associe le danger biologique, chimique, physique ou allergène à une étape du processus. Il documente :

1. le danger ;
2. la mesure de maîtrise ;
3. les limites critiques ;
4. la méthode et la fréquence de surveillance ;
5. l’action corrective ;
6. la méthode de vérification ;
7. le rôle responsable.

Un plan de contrôle peut référencer ce point. Ses limites sont alors visibles pendant le contrôle.

## Workflow d’un contrôle

1. Créer le contrôle ou le laisser être généré par une réception/fin de production.
2. Renseigner chaque paramètre obligatoire. Le système évalue automatiquement `PASS` ou `FAIL`.
3. Soumettre le contrôle : il passe à `PENDING_DECISION`.
4. Un utilisateur possédant `quality.approve` décide :
   - `RELEASE` : contrôle conforme et lot `RELEASED` ;
   - `BLOCK` : contrôle non conforme, lot `BLOCKED` et non-conformité automatique ;
   - `REJECT` : contrôle non conforme, lot `REJECTED` et non-conformité automatique.

Un échec critique interdit toujours `RELEASE`. Une décision défavorable crée une non-conformité majeure ou critique selon les résultats.

## Non-conformités et CAPA

Une non-conformité peut provenir d’un contrôle ou être déclarée manuellement. Une non-conformité majeure ou critique bloque immédiatement le lot lié.

Le traitement suit ces états :

`OPEN` → `ANALYSIS` → `ACTION_PLAN` → `VERIFYING` → `CLOSED`

L’analyse précise la cause racine et la disposition du produit/lot. Chaque action corrective ou préventive possède un propriétaire, une échéance et un critère d’efficacité. Le réalisateur documente l’exécution ; un approbateur différent peut vérifier l’efficacité. La clôture exige une analyse complète, au moins une action et toutes les actions au statut `VERIFIED`.

## Pièces jointes

Les PDF, images, tableurs, CSV et textes sont conservés sur le disque privé configuré par `QUALITY_FILESYSTEM_DISK` (`local` par défaut, S3/MinIO possible). En mode local, les fichiers se trouvent dans `storage/app/private/quality`. Aucun lien public direct n’est créé. Le téléchargement passe par l’application et exige `quality.view`. La taille maximale est contrôlée par le paramètre `quality.attachment_max_mb` (10 Mo par défaut).

## Intégration aux stocks et à la production

- Une réception comptabilisée crée les contrôles actifs de l’étape `RECEIVING`.
- La fin d’un ordre de fabrication crée les contrôles actifs `FINISHED_GOOD`.
- Le lot produit reste en quarantaine jusqu’à la décision qualité.
- FEFO ne sélectionne que les lots `RELEASED`, non périmés et disposant d’une quantité disponible.
- Une sortie explicite d’un lot non libéré est refusée.
- Si un plan approuvé s’applique, l’écran Stocks ne peut pas libérer manuellement le lot sans contrôle conforme.

## Exemple 1 — Libération du biscuit chocolat

Les données de démonstration fournissent :

- article `PF-BIS-CHOC` ;
- lot `LOT-BISCUIT-DEMO` ;
- plan `PCQ-PF-BIS-CHOC` version 1 ;
- point HACCP `CCP-CUISSON-01` ;
- contrôle `CQ-DEMO-001`.

Le plan demande dix biscuits et contrôle :

| Paramètre | Spécification | Exemple |
|---|---:|---:|
| Humidité, critique | 2 % à 5 %, cible 3,5 % | 3,4 % — conforme |
| Poids unitaire | 9,5 g à 10,5 g, cible 10 g | 10,1 g — conforme |
| Aspect visuel | Oui | Oui — conforme |

Après soumission, choisir `RELEASE` et expliquer la décision. Le contrôle passe à `CONFORMING`, le lot à `RELEASED` et une ligne est ajoutée à `quality_decisions`.

## Exemple 2 — Humidité critique hors limite

Créer un contrôle sur un lot en quarantaine avec le même plan, puis saisir une humidité de `8`. Le résultat devient `FAIL`. Après soumission :

- `RELEASE` est refusé ;
- choisir `BLOCK` place le lot en `BLOCKED` ;
- une non-conformité critique est créée automatiquement ;
- analyser la cause, par exemple un temps de cuisson insuffisant ;
- créer une action de vérification du four ;
- terminer puis vérifier cette action avant de clôturer l’écart.

## Exemple 3 — Non-conformité documentaire

`NC-DEMO-001` montre un écart mineur d’étiquetage sans impact produit. L’action `AC-DEMO-001` demande la mise à jour de l’instruction et la formation des opérateurs. Le critère d’efficacité est l’absence d’étiquette incomplète pendant cinq jours.

## Tables principales

- `haccp_control_points`
- `quality_control_plans`
- `quality_control_plan_parameters`
- `quality_inspections`
- `quality_inspection_results`
- `quality_decisions`
- `quality_non_conformities`
- `quality_corrective_actions`
- `quality_attachments`

Toutes les créations, approbations, décisions, analyses, actions et clôtures importantes sont enregistrées dans `audit_logs` et diffusent une mise à jour du tableau de bord lorsque nécessaire.
