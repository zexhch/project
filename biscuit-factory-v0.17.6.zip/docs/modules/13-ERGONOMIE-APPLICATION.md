# Ergonomie et parcours utilisateur

## Principes appliqués

La v0.8.0 introduit un langage d’interface centré sur la tâche. L’objectif n’est pas de montrer toutes les données à la fois, mais d’aider l’utilisateur à décider de la prochaine action.

1. **Une page, une tâche principale** : le titre, l’état et l’action suivante sont visibles en premier.
2. **Divulgation progressive** : les formulaires de création sont repliés par défaut et les champs rares restent dans « Options avancées ».
3. **Résumé avant détail** : une commande commence par quatre informations utiles, puis les lignes et enfin les lots FEFO repliables.
4. **États explicites** : badges et parcours visuel indiquent où se trouve le document.
5. **Actions contextuelles** : une commande brouillon propose « Soumettre » ; une commande soumise propose « Confirmer et réserver ».
6. **Densité maîtrisée** : indicateurs compacts, tableaux limités aux colonnes de décision et détails accessibles depuis une fiche.
7. **Responsive et accessible** : contrôles utilisables au clavier, libellés visibles, zones tactiles suffisantes et mise en page mobile.
8. **Correction sans impasse** : une ligne erronée peut être retirée d’un devis, d’une commande ou d’un tarif tant que le document est en brouillon.

## Composants communs

### Navigation du module

La barre horizontale donne accès aux commandes, devis, clients, tarifs et livraisons sans revenir au menu latéral. Sur mobile, elle défile horizontalement.

Le tableau de bord sépare désormais les alertes opérationnelles des compteurs de référentiels. Les premières restent visibles ; les seconds sont regroupés dans un panneau repliable selon les permissions.

### Formulaires

- les informations essentielles apparaissent directement ;
- les informations facultatives se trouvent dans un bloc repliable ;
- Select2 fournit la recherche dans les listes longues ;
- le client et l’entrepôt sont filtrés par la société sélectionnée ;
- les erreurs restent regroupées en haut de la page avec leurs messages précis.

### Tableaux

- DataTables fournit tri, recherche, pagination et mode responsive ;
- les listes paginées par Laravel évitent une seconde pagination côté navigateur ;
- les tableaux de saisie n’ajoutent aucun contrôle parasite ;
- l’action « ouvrir » reste dans une colonne discrète à droite ;
- les états vides indiquent clairement qu’aucune donnée ne correspond.

### Documents

Les devis, commandes et livraisons utilisent :

- un en-tête avec le numéro et le statut ;
- un résumé compact ;
- un parcours d’avancement lorsqu’il existe ;
- une action principale et un menu secondaire ;
- des sections métier séparées dans l’ordre du travail réel.

## Règles pour les prochains modules

Tout nouvel écran doit respecter ces questions avant livraison :

- l’utilisateur comprend-il en moins de cinq secondes où il se trouve ?
- l’action suivante est-elle visible sans faire défiler la page ?
- les champs facultatifs peuvent-ils être masqués ?
- chaque colonne du tableau aide-t-elle une décision ?
- les détails secondaires peuvent-ils être déplacés dans la fiche ou un panneau repliable ?
- le parcours reste-t-il utilisable à 375 px de largeur et en arabe RTL ?
- les actions dangereuses sont-elles séparées de l’action principale et protégées par une permission ?

Les classes communes se trouvent dans `resources/css/app.scss` : `module-nav`, `compact-metrics`, `action-panel`, `document-summary`, `workflow-steps`, `workspace-grid` et `form-advanced`.
