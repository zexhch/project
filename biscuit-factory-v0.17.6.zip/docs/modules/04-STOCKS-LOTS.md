# Stocks et lots

## Workflow

1. Créer une réception, sortie ou transfert en brouillon.
2. Saisir article, lot, emplacement, quantité et coût éventuel.
3. Contrôler puis comptabiliser le mouvement.
4. Consulter le solde et les alertes par lot/emplacement.

## Règles

- La comptabilisation est atomique et verrouille les soldes concernés.
- Un mouvement comptabilisé n’est plus modifiable.
- Le stock négatif est interdit par défaut (`stock.allow_negative_stock`).
- Un lot doit appartenir à l’article de la ligne.
- Une sortie automatique répartit la quantité en FEFO sur les lots libérés.
- Les réceptions calculent le coût moyen pondéré ; les transferts conservent le coût.
- Les lots reçus ou produits commencent en quarantaine et sont libérés par une action autorisée.
- Les alertes utilisent `minimum_stock` et `stock.expiry_alert_days`.

## Tables et permissions

`lots`, `stock_movements`, `stock_movement_lines`, `stock_balances`. Permissions `stocks.view/create/update/approve`.
