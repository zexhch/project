# Module 18 — Modularisation technique

## Finalité

Le registre des modules permet d’adapter le périmètre fonctionnel d’une installation sans supprimer les données ni maintenir plusieurs branches de l’application.

## Structure d’un module

Chaque domaine possède un répertoire `app/Modules/<Nom>` et un manifeste `module.php` contenant :

- code stable ;
- libellé et description traduisibles ;
- version ;
- ordre et icône ;
- caractère socle ou facultatif ;
- état par défaut ;
- préfixes de permissions ;
- dépendances ;
- fichiers de routes ;
- chemins de migrations.

Les routes sont chargées par `ModuleRouteLoader`. Toutes restent enregistrées pour garantir la compatibilité avec le cache des routes, mais `EnsureModuleEnabled` interdit l’accès lorsqu’un domaine est désactivé.

Les migrations métier sont physiquement rangées dans `app/Modules/<Nom>/database/migrations`. Les trois migrations techniques Laravel (`users`, cache et files de travaux) restent dans `database/migrations`. Les noms historiques des migrations ont été conservés afin qu’une mise à niveau depuis une version antérieure ne rejoue aucune création de table.

## Registre persistant

Les tables `application_modules` et `application_module_dependencies` conservent l’état, la version, l’empreinte du manifeste, les dates d’activation et les dépendances. `ModuleRegistry` synchronise les fichiers avec la base sans réactiver un module volontairement désactivé.

## Référentiels partagés

La route générique des référentiels applique `EnsureResourceModuleEnabled`. Une ressource comme `production-lines` suit ainsi le module Production, tandis que les sociétés et articles restent rattachés au socle Référentiels.

## Commandes

```bash
php artisan module:sync
php artisan module:list
php artisan module:diagnose --fail-on-error
php artisan module:disable finance
php artisan module:enable finance
```

La désactivation et l’activation sont auditées dans `audit_logs`.

## Règles d’exploitation

- Ne jamais désactiver un domaine pendant une transaction métier en cours.
- Vérifier les tâches en file avant la désactivation.
- Exécuter `module:diagnose` après chaque déploiement.
- Conserver les données du domaine désactivé.
- Modifier les dépendances uniquement dans les manifestes versionnés.
- Une réception ou un retour créant un lot le libère directement lorsque Qualité est désactivé ; aucune inspection n’est alors créée.
