# Temps réel, alertes et audit

## Temps réel

Reverb diffuse `DashboardUpdated` après validation des transactions. Livewire écoute le canal privé du tableau de bord. Un polling périodique assure le repli si WebSocket est indisponible.

## Traitements asynchrones

Redis porte les files ; Horizon les supervise. Le scheduler exécute snapshots, purge des travaux et génération du préventif. Les notifications système utilisent la file `notifications`.

## Audit

Le journal conserve utilisateur, événement, type et identifiant de l’entité, anciennes/nouvelles valeurs, IP, agent utilisateur et date. Il est en lecture seule dans l’application.

## Exploitation

Superviser Horizon, Reverb, le scheduler et les workers. Une panne de diffusion ne doit jamais annuler une transaction métier déjà validée. Consulter `docs/REALTIME.md`, `docs/BACKUP_RESTORE.md` et `docs/SECURITY.md`.
