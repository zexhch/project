# Rapports et pilotage

## Objectif

Fournir une lecture transversale des données opérationnelles sans dupliquer les écritures métier ni créer un entrepôt de données parallèle.

## Rapports disponibles

1. Synthèse de direction.
2. Ventes et clients.
3. Achats et fournisseurs.
4. Production et rendement.
5. Stocks et valorisation.
6. Qualité et non-conformités.
7. Maintenance et arrêts.
8. Finance, trésorerie et balance âgée.

Chaque rapport applique les permissions de l’utilisateur et l’état des modules sources. Les filtres communs portent sur la période, la société et le site.

## Exports

- CSV UTF-8 avec séparateur point-virgule et neutralisation des cellules interprétables comme formules.
- Vue imprimable adaptée au format A4 paysage et enregistrable en PDF depuis le navigateur.
- Téléchargement protégé par `reports.export`.

## Rapports programmés

Une programmation appartient à un utilisateur et définit :

- le rapport ;
- une fréquence quotidienne, hebdomadaire ou mensuelle ;
- l’heure et le jour d’exécution ;
- une période relative ;
- la société et le site optionnels.

Les permissions et l’état du module source sont revalidés au moment de chaque exécution. Le fichier est stocké sur un disque privé. Une notification est créée lorsque le traitement est terminé ou échoue. Un verrou distribué empêche l’exécution concurrente d’une même programmation. Les fichiers et historiques de plus de 90 jours sont purgés par défaut.

## Dashboard par rôle

Le tableau de bord sélectionne automatiquement le rapport le plus pertinent : direction, ventes, achats, production, magasin, qualité, maintenance ou finance. Ce choix reste borné par les permissions effectives et les modules actifs.
