# Module 16 — Facturation et règlements

## Objectif

Le module couvre le cycle financier qui suit les livraisons clients et les réceptions fournisseurs : facture, échéance, avoir, règlement, affectation, relance et balance âgée.

## Accès

Menu **Finance et contrôle de gestion → Facturation et règlements**.

Permissions :

- `finance.view` : consulter factures, règlements et balances âgées ;
- `finance.create` : créer factures et brouillons de règlements ;
- `finance.update` : enregistrer les relances ;
- `finance.approve` : émettre/approuver les factures et avoirs, comptabiliser ou annuler un règlement ;
- `finance.export` : réservé aux futurs exports financiers.

## Workflow client

1. La commande client est confirmée et réservée.
2. La livraison est préparée puis comptabilisée.
3. L’action **Facturer** génère une facture en brouillon depuis les quantités réellement expédiées.
4. L’émission ouvre la créance et calcule l’échéance selon les conditions du client.
5. Un avoir peut réduire le solde sans modifier le total historique de la facture.
6. Un règlement est saisi en brouillon puis ventilé sur une ou plusieurs factures.
7. La comptabilisation actualise les soldes et les statuts.
8. Les factures non soldées peuvent recevoir des relances datées avec canal et prochaine action.
9. La balance âgée répartit les créances entre non échues, 1–30, 31–60, 61–90 et plus de 90 jours.

## Workflow fournisseur

1. La commande fournisseur est approuvée.
2. La réception est comptabilisée.
3. La facture fournisseur est saisie depuis la réception avec son numéro externe et son total déclaré.
4. Le service compare la commande, la réception et la facture.
5. Un écart supérieur à la tolérance exige une acceptation explicite avant approbation.
6. Un avoir fournisseur peut réduire la dette ouverte.
7. Un règlement fournisseur est ventilé puis comptabilisé.
8. La dette et la balance âgée sont recalculées.

## Règlements partiels et multi-factures

- Une facture peut recevoir plusieurs règlements successifs.
- Un règlement peut être ventilé sur plusieurs factures du même tiers et de la même devise.
- Le total ventilé ne peut pas dépasser le montant du règlement.
- Une affectation ne peut pas dépasser le solde disponible de la facture.
- Le reliquat non affecté reste enregistré sur le règlement.

Formule du solde :

```text
solde = total facture - avoirs validés - affectations de règlements comptabilisés
```

## Annulation d’un règlement

Un règlement comptabilisé n’est jamais supprimé. L’annulation :

- exige un motif ;
- enregistre l’utilisateur et l’horodatage ;
- passe le règlement à `CANCELLED` ;
- exclut ses affectations du calcul ;
- recalcule toutes les factures concernées ;
- écrit une entrée dans le journal d’audit.

## Statuts

Factures :

- `DRAFT` : préparée mais non émise/approuvée ;
- `ISSUED` : ouverte au règlement ;
- `PARTIALLY_PAID` : partiellement soldée ;
- `PAID` : soldée par règlements et/ou avoirs ;
- `OVERDUE` : ouverte et échue.

Règlements :

- `DRAFT` : modifiable et sans incidence sur les soldes ;
- `POSTED` : comptabilisé ;
- `CANCELLED` : annulé avec piste d’audit.

## Paramètres dynamiques

- types de comptes de trésorerie ;
- modes de règlement ;
- motifs d’avoir ;
- canaux de relance ;
- tolérance de rapprochement ;
- seuils de balance âgée.

## Traçabilité

Les factures conservent leurs liens vers livraison/réception et commande. Les avoirs, règlements, affectations, annulations et relances sont datés et associés à leur auteur.

## Contrôles d’exploitation v0.10.1

Rafraîchir manuellement les statuts et soldes des factures ouvertes :

```bash
php artisan finance:refresh-overdue
php artisan finance:refresh-overdue --company=COMP-DEMO
```

Contrôler la cohérence du grand livre auxiliaire :

```bash
php artisan finance:audit-ledger --fail-on-error
php artisan finance:audit-ledger --company=COMP-DEMO --json
```

Une réparation doit rester une action explicite, précédée d’une sauvegarde :

```bash
php artisan finance:audit-ledger --company=COMP-DEMO --repair --fail-on-error
```

L’option `--repair` reconstruit uniquement les montants dérivés des factures et règlements. Elle ne crée, ne supprime et ne réaffecte aucun règlement ou avoir.

Le Scheduler exécute `finance:refresh-overdue` chaque heure avec verrou anti-chevauchement. Le conteneur Scheduler doit donc rester actif en production.

