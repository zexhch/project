# Mise à niveau vers la version 0.13.0

La version 0.13.0 ajoute le module Rapports, les tableaux de bord par rôle, les exports et la programmation de rapports privés.

## Procédure

1. Sauvegarder la base et les fichiers applicatifs.
2. Déployer l’archive v0.13.0.
3. Reconstruire les dépendances et les assets.
4. Exécuter les migrations et synchroniser les modules.
5. Vérifier le planificateur Laravel et le worker de notifications.

```bash
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --no-interaction --prefer-dist --no-progress
docker compose run --rm vite sh -c 'npm ci --no-audit --no-fund && npm run build'
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --class=Database\\Seeders\\RolePermissionSeeder --force
docker compose run --rm app php artisan module:sync
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan module:diagnose --fail-on-error
docker compose run --rm app php artisan test
```

## Permissions et dépendances

Le seeder des rôles système doit être rejoué pour créer les permissions `reports.*` et les attribuer aux profils concernés. Les rôles personnalisés ne sont pas modifiés automatiquement et doivent recevoir explicitement les droits nécessaires depuis l’administration.

Le module Rapports dépend des modules `core` et `master-data`. Chaque rapport métier reste conditionné par l’activation de son module source et par les permissions de l’utilisateur.

## Nouvelles tables

- `report_schedules` : définition, fréquence, période relative, périmètre et prochaine exécution.
- `report_runs` : historique, statut, fichier privé, volume et erreur éventuelle.

## Exploitation

Le scheduler doit exécuter `php artisan schedule:run` chaque minute. La commande interne suivante est déclenchée toutes les cinq minutes :

```bash
php artisan reports:run-schedules
```

Exécution ciblée d’une programmation :

```bash
php artisan reports:run-schedules --schedule=<UUID>
php artisan reports:prune --days=90
```

Les fichiers sont stockés sur le disque Laravel `local` sous `reports/<user>/<année>/<mois>/`. Ils ne sont accessibles que par la route de téléchargement authentifiée.

## Contrôles recommandés

- Ouvrir chaque rapport avec un utilisateur autorisé.
- Vérifier les filtres société, site et période.
- Exporter un CSV et imprimer une vue PDF.
- Créer une programmation, forcer son exécution, puis télécharger le fichier depuis l’historique.
- Désactiver le module Rapports et confirmer que le menu et les URL ne sont plus accessibles.
