# Mise à niveau vers la version 0.14.0

## Avant la mise à niveau

1. Sauvegarder PostgreSQL et `storage/app`.
2. Vérifier l’empreinte SHA-256 de l’archive.
3. Conserver le fichier `.env` existant.

## Windows / Docker Desktop

```powershell
.\install-windows.cmd
.\security-audit-windows.cmd
.\healthcheck-windows.cmd
```

L’installation reconstruit l’image applicative car la v0.14.0 ajoute `postgresql-client-17` au conteneur PHP. Le client `pg_dump` doit être au moins de la même génération que le serveur PostgreSQL 17.

## Linux

```bash
bash scripts/init.sh
bash scripts/security-audit.sh
bash scripts/healthcheck.sh
```

## Migrations

La migration v0.14.0 ajoute :

- les champs de verrouillage, expiration et dernière connexion sur `users` ;
- la sévérité, la corrélation et les métadonnées sur `audit_logs` ;
- les tables `backup_schedules`, `backup_runs` et `system_health_snapshots`.

Les utilisateurs existants conservent leur accès. Leur date de changement de mot de passe est initialisée à la date de migration.

## Configuration recommandée

En production :

```dotenv
APP_ENV=production
APP_DEBUG=false
SESSION_ENCRYPT=true
SESSION_SECURE_COOKIE=true
```

Remplacer tous les secrets de démonstration signalés par `security:audit`.

## Validation

```bash
docker compose exec -T app php artisan migrate:status
docker compose exec -T app php artisan module:sync
docker compose exec -T app php artisan module:diagnose --fail-on-error
docker compose exec -T app php artisan security:audit
docker compose exec -T app php artisan app:doctor
```
