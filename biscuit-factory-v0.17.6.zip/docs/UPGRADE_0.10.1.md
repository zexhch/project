# Mise à niveau vers la version 0.10.1

Cette version stabilise la facturation sans modifier le workflow fonctionnel de la v0.10.0.

## 1. Sauvegarde obligatoire

```powershell
./scripts/backup.sh
```

Conserver l’archive, le dump PostgreSQL et le fichier `.env` hors du répertoire de déploiement.

## 2. Mise à jour applicative

Remplacer les sources par celles de la v0.10.1, puis exécuter :

```powershell
docker compose build --no-cache app
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --no-interaction --prefer-dist --no-progress
docker compose run --rm app php artisan optimize:clear
docker compose run --rm app php artisan migrate --force
docker compose run --rm vite sh -c "npm ci --no-audit --no-fund && npm run build"
docker compose up -d
```

La migration ajoute des index financiers et des contraintes PostgreSQL `NOT VALID`. Elles protègent les nouvelles écritures sans bloquer une base historique qui doit d’abord être auditée.

## 3. Audit après migration

```powershell
docker compose exec app php artisan finance:refresh-overdue
docker compose exec app php artisan finance:audit-ledger --fail-on-error
```

En cas d’anomalies portant uniquement sur des montants dérivés :

```powershell
docker compose exec app php artisan finance:audit-ledger --repair --fail-on-error
```

Ne pas utiliser `--repair` avant sauvegarde. Cette option ne modifie pas les ventilations, mais recalcule les totaux, soldes et statuts.

## 4. Tests recommandés

```powershell
docker compose exec app php artisan test --filter=BillingWorkflowTest
docker compose exec app php artisan test --filter=BillingStabilizationTest
docker compose exec app vendor/bin/pint --test
docker compose ps
Invoke-WebRequest http://localhost:8080/up
```

Vérifier que le service `scheduler` est actif, car il rafraîchit les échéances chaque heure.

## 5. Retour arrière

La migration de durcissement peut être annulée sans supprimer les factures ni les règlements :

```powershell
docker compose run --rm app php artisan migrate:rollback --step=1
```

Cette opération supprime uniquement les index et contraintes ajoutés par la v0.10.1.
