# Installation

## Prérequis communs

- Docker Desktop sous Windows, ou Docker Engine sous Linux.
- Docker Compose v2.
- Au moins 4 Gio de mémoire disponible pour Docker.
- Ports disponibles : 8080, 5173, 5433, 8025, 8082, 9000 et 9001.

Aucune ancienne version n’est requise : l’archive v0.17.6 est cumulative.

## Installation neuve sous Windows

```powershell
Expand-Archive .\biscuit-factory-v0.17.6.zip -DestinationPath C:\Projects\biscuit-factory-v0.17.6
Set-Location C:\Projects\biscuit-factory-v0.17.6
.\install-windows.cmd
```

Options :

```powershell
.\install-windows.cmd -NoSeed
.\install-windows.cmd -SkipHealthcheck
.\install-windows.cmd -Fresh -ConfirmReset
.\install-windows.cmd -SlowCommandSeconds 15
.\installation-report-windows.cmd
```

Le lanceur utilise PowerShell 7 s’il est installé, sinon Windows PowerShell 5.1. Voir `docs/WINDOWS.md` pour la validation, la sauvegarde, la restauration et le dépannage.

## Installation neuve sous Linux/macOS

```bash
unzip biscuit-factory-v0.17.6.zip
cd biscuit-factory-v0.17.6
cp .env.example .env
bash scripts/init.sh
```

Options :

```bash
bash scripts/init.sh --no-seed
bash scripts/init.sh --skip-healthcheck
BISCUIT_FACTORY_CONFIRM_RESET=YES bash scripts/init.sh --fresh
bash scripts/init.sh --slow-command-seconds 15
bash scripts/installation-report.sh
```

## Ce que fait le script d’installation

1. contrôle Docker, Compose, `.env`, les fichiers essentiels et les secrets par défaut ;
2. construit l’image PHP ;
3. démarre PostgreSQL, Redis, MinIO et Mailpit ;
4. installe les dépendances Composer depuis le verrou ;
5. génère la clé Laravel lorsqu’elle est absente ;
6. applique toutes les migrations cumulatives ;
7. injecte les données initiales sauf option contraire ;
8. synchronise les modules et vide les caches ;
9. démarre Nginx, Horizon, Scheduler, Reverb et Vite ;
10. exécute les contrôles de santé ;
11. écrit les marqueurs, chronométrages et journaux dans `storage/logs/installer`.

Chaque commande affiche un identifiant `CMD-nnn`. Une commande démarrée sans marqueur de fin est l'opération actuellement bloquée. Voir `docs/INSTALLATION_TRACING.md`.

## Vérifications Windows

```powershell
.\scripts\windows\preflight.cmd
.\healthcheck-windows.cmd
powershell -ExecutionPolicy Bypass -File .\scripts\windows\validate-static.ps1
```

Validation destructive de l’environnement de test :

```powershell
.\validate-installation-windows.cmd -ConfirmReset
```

## Vérifications Linux/macOS

```bash
bash scripts/validate-static.sh
bash scripts/preflight.sh
bash scripts/healthcheck.sh
```

Validation destructive de l’environnement de test :

```bash
BISCUIT_FACTORY_CONFIRM_RESET=YES bash scripts/validate-installation.sh
```

## Endpoints de supervision

```text
GET /health/live   -> processus web vivant
GET /health/ready  -> dépendances et migrations opérationnelles
```

## Installation manuelle

```bash
cp .env.example .env
docker compose build
docker compose up -d postgres redis minio minio-init mailpit
docker compose run --rm -e COMPOSER_PROCESS_TIMEOUT=1800 app composer install --prefer-dist --no-progress
docker compose run --rm app php artisan key:generate --force
docker compose run --rm app php artisan migrate --force
docker compose run --rm app php artisan db:seed --force
docker compose run --rm app php artisan module:sync
docker compose run --rm app php artisan storage:link
docker compose up -d
```

Le fichier `composer.lock` doit rester dans le projet. Le contrôle Reverb de `compose.yaml` utilise volontairement `$$s` pour préserver la variable shell dans Docker Compose.
