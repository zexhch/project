# Sauvegarde et restauration

## Deux formats pris en charge

### Sauvegarde applicative

Créée depuis **Administration → Sécurité et exploitation** ou avec :

```bash
php artisan operations:run-backups --manual
```

- fichier `.zip` lorsque les documents privés sont inclus ;
- fichier `.dump` lorsque seule la base est incluse ;
- empreinte SHA-256 enregistrée dans l’historique applicatif ;
- stockage privé dans `storage/app/private/backups`.

L’archive ZIP contient uniquement :

```text
database.dump
files/...
```

Les sessions, caches, files de travaux et historiques de sauvegardes ne sont pas réinjectés dans le dump applicatif.

### Sauvegarde d’exploitation

Créée avec les scripts Windows ou Linux. Elle produit :

- `database_YYYYMMDD_HHMMSS.dump` ;
- `storage_YYYYMMDD_HHMMSS.tar.gz` ;
- `backup_YYYYMMDD_HHMMSS.sha256`.

## Linux/macOS

Sauvegarde :

```bash
bash scripts/backup.sh
```

Restauration d’un dump et des documents :

```bash
BISCUIT_FACTORY_CONFIRM_RESTORE=YES \
  bash scripts/restore.sh \
  backups/database_YYYYMMDD_HHMMSS.dump \
  backups/storage_YYYYMMDD_HHMMSS.tar.gz
```

Restauration d’une archive ZIP téléchargée depuis l’application :

```bash
BISCUIT_FACTORY_CONFIRM_RESTORE=YES \
  bash scripts/restore.sh biscuit-factory-YYYYMMDD-HHMMSS-UUID.zip
```

## Windows

Sauvegarde :

```powershell
.\scripts\windows\backup.cmd
```

Dossier personnalisé :

```powershell
.\scripts\windows\backup.cmd -BackupDirectory D:\Backups\BiscuitFactory
```

Restauration d’un dump et des documents :

```powershell
.\scripts\windows\restore.cmd `
  -DatabaseDump .\backups\database_YYYYMMDD_HHMMSS.dump `
  -StorageArchive .\backups\storage_YYYYMMDD_HHMMSS.tar.gz `
  -ConfirmRestore
```

Restauration d’une archive applicative ZIP :

```powershell
.\scripts\windows\restore.cmd `
  -DatabaseDump .\biscuit-factory-YYYYMMDD-HHMMSS-UUID.zip `
  -ExpectedSha256 EMPREINTE_COPIEE_DEPUIS_L_APPLICATION `
  -ConfirmRestore
```

Le script cherche automatiquement un fichier `.sha256` adjacent. Pour une archive téléchargée depuis l’application, `-ExpectedSha256` permet d’imposer l’empreinte affichée dans l’historique.

## Sécurités appliquées pendant une restauration

- confirmation explicite obligatoire ;
- validation SHA-256 lorsqu’une empreinte est fournie ou disponible ;
- refus des entrées ZIP inattendues ou traversant les répertoires ;
- passage automatique en mode maintenance ;
- arrêt d’Horizon, du scheduler et de Reverb ;
- terminaison des connexions PostgreSQL actives ;
- restauration atomique avec `pg_restore --single-transaction --exit-on-error` ;
- invalidation de toutes les sessions et jetons « se souvenir de moi » ;
- suppression des caches et travaux asynchrones restaurés ;
- migrations, synchronisation des modules et contrôle de santé ;
- maintien du mode maintenance lorsque la restauration échoue.

Le script Windows utilise `docker cp` pour les dumps binaires et ne redirige jamais leur contenu avec `>`, évitant les conversions d’encodage de Windows PowerShell 5.1.

## Production

Prévoir en complément :

- copie hors serveur ou stockage objet immuable ;
- chiffrement des archives ;
- rotation distincte des sauvegardes quotidiennes, hebdomadaires et mensuelles ;
- surveillance des échecs ;
- test de restauration périodique sur un environnement isolé ;
- conservation documentée des clés et secrets nécessaires à la reprise.
