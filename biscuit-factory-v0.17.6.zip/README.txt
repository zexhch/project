BISCUIT FACTORY v0.17.6
======================

Installation Windows / Docker Desktop
-------------------------------------
1. Extraire l'archive dans un dossier local hors OneDrive.
2. Demarrer Docker Desktop en mode conteneurs Linux.
3. Executer : install-windows.cmd
4. Ouvrir : http://localhost:8080
5. Executer : security-audit-windows.cmd

Installation Linux
------------------
1. cp .env.example .env
2. bash scripts/init.sh
3. bash scripts/security-audit.sh
4. Ouvrir : http://localhost:8080

Compte initial de demonstration
-------------------------------
admin@biscuit-factory.local / ChangeMe123!

Changer ce mot de passe et tous les secrets de demonstration avant toute mise
en production. Consulter README.md, docs/INSTALLATION.md, docs/WINDOWS.md,
docs/SECURITY.md, docs/PLANNING.md, docs/LEGAL_DOCUMENTS.md,
docs/PACKAGING_AND_IMAGES.md, docs/UI_REDESIGN_0.17.3.md,
docs/UPGRADE_0.17.4.md, docs/UPGRADE_0.17.5.md, docs/UPGRADE_0.17.6.md,
docs/INSTALLATION_TRACING.md et docs/RESOURCE_ALLOCATION.md.
