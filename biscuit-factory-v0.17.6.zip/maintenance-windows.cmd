@echo off
call "%~dp0scripts\windows\maintenance.cmd" %*
exit /b %errorlevel%
