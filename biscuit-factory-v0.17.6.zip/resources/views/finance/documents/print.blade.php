<!doctype html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $number }}</title>
    <style>
        @page { size: A4; margin: 11mm 12mm; }
        * { box-sizing: border-box; }
        body { margin: 0; color: #16191d; font-family: Arial, "Noto Sans Arabic", sans-serif; font-size: 11px; line-height: 1.35; }
        .toolbar { position: sticky; top: 0; z-index: 10; display: flex; justify-content: flex-end; padding: 10px; background: #fff; border-bottom: 1px solid #d8dadd; }
        .toolbar button { border: 0; border-radius: 5px; padding: 9px 16px; background: #206bc4; color: #fff; cursor: pointer; }
        .page { width: 100%; max-width: 186mm; min-height: 274mm; margin: 0 auto; padding: 5mm 0 0; display: flex; flex-direction: column; }
        .header { display: grid; grid-template-columns: 1.15fr 1fr; gap: 18px; align-items: start; }
        .brand-row { display: flex; gap: 12px; align-items: flex-start; }
        .logo { max-width: 150px; max-height: 70px; object-fit: contain; object-position: left top; }
        [dir="rtl"] .logo { object-position: right top; }
        .company-name { font-size: 18px; font-weight: 800; margin: 0 0 2px; }
        .company-activity { font-size: 11px; color: #4f5965; margin-bottom: 6px; }
        .document-heading { text-align: center; padding-top: 4px; }
        .document-heading h1 { font-size: 23px; margin: 0 0 4px; text-transform: uppercase; letter-spacing: .02em; }
        .document-number { font-size: 17px; font-weight: 800; }
        .document-date { margin-top: 3px; font-weight: 700; }
        .status { display: inline-block; margin-top: 6px; padding: 3px 9px; border-radius: 12px; background: #eaf2fb; color: #185ca6; font-size: 9px; font-weight: 800; }
        .identity-grid { display: grid; grid-template-columns: 1.15fr 1fr; gap: 18px; margin-top: 12px; }
        .identity { font-size: 10px; }
        .identity strong { font-size: 12px; }
        .identity-title { font-weight: 800; text-transform: uppercase; font-size: 10px; margin-bottom: 3px; }
        .legal-line { margin-top: 2px; }
        .separator { border: 0; border-top: 2px solid #1f2937; margin: 12px 0 13px; }
        .references { border: 1px solid #d7d9dd; background: #f8f9fa; padding: 8px 10px; margin-bottom: 12px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 5px 16px; font-size: 10px; }
        .references strong { font-weight: 700; }
        table.lines { width: 100%; border-collapse: collapse; table-layout: fixed; }
        table.lines th { background: #eceeef; font-weight: 800; text-transform: uppercase; font-size: 9px; }
        table.lines th, table.lines td { border: 1px solid #cfd3d8; padding: 7px 6px; vertical-align: top; }
        table.lines tbody tr { height: 34px; }
        .col-no { width: 35px; text-align: center; }
        .col-ref { width: 84px; }
        .col-qty { width: 88px; }
        .col-price { width: 88px; }
        .col-tax { width: 58px; }
        .col-total { width: 100px; }
        .num { text-align: right; white-space: nowrap; }
        [dir="rtl"] .num { text-align: left; }
        .totals-wrap { display: flex; justify-content: flex-end; margin-top: 10px; }
        table.totals { width: 285px; border-collapse: collapse; }
        table.totals td { border: 1px solid #cfd3d8; padding: 6px 8px; }
        table.totals td:first-child { text-align: right; font-weight: 700; background: #f7f7f7; }
        table.totals tr.grand-total td { font-weight: 900; font-size: 13px; border-top: 2px solid #16191d; }
        .amount-words { margin-top: 20px; font-size: 10.5px; }
        .amount-words strong { display: block; margin-top: 3px; font-size: 11px; }
        .terms { margin-top: 14px; padding: 9px 11px; background: #f6f7f8; white-space: pre-line; }
        .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 55px; margin-top: 36px; }
        .signature { min-height: 68px; text-align: center; padding-top: 5px; }
        .signature-line { border-top: 1px solid #343a40; padding-top: 5px; }
        footer { margin-top: auto; padding-top: 14px; text-align: center; color: #5d6670; white-space: pre-line; font-size: 9px; }
        .bank { margin-top: 4px; }
        @media print { .toolbar { display: none; } .page { padding-top: 0; } }
    </style>
</head>
<body>
@php
    $showLogo = $template?->show_logo ?? true;
    $showLegal = $template?->show_legal_identifiers ?? true;
    $showBank = $template?->show_bank_details ?? true;
    $showNumbers = $template?->show_line_numbers ?? true;
    $showTaxRate = $template?->show_tax_rate ?? true;
    $showReferences = $template?->show_internal_references ?? true;
    $showStatus = $template?->show_status ?? true;
    $columnCount = 2 + ($showNumbers ? 1 : 0) + ($showReferences ? 1 : 0) + ($showAmounts ? 3 : 0) + (($showAmounts && $showTaxRate) ? 1 : 0);
    $amountIntro = match ($documentType) {
        \App\Services\Finance\Governance\FinancialDocumentCatalog::CUSTOMER_INVOICE,
        \App\Services\Finance\Governance\FinancialDocumentCatalog::SUPPLIER_INVOICE => __('governance.invoice_amount_in_words_intro'),
        \App\Services\Finance\Governance\FinancialDocumentCatalog::DELIVERY_NOTE => __('governance.delivery_amount_in_words_intro'),
        default => __('governance.document_amount_in_words_intro'),
    };
@endphp
<div class="toolbar"><button type="button" onclick="window.print()">{{ __('governance.print_now') }}</button></div>
<div class="page">
    <div class="header">
        <div>
            <div class="brand-row">
                @if($showLogo && $companyLogoUrl)
                    <img src="{{ $companyLogoUrl }}" alt="{{ $companyIdentity['name'] }}" class="logo">
                @endif
                @if($template?->show_company_details ?? true)
                    <div>
                        <div class="company-name">{{ $companyIdentity['name'] }}</div>
                        @if($companyIdentity['activity'])<div class="company-activity">{{ $companyIdentity['activity'] }}</div>@endif
                    </div>
                @endif
            </div>
        </div>
        <div class="document-heading">
            <h1>{{ $template?->title ?: __($definition['label']) }}</h1>
            <div class="document-number">{{ $number }}</div>
            <div class="document-date">{{ __('governance.date') }} : {{ $date?->format('d/m/Y') }}</div>
            @if($showStatus && $document->status)<div class="status">{{ $document->status }}</div>@endif
        </div>
    </div>

    <div class="identity-grid">
        <div class="identity">
            @if($template?->show_company_details ?? true)
                <div class="identity-title">{{ __('governance.issuer') }}</div>
                @if($companyIdentity['address'])<div>{{ $companyIdentity['address'] }}</div>@endif
                @if($companyIdentity['phone'] || $companyIdentity['email'])<div>{{ $companyIdentity['phone'] }}@if($companyIdentity['phone'] && $companyIdentity['email']) · @endif{{ $companyIdentity['email'] }}</div>@endif
                @if($showLegal)
                    <div class="legal-line">
                        @if($companyIdentity['registration_number'])<strong>{{ __('governance.rc') }} :</strong> {{ $companyIdentity['registration_number'] }}<br>@endif
                        @if($companyIdentity['tax_identifier'])<strong>{{ __('governance.nif') }} :</strong> {{ $companyIdentity['tax_identifier'] }}<br>@endif
                        @if($companyIdentity['statistical_identifier'])<strong>{{ __('governance.nis') }} :</strong> {{ $companyIdentity['statistical_identifier'] }}<br>@endif
                        @if($companyIdentity['article_of_imposition'])<strong>{{ __('governance.ai') }} :</strong> {{ $companyIdentity['article_of_imposition'] }}@endif
                    </div>
                @endif
                @if($showBank && ($bankDetails['bank_name'] || $bankDetails['account_number'] || $bankDetails['iban']))
                    <div class="bank">
                        @if($bankDetails['bank_name'])<strong>{{ __('billing.bank_name') }} :</strong> {{ $bankDetails['bank_name'] }} {{ $bankDetails['bank_branch'] }}<br>@endif
                        @if($bankDetails['account_number'])<strong>{{ __('billing.account_number') }} :</strong> {{ $bankDetails['account_number'] }}<br>@endif
                        @if($bankDetails['iban'])<strong>{{ __('billing.iban') }} :</strong> {{ $bankDetails['iban'] }}@endif
                    </div>
                @endif
            @endif
            @if($template?->header_text)<div style="margin-top:6px;white-space:pre-line">{{ $template->header_text }}</div>@endif
        </div>

        <div class="identity">
            <div class="identity-title">{{ $partyLabel }}</div>
            <strong>{{ $partyIdentity['code'] ? $partyIdentity['code'].' — ' : '' }}{{ $partyIdentity['name'] }}</strong>
            @if($partyIdentity['address'])<div>{{ $partyIdentity['address'] }}</div>@endif
            @if($partyIdentity['phone'] || $partyIdentity['email'])<div>{{ $partyIdentity['phone'] }}@if($partyIdentity['phone'] && $partyIdentity['email']) · @endif{{ $partyIdentity['email'] }}</div>@endif
            @if($showLegal)
                <div class="legal-line">
                    @if($partyIdentity['registration_number'])<strong>{{ __('governance.rc') }} :</strong> {{ $partyIdentity['registration_number'] }}<br>@endif
                    @if($partyIdentity['tax_identifier'])<strong>{{ __('governance.nif') }} :</strong> {{ $partyIdentity['tax_identifier'] }}<br>@endif
                    @if($partyIdentity['statistical_identifier'])<strong>{{ __('governance.nis') }} :</strong> {{ $partyIdentity['statistical_identifier'] }}<br>@endif
                    @if($partyIdentity['article_of_imposition'])<strong>{{ __('governance.ai') }} :</strong> {{ $partyIdentity['article_of_imposition'] }}@endif
                </div>
            @endif
        </div>
    </div>

    <hr class="separator">

    @if($showReferences)
        <div class="references">
            @switch($documentType)
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::SALES_QUOTATION)
                    <div><strong>{{ __('sales.valid_until') }} :</strong> {{ $document->valid_until?->format('d/m/Y') ?? '—' }}</div>
                    <div><strong>{{ __('sales.requested_delivery_date') }} :</strong> {{ $document->requested_delivery_date?->format('d/m/Y') ?? '—' }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::SALES_ORDER)
                    <div><strong>{{ __('sales.requested_delivery_date') }} :</strong> {{ $document->requested_delivery_date?->format('d/m/Y') ?? '—' }}</div>
                    <div><strong>{{ __('sales.customer_reference') }} :</strong> {{ $document->customer_reference ?: '—' }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::DELIVERY_NOTE)
                    <div><strong>{{ __('billing.sales_order') }} :</strong> {{ $document->salesOrder?->order_number ?? '—' }}</div>
                    <div><strong>{{ __('sales.delivered_at') }} :</strong> {{ $document->delivered_at?->format('d/m/Y H:i') }}</div>
                    <div><strong>{{ __('admin.warehouse') }} :</strong> {{ $document->warehouse?->name ?? '—' }}</div>
                    @if($document->carrier)<div><strong>{{ __('sales.carrier') }} :</strong> {{ $document->carrier }}</div>@endif
                    @if($document->vehicle_registration)<div><strong>{{ __('sales.vehicle_registration') }} :</strong> {{ $document->vehicle_registration }}</div>@endif
                    @if($document->driver_name)<div><strong>{{ __('sales.driver_name') }} :</strong> {{ $document->driver_name }}</div>@endif
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::PURCHASE_REQUISITION)
                    <div><strong>{{ __('purchasing.required_date') }} :</strong> {{ $document->required_date?->format('d/m/Y') ?? '—' }}</div>
                    <div><strong>{{ __('purchasing.priority') }} :</strong> {{ $document->priority }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::PURCHASE_ORDER)
                    <div><strong>{{ __('purchasing.expected_date') }} :</strong> {{ $document->expected_date?->format('d/m/Y') ?? '—' }}</div>
                    <div><strong>{{ __('purchasing.payment_terms') }} :</strong> {{ $document->payment_terms_days }} {{ __('governance.days') }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::GOODS_RECEIPT)
                    <div><strong>{{ __('purchasing.purchase_order') }} :</strong> {{ $document->purchaseOrder?->order_number ?? '—' }}</div>
                    <div><strong>{{ __('purchasing.delivery_note') }} :</strong> {{ $document->supplier_delivery_note ?: '—' }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::CUSTOMER_INVOICE)
                    <div><strong>{{ __('billing.due_date') }} :</strong> {{ $document->due_date?->format('d/m/Y') }}</div>
                    <div><strong>{{ __('billing.sales_order') }} :</strong> {{ $document->salesOrder?->order_number ?? '—' }}</div>
                    <div><strong>{{ __('billing.delivery') }} :</strong> {{ $document->deliveryNote?->delivery_number ?? '—' }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::SUPPLIER_INVOICE)
                    <div><strong>{{ __('billing.due_date') }} :</strong> {{ $document->due_date?->format('d/m/Y') }}</div>
                    <div><strong>{{ __('billing.supplier_invoice_number') }} :</strong> {{ $document->supplier_invoice_number }}</div>
                    <div><strong>{{ __('billing.matching_status') }} :</strong> {{ $document->matching_status }}</div>
                    @break
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::CUSTOMER_PAYMENT)
                @case(\App\Services\Finance\Governance\FinancialDocumentCatalog::SUPPLIER_PAYMENT)
                    <div><strong>{{ __('billing.payment_method') }} :</strong> {{ $document->payment_method_code }}</div>
                    <div><strong>{{ __('billing.external_reference') }} :</strong> {{ $document->external_reference ?: '—' }}</div>
                    <div><strong>{{ __('billing.financial_account') }} :</strong> {{ $document->financialAccount?->name ?? '—' }}</div>
                    @break
                @default
                    <div><strong>{{ __('governance.reason') }} :</strong> {{ $document->reason }}</div>
            @endswitch
        </div>
    @endif

    <table class="lines">
        <thead>
        <tr>
            @if($showNumbers)<th class="col-no">{{ __('governance.line_number') }}</th>@endif
            @if($showReferences)<th class="col-ref">{{ __('governance.reference') }}</th>@endif
            <th>{{ __('governance.designation') }}</th>
            <th class="col-qty num">{{ __('governance.quantity') }}</th>
            @if($showAmounts)
                <th class="col-price num">{{ __('governance.unit_price_ht') }}</th>
                @if($showTaxRate)<th class="col-tax num">{{ __('governance.tax_rate') }}</th>@endif
                <th class="col-total num">{{ __('governance.amount_ht') }}</th>
            @endif
        </tr>
        </thead>
        <tbody>
        @forelse($lines as $line)
            <tr>
                @if($showNumbers)<td class="col-no">{{ str_pad((string)$line['number'], 2, '0', STR_PAD_LEFT) }}</td>@endif
                @if($showReferences)<td>{{ $line['reference'] ?: '—' }}</td>@endif
                <td>{{ $line['description'] }}</td>
                <td class="num">{{ number_format($line['quantity'], 3, ',', ' ') }} {{ $line['unit'] }}</td>
                @if($showAmounts)
                    <td class="num">{{ number_format($line['unit_price'], 2, ',', ' ') }}</td>
                    @if($showTaxRate)<td class="num">{{ number_format($line['tax_rate'], 2, ',', ' ') }} %</td>@endif
                    <td class="num">{{ number_format($line['subtotal'], 2, ',', ' ') }}</td>
                @endif
            </tr>
        @empty
            <tr><td colspan="{{ $columnCount }}">—</td></tr>
        @endforelse
        </tbody>
    </table>

    @if($showAmounts)
        <div class="totals-wrap">
            <table class="totals">
                <tr><td>{{ __('governance.total_ht') }}</td><td class="num">{{ number_format($totals['subtotal'], 2, ',', ' ') }} {{ $totals['currency'] }}</td></tr>
                @if($totals['discount'] > 0)<tr><td>{{ __('governance.discount') }}</td><td class="num">- {{ number_format($totals['discount'], 2, ',', ' ') }} {{ $totals['currency'] }}</td></tr>@endif
                <tr><td>{{ __('governance.tax') }}</td><td class="num">{{ number_format($totals['tax'], 2, ',', ' ') }} {{ $totals['currency'] }}</td></tr>
                <tr class="grand-total"><td>{{ __('governance.total_ttc') }}</td><td class="num">{{ number_format($totals['total'], 2, ',', ' ') }} {{ $totals['currency'] }}</td></tr>
                @if($totals['balance'] > 0)<tr><td>{{ __('governance.balance') }}</td><td class="num">{{ number_format($totals['balance'], 2, ',', ' ') }} {{ $totals['currency'] }}</td></tr>@endif
            </table>
        </div>
    @endif

    @if($amountInWords)
        <div class="amount-words">{{ $amountIntro }}<strong>{{ $amountInWords }}</strong></div>
    @endif

    @if($template?->terms)<div class="terms"><strong>{{ __('governance.terms') }}</strong><br>{{ $template->terms }}</div>@endif

    @if($template?->show_signature_blocks ?? true)
        <div class="signatures">
            <div class="signature"><div class="signature-line">{{ __('governance.prepared_by') }}</div></div>
            <div class="signature"><div class="signature-line">{{ __('governance.stamp_and_signature') }}</div></div>
        </div>
    @endif

    <footer>{{ $template?->footer_text ?: __('governance.legal_document') }}</footer>
</div>
</body>
</html>
