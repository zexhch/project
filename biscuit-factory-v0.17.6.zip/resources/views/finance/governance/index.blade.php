@extends('layouts.app')
@section('title', __('governance.title'))

@section('content')
@php
    $tab = request('tab', 'periods');
    $canUpdate = auth()->user()->hasPermission('finance.update');
    $canApprove = auth()->user()->hasPermission('finance.approve');
    $approvalService = app(\App\Services\Finance\Governance\ApprovalService::class);
    $statusTone = fn(string $status) => match ($status) {
        'OPEN', 'APPROVED' => 'success',
        'CLOSED', 'REJECTED' => 'danger',
        'PENDING' => 'warning',
        'WAITING' => 'secondary',
        default => 'blue',
    };
    $documentLink = function ($request) {
        return match ($request->approvable_type) {
            \App\Models\CustomerInvoice::class => route('finance.billing.customer-invoices.show', $request->approvable_id),
            \App\Models\SupplierInvoice::class => route('finance.billing.supplier-invoices.show', $request->approvable_id),
            default => null,
        };
    };
@endphp

<div class="page-header d-print-none mb-3">
    <div>
        <div class="page-pretitle">{{ __('navigation.finance_controlling') }}</div>
        <h2 class="page-title"><i class="ti ti-scale me-2"></i>{{ __('governance.title') }}</h2>
        <div class="text-secondary mt-1">{{ __('governance.subtitle') }}</div>
    </div>
    <div class="ms-auto">
        <form method="GET" class="d-flex gap-2">
            <input type="hidden" name="tab" value="{{ $tab }}">
            <select name="company_id" class="form-select" onchange="this.form.submit()">
                @foreach($companies as $company)
                    <option value="{{ $company->id }}" @selected($company->id === $selectedCompanyId)>{{ $company->name }}</option>
                @endforeach
            </select>
            <select name="year" class="form-select" onchange="this.form.submit()">
                @for($value = now()->year - 3; $value <= now()->year + 3; $value++)
                    <option value="{{ $value }}" @selected($value === $year)>{{ $value }}</option>
                @endfor
            </select>
        </form>
    </div>
</div>

@if(session('success'))<div class="alert alert-success"><i class="ti ti-check me-2"></i>{{ session('success') }}</div>@endif
@if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif

<div class="card mb-3">
    <div class="card-header p-0">
        <ul class="nav nav-tabs card-header-tabs m-0 px-3 overflow-auto flex-nowrap">
            @foreach([
                'periods' => ['ti-calendar-lock', __('governance.periods')],
                'sequences' => ['ti-list-numbers', __('governance.sequences')],
                'workflows' => ['ti-route', __('governance.workflows')],
                'approvals' => ['ti-checklist', __('governance.approval_inbox')],
                'templates' => ['ti-template', __('governance.templates')],
                'revisions' => ['ti-history', __('governance.revisions')],
            ] as $key => [$icon, $label])
                <li class="nav-item"><a class="nav-link {{ $tab === $key ? 'active' : '' }}" href="{{ request()->fullUrlWithQuery(['tab' => $key]) }}"><i class="ti {{ $icon }} me-1"></i>{{ $label }}</a></li>
            @endforeach
        </ul>
    </div>
</div>

@if($tab === 'periods')
    <div class="row row-cards">
        <div class="col-xl-9">
            <div class="card">
                <div class="card-header"><h3 class="card-title">{{ __('governance.periods') }} {{ $year }}</h3></div>
                <div class="table-responsive">
                    <table class="table table-vcenter card-table">
                        <thead><tr><th>{{ __('governance.period') }}</th><th>{{ __('governance.dates') }}</th><th>{{ __('governance.status') }}</th><th>{{ __('governance.blockers') }}</th><th class="text-end">{{ __('governance.actions') }}</th></tr></thead>
                        <tbody>
                        @forelse($periods as $period)
                            @php($blockers = collect($periodBlockers[$period->id] ?? []))
                            <tr>
                                <td><strong>{{ str_pad($period->period, 2, '0', STR_PAD_LEFT) }}/{{ $period->fiscal_year }}</strong></td>
                                <td>{{ $period->starts_on->format('d/m/Y') }} → {{ $period->ends_on->format('d/m/Y') }}</td>
                                <td><span class="badge bg-{{ $statusTone($period->status) }}-lt">{{ __('governance.'.strtolower($period->status)) }}</span></td>
                                <td>
                                    @if($blockers->sum() > 0)
                                        <span class="badge bg-warning-lt">{{ $blockers->sum() }}</span>
                                        <span class="small text-secondary">{{ $blockers->filter()->map(fn($count, $type) => "$type: $count")->join(' · ') }}</span>
                                    @else
                                        <span class="text-success"><i class="ti ti-circle-check me-1"></i>0</span>
                                    @endif
                                </td>
                                <td class="text-end">
                                    @if($canApprove && $period->status === 'OPEN')
                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#close-period-{{ $period->id }}"><i class="ti ti-lock me-1"></i>{{ __('governance.close_period') }}</button>
                                    @elseif($canApprove && $period->status === 'CLOSED')
                                        <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#reopen-period-{{ $period->id }}"><i class="ti ti-lock-open me-1"></i>{{ __('governance.reopen_period') }}</button>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="empty-cell"><i class="ti ti-calendar-off"></i><span>{{ __('governance.no_periods') }}</span></td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-xl-3">
            @if($canUpdate)
                <div class="card">
                    <div class="card-header"><h3 class="card-title">{{ __('governance.generate_year') }}</h3></div>
                    <form method="POST" action="{{ route('finance.governance.periods.generate') }}" class="card-body">
                        @csrf
                        <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                        <label class="form-label">{{ __('governance.year') }}</label>
                        <input type="number" name="fiscal_year" min="2020" max="2100" value="{{ $year }}" class="form-control mb-3" required>
                        <button class="btn btn-primary w-100"><i class="ti ti-calendar-plus me-1"></i>{{ __('governance.generate_year') }}</button>
                    </form>
                </div>
            @endif
        </div>
    </div>

    @foreach($periods as $period)
        <div class="modal modal-blur fade" id="close-period-{{ $period->id }}" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form method="POST" action="{{ route('finance.governance.periods.close', $period) }}">@csrf
            <div class="modal-header"><h5 class="modal-title">{{ __('governance.close_period') }} {{ str_pad($period->period, 2, '0', STR_PAD_LEFT) }}/{{ $period->fiscal_year }}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><label class="form-label required">{{ __('governance.close_reason') }}</label><textarea name="reason" rows="3" class="form-control" required></textarea><label class="form-check mt-3"><input type="checkbox" name="force" value="1" class="form-check-input"><span class="form-check-label">{{ __('governance.force_close') }}</span></label><div class="form-hint">{{ __('governance.force_close_warning') }}</div></div>
            <div class="modal-footer"><button type="button" class="btn me-auto" data-bs-dismiss="modal">{{ __('admin.cancel') }}</button><button class="btn btn-danger">{{ __('governance.close_period') }}</button></div>
        </form></div></div></div>
        <div class="modal modal-blur fade" id="reopen-period-{{ $period->id }}" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form method="POST" action="{{ route('finance.governance.periods.reopen', $period) }}">@csrf
            <div class="modal-header"><h5 class="modal-title">{{ __('governance.reopen_period') }}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><label class="form-label required">{{ __('governance.reopen_reason') }}</label><textarea name="reason" rows="3" class="form-control" required></textarea></div>
            <div class="modal-footer"><button type="button" class="btn me-auto" data-bs-dismiss="modal">{{ __('admin.cancel') }}</button><button class="btn btn-warning">{{ __('governance.reopen_period') }}</button></div>
        </form></div></div></div>
    @endforeach
@endif

@if($tab === 'sequences')
    <div class="row row-cards">
        <div class="col-xl-5">
            @if($canUpdate)
            <div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.save_sequence') }}</h3></div><form method="POST" action="{{ route('finance.governance.sequences.store') }}" class="card-body">@csrf
                <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                <div class="mb-2"><label class="form-label required">{{ __('governance.document_type') }}</label><select name="document_type" class="form-select" required>@foreach($documentTypes as $code => $definition)<option value="{{ $code }}">{{ __($definition['label']) }}</option>@endforeach</select></div>
                <div class="row g-2"><div class="col-4"><label class="form-label required">{{ __('governance.prefix') }}</label><input name="prefix" value="FC" class="form-control" required></div><div class="col-8"><label class="form-label required">{{ __('governance.pattern') }}</label><input name="pattern" value="{PREFIX}-{YEAR}-{NUMBER}" class="form-control" required></div></div>
                <div class="form-hint mb-2">{{ __('governance.sequence_help') }}</div>
                <div class="row g-2"><div class="col-4"><label class="form-label">{{ __('governance.reset_policy') }}</label><select name="reset_policy" class="form-select"><option value="ANNUAL">{{ __('governance.annual') }}</option><option value="MONTHLY">{{ __('governance.monthly') }}</option><option value="NEVER">{{ __('governance.never') }}</option></select></div><div class="col-3"><label class="form-label">{{ __('governance.year') }}</label><input name="fiscal_year" type="number" value="{{ $year }}" class="form-control"></div><div class="col-2"><label class="form-label">{{ __('governance.period') }}</label><input name="period" type="number" min="0" max="12" value="0" class="form-control"></div><div class="col-3"><label class="form-label">{{ __('governance.padding') }}</label><input name="padding" type="number" min="1" max="18" value="6" class="form-control"></div></div>
                <div class="row g-2 mt-1"><div class="col-8"><label class="form-label">{{ __('governance.next_number') }}</label><input name="next_number" type="number" min="1" value="1" class="form-control"></div><div class="col-4 d-flex align-items-end"><label class="form-check mb-2"><input type="checkbox" name="active" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.active') }}</span></label></div></div>
                <button class="btn btn-primary w-100 mt-3"><i class="ti ti-device-floppy me-1"></i>{{ __('governance.save_sequence') }}</button>
            </form></div>
            @endif
        </div>
        <div class="col-xl-7"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.sequences') }}</h3></div><div class="table-responsive"><table class="table card-table"><thead><tr><th>{{ __('governance.document_type') }}</th><th>{{ __('governance.pattern') }}</th><th>{{ __('governance.reset_policy') }}</th><th class="text-end">{{ __('governance.next_number') }}</th><th>{{ __('governance.status') }}</th></tr></thead><tbody>
            @forelse($sequences as $sequence)<tr><td>{{ __($documentTypes[$sequence->document_type]['label'] ?? $sequence->document_type) }}<div class="small text-secondary">{{ $sequence->fiscal_year ?: '∞' }}{{ $sequence->period ? '/'.str_pad($sequence->period,2,'0',STR_PAD_LEFT) : '' }}</div></td><td><code>{{ $sequence->pattern }}</code></td><td>{{ __('governance.'.strtolower($sequence->reset_policy)) }}</td><td class="text-end">{{ $sequence->next_number }}</td><td><span class="badge {{ $sequence->active ? 'bg-success-lt' : 'bg-secondary-lt' }}">{{ $sequence->active ? __('governance.active') : __('governance.disable') }}</span></td></tr>@empty<tr><td colspan="5" class="empty-cell"><i class="ti ti-list-numbers"></i><span>{{ __('governance.no_revisions') }}</span></td></tr>@endforelse
        </tbody></table></div></div></div>
    </div>
@endif

@if($tab === 'workflows')
    <div class="row row-cards">
        <div class="col-xl-4">
            @if($canUpdate)<div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.workflow') }}</h3></div><form method="POST" action="{{ route('finance.governance.workflows.store') }}" class="card-body">@csrf
                <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                <div class="row g-2"><div class="col-4"><label class="form-label required">{{ __('governance.workflow_code') }}</label><input name="code" class="form-control" required></div><div class="col-8"><label class="form-label required">{{ __('governance.workflow_name') }}</label><input name="name" class="form-control" required></div></div>
                <div class="mb-2 mt-2"><label class="form-label required">{{ __('governance.document_type') }}</label><select name="document_type" class="form-select">@foreach($documentTypes as $code => $definition)<option value="{{ $code }}">{{ __($definition['label']) }}</option>@endforeach</select></div>
                <div class="row g-2"><div class="col-6"><label class="form-label">{{ __('governance.minimum_amount') }}</label><input name="minimum_amount" type="number" min="0" step="0.01" value="0" class="form-control"></div><div class="col-6"><label class="form-label">{{ __('governance.currency') }}</label><input name="currency_code" value="DZD" maxlength="3" class="form-control"></div></div>
                <div class="mt-2"><label class="form-label">{{ __('governance.description') }}</label><textarea name="description" rows="3" class="form-control"></textarea></div>
                <label class="form-check mt-2"><input type="checkbox" name="active" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.active') }}</span></label>
                <button class="btn btn-primary w-100 mt-3">{{ __('governance.save_workflow') }}</button>
            </form></div>@endif
        </div>
        <div class="col-xl-8">
            @forelse($workflows as $workflow)
                <div class="card mb-3"><div class="card-header"><div><h3 class="card-title">{{ $workflow->code }} — {{ $workflow->name }}</h3><div class="text-secondary small">{{ __($documentTypes[$workflow->document_type]['label'] ?? $workflow->document_type) }} · ≥ {{ number_format((float)$workflow->minimum_amount,2,',',' ') }} {{ $workflow->currency_code }}</div></div>@if($canUpdate)<div class="card-actions"><form method="POST" action="{{ route('finance.governance.workflows.toggle',$workflow) }}">@csrf<button class="btn btn-sm {{ $workflow->active ? 'btn-outline-danger' : 'btn-outline-success' }}">{{ $workflow->active ? __('governance.disable') : __('governance.enable') }}</button></form></div>@endif</div>
                <div class="table-responsive"><table class="table card-table"><thead><tr><th>#</th><th>{{ __('governance.level_name') }}</th><th>{{ __('governance.permission_code') }}</th><th>{{ __('governance.role_code') }}</th><th>{{ __('governance.minimum_approvals') }}</th><th>{{ __('governance.amount') }}</th></tr></thead><tbody>@forelse($workflow->levels as $level)<tr><td>{{ $level->sequence }}</td><td>{{ $level->name }}</td><td><code>{{ $level->permission_code }}</code></td><td>{{ $level->role_code ?: '—' }}</td><td>{{ $level->minimum_approvals }}</td><td>{{ $level->amount_from ?? 0 }} → {{ $level->amount_to ?? '∞' }}</td></tr>@empty<tr><td colspan="6" class="text-secondary">{{ __('governance.waiting') }}</td></tr>@endforelse</tbody></table></div>
                @if($canUpdate)<form method="POST" action="{{ route('finance.governance.workflows.levels.store',$workflow) }}" class="card-body border-top">@csrf<div class="row g-2"><div class="col-md-1"><label class="form-label">#</label><input name="sequence" type="number" min="1" max="20" value="{{ ($workflow->levels->max('sequence') ?? 0)+1 }}" class="form-control" required></div><div class="col-md-3"><label class="form-label">{{ __('governance.level_name') }}</label><input name="name" class="form-control" required></div><div class="col-md-3"><label class="form-label">{{ __('governance.permission_code') }}</label><input name="permission_code" value="finance.approve" class="form-control" required></div><div class="col-md-2"><label class="form-label">{{ __('governance.role_code') }}</label><select name="role_code" class="form-select"><option value="">—</option>@foreach($roles as $role)<option value="{{ $role->code }}">{{ $role->name }}</option>@endforeach</select></div><div class="col-md-1"><label class="form-label">{{ __('governance.minimum_approvals') }}</label><input name="minimum_approvals" type="number" min="1" max="20" value="1" class="form-control"></div><div class="col-md-1"><label class="form-label">{{ __('governance.amount_from') }}</label><input name="amount_from" type="number" min="0" step="0.01" class="form-control"></div><div class="col-md-1"><label class="form-label">{{ __('governance.amount_to') }}</label><input name="amount_to" type="number" min="0" step="0.01" class="form-control"></div></div><div class="text-end mt-2"><button class="btn btn-outline-primary btn-sm">{{ __('governance.add_level') }}</button></div></form>@endif
                </div>
            @empty<div class="card"><div class="empty"><i class="ti ti-route-off display-4 text-secondary"></i><p class="empty-title">{{ __('governance.no_approval_requests') }}</p></div></div>@endforelse
        </div>
    </div>
@endif

@if($tab === 'approvals')
    <div class="card" id="approvals"><div class="card-header"><h3 class="card-title">{{ __('governance.approval_inbox') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('governance.document') }}</th><th>{{ __('governance.workflow') }}</th><th>{{ __('governance.submitted_by') }}</th><th>{{ __('governance.current_level') }}</th><th class="text-end">{{ __('governance.amount') }}</th><th>{{ __('governance.status') }}</th><th class="text-end">{{ __('governance.actions') }}</th></tr></thead><tbody>
        @forelse($approvalRequests as $approval)
            @php($currentStep = $approval->steps->firstWhere('sequence', $approval->current_level))
            @php($canDecide = $approval->status === 'PENDING' && $currentStep && $approvalService->canDecide($currentStep, auth()->user()))
            <tr id="approval-{{ $approval->id }}"><td>@if($documentLink($approval))<a href="{{ $documentLink($approval) }}"><strong>{{ $approval->document_number }}</strong></a>@else<strong>{{ $approval->document_number }}</strong>@endif<div class="small text-secondary">{{ __($documentTypes[$approval->document_type]['label'] ?? $approval->document_type) }}</div></td><td>{{ $approval->workflow->name }}</td><td>{{ $approval->submitter?->name ?? '—' }}<div class="small text-secondary">{{ $approval->submitted_at->format('d/m/Y H:i') }}</div></td><td>{{ $currentStep?->name ?? '—' }} @if($currentStep)<div class="small text-secondary">{{ $currentStep->approved_count }}/{{ $currentStep->required_approvals }}</div>@endif</td><td class="text-end">{{ number_format((float)$approval->amount,2,',',' ') }} {{ $approval->currency_code }}</td><td><span class="badge bg-{{ $statusTone($approval->status) }}-lt">{{ __('governance.'.strtolower($approval->status)) }}</span></td><td class="text-end">@if($canApprove && $canDecide)<div class="btn-list flex-nowrap justify-content-end"><form method="POST" action="{{ route('finance.governance.approvals.approve',$approval) }}">@csrf<input type="hidden" name="comment" value=""><button class="btn btn-sm btn-success"><i class="ti ti-check"></i></button></form><button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#reject-approval-{{ $approval->id }}"><i class="ti ti-x"></i></button></div>@endif</td></tr>
        @empty<tr><td colspan="7" class="empty-cell"><i class="ti ti-checklist"></i><span>{{ __('governance.no_approval_requests') }}</span></td></tr>@endforelse
    </tbody></table></div></div>
    @foreach($approvalRequests as $approval)
        <div class="modal modal-blur fade" id="reject-approval-{{ $approval->id }}" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form method="POST" action="{{ route('finance.governance.approvals.reject',$approval) }}">@csrf<div class="modal-header"><h5 class="modal-title">{{ __('governance.reject') }} {{ $approval->document_number }}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><label class="form-label required">{{ __('governance.comment') }}</label><textarea name="comment" rows="4" class="form-control" required></textarea></div><div class="modal-footer"><button type="button" class="btn me-auto" data-bs-dismiss="modal">{{ __('admin.cancel') }}</button><button class="btn btn-danger">{{ __('governance.reject') }}</button></div></form></div></div></div>
    @endforeach
@endif

@if($tab === 'templates')
    <div class="row row-cards"><div class="col-xl-5">@if($canUpdate)<div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.save_template') }}</h3></div><form method="POST" action="{{ route('finance.governance.templates.store') }}" class="card-body">@csrf
        <input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
        <div class="row g-2"><div class="col-4"><label class="form-label required">{{ __('governance.template_code') }}</label><input name="code" class="form-control" required></div><div class="col-8"><label class="form-label required">{{ __('governance.template_name') }}</label><input name="name" class="form-control" required></div></div>
        <div class="row g-2 mt-1"><div class="col-8"><label class="form-label">{{ __('governance.document_type') }}</label><select name="document_type" class="form-select">@foreach($documentTypes as $code => $definition)<option value="{{ $code }}">{{ __($definition['label']) }}</option>@endforeach</select></div><div class="col-4"><label class="form-label">{{ __('governance.locale') }}</label><select name="locale" class="form-select"><option value="fr">FR</option><option value="en">EN</option><option value="ar">AR</option></select></div></div>
        <div class="mt-2"><label class="form-label">{{ __('governance.document_title') }}</label><input name="title" class="form-control"></div><div class="mt-2"><label class="form-label">{{ __('governance.header_text') }}</label><textarea name="header_text" rows="2" class="form-control"></textarea></div><div class="mt-2"><label class="form-label">{{ __('governance.terms') }}</label><textarea name="terms" rows="4" class="form-control"></textarea></div><div class="mt-2"><label class="form-label">{{ __('governance.footer_text') }}</label><textarea name="footer_text" rows="2" class="form-control"></textarea></div>
        <div class="mt-2"><label class="form-label">{{ __('governance.amounts_display') }}</label><select name="show_amounts_mode" class="form-select"><option value="DEFAULT">{{ __('governance.amounts_default') }}</option><option value="SHOW">{{ __('governance.amounts_show') }}</option><option value="HIDE">{{ __('governance.amounts_hide') }}</option></select></div>
        <div class="row mt-2 g-2"><div class="col-6">
            <label class="form-check"><input type="checkbox" name="show_company_details" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_company_details') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_logo" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_logo') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_legal_identifiers" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_legal_identifiers') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_bank_details" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_bank_details') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_signature_blocks" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_signature_blocks') }}</span></label>
        </div><div class="col-6">
            <label class="form-check"><input type="checkbox" name="show_line_numbers" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_line_numbers') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_tax_rate" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_tax_rate') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_amount_in_words" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_amount_in_words') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_internal_references" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_internal_references') }}</span></label>
            <label class="form-check"><input type="checkbox" name="show_status" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.show_status') }}</span></label>
            <label class="form-check"><input type="checkbox" name="is_default" value="1" class="form-check-input"><span class="form-check-label">{{ __('governance.default_template') }}</span></label>
            <label class="form-check"><input type="checkbox" name="active" value="1" checked class="form-check-input"><span class="form-check-label">{{ __('governance.active') }}</span></label>
        </div></div>
        <button class="btn btn-primary w-100 mt-3">{{ __('governance.save_template') }}</button>
    </form></div>@endif</div><div class="col-xl-7"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.templates') }}</h3></div><div class="table-responsive"><table class="table card-table"><thead><tr><th>{{ __('governance.template_name') }}</th><th>{{ __('governance.document_type') }}</th><th>{{ __('governance.locale') }}</th><th>{{ __('governance.company') }}</th><th>{{ __('governance.status') }}</th><th></th></tr></thead><tbody>@forelse($templates as $template)<tr><td><strong>{{ $template->code }}</strong><div class="small text-secondary">{{ $template->name }}</div></td><td>{{ __($documentTypes[$template->document_type]['label'] ?? $template->document_type) }}</td><td>{{ strtoupper($template->locale) }}</td><td>{{ $template->company?->name ?? __('governance.global_template') }}</td><td>@if($template->is_default)<span class="badge bg-primary-lt">{{ __('governance.default_template') }}</span>@elseif($template->active)<span class="badge bg-success-lt">{{ __('governance.active') }}</span>@endif</td><td class="text-end">@if($canUpdate && !$template->is_default)<form method="POST" action="{{ route('finance.governance.templates.default',$template) }}">@csrf<button class="btn btn-sm btn-outline-primary">{{ __('governance.set_default') }}</button></form>@endif</td></tr>@empty<tr><td colspan="6" class="empty-cell"><span>{{ __('governance.no_templates') }}</span></td></tr>@endforelse</tbody></table></div></div></div></div>
@endif

@if($tab === 'revisions')
    <div class="card"><div class="card-header"><h3 class="card-title">{{ __('governance.revisions') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('governance.document') }}</th><th>{{ __('governance.version') }}</th><th>{{ __('governance.action') }}</th><th>{{ __('governance.user') }}</th><th>{{ __('governance.reason') }}</th><th>{{ __('governance.dates') }}</th></tr></thead><tbody>@forelse($revisions as $revision)<tr><td><strong>{{ $revision->document_number }}</strong><div class="small text-secondary">{{ __($documentTypes[$revision->document_type]['label'] ?? $revision->document_type) }}</div></td><td>v{{ $revision->version }}</td><td><span class="badge bg-blue-lt">{{ $revision->action }}</span></td><td>{{ $revision->user?->name ?? '—' }}</td><td>{{ $revision->reason ?: '—' }}</td><td>{{ $revision->created_at->format('d/m/Y H:i:s') }}</td></tr>@empty<tr><td colspan="6" class="empty-cell"><span>{{ __('governance.no_revisions') }}</span></td></tr>@endforelse</tbody></table></div></div>
@endif
@endsection
