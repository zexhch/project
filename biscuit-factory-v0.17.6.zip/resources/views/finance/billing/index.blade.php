@extends('layouts.app')
@section('title', __('billing.billing'))

@section('content')
@php
    $tab = request('tab', 'overview');
    $currency = $companies->firstWhere('id', $selectedCompanyId)?->currency_code ?? 'DZD';
    $canCreate = auth()->user()->hasPermission('finance.create');
    $canApprove = auth()->user()->hasPermission('finance.approve');
    $statusTone = fn(string $status) => match($status) {
        'PAID' => 'success', 'PARTIALLY_PAID' => 'azure', 'OVERDUE' => 'danger',
        'ISSUED' => 'blue', 'POSTED' => 'success', 'CANCELLED' => 'secondary', 'PENDING_APPROVAL' => 'warning', 'REJECTED' => 'danger', default => 'yellow'
    };
@endphp

<div class="bf-page-heading">
    <div>
        <div class="bf-page-heading__eyebrow">{{ __('billing.dashboard_title') }}</div>
        <h1>{{ __('billing.billing') }}</h1>
        <p>{{ __('billing.billing_description') }}</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="{{ route('finance.billing.index', ['tab'=>'aging','company_id'=>$selectedCompanyId]) }}" class="btn btn-outline-primary"><i class="ti ti-calendar-stats me-1"></i>{{ __('billing.aging') }}</a>
        <a href="{{ route('finance.billing.index', ['tab'=>'customer-payments','company_id'=>$selectedCompanyId]) }}" class="btn btn-primary"><i class="ti ti-cash-banknote me-1"></i>{{ __('billing.customer_payments') }}</a>
    </div>
</div>

@if(session('success'))<div class="alert alert-success alert-dismissible"><i class="ti ti-circle-check me-2"></i>{{ session('success') }}<button class="btn-close" data-bs-dismiss="alert"></button></div>@endif
@if($errors->any())<div class="alert alert-danger"><strong>{{ __('billing.validation_errors') }}</strong><ul class="mb-0 mt-1">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif

@if($companies->count() > 1)
<form method="GET" class="card card-body py-2 mb-3"><input type="hidden" name="tab" value="{{ $tab }}"><div class="row align-items-center g-2"><div class="col-auto"><label class="form-label mb-0">{{ __('billing.company') }}</label></div><div class="col-sm-4"><select name="company_id" class="form-select" onchange="this.form.submit()">@foreach($companies as $company)<option value="{{ $company->id }}" @selected($company->id===$selectedCompanyId)>{{ $company->name }}</option>@endforeach</select></div></div></form>
@endif

<div class="bf-kpi-grid mb-4">
    <x-kpi-card icon="ti-wallet" :label="__('billing.receivables')" :value="number_format($totals['receivable'],2,',',' ').' '.$currency" tone="teal" :meta="__('billing.overdue').': '.number_format($totals['overdue_receivable'],2,',',' ').' '.$currency" />
    <x-kpi-card icon="ti-credit-card-pay" :label="__('billing.payables')" :value="number_format($totals['payable'],2,',',' ').' '.$currency" tone="blue" :meta="__('billing.overdue').': '.number_format($totals['overdue_payable'],2,',',' ').' '.$currency" />
    <x-kpi-card icon="ti-truck-delivery" :label="__('billing.unbilled_deliveries')" :value="$eligibleDeliveries->count()" tone="orange" :meta="__('billing.ready_to_invoice')" />
    <x-kpi-card icon="ti-package-import" :label="__('billing.unbilled_receipts')" :value="$eligibleReceipts->count()" tone="purple" :meta="__('billing.ready_for_matching')" />
    <x-kpi-card icon="ti-alert-triangle" :label="__('billing.overdue_receivables')" :value="number_format($totals['overdue_receivable'],2,',',' ').' '.$currency" :tone="$totals['overdue_receivable'] > 0 ? 'red' : 'green'" />
    <x-kpi-card icon="ti-percentage" :label="__('billing.collection_rate')" :value="number_format($dashboard['collection_rate'], 1, ',', ' ').' %'" tone="green" :progress="$dashboard['collection_rate']" />
</div>

<ul class="nav nav-pills recipe-tabs mb-3 flex-wrap">
    @foreach([
        'overview'=>['ti-layout-dashboard','billing.overview'],
        'customer-invoices'=>['ti-file-invoice','billing.customer_invoices'],
        'supplier-invoices'=>['ti-file-dollar','billing.supplier_invoices'],
        'customer-payments'=>['ti-cash-banknote','billing.customer_payments'],
        'supplier-payments'=>['ti-credit-card-pay','billing.supplier_payments'],
        'aging'=>['ti-calendar-stats','billing.aging'],
    ] as $key=>$meta)
    <li class="nav-item"><a class="nav-link {{ $tab===$key?'active':'' }}" href="{{ route('finance.billing.index',['tab'=>$key,'company_id'=>$selectedCompanyId]) }}"><i class="ti {{ $meta[0] }} me-1"></i>{{ __($meta[1]) }}</a></li>
    @endforeach
</ul>

@if($tab === 'overview')
<div class="bf-dashboard-grid mb-4">
    <div class="bf-col-4">
        <x-dashboard-chart :title="__('billing.invoicing_trend')" :subtitle="__('billing.last_seven_days')" type="line" :labels="$dashboard['invoice_trend']['labels']" :values="$dashboard['invoice_trend']['values']" tone="teal" :height="245" :value-suffix="' '.$currency" />
    </div>
    <div class="bf-col-4">
        <x-dashboard-chart :title="__('billing.payment_trend')" :subtitle="__('billing.last_seven_days')" type="bar" :labels="$dashboard['payment_trend']['labels']" :values="$dashboard['payment_trend']['values']" tone="green" :height="245" :value-suffix="' '.$currency" />
    </div>
    <div class="bf-col-4">
        <x-dashboard-chart :title="__('billing.invoice_distribution')" type="donut" :labels="$dashboard['status_chart']['labels']" :values="$dashboard['status_chart']['values']" :height="245" />
    </div>
    <div class="bf-col-12">
        <x-dashboard-chart :title="__('billing.customer_aging')" :subtitle="__('billing.aging_help')" type="horizontal-bar" :labels="$dashboard['aging_chart']['labels']" :values="$dashboard['aging_chart']['values']" tone="orange" :height="235" :value-suffix="' '.$currency" />
    </div>
</div>
<div class="row row-cards">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header"><div><h3 class="card-title">{{ __('billing.invoice_delivery') }}</h3><div class="text-secondary small">{{ __('billing.invoice_delivery_help') }}</div></div></div>
            @if($canCreate)
            <form method="POST" action="{{ route('finance.billing.customer-invoices.store') }}" class="card-body">@csrf
                <div class="mb-3"><label class="form-label required">{{ __('billing.delivery') }}</label><select name="delivery_note_id" class="form-select" required><option value="">{{ __('billing.choose') }}</option>@foreach($eligibleDeliveries as $delivery)<option value="{{ $delivery->id }}" @selected(request('delivery_id')===$delivery->id)>{{ $delivery->delivery_number }} — {{ $delivery->customer->name }} — {{ $delivery->salesOrder->currency_code }}</option>@endforeach</select></div>
                <div class="row g-2"><div class="col-sm-5"><label class="form-label required">{{ __('billing.invoice_date') }}</label><input type="date" name="invoice_date" value="{{ old('invoice_date',today()->toDateString()) }}" class="form-control" required></div><div class="col-sm-7"><label class="form-label">{{ __('billing.notes') }}</label><input name="notes" class="form-control" value="{{ old('notes') }}"></div></div>
                <div class="mt-3 text-end"><button class="btn btn-primary" @disabled($eligibleDeliveries->isEmpty())><i class="ti ti-file-plus me-1"></i>{{ __('billing.create_invoice') }}</button></div>
            </form>
            @else<div class="card-body text-secondary">{{ __('billing.read_only') }}</div>@endif
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header"><div><h3 class="card-title">{{ __('billing.record_supplier_invoice') }}</h3><div class="text-secondary small">{{ __('billing.three_way_matching_help') }}</div></div></div>
            @if($canCreate)
            <form method="POST" action="{{ route('finance.billing.supplier-invoices.store') }}" class="card-body">@csrf
                <div class="mb-3"><label class="form-label required">{{ __('billing.goods_receipt') }}</label><select name="goods_receipt_id" class="form-select" required><option value="">{{ __('billing.choose') }}</option>@foreach($eligibleReceipts as $receipt)<option value="{{ $receipt->id }}" @selected(request('receipt_id')===$receipt->id)>{{ $receipt->receipt_number }} — {{ $receipt->supplier->name }} — {{ $receipt->purchaseOrder->currency_code }}</option>@endforeach</select></div>
                <div class="row g-2"><div class="col-sm-4"><label class="form-label required">{{ __('billing.supplier_invoice_number') }}</label><input name="supplier_invoice_number" class="form-control" required></div><div class="col-sm-4"><label class="form-label required">{{ __('billing.invoice_date') }}</label><input type="date" name="invoice_date" value="{{ today()->toDateString() }}" class="form-control" required></div><div class="col-sm-4"><label class="form-label required">{{ __('billing.declared_total') }}</label><input type="number" name="total_amount" min="0.01" step="0.01" class="form-control" required></div></div>
                <details class="form-advanced mt-3"><summary>{{ __('billing.notes') }}</summary><div class="pt-2"><textarea name="notes" class="form-control" rows="2"></textarea></div></details>
                <div class="mt-3 text-end"><button class="btn btn-primary" @disabled($eligibleReceipts->isEmpty())><i class="ti ti-file-plus me-1"></i>{{ __('billing.create_invoice') }}</button></div>
            </form>
            @else<div class="card-body text-secondary">{{ __('billing.read_only') }}</div>@endif
        </div>
    </div>
</div>
@endif

@if($tab === 'customer-invoices')
<div class="card"><div class="card-header"><h3 class="card-title">{{ __('billing.customer_invoices') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table" data-datatable-mode="server-rendered"><thead><tr><th>{{ __('billing.number') }}</th><th>{{ __('billing.customer') }}</th><th>{{ __('billing.dates') }}</th><th class="text-end">{{ __('billing.total') }}</th><th class="text-end">{{ __('billing.paid') }}</th><th class="text-end">{{ __('billing.balance') }}</th><th>{{ __('billing.status') }}</th><th></th></tr></thead><tbody>
@forelse($customerInvoices as $invoice)<tr><td><a class="fw-bold" href="{{ route('finance.billing.customer-invoices.show',$invoice) }}">{{ $invoice->invoice_number }}</a><div class="small text-secondary">{{ $invoice->deliveryNote?->delivery_number }}</div></td><td><strong>{{ $invoice->customer->code }}</strong><div class="small text-secondary">{{ $invoice->customer->name }}</div></td><td>{{ $invoice->invoice_date->format('d/m/Y') }}<div class="small {{ $invoice->status==='OVERDUE'?'text-danger':'text-secondary' }}">{{ __('billing.due') }} {{ $invoice->due_date->format('d/m/Y') }}</div></td><td class="text-end">{{ number_format((float)$invoice->total_amount,2,',',' ') }} {{ $invoice->currency_code }}</td><td class="text-end">{{ number_format((float)$invoice->paid_amount+(float)$invoice->credit_amount,2,',',' ') }}</td><td class="text-end fw-bold">{{ number_format((float)$invoice->balance_amount,2,',',' ') }}</td><td><span class="badge bg-{{ $statusTone($invoice->status) }}-lt">{{ __('billing.status_'.strtolower($invoice->status)) }}</span></td><td class="text-end"><a class="btn btn-sm btn-ghost-primary" href="{{ route('finance.billing.customer-invoices.show',$invoice) }}"><i class="ti ti-chevron-right"></i></a></td></tr>
@empty<tr><td colspan="8" class="empty-cell"><i class="ti ti-file-off"></i><span>{{ __('billing.no_customer_invoices') }}</span></td></tr>@endforelse
</tbody></table></div></div>
@endif

@if($tab === 'supplier-invoices')
<div class="card"><div class="card-header"><h3 class="card-title">{{ __('billing.supplier_invoices') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table" data-datatable-mode="server-rendered"><thead><tr><th>{{ __('billing.number') }}</th><th>{{ __('billing.supplier') }}</th><th>{{ __('billing.matching') }}</th><th>{{ __('billing.dates') }}</th><th class="text-end">{{ __('billing.total') }}</th><th class="text-end">{{ __('billing.balance') }}</th><th>{{ __('billing.status') }}</th><th></th></tr></thead><tbody>
@forelse($supplierInvoices as $invoice)<tr><td><a class="fw-bold" href="{{ route('finance.billing.supplier-invoices.show',$invoice) }}">{{ $invoice->invoice_number }}</a><div class="small text-secondary">{{ $invoice->supplier_invoice_number }}</div></td><td><strong>{{ $invoice->supplier->code }}</strong><div class="small text-secondary">{{ $invoice->supplier->name }}</div></td><td><span class="badge {{ $invoice->matching_status==='MATCHED'?'bg-success-lt':'bg-danger-lt' }}">{{ __('billing.matching_'.strtolower($invoice->matching_status)) }}</span><div class="small text-secondary">{{ number_format((float)$invoice->matching_variance_amount,2,',',' ') }}</div></td><td>{{ $invoice->invoice_date->format('d/m/Y') }}<div class="small {{ $invoice->status==='OVERDUE'?'text-danger':'text-secondary' }}">{{ __('billing.due') }} {{ $invoice->due_date->format('d/m/Y') }}</div></td><td class="text-end">{{ number_format((float)$invoice->total_amount,2,',',' ') }} {{ $invoice->currency_code }}</td><td class="text-end fw-bold">{{ number_format((float)$invoice->balance_amount,2,',',' ') }}</td><td><span class="badge bg-{{ $statusTone($invoice->status) }}-lt">{{ __('billing.status_'.strtolower($invoice->status)) }}</span></td><td class="text-end"><a class="btn btn-sm btn-ghost-primary" href="{{ route('finance.billing.supplier-invoices.show',$invoice) }}"><i class="ti ti-chevron-right"></i></a></td></tr>
@empty<tr><td colspan="8" class="empty-cell"><i class="ti ti-file-off"></i><span>{{ __('billing.no_supplier_invoices') }}</span></td></tr>@endforelse
</tbody></table></div></div>
@endif

@if($tab === 'customer-payments')
<div class="row row-cards">
<div class="col-xl-5">@if($canCreate)<div class="card"><div class="card-header"><div><h3 class="card-title">{{ __('billing.new_customer_payment') }}</h3><div class="small text-secondary">{{ __('billing.multi_allocation_help') }}</div></div></div><form method="POST" action="{{ route('finance.billing.customer-payments.store') }}" id="customer-payment-form" class="card-body" data-payment-form="customer">@csrf<input type="hidden" name="company_id" value="{{ $selectedCompanyId }}"><input type="hidden" name="currency_code" value="{{ $currency }}">
<div class="mb-3"><label class="form-label required">{{ __('billing.customer') }}</label><select name="customer_id" class="form-select" data-party-select required><option value="">{{ __('billing.choose') }}</option>@foreach($customers as $customer)<option value="{{ $customer->id }}" @selected(request('party_id') === $customer->id)>{{ $customer->code }} — {{ $customer->name }}</option>@endforeach</select></div>
<div class="row g-2"><div class="col-sm-6"><label class="form-label required">{{ __('billing.payment_date') }}</label><input type="date" name="payment_date" value="{{ today()->toDateString() }}" class="form-control" required></div><div class="col-sm-6"><label class="form-label required">{{ __('billing.amount') }}</label><input type="number" name="amount" min="0.01" step="0.01" class="form-control" required></div><div class="col-sm-6"><label class="form-label required">{{ __('billing.payment_method') }}</label><select name="payment_method_code" class="form-select" required>@foreach($paymentMethods as $method)<option value="{{ $method->code }}">{{ $method->localized_label }}</option>@endforeach</select></div><div class="col-sm-6"><label class="form-label">{{ __('billing.financial_account') }}</label><select name="financial_account_id" class="form-select"><option value="">—</option>@foreach($accounts as $account)<option value="{{ $account->id }}">{{ $account->code }} — {{ $account->name }}</option>@endforeach</select></div></div>
<div class="mt-3"><label class="form-label">{{ __('billing.reference') }}</label><input name="external_reference" class="form-control"></div>
<div class="mt-3"><div class="fw-semibold mb-2">{{ __('billing.allocate_invoices') }}</div><div class="payment-allocation-list">@forelse($openCustomerInvoices as $invoice)<label class="payment-allocation-row d-none" data-party="{{ $invoice->customer_id }}" data-workflow-target="{{ request('invoice_id') === $invoice->id ? 'true' : 'false' }}"><span><strong>{{ $invoice->invoice_number }}</strong><small>{{ $invoice->due_date->format('d/m/Y') }} · {{ number_format((float)$invoice->balance_amount,2,',',' ') }}</small></span><input type="number" name="allocations[{{ $invoice->id }}]" min="0" max="{{ $invoice->balance_amount }}" step="0.01" class="form-control form-control-sm" placeholder="0"></label>@empty<div class="text-secondary">{{ __('billing.no_open_invoices') }}</div>@endforelse</div></div>
<div class="mt-3 text-end"><button class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>{{ __('billing.save_draft') }}</button></div></form></div>@endif</div>
<div class="col-xl-7"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('billing.customer_payments') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('billing.number') }}</th><th>{{ __('billing.customer') }}</th><th class="text-end">{{ __('billing.amount') }}</th><th class="text-end">{{ __('billing.allocated') }}</th><th>{{ __('billing.status') }}</th><th></th></tr></thead><tbody>@forelse($customerPayments as $payment)<tr><td><a target="_blank" class="fw-bold" href="{{ route('finance.documents.customer-payments.print',$payment) }}">{{ $payment->payment_number }}</a><div class="small text-secondary">{{ $payment->payment_date->format('d/m/Y') }}</div></td><td>{{ $payment->customer->name }}</td><td class="text-end">{{ number_format((float)$payment->amount,2,',',' ') }} {{ $payment->currency_code }}</td><td class="text-end">{{ number_format((float)$payment->allocated_amount,2,',',' ') }}<div class="small text-secondary">{{ $payment->allocations->count() }} {{ __('billing.invoices') }}</div></td><td><span class="badge bg-{{ $statusTone($payment->status) }}-lt">{{ __('billing.status_'.strtolower($payment->status)) }}</span></td><td class="text-end">@if($payment->status==='DRAFT' && $canApprove)<form method="POST" action="{{ route('finance.billing.customer-payments.post',$payment) }}">@csrf<button class="btn btn-sm btn-success"><i class="ti ti-check me-1"></i>{{ __('billing.post') }}</button></form>@elseif($payment->status==='POSTED' && $canApprove)<details class="payment-reversal"><summary class="btn btn-sm btn-outline-danger"><i class="ti ti-arrow-back-up me-1"></i>{{ __('billing.reverse_payment') }}</summary><form method="POST" action="{{ route('finance.billing.customer-payments.reverse',$payment) }}" class="mt-2">@csrf<textarea name="reversal_reason" class="form-control form-control-sm mb-2" rows="2" placeholder="{{ __('billing.reversal_reason') }}" required></textarea><button class="btn btn-sm btn-danger w-100">{{ __('billing.confirm_reverse') }}</button></form></details>@endif</td></tr>@empty<tr><td colspan="6" class="empty-cell"><i class="ti ti-cash-off"></i><span>{{ __('billing.no_payments') }}</span></td></tr>@endforelse</tbody></table></div></div></div>
</div>
@endif

@if($tab === 'supplier-payments')
<div class="row row-cards">
<div class="col-xl-5">@if($canCreate)<div class="card"><div class="card-header"><div><h3 class="card-title">{{ __('billing.new_supplier_payment') }}</h3><div class="small text-secondary">{{ __('billing.multi_allocation_help') }}</div></div></div><form method="POST" action="{{ route('finance.billing.supplier-payments.store') }}" id="supplier-payment-form" class="card-body" data-payment-form="supplier">@csrf<input type="hidden" name="company_id" value="{{ $selectedCompanyId }}"><input type="hidden" name="currency_code" value="{{ $currency }}">
<div class="mb-3"><label class="form-label required">{{ __('billing.supplier') }}</label><select name="supplier_id" class="form-select" data-party-select required><option value="">{{ __('billing.choose') }}</option>@foreach($suppliers as $supplier)<option value="{{ $supplier->id }}" @selected(request('party_id') === $supplier->id)>{{ $supplier->code }} — {{ $supplier->name }}</option>@endforeach</select></div>
<div class="row g-2"><div class="col-sm-6"><label class="form-label required">{{ __('billing.payment_date') }}</label><input type="date" name="payment_date" value="{{ today()->toDateString() }}" class="form-control" required></div><div class="col-sm-6"><label class="form-label required">{{ __('billing.amount') }}</label><input type="number" name="amount" min="0.01" step="0.01" class="form-control" required></div><div class="col-sm-6"><label class="form-label required">{{ __('billing.payment_method') }}</label><select name="payment_method_code" class="form-select" required>@foreach($paymentMethods as $method)<option value="{{ $method->code }}">{{ $method->localized_label }}</option>@endforeach</select></div><div class="col-sm-6"><label class="form-label">{{ __('billing.financial_account') }}</label><select name="financial_account_id" class="form-select"><option value="">—</option>@foreach($accounts as $account)<option value="{{ $account->id }}">{{ $account->code }} — {{ $account->name }}</option>@endforeach</select></div></div>
<div class="mt-3"><label class="form-label">{{ __('billing.reference') }}</label><input name="external_reference" class="form-control"></div>
<div class="mt-3"><div class="fw-semibold mb-2">{{ __('billing.allocate_invoices') }}</div><div class="payment-allocation-list">@forelse($openSupplierInvoices as $invoice)<label class="payment-allocation-row d-none" data-party="{{ $invoice->supplier_id }}" data-workflow-target="{{ request('invoice_id') === $invoice->id ? 'true' : 'false' }}"><span><strong>{{ $invoice->invoice_number }}</strong><small>{{ $invoice->due_date->format('d/m/Y') }} · {{ number_format((float)$invoice->balance_amount,2,',',' ') }}</small></span><input type="number" name="allocations[{{ $invoice->id }}]" min="0" max="{{ $invoice->balance_amount }}" step="0.01" class="form-control form-control-sm" placeholder="0"></label>@empty<div class="text-secondary">{{ __('billing.no_open_invoices') }}</div>@endforelse</div></div>
<div class="mt-3 text-end"><button class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>{{ __('billing.save_draft') }}</button></div></form></div>@endif</div>
<div class="col-xl-7"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('billing.supplier_payments') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('billing.number') }}</th><th>{{ __('billing.supplier') }}</th><th class="text-end">{{ __('billing.amount') }}</th><th class="text-end">{{ __('billing.allocated') }}</th><th>{{ __('billing.status') }}</th><th></th></tr></thead><tbody>@forelse($supplierPayments as $payment)<tr><td><a target="_blank" class="fw-bold" href="{{ route('finance.documents.supplier-payments.print',$payment) }}">{{ $payment->payment_number }}</a><div class="small text-secondary">{{ $payment->payment_date->format('d/m/Y') }}</div></td><td>{{ $payment->supplier->name }}</td><td class="text-end">{{ number_format((float)$payment->amount,2,',',' ') }} {{ $payment->currency_code }}</td><td class="text-end">{{ number_format((float)$payment->allocated_amount,2,',',' ') }}<div class="small text-secondary">{{ $payment->allocations->count() }} {{ __('billing.invoices') }}</div></td><td><span class="badge bg-{{ $statusTone($payment->status) }}-lt">{{ __('billing.status_'.strtolower($payment->status)) }}</span></td><td class="text-end">@if($payment->status==='DRAFT' && $canApprove)<form method="POST" action="{{ route('finance.billing.supplier-payments.post',$payment) }}">@csrf<button class="btn btn-sm btn-success"><i class="ti ti-check me-1"></i>{{ __('billing.post') }}</button></form>@elseif($payment->status==='POSTED' && $canApprove)<details class="payment-reversal"><summary class="btn btn-sm btn-outline-danger"><i class="ti ti-arrow-back-up me-1"></i>{{ __('billing.reverse_payment') }}</summary><form method="POST" action="{{ route('finance.billing.supplier-payments.reverse',$payment) }}" class="mt-2">@csrf<textarea name="reversal_reason" class="form-control form-control-sm mb-2" rows="2" placeholder="{{ __('billing.reversal_reason') }}" required></textarea><button class="btn btn-sm btn-danger w-100">{{ __('billing.confirm_reverse') }}</button></form></details>@endif</td></tr>@empty<tr><td colspan="6" class="empty-cell"><i class="ti ti-cash-off"></i><span>{{ __('billing.no_payments') }}</span></td></tr>@endforelse</tbody></table></div></div></div>
</div>
@endif

@if($tab === 'aging')
<div class="row row-cards">
@foreach(['customer'=>['billing.customer_aging',$customerAging,'ti-users'],'supplier'=>['billing.supplier_aging',$supplierAging,'ti-building-factory-2']] as $type=>$data)
<div class="col-lg-6"><div class="card"><div class="card-header"><h3 class="card-title"><i class="ti {{ $data[2] }} me-2"></i>{{ __($data[0]) }}</h3></div><div class="table-responsive"><table class="table card-table"><thead><tr><th>{{ __('billing.bucket') }}</th><th class="text-end">{{ __('billing.balance') }}</th></tr></thead><tbody>@foreach(['current','days_1_30','days_31_60','days_61_90','days_90_plus'] as $bucket)<tr><td>{{ __('billing.'.$bucket) }}</td><td class="text-end {{ $bucket!=='current' && $data[1][$bucket]>0?'text-danger':'' }}">{{ number_format($data[1][$bucket],2,',',' ') }} {{ $currency }}</td></tr>@endforeach</tbody><tfoot><tr><th>{{ __('billing.total') }}</th><th class="text-end">{{ number_format(array_sum($data[1]),2,',',' ') }} {{ $currency }}</th></tr></tfoot></table></div></div></div>
@endforeach
</div>
@endif
@endsection

@push('scripts')
<script>
document.querySelectorAll('[data-payment-form]').forEach((form) => {
    const select = form.querySelector('[data-party-select]');
    if (!select) return;
    const refresh = () => form.querySelectorAll('[data-party]').forEach((row) => {
        const visible = select.value && row.dataset.party === select.value;
        row.classList.toggle('d-none', !visible);
        if (!visible) row.querySelector('input').value = '';
    });
    select.addEventListener('change', refresh); refresh();
});
</script>
@endpush
