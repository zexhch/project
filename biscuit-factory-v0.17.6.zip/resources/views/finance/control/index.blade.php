@extends('layouts.app')
@section('title', __('finance.management_control'))

@section('content')
    @php
        $activeTab = request('tab', 'overview');
        $currencyCode = $companies->firstWhere('id', $selectedCompanyId)?->currency_code ?? 'DZD';
        $canCreate = auth()->user()->hasPermission('finance.create');
        $canUpdate = auth()->user()->hasPermission('finance.update');
        $canApprove = auth()->user()->hasPermission('finance.approve');
    @endphp

    <div class="page-header d-print-none mb-3">
        <div>
            <div class="page-pretitle">{{ __('navigation.finance_controlling') }}</div>
            <h2 class="page-title"><i class="ti ti-chart-histogram me-2"></i>{{ __('finance.management_control') }}</h2>
            <div class="text-secondary mt-1">{{ __('finance.management_control_description') }}</div>
        </div>
    </div>

    @if (session('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
            <i class="ti ti-circle-check me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <div class="fw-bold mb-1">{{ __('finance.details') }}</div>
            <ul class="mb-0">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif

    @if($companies->count() > 1)
        <form method="GET" class="card card-body py-2 mb-3">
            <input type="hidden" name="tab" value="{{ $activeTab }}">
            <input type="hidden" name="year" value="{{ $year }}">
            <div class="row align-items-center g-2">
                <div class="col-auto"><label class="form-label mb-0">{{ __('finance.company') }}</label></div>
                <div class="col-sm-5 col-lg-3"><select name="company_id" class="form-select" onchange="this.form.submit()">@foreach($companies as $company)<option value="{{ $company->id }}" @selected($company->id===$selectedCompanyId)>{{ $company->name }}</option>@endforeach</select></div>
            </div>
        </form>
    @endif

    <ul class="nav nav-pills recipe-tabs mb-3">
        <li class="nav-item"><a class="nav-link {{ $activeTab === 'overview' ? 'active' : '' }}" href="{{ route('finance.control.index', ['tab' => 'overview', 'year' => $year, 'company_id' => $selectedCompanyId]) }}"><i class="ti ti-layout-dashboard me-1"></i>{{ __('finance.overview') }}</a></li>
        <li class="nav-item"><a class="nav-link {{ $activeTab === 'centers' ? 'active' : '' }}" href="{{ route('finance.control.index', ['tab' => 'centers', 'year' => $year, 'company_id' => $selectedCompanyId]) }}"><i class="ti ti-building-factory me-1"></i>{{ __('finance.cost_centers') }}</a></li>
        <li class="nav-item"><a class="nav-link {{ $activeTab === 'scenarios' ? 'active' : '' }}" href="{{ route('finance.control.index', ['tab' => 'scenarios', 'year' => $year, 'company_id' => $selectedCompanyId]) }}"><i class="ti ti-flask me-1"></i>{{ __('finance.scenarios') }}</a></li>
        <li class="nav-item"><a class="nav-link {{ $activeTab === 'budgets' ? 'active' : '' }}" href="{{ route('finance.control.index', ['tab' => 'budgets', 'year' => $year, 'company_id' => $selectedCompanyId]) }}"><i class="ti ti-chart-bar me-1"></i>{{ __('finance.budgets') }}</a></li>
    </ul>

    @if ($activeTab === 'overview')
        <div class="row row-deck row-cards mb-3">
            <div class="col-sm-6 col-lg-3"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.revenue') }}</div><div class="h2 mb-0">{{ number_format($marginReport['totals']['revenue'], 2, ',', ' ') }} <small>{{ $currencyCode }}</small></div></div></div></div>
            <div class="col-sm-6 col-lg-3"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.margin') }}</div><div class="h2 mb-0 {{ $marginReport['totals']['margin'] < 0 ? 'text-danger' : 'text-success' }}">{{ number_format($marginReport['totals']['margin'], 2, ',', ' ') }} <small>{{ $currencyCode }}</small></div><div class="text-secondary small">{{ number_format($marginReport['totals']['margin_percentage'], 2, ',', ' ') }}%</div></div></div></div>
            <div class="col-sm-6 col-lg-3"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.budget') }} {{ $year }}</div><div class="h2 mb-0">{{ number_format($budgetTotals['budget'], 2, ',', ' ') }} <small>{{ $currencyCode }}</small></div><div class="text-secondary small">{{ __('finance.actual') }} : {{ number_format($budgetTotals['actual'], 2, ',', ' ') }}</div></div></div></div>
            <div class="col-sm-6 col-lg-3"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.variance') }}</div><div class="h2 mb-0 {{ $budgetTotals['variance'] < 0 ? 'text-danger' : 'text-success' }}">{{ number_format($budgetTotals['variance'], 2, ',', ' ') }} <small>{{ $currencyCode }}</small></div><div class="text-secondary small">{{ $costCenters->where('active', true)->count() }} {{ __('finance.centers_count') }}</div></div></div></div>
        </div>

        <div class="card mb-3">
            <div class="card-header"><div><h3 class="card-title">{{ __('finance.margin_analysis') }}</h3><div class="text-secondary small">{{ __('finance.margin_help') }}</div></div></div>
            <div class="card-body border-bottom py-2">
                <form method="GET" class="row g-2 align-items-end">
                    <input type="hidden" name="tab" value="overview"><input type="hidden" name="company_id" value="{{ $selectedCompanyId }}">
                    <div class="col-sm-4 col-lg-3"><label class="form-label">{{ __('finance.date_from') }}</label><input type="date" class="form-control" name="date_from" value="{{ $dateFrom }}"></div>
                    <div class="col-sm-4 col-lg-3"><label class="form-label">{{ __('finance.date_to') }}</label><input type="date" class="form-control" name="date_to" value="{{ $dateTo }}"></div>
                    <div class="col-sm-4 col-lg-2"><button class="btn btn-primary w-100"><i class="ti ti-filter me-1"></i>{{ __('finance.apply_filters') }}</button></div>
                </form>
            </div>
        </div>

        <div class="row row-cards">
            <div class="col-lg-6">
                <div class="card h-100"><div class="card-header"><h3 class="card-title">{{ __('finance.by_customer') }}</h3></div>
                    <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('finance.customer') }}</th><th class="text-end">{{ __('finance.revenue') }}</th><th class="text-end">{{ __('finance.cost') }}</th><th class="text-end">{{ __('finance.margin') }}</th><th class="text-end">%</th></tr></thead><tbody>
                        @forelse ($marginReport['by_customer'] as $row)
                            <tr><td class="fw-semibold">{{ $row['customer_name'] }}</td><td class="text-end">{{ number_format($row['revenue'], 2, ',', ' ') }}</td><td class="text-end">{{ number_format($row['cost'], 2, ',', ' ') }}</td><td class="text-end {{ $row['margin'] < 0 ? 'text-danger' : 'text-success' }}">{{ number_format($row['margin'], 2, ',', ' ') }}</td><td class="text-end">{{ number_format($row['margin_percentage'], 2, ',', ' ') }}%</td></tr>
                        @empty <tr><td colspan="5" class="empty-cell"><i class="ti ti-chart-bar-off"></i><span>{{ __('finance.no_margin_data') }}</span></td></tr> @endforelse
                    </tbody></table></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card h-100"><div class="card-header"><h3 class="card-title">{{ __('finance.by_product') }}</h3></div>
                    <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('finance.product') }}</th><th class="text-end">{{ __('finance.revenue') }}</th><th class="text-end">{{ __('finance.cost') }}</th><th class="text-end">{{ __('finance.margin') }}</th><th class="text-end">%</th></tr></thead><tbody>
                        @forelse ($marginReport['by_item'] as $row)
                            <tr><td><strong>{{ $row['item_code'] }}</strong><div class="text-secondary small">{{ $row['item_name'] }}</div><span class="badge mt-1 {{ $row['cost_source']==='ACTUAL'?'bg-success-lt':($row['cost_source']==='THEORETICAL'?'bg-blue-lt':'bg-yellow-lt') }}">{{ $row['cost_source']==='ACTUAL'?__('finance.actual_cost'):($row['cost_source']==='THEORETICAL'?__('finance.theoretical_cost'):__('finance.missing_cost')) }}</span></td><td class="text-end">{{ number_format($row['revenue'], 2, ',', ' ') }}</td><td class="text-end">{{ number_format($row['cost'], 2, ',', ' ') }}</td><td class="text-end {{ $row['margin'] < 0 ? 'text-danger' : 'text-success' }}">{{ number_format($row['margin'], 2, ',', ' ') }}</td><td class="text-end">{{ number_format($row['margin_percentage'], 2, ',', ' ') }}%</td></tr>
                        @empty <tr><td colspan="5" class="empty-cell"><i class="ti ti-chart-bar-off"></i><span>{{ __('finance.no_margin_data') }}</span></td></tr> @endforelse
                    </tbody></table></div>
                </div>
            </div>
        </div>
    @endif

    @if ($activeTab === 'centers')
        @if ($canCreate)
            <div class="card mb-3">
                <div class="card-header"><h3 class="card-title">{{ __('finance.create_cost_center') }}</h3></div>
                <form method="POST" action="{{ route('finance.control.centers.store') }}" class="card-body"><div class="row g-3">@csrf
                    <div class="col-md-3"><label class="form-label required">{{ __('finance.company') }}</label><select name="company_id" class="form-select" data-company-select required>@foreach($companies as $company)<option value="{{ $company->id }}" @selected($company->id===$selectedCompanyId)>{{ $company->name }}</option>@endforeach</select></div>
                    <div class="col-md-3"><label class="form-label">{{ __('finance.site') }}</label><select name="site_id" class="form-select" data-filter-by-company><option value=""></option>@foreach($sites as $site)<option value="{{ $site->id }}" data-company-id="{{ $site->company_id }}">{{ $site->name }}</option>@endforeach</select></div>
                    <div class="col-md-2"><label class="form-label required">{{ __('finance.code') }}</label><input name="code" class="form-control" required maxlength="80"></div>
                    <div class="col-md-4"><label class="form-label required">{{ __('finance.name') }}</label><input name="name" class="form-control" required></div>
                    <div class="col-md-3"><label class="form-label required">{{ __('finance.center_type') }}</label><select name="center_type" class="form-select" required>@foreach($centerTypes as $value)<option value="{{ $value->code }}">{{ $value->localized_label }}</option>@endforeach</select></div>
                    <div class="col-md-3"><label class="form-label required">{{ __('finance.allocation_method') }}</label><select name="allocation_method" class="form-select" required>@foreach($allocationMethods as $value)<option value="{{ $value->code }}">{{ $value->localized_label }}</option>@endforeach</select></div>
                    <div class="col-md-3"><label class="form-label">{{ __('finance.responsible') }}</label><select name="responsible_user_id" class="form-select"><option value=""></option>@foreach($users as $user)<option value="{{ $user->id }}">{{ $user->name }}</option>@endforeach</select></div>
                    <div class="col-md-3 d-flex align-items-end"><label class="form-check"><input class="form-check-input" type="checkbox" name="active" value="1" checked><span class="form-check-label">{{ __('finance.active') }}</span></label></div>
                    <div class="col-12"><label class="form-label">{{ __('finance.description') }}</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div><div class="mt-3 text-end"><button class="btn btn-primary"><i class="ti ti-plus me-1"></i>{{ __('finance.save') }}</button></div></form>
            </div>
        @endif

        <div class="card"><div class="card-header"><h3 class="card-title">{{ __('finance.cost_centers') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('finance.code') }}</th><th>{{ __('finance.name') }}</th><th>{{ __('finance.company') }}</th><th>{{ __('finance.center_type') }}</th><th>{{ __('finance.responsible') }}</th><th>{{ __('finance.rates') }}</th><th></th></tr></thead><tbody>
            @forelse($costCenters as $center)
                <tr><td><span class="badge bg-blue-lt">{{ $center->code }}</span></td><td><strong>{{ $center->name }}</strong><div class="text-secondary small">{{ $center->site?->name }}</div></td><td>{{ $center->company->name }}</td><td>{{ $center->center_type }}</td><td>{{ $center->responsibleUser?->name ?? '—' }}</td><td>{{ $center->rates->count() }}</td><td class="text-end"><button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#center-{{ $center->id }}"><i class="ti ti-adjustments me-1"></i>{{ __('finance.details') }}</button></td></tr>
            @empty <tr><td colspan="7" class="empty-cell"><i class="ti ti-building-off"></i><span>{{ __('finance.cost_centers') }}</span></td></tr> @endforelse
        </tbody></table></div></div>

        @foreach($costCenters as $center)
            <div class="modal modal-blur fade" id="center-{{ $center->id }}" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
                <div class="modal-header"><div><h5 class="modal-title">{{ $center->code }} — {{ $center->name }}</h5><div class="text-secondary small">{{ $center->company->name }}</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <h4>{{ __('finance.edit') }}</h4>
                            <form method="POST" action="{{ route('finance.control.centers.update', $center) }}"><div class="row g-2">@csrf @method('PUT')
                                <input type="hidden" name="company_id" value="{{ $center->company_id }}">
                                <div class="col-md-4"><label class="form-label">{{ __('finance.code') }}</label><input name="code" class="form-control" value="{{ $center->code }}" required></div>
                                <div class="col-md-8"><label class="form-label">{{ __('finance.name') }}</label><input name="name" class="form-control" value="{{ $center->name }}" required></div>
                                <div class="col-md-6"><label class="form-label">{{ __('finance.site') }}</label><select name="site_id" class="form-select"><option value=""></option>@foreach($sites->where('company_id',$center->company_id) as $site)<option value="{{ $site->id }}" @selected($site->id===$center->site_id)>{{ $site->name }}</option>@endforeach</select></div>
                                <div class="col-md-6"><label class="form-label">{{ __('finance.responsible') }}</label><select name="responsible_user_id" class="form-select"><option value=""></option>@foreach($users as $user)<option value="{{ $user->id }}" @selected($user->id===$center->responsible_user_id)>{{ $user->name }}</option>@endforeach</select></div>
                                <div class="col-md-6"><label class="form-label">{{ __('finance.center_type') }}</label><select name="center_type" class="form-select">@foreach($centerTypes as $value)<option value="{{ $value->code }}" @selected($value->code===$center->center_type)>{{ $value->localized_label }}</option>@endforeach</select></div>
                                <div class="col-md-6"><label class="form-label">{{ __('finance.allocation_method') }}</label><select name="allocation_method" class="form-select">@foreach($allocationMethods as $value)<option value="{{ $value->code }}" @selected($value->code===$center->allocation_method)>{{ $value->localized_label }}</option>@endforeach</select></div>
                                <div class="col-12"><label class="form-label">{{ __('finance.description') }}</label><textarea name="description" class="form-control" rows="2">{{ $center->description }}</textarea></div>
                                <div class="col-12"><label class="form-check"><input type="checkbox" name="active" value="1" class="form-check-input" @checked($center->active)><span class="form-check-label">{{ __('finance.active') }}</span></label></div>
                            </div>@if($canUpdate)<div class="mt-2 text-end"><button class="btn btn-primary btn-sm">{{ __('finance.save') }}</button></div>@endif</form>
                        </div>
                        <div class="col-lg-6">
                            <h4>{{ __('finance.resources') }}</h4>
                            <form method="POST" action="{{ route('finance.control.centers.resources', $center) }}">@csrf @method('PUT')
                                <div class="mb-2"><label class="form-label">{{ __('finance.production_lines') }}</label><select name="production_line_ids[]" class="form-select" multiple>@foreach($productionLines as $line)<option value="{{ $line->id }}" @selected($line->cost_center_id===$center->id)>{{ $line->code }} — {{ $line->name }}</option>@endforeach</select></div>
                                <div class="mb-2"><label class="form-label">{{ __('finance.machines') }}</label><select name="machine_ids[]" class="form-select" multiple>@foreach($machines as $machine)<option value="{{ $machine->id }}" @selected($machine->cost_center_id===$center->id)>{{ $machine->code }} — {{ $machine->name }}</option>@endforeach</select></div>
                                @if($canUpdate)<div class="text-end"><button class="btn btn-primary btn-sm">{{ __('finance.save') }}</button></div>@endif
                            </form>
                        </div>
                        <div class="col-12"><hr><h4>{{ __('finance.rates') }}</h4>
                            @if($canCreate)<form method="POST" action="{{ route('finance.control.rates.store', $center) }}" class="row g-2 align-items-end mb-3">@csrf
                                <div class="col-md-3"><label class="form-label">{{ __('finance.rate_type') }}</label><select name="rate_type" class="form-select" required>@foreach($rateTypes as $value)<option value="{{ $value->code }}">{{ $value->localized_label }}</option>@endforeach</select></div>
                                <div class="col-md-2"><label class="form-label">{{ __('finance.hourly_rate') }}</label><input name="hourly_rate" type="number" min="0" step="0.000001" class="form-control" required></div>
                                <div class="col-md-2"><label class="form-label">{{ __('finance.currency') }}</label><select name="currency_code" class="form-select">@foreach($currencies as $currency)<option value="{{ $currency->code }}">{{ $currency->code }}</option>@endforeach</select></div>
                                <div class="col-md-2"><label class="form-label">{{ __('finance.valid_from') }}</label><input name="valid_from" type="date" class="form-control" value="{{ today()->format('Y-m-d') }}" required></div>
                                <div class="col-md-2"><label class="form-label">{{ __('finance.valid_to') }}</label><input name="valid_to" type="date" class="form-control"></div>
                                <div class="col-md-1"><input type="hidden" name="active" value="1"><button class="btn btn-primary w-100"><i class="ti ti-plus"></i></button></div>
                            </form>@endif
                            <div class="table-responsive"><table class="table table-sm table-vcenter" data-datatable="false"><thead><tr><th>{{ __('finance.rate_type') }}</th><th class="text-end">{{ __('finance.hourly_rate') }}</th><th>{{ __('finance.valid_from') }}</th><th>{{ __('finance.valid_to') }}</th></tr></thead><tbody>@forelse($center->rates as $rate)<tr><td>{{ $rate->rate_type }}</td><td class="text-end">{{ number_format((float)$rate->hourly_rate,2,',',' ') }} {{ $rate->currency_code }}</td><td>{{ $rate->valid_from->format('d/m/Y') }}</td><td>{{ $rate->valid_to?->format('d/m/Y') ?? '—' }}</td></tr>@empty<tr><td colspan="4" class="text-secondary text-center">{{ __('finance.no_rate') }}</td></tr>@endforelse</tbody></table></div>
                        </div>
                    </div>
                </div>
            </div></div></div>
        @endforeach
    @endif

    @if ($activeTab === 'scenarios')
        <div class="row row-cards">
            <div class="col-lg-4">
                @if($canCreate)<div class="card mb-3"><div class="card-header"><h3 class="card-title">{{ __('finance.create_scenario') }}</h3></div><form method="POST" action="{{ route('finance.control.scenarios.store') }}" class="card-body">@csrf
                    <div class="mb-2"><label class="form-label">{{ __('finance.company') }}</label><select name="company_id" class="form-select">@foreach($companies as $company)<option value="{{ $company->id }}" @selected($company->id===$selectedCompanyId)>{{ $company->name }}</option>@endforeach</select></div>
                    <div class="row g-2"><div class="col-4"><label class="form-label">{{ __('finance.code') }}</label><input name="code" class="form-control" required></div><div class="col-8"><label class="form-label">{{ __('finance.name') }}</label><input name="name" class="form-control" required></div></div>
                    <div class="row g-2 mt-0"><div class="col-6"><label class="form-label">{{ __('finance.currency') }}</label><select name="currency_code" class="form-select">@foreach($currencies as $currency)<option value="{{ $currency->code }}">{{ $currency->code }}</option>@endforeach</select></div><div class="col-6"><label class="form-label">{{ __('finance.valid_from') }}</label><input name="valid_from" type="date" class="form-control"></div></div>
                    <div class="mt-2"><label class="form-label">{{ __('finance.notes') }}</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                    <div class="mt-3 text-end"><button class="btn btn-primary">{{ __('finance.save') }}</button></div>
                </form></div>@endif
                <div class="card"><div class="card-header"><h3 class="card-title">{{ __('finance.scenarios') }}</h3></div><div class="list-group list-group-flush">@forelse($scenarios as $scenario)<a href="{{ route('finance.control.index',['tab'=>'scenarios','scenario'=>$scenario->id,'year'=>$year,'company_id'=>$selectedCompanyId]) }}" class="list-group-item list-group-item-action {{ $selectedScenario?->id===$scenario->id?'active':'' }}"><div class="d-flex justify-content-between"><strong>{{ $scenario->code }}</strong><span class="badge {{ $scenario->status==='APPROVED'?'bg-success-lt':'bg-blue-lt' }}">{{ $scenario->status }}</span></div><div>{{ $scenario->name }}</div><div class="small opacity-75">{{ $scenario->lines_count }} {{ __('finance.lines') }} · {{ number_format((float)$scenario->planned_margin,2,',',' ') }} {{ $scenario->currency_code }}</div></a>@empty<div class="p-3 text-secondary">{{ __('finance.no_scenario_selected') }}</div>@endforelse</div></div>
            </div>
            <div class="col-lg-8">
                @if($selectedScenario)
                    <div class="alert alert-info"><i class="ti ti-info-circle me-2"></i>{{ __('finance.scenario_help') }}</div>
                    <div class="card mb-3"><div class="card-header"><div><h3 class="card-title">{{ $selectedScenario->code }} — {{ $selectedScenario->name }}</h3><div class="text-secondary small">{{ $selectedScenario->status }} @if($selectedScenario->calculated_at) · {{ $selectedScenario->calculated_at->format('d/m/Y H:i') }}@endif</div></div><div class="card-actions d-flex gap-2">@if($canUpdate && $selectedScenario->status!=='APPROVED')<form method="POST" action="{{ route('finance.control.scenarios.calculate',$selectedScenario) }}">@csrf<button class="btn btn-outline-primary btn-sm"><i class="ti ti-refresh me-1"></i>{{ __('finance.calculate') }}</button></form>@endif @if($canApprove && $selectedScenario->status==='CALCULATED')<form method="POST" action="{{ route('finance.control.scenarios.approve',$selectedScenario) }}">@csrf<button class="btn btn-success btn-sm"><i class="ti ti-check me-1"></i>{{ __('finance.approve') }}</button></form>@endif</div></div>
                        <div class="card-body"><div class="row text-center"><div class="col-4"><div class="text-secondary">{{ __('finance.planned_revenue') }}</div><div class="h3">{{ number_format((float)$selectedScenario->planned_revenue,2,',',' ') }}</div></div><div class="col-4"><div class="text-secondary">{{ __('finance.planned_cost') }}</div><div class="h3">{{ number_format((float)$selectedScenario->planned_cost,2,',',' ') }}</div></div><div class="col-4"><div class="text-secondary">{{ __('finance.planned_margin') }}</div><div class="h3 {{ $selectedScenario->planned_margin<0?'text-danger':'text-success' }}">{{ number_format((float)$selectedScenario->planned_margin,2,',',' ') }} <small>({{ number_format((float)$selectedScenario->planned_margin_percentage,2,',',' ') }}%)</small></div></div></div></div>
                    </div>
                    @if($canUpdate && $selectedScenario->status!=='APPROVED')<div class="card mb-3"><div class="card-header"><h3 class="card-title">{{ __('finance.add_scenario_line') }}</h3></div><form method="POST" action="{{ route('finance.control.scenarios.lines.store',$selectedScenario) }}" class="card-body">@csrf<div class="row g-2">
                        <div class="col-md-6"><label class="form-label">{{ __('finance.product') }}</label><select name="item_id" class="form-select" required>@foreach($items as $item)<option value="{{ $item->id }}">{{ $item->code }} — {{ $item->name }}</option>@endforeach</select></div>
                        <div class="col-md-6"><label class="form-label">{{ __('finance.recipe_version') }}</label><select name="recipe_version_id" class="form-select"><option value="">{{ __('finance.automatic_recipe') }}</option>@foreach($recipeVersions as $version)<option value="{{ $version->id }}">{{ $version->recipe->code }} · v{{ $version->version_number }} · {{ $version->recipe->finishedItem->name }}</option>@endforeach</select></div>
                        <div class="col-md-3"><label class="form-label">{{ __('finance.planned_quantity') }}</label><input name="planned_quantity" type="number" min="0.000001" step="0.001" class="form-control" required></div>
                        <div class="col-md-3"><label class="form-label">{{ __('finance.sales_unit_price') }}</label><input name="sales_unit_price" type="number" min="0" step="0.000001" class="form-control" required></div>
                        <div class="col-md-2"><label class="form-label">{{ __('finance.material_adjustment') }}</label><input name="material_adjustment_percentage" type="number" step="0.01" value="0" class="form-control"></div>
                        <div class="col-md-2"><label class="form-label">{{ __('finance.conversion_adjustment') }}</label><input name="conversion_adjustment_percentage" type="number" step="0.01" value="0" class="form-control"></div>
                        <div class="col-md-2"><label class="form-label">{{ __('finance.overhead_adjustment') }}</label><input name="overhead_adjustment_percentage" type="number" step="0.01" value="0" class="form-control"></div>
                    </div><div class="mt-3 text-end"><button class="btn btn-primary"><i class="ti ti-plus me-1"></i>{{ __('finance.save') }}</button></div></form></div>@endif
                    <div class="card"><div class="card-header"><h3 class="card-title">{{ __('finance.scenario_lines') }}</h3></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('finance.product') }}</th><th class="text-end">{{ __('finance.planned_quantity') }}</th><th class="text-end">{{ __('finance.sales_unit_price') }}</th><th class="text-end">{{ __('finance.unit_cost') }}</th><th class="text-end">{{ __('finance.planned_margin') }}</th><th></th></tr></thead><tbody>@forelse($selectedScenario->lines as $line)<tr><td><strong>{{ $line->item->code }}</strong><div class="text-secondary small">{{ $line->item->name }} @if($line->recipeVersion) · v{{ $line->recipeVersion->version_number }}@endif</div></td><td class="text-end">{{ number_format((float)$line->planned_quantity,3,',',' ') }}</td><td class="text-end">{{ number_format((float)$line->sales_unit_price,4,',',' ') }}</td><td class="text-end">{{ number_format((float)$line->total_unit_cost,4,',',' ') }}</td><td class="text-end {{ $line->planned_margin<0?'text-danger':'text-success' }}">{{ number_format((float)$line->planned_margin,2,',',' ') }}<div class="small">{{ number_format((float)$line->planned_margin_percentage,2,',',' ') }}%</div></td><td class="text-end">@if($canUpdate && $selectedScenario->status!=='APPROVED')<form method="POST" action="{{ route('finance.control.scenarios.lines.destroy',[$selectedScenario,$line]) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-ghost-danger" onclick="return confirm('{{ __('finance.remove') }} ?')"><i class="ti ti-trash"></i></button></form>@endif</td></tr>@empty<tr><td colspan="6" class="empty-cell"><i class="ti ti-flask-off"></i><span>{{ __('finance.no_scenario_lines') }}</span></td></tr>@endforelse</tbody></table></div></div>
                @else
                    <div class="card"><div class="empty"><div class="empty-img"><i class="ti ti-flask-off display-4 text-secondary"></i></div><p class="empty-title">{{ __('finance.no_scenario_selected') }}</p></div></div>
                @endif
            </div>
        </div>
    @endif

    @if ($activeTab === 'budgets')
        <div class="alert alert-info"><i class="ti ti-info-circle me-2"></i>{{ __('finance.budget_help') }}</div>
        <div class="row row-deck row-cards mb-3"><div class="col-md-4"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.budget') }}</div><div class="h2">{{ number_format($budgetTotals['budget'],2,',',' ') }} {{ $currencyCode }}</div></div></div></div><div class="col-md-4"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.actual') }}</div><div class="h2">{{ number_format($budgetTotals['actual'],2,',',' ') }} {{ $currencyCode }}</div></div></div></div><div class="col-md-4"><div class="card"><div class="card-body"><div class="subheader">{{ __('finance.variance') }}</div><div class="h2 {{ $budgetTotals['variance']<0?'text-danger':'text-success' }}">{{ number_format($budgetTotals['variance'],2,',',' ') }} {{ $currencyCode }}</div></div></div></div></div>
        @if($canCreate)<div class="card mb-3"><div class="card-header"><h3 class="card-title">{{ __('finance.create_budget') }}</h3></div><form method="POST" action="{{ route('finance.control.budgets.store') }}" class="card-body">@csrf<div class="row g-2 align-items-end">
            <div class="col-md-2"><label class="form-label">{{ __('finance.company') }}</label><select name="company_id" class="form-select">@foreach($companies as $company)<option value="{{ $company->id }}" @selected($company->id===$selectedCompanyId)>{{ $company->name }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('finance.cost_centers') }}</label><select name="cost_center_id" class="form-select"><option value="">{{ __('finance.all_centers') }}</option>@foreach($costCenters as $center)<option value="{{ $center->id }}">{{ $center->code }} — {{ $center->name }}</option>@endforeach</select></div>
            <div class="col-md-1"><label class="form-label">{{ __('finance.fiscal_year') }}</label><input name="fiscal_year" type="number" min="2020" max="2100" value="{{ $year }}" class="form-control" required></div>
            <div class="col-md-2"><label class="form-label">{{ __('finance.period') }}</label><select name="period" class="form-select"><option value="0">{{ __('finance.annual') }}</option>@for($month=1;$month<=12;$month++)<option value="{{ $month }}">{{ str_pad($month,2,'0',STR_PAD_LEFT) }}</option>@endfor</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('finance.category') }}</label><select name="category_code" class="form-select">@foreach($budgetCategories as $value)<option value="{{ $value->code }}">{{ $value->localized_label }}</option>@endforeach</select></div>
            <div class="col-md-2"><label class="form-label">{{ __('finance.budget_amount') }}</label><input name="budget_amount" type="number" min="0" step="0.01" class="form-control" required></div>
            <div class="col-md-1"><input type="hidden" name="currency_code" value="{{ $currencyCode }}"><button class="btn btn-primary w-100"><i class="ti ti-plus"></i></button></div>
        </div></form></div>@endif
        <div class="card"><div class="card-header"><div><h3 class="card-title">{{ __('finance.budgets') }} {{ $year }}</h3></div><div class="card-actions"><form method="GET"><input type="hidden" name="tab" value="budgets"><input type="hidden" name="company_id" value="{{ $selectedCompanyId }}"><select name="year" class="form-select" onchange="this.form.submit()">@for($y=now()->year-2;$y<=now()->year+3;$y++)<option value="{{ $y }}" @selected($y===$year)>{{ $y }}</option>@endfor</select></form></div></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('finance.period') }}</th><th>{{ __('finance.cost_centers') }}</th><th>{{ __('finance.category') }}</th><th class="text-end">{{ __('finance.budget') }}</th><th class="text-end">{{ __('finance.actual') }}</th><th class="text-end">{{ __('finance.variance') }}</th><th>{{ __('finance.status') }}</th><th></th></tr></thead><tbody>
            @forelse($budgets as $budget)<tr><td>{{ $budget->period===0?__('finance.annual'):str_pad($budget->period,2,'0',STR_PAD_LEFT) }}</td><td>{{ $budget->costCenter?->code ?? __('finance.all_centers') }}</td><td>{{ $budget->category_code }}</td><td class="text-end">{{ number_format((float)$budget->budget_amount,2,',',' ') }}</td><td class="text-end">{{ number_format((float)$budget->actual_amount,2,',',' ') }}</td><td class="text-end {{ $budget->variance_amount<0?'text-danger':'text-success' }}">{{ number_format((float)$budget->variance_amount,2,',',' ') }}<div class="small">{{ number_format((float)$budget->variance_percentage,2,',',' ') }}%</div></td><td><span class="badge {{ $budget->status==='APPROVED'?'bg-success-lt':'bg-blue-lt' }}">{{ $budget->status }}</span></td><td class="text-end"><div class="btn-list flex-nowrap justify-content-end">@if($canUpdate)<form method="POST" action="{{ route('finance.control.budgets.refresh',$budget) }}">@csrf<button class="btn btn-sm btn-ghost-primary" title="{{ __('finance.refresh') }}"><i class="ti ti-refresh"></i></button></form>@endif @if($canApprove && $budget->status!=='APPROVED')<form method="POST" action="{{ route('finance.control.budgets.approve',$budget) }}">@csrf<button class="btn btn-sm btn-ghost-success" title="{{ __('finance.approve') }}"><i class="ti ti-check"></i></button></form>@endif</div></td></tr>
            @empty<tr><td colspan="8" class="empty-cell"><i class="ti ti-chart-bar-off"></i><span>{{ __('finance.no_budgets') }}</span></td></tr>@endforelse
        </tbody></table></div></div>
    @endif
@endsection
