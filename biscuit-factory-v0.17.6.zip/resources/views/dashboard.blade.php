@extends('layouts.app')

@section('title', __('messages.dashboard'))

@section('content')
    <div class="bf-page-heading">
        <div>
            <div class="bf-page-heading__eyebrow">{{ __('messages.operational_workspace') }}</div>
            <h1>{{ __('messages.dashboard') }}</h1>
            <p>{{ __('messages.dashboard_subtitle') }}</p>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <span class="bf-live-status">{{ __('messages.automatic_refresh') }}</span>
            <span class="bf-stat-chip"><i class="ti ti-calendar"></i>{{ now()->translatedFormat('l d F Y') }}</span>
        </div>
    </div>

    <livewire:dashboard.operations-overview />
@endsection
