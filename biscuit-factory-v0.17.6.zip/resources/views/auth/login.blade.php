<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->isLocale('ar') ? 'rtl' : 'ltr' }}" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ __('messages.login') }} — {{ config('app.name') }}</title>
    @vite(app()->isLocale('ar')
        ? ['resources/css/app.scss', 'resources/css/rtl.scss', 'resources/js/app.js']
        : ['resources/css/app.scss', 'resources/js/app.js'])
</head>
<body>
<div class="login-shell">
    <div class="card login-card">
        <div class="card-body p-4 p-md-5">
            <div class="text-center mb-4">
                <div class="avatar avatar-xl bg-yellow-lt mb-3"><i class="ti ti-cookie fs-1"></i></div>
                <h1 class="h3 text-factory">{{ config('app.name') }}</h1>
                <p class="text-secondary mb-0">{{ __('messages.login_subtitle') }}</p>
            </div>

            @if ($errors->any())
                <div class="alert alert-danger">
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('login.store') }}">
                @csrf

                <div class="mb-3">
                    <label for="email" class="form-label">{{ __('messages.email') }}</label>
                    <input id="email"
                           name="email"
                           type="email"
                           class="form-control"
                           value="{{ old('email') }}"
                           autocomplete="email"
                           required
                           autofocus>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">{{ __('messages.password') }}</label>
                    <input id="password"
                           name="password"
                           type="password"
                           class="form-control"
                           autocomplete="current-password"
                           required>
                </div>

                <div class="form-check mb-4">
                    <input id="remember" name="remember" type="checkbox" class="form-check-input" value="1">
                    <label for="remember" class="form-check-label">{{ __('messages.remember_me') }}</label>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    {{ __('messages.login') }}
                </button>
            </form>

            <div class="d-flex justify-content-center gap-3 mt-4 small">
                <a href="{{ route('locale.switch', 'fr') }}">FR</a>
                <a href="{{ route('locale.switch', 'ar') }}">AR</a>
                <a href="{{ route('locale.switch', 'en') }}">EN</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
