@if ($nextStep)
    <div class="card action-panel mb-3" id="next-step">
        <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div>
                <div class="text-uppercase text-secondary small fw-semibold">{{ __('workflow.recommended_next_step') }}</div>
                <div class="h4 mb-0">{{ __($nextStep['label']) }}</div>
            </div>
            @if ($nextStep['type'] === 'form')
                <form method="POST" action="{{ route($nextStep['route'], $nextStep['parameters']) }}">
                    @csrf
                    <button class="btn btn-primary" type="submit">
                        <i class="ti {{ $nextStep['icon'] }} me-1"></i>{{ __($nextStep['label']) }}
                    </button>
                </form>
            @else
                <a class="btn btn-primary" href="{{ $nextStep['url'] }}">
                    <i class="ti {{ $nextStep['icon'] }} me-1"></i>{{ __($nextStep['label']) }}
                </a>
            @endif
        </div>
    </div>
@endif
