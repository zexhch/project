<div class="card mt-3">
    <div class="card-header">
        <h3 class="card-title"><i class="ti ti-timeline me-2"></i>{{ __('workflow.timeline') }}</h3>
    </div>
    <div class="card-body">
        @forelse ($entries as $entry)
            <div class="workflow-timeline-entry">
                <span class="workflow-timeline-dot {{ $entry['to_status'] ? 'is-transition' : '' }}"></span>
                <div class="flex-fill min-w-0">
                    <div class="d-flex flex-wrap justify-content-between gap-2">
                        <strong>{{ __($entry['label']) }}</strong>
                        <small class="text-secondary">{{ $entry['occurred_at']?->format('d/m/Y H:i') }}</small>
                    </div>
                    @if ($entry['from_status'] || $entry['to_status'])
                        <div class="mt-1">
                            @if ($entry['from_status'])<span class="badge bg-secondary-lt text-secondary">{{ $entry['from_status'] }}</span>@endif
                            @if ($entry['to_status'])<i class="ti ti-arrow-right mx-1 text-secondary"></i><span class="badge bg-primary-lt text-primary">{{ $entry['to_status'] }}</span>@endif
                        </div>
                    @endif
                    <small class="text-secondary">{{ $entry['user'] ?: __('workflow.system_user') }}</small>
                </div>
            </div>
        @empty
            <div class="empty py-4">
                <div class="empty-icon"><i class="ti ti-timeline-event"></i></div>
                <p class="empty-title">{{ __('workflow.no_timeline_events') }}</p>
            </div>
        @endforelse
    </div>
</div>
