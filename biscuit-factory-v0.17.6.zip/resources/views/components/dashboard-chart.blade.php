@props([
    'title',
    'subtitle' => null,
    'type' => 'line',
    'labels' => [],
    'values' => [],
    'series' => [],
    'tone' => 'primary',
    'height' => 230,
    'valueSuffix' => '',
    'emptyText' => null,
])
@php
    $chartId = 'bf-chart-'.str()->uuid();
    $payload = [
        'type' => $type,
        'labels' => array_values($labels),
        'values' => array_values($values),
        'series' => array_values($series),
        'tone' => $tone,
        'valueSuffix' => $valueSuffix,
        'emptyText' => $emptyText ?: __('messages.no_data'),
    ];
@endphp
<div {{ $attributes->class(['card bf-dashboard-card h-100']) }}>
    <div class="card-header border-0 pb-0">
        <div>
            <h3 class="card-title mb-1">{{ $title }}</h3>
            @if($subtitle)<div class="text-secondary small">{{ $subtitle }}</div>@endif
        </div>
        <span class="bf-chart-legend-dot bf-tone-{{ $tone }} ms-auto"></span>
    </div>
    <div class="card-body pt-3">
        <div id="{{ $chartId }}" class="bf-chart" style="min-height: {{ (int) $height }}px" data-bf-chart>
            <script type="application/json" data-bf-chart-data>@json($payload)</script>
            <div class="bf-chart-loading"><span class="spinner-border spinner-border-sm"></span></div>
        </div>
    </div>
</div>
