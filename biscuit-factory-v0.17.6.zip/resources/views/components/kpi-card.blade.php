@props([
    'icon' => 'ti-chart-bar',
    'label',
    'value',
    'tone' => 'primary',
    'meta' => null,
    'trend' => null,
    'trendTone' => 'success',
    'href' => null,
    'progress' => null,
])
@php($tag = $href ? 'a' : 'div')
<{{ $tag }} @if($href) href="{{ $href }}" @endif {{ $attributes->class(['bf-kpi-card', 'text-decoration-none' => $href]) }}>
    <div class="bf-kpi-card__head">
        <span class="bf-kpi-card__icon bf-tone-{{ $tone }}"><i class="ti {{ $icon }}"></i></span>
        <span class="bf-kpi-card__label">{{ $label }}</span>
        <span class="bf-kpi-card__help" data-bs-toggle="tooltip" data-bs-title="{{ $label }}" tabindex="0"><i class="ti ti-info-circle"></i></span>
    </div>
    <div class="bf-kpi-card__value">{{ $value }}</div>
    @if($meta || $trend)
        <div class="bf-kpi-card__foot">
            @if($meta)<span class="text-secondary">{{ $meta }}</span>@endif
            @if($trend)<span class="text-{{ $trendTone }} ms-auto"><i class="ti {{ $trendTone === 'danger' ? 'ti-trending-down' : 'ti-trending-up' }} me-1"></i>{{ $trend }}</span>@endif
        </div>
    @endif
    @if($progress !== null)
        <div class="progress progress-sm mt-3"><div class="progress-bar bg-{{ $tone }}" style="width: {{ max(0, min(100, (float) $progress)) }}%"></div></div>
    @endif
</{{ $tag }}>
