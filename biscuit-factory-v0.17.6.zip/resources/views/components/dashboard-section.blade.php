@props(['title', 'subtitle' => null, 'icon' => null, 'href' => null, 'hrefLabel' => null])
<div {{ $attributes->class(['card bf-dashboard-card']) }}>
    <div class="card-header border-0">
        @if($icon)<span class="bf-section-icon"><i class="ti {{ $icon }}"></i></span>@endif
        <div>
            <h3 class="card-title mb-1">{{ $title }}</h3>
            @if($subtitle)<div class="text-secondary small">{{ $subtitle }}</div>@endif
        </div>
        @if($href)<a href="{{ $href }}" class="btn btn-sm btn-ghost-primary ms-auto">{{ $hrefLabel ?: __('workflow.view_all') }}<i class="ti ti-arrow-right ms-1"></i></a>@endif
    </div>
    {{ $slot }}
</div>
