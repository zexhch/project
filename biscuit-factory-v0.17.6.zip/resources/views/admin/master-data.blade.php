@extends('layouts.app')

@section('title', __($configuration['label']))

@section('content')
    <livewire:admin.master-data-manager :resource="$resource" />
@endsection
