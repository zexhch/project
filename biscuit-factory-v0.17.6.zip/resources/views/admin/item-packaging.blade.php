@extends('layouts.app')

@section('title', __('packaging.title'))

@section('content')
<div class="page-header d-print-none mb-3">
    <div class="row g-2 align-items-center">
        <div class="col">
            <div class="page-pretitle">{{ __('admin.catalog') }}</div>
            <h2 class="page-title"><i class="ti ti-packages me-2"></i>{{ __('packaging.title') }}</h2>
            <div class="text-secondary mt-1">{{ $item->code }} — {{ $item->name }}</div>
        </div>
        <div class="col-auto ms-auto">
            <a href="{{ route('admin.master-data', 'items') }}" class="btn btn-ghost-secondary">
                <i class="ti ti-arrow-left me-1"></i>{{ __('admin.back') }}
            </a>
        </div>
    </div>
</div>

@if (session('success'))
    <div class="alert alert-success"><i class="ti ti-circle-check me-2"></i>{{ session('success') }}</div>
@endif
@foreach (['packaging', 'image', 'images', 'archive'] as $errorKey)
    @error($errorKey)<div class="alert alert-danger"><i class="ti ti-alert-triangle me-2"></i>{{ $message }}</div>@enderror
@endforeach
@if (session('image_import_result'))
    @php($result = session('image_import_result'))
    <div class="alert alert-info">
        {{ __('packaging.image_archive_summary', ['imported' => $result['imported'], 'unknown' => count($result['unknown']), 'invalid' => count($result['invalid'])]) }}
    </div>
@endif

<div class="row g-3">
    <div class="col-12 col-xl-4">
        <div class="card h-100">
            <div class="card-header"><h3 class="card-title">{{ __('packaging.article_identity') }}</h3></div>
            <div class="card-body">
                <div class="text-center mb-3">
                    @if ($item->main_image_path)
                        <img src="{{ asset('storage/'.$item->main_image_path) }}" alt="{{ $item->name }}" class="img-fluid rounded border" style="max-height:260px">
                    @else
                        <div class="empty py-4"><div class="empty-icon"><i class="ti ti-photo-off"></i></div><p class="empty-title">{{ __('packaging.no_image') }}</p></div>
                    @endif
                </div>
                <dl class="row mb-0">
                    <dt class="col-5">{{ __('admin.code') }}</dt><dd class="col-7"><code>{{ $item->code }}</code></dd>
                    <dt class="col-5">{{ __('admin.unit') }}</dt><dd class="col-7">{{ $item->baseUnit?->symbol }}</dd>
                    <dt class="col-5">{{ __('admin.category') }}</dt><dd class="col-7">{{ $item->category?->name ?? '—' }}</dd>
                    <dt class="col-5">{{ __('packaging.stock') }}</dt><dd class="col-7">{{ number_format($stockBaseQuantity, 3, ',', ' ') }} {{ $item->baseUnit?->symbol }}</dd>
                </dl>
                @if ($decomposition !== [])
                    <div class="alert alert-secondary mt-3 mb-0">
                        <strong>{{ __('packaging.stock_breakdown') }}</strong><br>
                        {{ collect($decomposition)->map(fn ($line) => number_format($line['quantity'], 3, ',', ' ').' '.$line['unit'])->join(' + ') }}
                    </div>
                @endif
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-8">
        <div class="card mb-3">
            <div class="card-header"><h3 class="card-title">{{ __('packaging.images') }}</h3></div>
            <div class="card-body">
                @if ($canUpdate)
                    <div class="row g-3">
                        <div class="col-12 col-lg-6">
                            <form method="post" action="{{ route('admin.items.main-image.store', $item) }}" enctype="multipart/form-data">
                                @csrf
                                <label class="form-label" for="main-image">{{ __('packaging.main_image') }}</label>
                                <input id="main-image" name="image" type="file" accept="image/png,image/jpeg" class="form-control" required>
                                <div class="form-hint">{{ __('packaging.main_image_hint', ['filename' => $item->code.'.png']) }}</div>
                                <button class="btn btn-primary mt-2"><i class="ti ti-upload me-1"></i>{{ __('packaging.upload') }}</button>
                            </form>
                            @if($item->main_image_path)
                                <form method="post" action="{{ route('admin.items.main-image.destroy', $item) }}" class="mt-2">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-ghost-danger" onclick="return confirm('{{ __('admin.delete_confirmation') }}')"><i class="ti ti-trash me-1"></i>{{ __('packaging.delete_main_image') }}</button>
                                </form>
                            @endif
                        </div>
                        <div class="col-12 col-lg-6">
                            <form method="post" action="{{ route('admin.items.gallery.store', $item) }}" enctype="multipart/form-data">
                                @csrf
                                <label class="form-label" for="gallery-images">{{ __('packaging.gallery') }}</label>
                                <input id="gallery-images" name="images[]" type="file" accept="image/png,image/jpeg" multiple class="form-control" required>
                                <div class="form-hint">{{ __('packaging.gallery_hint') }}</div>
                                <button class="btn btn-outline-primary mt-2"><i class="ti ti-photo-plus me-1"></i>{{ __('packaging.add_gallery') }}</button>
                            </form>
                        </div>
                    </div>
                @endif
                @if ($item->images->isNotEmpty())
                    <div class="row g-2 mt-3">
                        @foreach ($item->images as $image)
                            <div class="col-6 col-md-3">
                                <div class="card card-sm">
                                    <img src="{{ asset('storage/'.($image->thumbnail_path ?: $image->path)) }}" class="card-img-top" alt="{{ $item->name }}">
                                    @if ($canUpdate)
                                        <div class="card-body p-2 text-end">
                                            <form method="post" action="{{ route('admin.items.gallery.destroy', [$item, $image]) }}">
                                                @csrf @method('DELETE')
                                                <button class="btn btn-sm btn-ghost-danger" onclick="return confirm('{{ __('admin.delete_confirmation') }}')"><i class="ti ti-trash"></i></button>
                                            </form>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        @if ($canUpdate)
        <div class="card mb-3">
            <div class="card-header"><h3 class="card-title">{{ $editing ? __('packaging.edit_packaging') : __('packaging.add_packaging') }}</h3></div>
            <form method="post" action="{{ $editing ? route('admin.items.packaging.update', [$item, $editing]) : route('admin.items.packaging.store', $item) }}">
                @csrf @if($editing) @method('PUT') @endif
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label class="form-label form-required" for="unit_id">{{ __('packaging.unit') }}</label>
                            <select id="unit_id" name="unit_id" class="form-select" required>
                                @foreach($units as $unit)
                                    <option value="{{ $unit->id }}" @selected(old('unit_id', $editing?->unit_id) === $unit->id)>{{ $unit->code }} — {{ $unit->name }} ({{ $unit->symbol }})</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12 col-md-4">
                            <label class="form-label" for="parent_unit_id">{{ __('packaging.parent_unit') }}</label>
                            <select id="parent_unit_id" name="parent_unit_id" class="form-select">
                                <option value="">{{ __('packaging.base_unit_or_none') }}</option>
                                @foreach($item->unitConversions->where('active', true) as $parent)
                                    <option value="{{ $parent->unit_id }}" @selected(old('parent_unit_id', $editing?->parent_unit_id) === $parent->unit_id)>{{ $parent->unit?->code }} — × {{ number_format((float)$parent->factor_to_base, 3, ',', ' ') }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12 col-md-4">
                            <label class="form-label form-required" for="factor_to_parent">{{ __('packaging.factor_to_parent') }}</label>
                            <input id="factor_to_parent" name="factor_to_parent" type="number" min="0.00000001" step="0.00000001" class="form-control" value="{{ old('factor_to_parent', $editing?->factor_to_parent ?? 1) }}" required>
                        </div>
                        <div class="col-12 col-md-4">
                            <label class="form-label" for="packaging_barcode">{{ __('admin.barcode') }}</label>
                            <input id="packaging_barcode" name="barcode" class="form-control" value="{{ old('barcode', $editing?->unit_id === $item->base_unit_id ? $item->barcode : $editing?->barcode) }}" @readonly($editing?->unit_id === $item->base_unit_id)>
                            @if($editing?->unit_id === $item->base_unit_id)<div class="form-hint">{{ __('packaging.base_barcode_managed_on_item') }}</div>@endif
                        </div>
                        <div class="col-6 col-md-2"><label class="form-label" for="net_weight_kg">{{ __('packaging.net_weight_kg') }}</label><input id="net_weight_kg" name="net_weight_kg" type="number" min="0" step="0.000001" class="form-control" value="{{ old('net_weight_kg', $editing?->net_weight_kg) }}"></div>
                        <div class="col-6 col-md-2"><label class="form-label" for="gross_weight_kg">{{ __('packaging.gross_weight_kg') }}</label><input id="gross_weight_kg" name="gross_weight_kg" type="number" min="0" step="0.000001" class="form-control" value="{{ old('gross_weight_kg', $editing?->gross_weight_kg) }}"></div>
                        <div class="col-6 col-md-2"><label class="form-label" for="tare_weight_kg">{{ __('packaging.tare_weight_kg') }}</label><input id="tare_weight_kg" name="tare_weight_kg" type="number" min="0" step="0.000001" class="form-control" value="{{ old('tare_weight_kg', $editing?->tare_weight_kg) }}"></div>
                        <div class="col-6 col-md-2"><label class="form-label" for="length_cm">{{ __('packaging.length_cm') }}</label><input id="length_cm" name="length_cm" type="number" min="0" step="0.001" class="form-control" value="{{ old('length_cm', $editing?->length_cm) }}"></div>
                        <div class="col-6 col-md-2"><label class="form-label" for="width_cm">{{ __('packaging.width_cm') }}</label><input id="width_cm" name="width_cm" type="number" min="0" step="0.001" class="form-control" value="{{ old('width_cm', $editing?->width_cm) }}"></div>
                        <div class="col-6 col-md-2"><label class="form-label" for="height_cm">{{ __('packaging.height_cm') }}</label><input id="height_cm" name="height_cm" type="number" min="0" step="0.001" class="form-control" value="{{ old('height_cm', $editing?->height_cm) }}"></div>
                        <div class="col-12 col-md-4">
                            <label class="form-label" for="rounding_mode">{{ __('packaging.rounding_mode') }}</label>
                            <select id="rounding_mode" name="rounding_mode" class="form-select">
                                @foreach(['NONE','UP','DOWN','NEAREST'] as $mode)<option value="{{ $mode }}" @selected(old('rounding_mode', $editing?->rounding_mode ?? 'NONE') === $mode)>{{ __('packaging.rounding_'.$mode) }}</option>@endforeach
                            </select>
                        </div>
                        <div class="col-6 col-md-4"><label class="form-label" for="valid_from">{{ __('packaging.valid_from') }}</label><input id="valid_from" name="valid_from" type="date" class="form-control" value="{{ old('valid_from', $editing?->valid_from?->format('Y-m-d')) }}"></div>
                        <div class="col-6 col-md-4"><label class="form-label" for="valid_to">{{ __('packaging.valid_to') }}</label><input id="valid_to" name="valid_to" type="date" class="form-control" value="{{ old('valid_to', $editing?->valid_to?->format('Y-m-d')) }}"></div>
                        <div class="col-12 d-flex flex-wrap gap-3">
                            @foreach(['purchasing_unit','sales_unit','production_unit','inventory_unit','fractional_allowed','active'] as $flag)
                                <label class="form-check form-switch"><input type="hidden" name="{{ $flag }}" value="0"><input class="form-check-input" type="checkbox" name="{{ $flag }}" value="1" @checked((bool) old($flag, $editing?->{$flag} ?? ($flag === 'active')))><span class="form-check-label">{{ __('packaging.'.$flag) }}</span></label>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex justify-content-end gap-2">
                    @if($editing)<a href="{{ route('admin.items.packaging', $item) }}" class="btn btn-ghost-secondary">{{ __('admin.cancel') }}</a>@endif
                    <button class="btn btn-primary"><i class="ti ti-device-floppy me-1"></i>{{ __('admin.save') }}</button>
                </div>
            </form>
        </div>
        @endif
    </div>
</div>

<div class="card mt-3">
    <div class="card-header"><h3 class="card-title">{{ __('packaging.packaging_hierarchy') }}</h3></div>
    <div class="table-responsive">
        <table class="table table-vcenter card-table">
            <thead><tr><th>{{ __('packaging.unit') }}</th><th>{{ __('packaging.parent_unit') }}</th><th>{{ __('packaging.factor_to_parent') }}</th><th>{{ __('packaging.factor_to_base') }}</th><th>{{ __('packaging.roles') }}</th><th>{{ __('packaging.weights') }}</th><th>{{ __('admin.status') }}</th>@if($canUpdate)<th class="text-end">{{ __('admin.actions') }}</th>@endif</tr></thead>
            <tbody>
                @foreach($item->unitConversions->sortBy('factor_to_base') as $conversion)
                    <tr>
                        <td><strong>{{ $conversion->unit?->code }}</strong><br><small class="text-secondary">{{ $conversion->unit?->name }}</small></td>
                        <td>{{ $conversion->parentUnit?->code ?? '—' }}</td>
                        <td>{{ number_format((float)$conversion->factor_to_parent, 8, ',', ' ') }}</td>
                        <td><span class="badge bg-blue-lt">× {{ number_format((float)$conversion->factor_to_base, 8, ',', ' ') }}</span></td>
                        <td>
                            @foreach(['purchasing_unit'=>'Achat','sales_unit'=>'Vente','production_unit'=>'Production','inventory_unit'=>'Inventaire'] as $flag=>$label)
                                @if($conversion->{$flag})<span class="badge bg-azure-lt me-1">{{ $label }}</span>@endif
                            @endforeach
                        </td>
                        <td>{{ $conversion->net_weight_kg !== null ? number_format((float)$conversion->net_weight_kg, 3, ',', ' ').' kg net' : '—' }}</td>
                        <td><span class="badge {{ $conversion->active ? 'bg-success-lt' : 'bg-secondary-lt' }}">{{ $conversion->active ? __('admin.active') : __('admin.inactive') }}</span></td>
                        @if($canUpdate)
                            <td class="text-end text-nowrap">
                                <a class="btn btn-sm btn-icon btn-ghost-primary" href="{{ route('admin.items.packaging', ['item'=>$item, 'edit'=>$conversion->id]) }}"><i class="ti ti-edit"></i></a>
                                @if($conversion->unit_id !== $item->base_unit_id)
                                    <form method="post" action="{{ route('admin.items.packaging.destroy', [$item, $conversion]) }}" class="d-inline">@csrf @method('DELETE')<button class="btn btn-sm btn-icon btn-ghost-danger" onclick="return confirm('{{ __('admin.delete_confirmation') }}')"><i class="ti ti-trash"></i></button></form>
                                @endif
                            </td>
                        @endif
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@if($canUpdate)
<div class="card mt-3">
    <div class="card-header"><h3 class="card-title">{{ __('packaging.bulk_image_import') }}</h3></div>
    <div class="card-body">
        <form method="post" action="{{ route('admin.items.images.import') }}" enctype="multipart/form-data" class="row g-3 align-items-end">
            @csrf
            <div class="col-12 col-md-8"><label class="form-label" for="image-archive">{{ __('packaging.image_zip') }}</label><input id="image-archive" name="archive" type="file" accept=".zip" class="form-control" required><div class="form-hint">{{ __('packaging.image_zip_hint') }}</div></div>
            <div class="col-auto"><button class="btn btn-outline-primary"><i class="ti ti-file-zip me-1"></i>{{ __('packaging.import') }}</button></div>
        </form>
    </div>
</div>
@endif
@endsection
