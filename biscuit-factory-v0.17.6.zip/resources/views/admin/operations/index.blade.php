@extends('layouts.app')

@section('title', __('operations.title'))

@section('content')
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
        <div>
            <h1 class="h2 mb-1">{{ __('operations.title') }}</h1>
            <p class="text-secondary mb-0">{{ __('operations.description') }}</p>
        </div>
        @if (auth()->user()->hasPermission('operations.create'))
            <form method="POST" action="{{ route('admin.operations.backups.run') }}">
                @csrf
                <button class="btn btn-primary" type="submit"><i class="ti ti-database-export me-1"></i>{{ __('operations.run_backup') }}</button>
            </form>
        @endif
    </div>

    @if (session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    @if (session('error'))<div class="alert alert-danger">{{ session('error') }}</div>@endif
    @if ($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif

    <div class="row g-3 mb-4">
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.overall_status') }}</div><div class="h3 mb-0 {{ $status['readiness']['ready'] ? 'text-success' : 'text-danger' }}">{{ strtoupper($status['readiness']['status']) }}</div></div></div></div>
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.active_sessions') }}</div><div class="h3 mb-0">{{ $status['active_sessions'] }}</div></div></div></div>
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.locked_users') }}</div><div class="h3 mb-0">{{ $status['locked_users'] }}</div></div></div></div>
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.queued_jobs') }}</div><div class="h3 mb-0">{{ $status['queued_jobs'] }}</div></div></div></div>
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.failed_jobs') }}</div><div class="h3 mb-0 {{ $status['failed_jobs'] ? 'text-danger' : '' }}">{{ $status['failed_jobs'] }}</div></div></div></div>
        <div class="col-6 col-xl-2"><div class="card"><div class="card-body"><div class="text-secondary small">{{ __('operations.last_backup') }}</div><div class="small fw-semibold">{{ $status['last_backup']?->started_at?->format('d/m H:i') ?? '—' }}</div><span class="badge {{ $status['last_backup']?->status === 'COMPLETED' ? 'bg-green-lt text-green' : 'bg-secondary-lt' }}">{{ $status['last_backup']?->status ?? '—' }}</span></div></div></div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-xl-7">
            <div class="card h-100">
                <div class="card-header"><h2 class="card-title">{{ __('operations.service_health') }}</h2></div>
                <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('operations.check') }}</th><th>{{ __('operations.status') }}</th><th>{{ __('operations.message') }}</th></tr></thead><tbody>
                @foreach ($status['readiness']['checks'] as $name => $check)
                    <tr><td class="fw-semibold">{{ $name }}</td><td><span class="badge {{ $check['status'] === 'ok' ? 'bg-green-lt text-green' : ($check['status'] === 'warning' ? 'bg-yellow-lt text-yellow' : 'bg-red-lt text-red') }}">{{ strtoupper($check['status']) }}</span></td><td class="text-secondary">{{ $check['message'] }}</td></tr>
                @endforeach
                </tbody></table></div>
            </div>
        </div>
        <div class="col-12 col-xl-5">
            <div class="card h-100">
                <div class="card-header"><h2 class="card-title">{{ __('operations.security_policy') }}</h2></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.operations.policy.update') }}">
                        @csrf @method('PUT')
                        <div class="row g-2">
                            <div class="col-6"><label class="form-label">{{ __('operations.password_min_length') }}</label><input class="form-control" type="number" name="password_min_length" value="{{ $policy['password_min_length'] }}" min="8" max="128"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.password_max_age') }}</label><input class="form-control" type="number" name="password_max_age_days" value="{{ $policy['password_max_age_days'] }}" min="0" max="730"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.login_max_attempts') }}</label><input class="form-control" type="number" name="login_max_attempts" value="{{ $policy['login_max_attempts'] }}" min="3" max="20"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.login_lock_minutes') }}</label><input class="form-control" type="number" name="login_lock_minutes" value="{{ $policy['login_lock_minutes'] }}" min="1" max="1440"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.session_idle_minutes') }}</label><input class="form-control" type="number" name="session_idle_minutes" value="{{ $policy['session_idle_minutes'] }}" min="15" max="1440"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.audit_retention_days') }}</label><input class="form-control" type="number" name="audit_retention_days" value="{{ $policy['audit_retention_days'] }}" min="30" max="3650"></div>
                            <input type="hidden" name="health_snapshot_retention_days" value="{{ $policy['health_snapshot_retention_days'] }}">
                        </div>
                        <div class="row g-2 mt-2">
                            @foreach (['password_require_uppercase', 'password_require_lowercase', 'password_require_number', 'password_require_symbol'] as $key)
                                <div class="col-6"><label class="form-check"><input class="form-check-input" type="checkbox" name="{{ $key }}" value="1" @checked($policy[$key])><span class="form-check-label">{{ __('operations.'.$key) }}</span></label></div>
                            @endforeach
                        </div>
                        @if (auth()->user()->hasPermission('security.update'))
                            <button class="btn btn-outline-primary mt-3" type="submit">{{ __('messages.save') }}</button>
                        @endif
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-xl-5">
            <div class="card h-100">
                <div class="card-header"><h2 class="card-title">{{ __('operations.schedule_backup') }}</h2></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.operations.schedules.store') }}">
                        @csrf
                        <div class="mb-2"><label class="form-label">{{ __('operations.name') }}</label><input class="form-control" name="name" required></div>
                        <div class="row g-2">
                            <div class="col-6"><label class="form-label">{{ __('operations.frequency') }}</label><select class="form-select" name="frequency"><option value="DAILY">{{ __('operations.daily') }}</option><option value="WEEKLY">{{ __('operations.weekly') }}</option><option value="MONTHLY">{{ __('operations.monthly') }}</option></select></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.run_hour') }}</label><input class="form-control" type="number" name="run_hour" value="2" min="0" max="23"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.weekday') }}</label><input class="form-control" type="number" name="weekday" value="1" min="0" max="6"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.month_day') }}</label><input class="form-control" type="number" name="month_day" value="1" min="1" max="28"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.retention_days') }}</label><input class="form-control" type="number" name="retention_days" value="30" min="1" max="3650"></div>
                            <div class="col-6"><label class="form-label">{{ __('operations.notify_user') }}</label><select class="form-select" name="notification_user_id"><option value="">—</option>@foreach($users as $user)<option value="{{ $user->id }}">{{ $user->name }}</option>@endforeach</select></div>
                        </div>
                        <label class="form-check mt-3"><input class="form-check-input" type="checkbox" name="include_files" value="1" checked><span class="form-check-label">{{ __('operations.include_files') }}</span></label>
                        @if (auth()->user()->hasPermission('operations.create'))<button class="btn btn-outline-primary mt-3" type="submit">{{ __('operations.create_schedule') }}</button>@endif
                    </form>
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-7">
            <div class="card h-100"><div class="card-header"><h2 class="card-title">{{ __('operations.backup_schedules') }}</h2></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('operations.name') }}</th><th>{{ __('operations.frequency') }}</th><th>{{ __('operations.next_run') }}</th><th>{{ __('operations.status') }}</th><th></th></tr></thead><tbody>
            @forelse($schedules as $schedule)
                <tr><td>{{ $schedule->name }}</td><td><code>{{ $schedule->frequency }}</code></td><td>{{ $schedule->next_run_at?->format('d/m/Y H:i') ?? '—' }}</td><td><span class="badge {{ $schedule->active ? 'bg-green-lt text-green' : 'bg-secondary-lt' }}">{{ $schedule->active ? __('modules.enabled') : __('modules.disabled') }}</span></td><td class="text-end"><div class="btn-list justify-content-end"><form method="POST" action="{{ route('admin.operations.schedules.toggle', $schedule) }}">@csrf @method('PATCH')<button class="btn btn-sm btn-outline-secondary">{{ $schedule->active ? __('modules.disable') : __('modules.enable') }}</button></form><form method="POST" action="{{ route('admin.operations.schedules.destroy', $schedule) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger"><i class="ti ti-trash"></i></button></form></div></td></tr>
            @empty<tr><td colspan="5" class="text-center text-secondary py-4">{{ __('operations.no_schedules') }}</td></tr>@endforelse
            </tbody></table></div></div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-12 col-xl-5">
            <div class="card h-100">
                <div class="card-header"><h2 class="card-title">{{ __('operations.locked_accounts') }}</h2></div>
                <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('admin.user') }}</th><th>{{ __('admin.locked_until') }}</th><th></th></tr></thead><tbody>
                @forelse($lockedAccounts as $account)
                    <tr><td><div class="fw-semibold">{{ $account->name }}</div><div class="text-secondary small">{{ $account->email }}</div></td><td>{{ $account->locked_until?->format('d/m/Y H:i') }}</td><td class="text-end">@if(auth()->user()->hasPermission('security.update'))<form method="POST" action="{{ route('admin.operations.users.unlock', $account) }}">@csrf<button class="btn btn-sm btn-outline-primary">{{ __('operations.unlock') }}</button></form>@endif</td></tr>
                @empty<tr><td colspan="3" class="text-center text-secondary py-4">{{ __('operations.no_locked_accounts') }}</td></tr>@endforelse
                </tbody></table></div>
            </div>
        </div>
        <div class="col-12 col-xl-7">
            <div class="card h-100">
                <div class="card-header"><h2 class="card-title">{{ __('operations.recent_sessions') }}</h2></div>
                <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('admin.user') }}</th><th>{{ __('security.ip_address') }}</th><th>{{ __('security.last_activity') }}</th><th></th></tr></thead><tbody>
                @forelse($sessions as $session)
                    <tr><td><div class="fw-semibold">{{ $session->user_name ?: $session->user_id }}</div><div class="text-secondary small">{{ $session->user_email }}</div></td><td><code>{{ $session->ip_address ?: '—' }}</code></td><td>{{ now()->setTimestamp((int) $session->last_activity)->format('d/m/Y H:i') }}</td><td class="text-end">@if(auth()->user()->hasPermission('security.update') && !hash_equals(session()->getId(), $session->id))<form method="POST" action="{{ route('admin.operations.sessions.destroy', $session->id) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">{{ __('security.revoke') }}</button></form>@endif</td></tr>
                @empty<tr><td colspan="4" class="text-center text-secondary py-4">{{ __('security.no_sessions') }}</td></tr>@endforelse
                </tbody></table></div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h2 class="card-title">{{ __('operations.backup_history') }}</h2></div>
        <div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('operations.started_at') }}</th><th>{{ __('operations.type') }}</th><th>{{ __('operations.status') }}</th><th>{{ __('operations.size') }}</th><th>{{ __('operations.checksum') }}</th><th></th></tr></thead><tbody>
        @forelse($runs as $run)
            <tr><td>{{ $run->started_at?->format('d/m/Y H:i:s') }}</td><td><code>{{ $run->type }}</code></td><td><span class="badge {{ $run->status === 'COMPLETED' ? 'bg-green-lt text-green' : ($run->status === 'FAILED' ? 'bg-red-lt text-red' : 'bg-yellow-lt text-yellow') }}">{{ $run->status }}</span>@if($run->error_message)<div class="text-danger small">{{ \Illuminate\Support\Str::limit($run->error_message, 120) }}</div>@endif</td><td>{{ $run->size_bytes ? number_format($run->size_bytes / 1048576, 2).' MB' : '—' }}</td><td><code class="small">{{ $run->checksum_sha256 ? substr($run->checksum_sha256, 0, 16).'…' : '—' }}</code></td><td class="text-end">@if($run->status === 'COMPLETED' && auth()->user()->hasPermission('operations.export'))<a class="btn btn-sm btn-outline-primary" href="{{ route('admin.operations.backups.download', $run) }}"><i class="ti ti-download"></i></a>@endif</td></tr>
        @empty<tr><td colspan="6" class="text-center text-secondary py-4">{{ __('operations.no_backups') }}</td></tr>@endforelse
        </tbody></table></div>
    </div>
@endsection
