@extends('layouts.app')

@section('title', __('modules.module_management'))

@section('content')
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-3">
        <div>
            <h1 class="h2 mb-1">{{ __('modules.module_management') }}</h1>
            <p class="text-secondary mb-0">{{ __('modules.module_management_description') }}</p>
        </div>
        @if (auth()->user()->hasPermission('modules.update'))
            <form method="POST" action="{{ route('admin.modules.sync') }}">
                @csrf
                <button class="btn btn-outline-primary" type="submit">
                    <i class="ti ti-refresh me-1"></i>{{ __('modules.sync_manifests') }}
                </button>
            </form>
        @endif
    </div>

    @if (session('status'))
        <div class="alert alert-success" role="alert">{{ session('status') }}</div>
    @endif
    @if ($errors->has('module'))
        <div class="alert alert-danger" role="alert">{{ $errors->first('module') }}</div>
    @endif

    <div class="alert alert-info d-flex gap-2" role="alert">
        <i class="ti ti-info-circle fs-3"></i>
        <div>
            <strong>{{ __('modules.dependency_rule') }}</strong>
            <div>{{ __('modules.dependency_rule_description') }}</div>
        </div>
    </div>

    <div class="row g-3">
        @foreach ($modules as $module)
            @php
                $enabledDependents = collect($module['dependents_state'])->where('enabled', true);
                $missingDependencies = collect($module['dependencies_state'])->where('enabled', false);
                $toggleBlocked = $module['core'] || ($module['enabled'] ? $enabledDependents->isNotEmpty() : $missingDependencies->isNotEmpty());
            @endphp
            <div class="col-12 col-xl-6">
                <div class="card h-100 {{ $module['enabled'] ? '' : 'opacity-75' }}">
                    <div class="card-body">
                        <div class="d-flex align-items-start gap-3">
                            <span class="avatar avatar-lg {{ $module['enabled'] ? 'bg-primary-lt' : 'bg-secondary-lt' }}">
                                <i class="ti {{ $module['icon'] }} fs-2"></i>
                            </span>
                            <div class="flex-fill min-w-0">
                                <div class="d-flex flex-wrap align-items-center gap-2">
                                    <h2 class="h4 mb-0">{{ __($module['name']) }}</h2>
                                    <span class="badge {{ $module['enabled'] ? 'bg-success-lt text-success' : 'bg-secondary-lt text-secondary' }}">
                                        {{ $module['enabled'] ? __('modules.enabled') : __('modules.disabled') }}
                                    </span>
                                    @if ($module['core'])
                                        <span class="badge bg-azure-lt text-azure">{{ __('modules.core') }}</span>
                                    @endif
                                </div>
                                <div class="text-secondary small mt-1">
                                    <code>{{ $module['code'] }}</code> · {{ __('messages.version') }} {{ $module['version'] }}
                                </div>
                                <p class="text-secondary mt-2 mb-3">{{ __($module['description']) }}</p>

                                <div class="row g-2 small">
                                    <div class="col-12 col-md-6">
                                        <strong class="d-block mb-1">{{ __('modules.dependencies') }}</strong>
                                        @forelse ($module['dependencies_state'] as $dependency)
                                            <span class="badge me-1 mb-1 {{ $dependency['enabled'] ? 'bg-green-lt text-green' : 'bg-red-lt text-red' }}">
                                                <i class="ti {{ $dependency['enabled'] ? 'ti-check' : 'ti-x' }} me-1"></i>{{ $dependency['label'] }}
                                            </span>
                                        @empty
                                            <span class="text-secondary">{{ __('modules.none') }}</span>
                                        @endforelse
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <strong class="d-block mb-1">{{ __('modules.used_by') }}</strong>
                                        @forelse ($module['dependents_state'] as $dependent)
                                            <span class="badge me-1 mb-1 {{ $dependent['enabled'] ? 'bg-blue-lt text-blue' : 'bg-secondary-lt text-secondary' }}">
                                                {{ $dependent['label'] }}
                                            </span>
                                        @empty
                                            <span class="text-secondary">{{ __('modules.none') }}</span>
                                        @endforelse
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <div class="text-secondary small">
                            @if ($module['model']?->disabled_at)
                                {{ __('modules.disabled_at') }} {{ $module['model']->disabled_at->format('d/m/Y H:i') }}
                            @elseif ($module['model']?->enabled_at)
                                {{ __('modules.enabled_at') }} {{ $module['model']->enabled_at->format('d/m/Y H:i') }}
                            @else
                                {{ __('modules.manifest_default') }}
                            @endif
                        </div>

                        @if (auth()->user()->hasPermission('modules.update'))
                            <form method="POST" action="{{ route('admin.modules.update', $module['code']) }}">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="enabled" value="{{ $module['enabled'] ? 0 : 1 }}">
                                <button class="btn btn-sm {{ $module['enabled'] ? 'btn-outline-danger' : 'btn-primary' }}" type="submit"
                                    {{ $toggleBlocked ? 'disabled' : '' }}
                                    title="{{ $module['core'] ? __('modules.core_cannot_disable') : ($module['enabled'] && $enabledDependents->isNotEmpty() ? __('modules.disable_dependents_first', ['modules' => $enabledDependents->pluck('label')->join(', ')]) : ($missingDependencies->isNotEmpty() ? __('modules.enable_dependencies_first', ['modules' => $missingDependencies->pluck('label')->join(', ')]) : '')) }}">
                                    <i class="ti {{ $module['enabled'] ? 'ti-toggle-left' : 'ti-toggle-right' }} me-1"></i>
                                    {{ $module['enabled'] ? __('modules.disable') : __('modules.enable') }}
                                </button>
                            </form>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
