@extends('layouts.app')

@section('title', __('help.title'))

@section('content')
<div class="page-header d-print-none mb-3">
    <div class="row g-2 align-items-center">
        <div class="col">
            <div class="page-pretitle">{{ __('navigation.pilotage') }}</div>
            <h2 class="page-title"><i class="ti ti-help-circle me-2"></i>{{ __('help.title') }}</h2>
            <div class="text-secondary mt-1">{{ __('help.subtitle') }}</div>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <div class="input-icon">
            <span class="input-icon-addon"><i class="ti ti-search"></i></span>
            <input type="search" class="form-control" placeholder="{{ __('help.search') }}" data-glossary-search>
        </div>
    </div>
</div>

<div class="row g-3" data-glossary-list>
    @foreach($glossary as $code => $definition)
        <div class="col-12 col-md-6 col-xl-4" data-glossary-entry="{{ mb_strtolower($code.' '.$definition['label'].' '.$definition['description']) }}">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex align-items-start gap-3">
                        <span class="badge bg-primary-lt text-primary fs-3">{{ $code }}</span>
                        <div><h3 class="card-title mb-1">{{ $definition['label'] }}</h3><p class="text-secondary mb-0">{{ $definition['description'] }}</p></div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach

    @foreach($fields as $key => $definition)
        <div class="col-12 col-md-6 col-xl-4" data-glossary-entry="{{ mb_strtolower($key.' '.$definition['description'].' '.($definition['format'] ?? '').' '.($definition['example'] ?? '')) }}">
            <div class="card h-100">
                <div class="card-body">
                    <code>{{ $key }}</code>
                    <p class="mt-2 mb-2">{{ $definition['description'] }}</p>
                    @if(!empty($definition['format']))<div class="text-secondary"><strong>Format :</strong> {{ $definition['format'] }}</div>@endif
                    @if(!empty($definition['example']))<div class="text-secondary"><strong>Exemple :</strong> {{ $definition['example'] }}</div>@endif
                </div>
            </div>
        </div>
    @endforeach
</div>
@endsection
