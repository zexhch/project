<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->isLocale('ar') ? 'rtl' : 'ltr' }}" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', __('messages.dashboard')) — {{ config('app.name') }}</title>
    <script>
        document.documentElement.setAttribute('data-bs-theme', localStorage.getItem('bf-theme') || 'light');
        window.biscuitFactoryUi = @json(__('ui'));
        window.biscuitFactoryFieldHelp = @json(\App\Support\FieldHelp::fields());
        window.biscuitFactoryUserId = @json(auth()->id());
        window.biscuitFactoryWorkflowSummaryUrl = @json(route('workflow.summary'));
        window.biscuitFactoryGlobalSearchUrl = @json(auth()->user()->hasPermission('productivity.view') && app(\App\Services\Modules\ModuleRegistry::class)->enabled('productivity') ? route('productivity.search') : null);
    </script>
    @vite(app()->isLocale('ar') ? ['resources/css/app.scss', 'resources/css/rtl.scss', 'resources/js/app.js'] : ['resources/css/app.scss', 'resources/js/app.js'])
    @livewireStyles
    @stack('head')
</head>
<body class="bf-app-shell">
    <div class="page">
        @include('layouts.partials.sidebar')

        <div class="page-wrapper">
            <header class="navbar navbar-expand-md d-print-none bf-topbar">
                <div class="container-xl">
                    <button class="bf-topbar-action bf-mobile-menu" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu" aria-label="{{ __('admin.toggle_navigation') }}">
                        <i class="ti ti-menu-2"></i>
                    </button>

                    <div class="bf-context-pill me-3" title="{{ __('messages.environment_hint') }}">
                        <i class="ti ti-building-factory-2"></i>
                        <span>{{ __('messages.main_factory') }}</span>
                        <i class="ti ti-chevron-down text-secondary"></i>
                    </div>

                    @if(auth()->user()->hasPermission('productivity.view') && app(\App\Services\Modules\ModuleRegistry::class)->enabled('productivity'))
                        <div class="global-search-wrap d-none d-md-block me-3" data-global-search>
                            <div class="input-icon">
                                <span class="input-icon-addon"><i class="ti ti-search"></i></span>
                                <input type="search" class="form-control" placeholder="{{ __('productivity.global_search') }}" autocomplete="off" data-global-search-input>
                                <span class="bf-search-shortcut">Ctrl K</span>
                            </div>
                            <div class="dropdown-menu global-search-results" data-global-search-results></div>
                        </div>
                    @endif

                    <div class="navbar-nav flex-row order-md-last ms-auto align-items-center gap-1">
                        <button class="nav-link bf-topbar-action" type="button" data-theme-toggle title="{{ __('admin.toggle_theme') }}">
                            <i class="ti ti-sun-high d-none-dark"></i><i class="ti ti-moon d-none-light"></i>
                        </button>

                        @if(auth()->user()->hasPermission('productivity.view') && app(\App\Services\Modules\ModuleRegistry::class)->enabled('productivity'))
                            <a class="nav-link bf-topbar-action" href="{{ route('productivity.index') }}" title="{{ __('productivity.favorites_shortcuts') }}">
                                <i class="ti ti-star"></i>
                            </a>
                        @endif

                        <div class="nav-item dropdown">
                            <button class="nav-link bf-topbar-action" data-bs-toggle="dropdown" type="button" title="{{ __('workflow.notifications') }}">
                                <i class="ti ti-bell"></i>
                                <span class="badge bg-danger notification-badge d-none" data-workflow-badge="unread_notifications">0</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end notification-menu">
                                <div class="dropdown-header">{{ __('workflow.notifications') }}</div>
                                <div class="dropdown-item-text text-secondary small">{{ __('messages.notifications_loaded_on_demand') }}</div>
                                <div class="dropdown-divider"></div>
                                <a href="{{ route('workflow.alerts') }}" class="dropdown-item"><i class="ti ti-bell-ringing me-2"></i>{{ __('workflow.view_all') }}</a>
                            </div>
                        </div>

                        <div class="nav-item dropdown">
                            <button class="nav-link bf-topbar-action" data-bs-toggle="dropdown" type="button" title="{{ strtoupper(app()->getLocale()) }}">
                                <i class="ti ti-language"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="{{ route('locale.switch', 'fr') }}">Français</a>
                                <a class="dropdown-item" href="{{ route('locale.switch', 'ar') }}">العربية</a>
                                <a class="dropdown-item" href="{{ route('locale.switch', 'en') }}">English</a>
                            </div>
                        </div>

                        <div class="nav-item dropdown ms-1">
                            <button class="nav-link d-flex lh-1 text-reset bf-user-menu" data-bs-toggle="dropdown" type="button">
                                <span class="avatar avatar-sm">{{ mb_strtoupper(mb_substr(auth()->user()->name, 0, 1)) }}</span>
                                <span class="bf-user-copy d-none d-xl-block ps-2 text-start">
                                    <span class="d-block fw-semibold">{{ auth()->user()->name }}</span>
                                    <small class="text-secondary">{{ auth()->user()->email }}</small>
                                </span>
                                <i class="ti ti-chevron-down ms-2 text-secondary d-none d-xl-inline"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="{{ route('security.password.edit') }}"><i class="ti ti-key me-2"></i>{{ __('security.change_password') }}</a>
                                <a class="dropdown-item" href="{{ route('security.sessions.index') }}"><i class="ti ti-devices me-2"></i>{{ __('security.active_sessions') }}</a>
                                <div class="dropdown-divider"></div>
                                <form method="POST" action="{{ route('logout') }}">@csrf
                                    <button type="submit" class="dropdown-item"><i class="ti ti-logout me-2"></i>{{ __('messages.logout') }}</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <main class="page-body">
                <div class="container-xl">@yield('content')</div>
            </main>

            <footer class="footer footer-transparent d-print-none">
                <div class="container-xl d-flex justify-content-between text-secondary small">
                    <span>{{ config('app.name') }}</span>
                    <span>{{ __('messages.version') }} {{ trim(file_get_contents(base_path('VERSION'))) }}</span>
                </div>
            </footer>
        </div>
    </div>

    @livewireScripts
    @stack('scripts')
</body>
</html>
