import './bootstrap';
import { Tooltip, bootstrap as tablerBootstrap } from '@tabler/core';
import jQuery from 'jquery';
import select2Factory from 'select2';
import DataTable from 'datatables.net-bs5';
import 'datatables.net-responsive-bs5';

window.bootstrap = tablerBootstrap;
window.jQuery = window.$ = jQuery;

select2Factory(window, jQuery);

const uiTranslations = window.biscuitFactoryUi ?? {};

const elementsIn = (root, selector) => {
    const elements = [];

    if (root instanceof Element && root.matches(selector)) {
        elements.push(root);
    }

    if (root?.querySelectorAll) {
        elements.push(...root.querySelectorAll(selector));
    }

    return elements;
};

const initTooltips = (root = document) => {
    elementsIn(root, '[data-bs-toggle="tooltip"]').forEach((element) => {
        Tooltip.getOrCreateInstance(element);
    });
};

const select2Language = () => {
    const translations = uiTranslations.select2 ?? {};

    return {
        errorLoading: () => translations.error_loading ?? 'The results could not be loaded.',
        inputTooLong: () => translations.input_too_long ?? 'Please delete some characters.',
        inputTooShort: () => translations.input_too_short ?? 'Please enter more characters.',
        loadingMore: () => translations.loading_more ?? 'Loading more results…',
        maximumSelected: () => translations.maximum_selected ?? 'Maximum number of items selected.',
        noResults: () => translations.no_results ?? 'No results found.',
        searching: () => translations.searching ?? 'Searching…',
        removeAllItems: () => translations.remove_all ?? 'Remove all items',
    };
};

const initSelect2 = (root = document) => {
    elementsIn(root, 'select.form-select:not([data-select2="false"])').forEach((element) => {
        const $element = jQuery(element);

        if ($element.hasClass('select2-hidden-accessible')) {
            return;
        }

        const emptyOption = Array.from(element.options).find((option) => option.value === '');
        const searchable = element.dataset.select2Search === 'true' || element.options.length > 7;
        const modal = element.closest('.modal');

        $element.select2({
            allowClear: !element.required && Boolean(emptyOption),
            closeOnSelect: element.dataset.select2Close !== 'false',
            dir: document.documentElement.dir || 'ltr',
            dropdownAutoWidth: true,
            dropdownParent: modal ? jQuery(modal) : jQuery(document.body),
            language: select2Language(),
            minimumResultsForSearch: searchable ? 0 : Number.POSITIVE_INFINITY,
            placeholder: element.dataset.placeholder || emptyOption?.text || uiTranslations.select_placeholder || '',
            width: '100%',
        });

        $element.on('select2:select.biscuitFactory select2:unselect.biscuitFactory select2:clear.biscuitFactory', () => {
            element.dispatchEvent(new Event('change', { bubbles: true }));
        });
    });
};

const hasLaravelPagination = (table) => Boolean(
    table.closest('.card')?.querySelector('.pagination')
    || table.parentElement?.parentElement?.querySelector(':scope > .pagination'),
);

const tableMode = (table) => {
    if (table.dataset.datatableMode) {
        return table.dataset.datatableMode;
    }

    if (table.querySelector('input, select, textarea')) {
        return 'form';
    }

    return hasLaravelPagination(table) ? 'server-rendered' : 'client';
};

const initDataTables = (root = document) => {
    elementsIn(root, 'table.table:not([data-datatable="false"])').forEach((table) => {
        if (DataTable.isDataTable(table) || table.querySelector('tbody > tr > td[colspan]')) {
            return;
        }

        const mode = tableMode(table);
        const controlsEnabled = mode === 'client';
        const orderingEnabled = mode !== 'form' && table.dataset.datatableOrdering !== 'false';
        const responsiveEnabled = mode !== 'form' && table.dataset.datatableResponsive !== 'false';

        const dataTable = new DataTable(table, {
            autoWidth: false,
            deferRender: true,
            info: controlsEnabled,
            language: uiTranslations.datatables ?? {},
            layout: controlsEnabled
                ? {
                    topStart: 'pageLength',
                    topEnd: 'search',
                    bottomStart: 'info',
                    bottomEnd: 'paging',
                }
                : {
                    topStart: null,
                    topEnd: null,
                    bottomStart: null,
                    bottomEnd: null,
                },
            order: [],
            ordering: orderingEnabled,
            pageLength: Number.parseInt(table.dataset.datatablePageLength || '25', 10),
            paging: controlsEnabled,
            responsive: responsiveEnabled,
            searching: controlsEnabled,
        });

        dataTable.on('draw', () => initTooltips(table));
    });
};

const syncCompanyFilters = (root = document) => {
    elementsIn(root, '[data-company-select]').forEach((companySelect) => {
        const form = companySelect.closest('form') || document;
        const companyId = companySelect.value;

        form.querySelectorAll('select[data-filter-by-company]').forEach((select) => {
            let selectedStillValid = !select.value;

            Array.from(select.options).forEach((option) => {
                if (!option.value) {
                    return;
                }

                const visible = !companyId || option.dataset.companyId === companyId;
                option.disabled = !visible;
                option.hidden = !visible;
                if (option.selected && visible) {
                    selectedStillValid = true;
                }
            });

            if (!selectedStillValid) {
                select.value = '';
            }

            if (jQuery(select).hasClass('select2-hidden-accessible')) {
                jQuery(select).trigger('change.select2');
            }
        });
    });
};

const syncExclusiveScopes = (root = document) => {
    const groups = new Map();

    elementsIn(root, '[data-exclusive-scope]').forEach((select) => {
        const form = select.closest('form') || document;
        const key = `${select.dataset.exclusiveScope}:${form.id || Array.from(document.forms).indexOf(form)}`;
        groups.set(key, [...(groups.get(key) || []), select]);
    });

    groups.forEach((selects) => {
        const selected = selects.find((select) => Boolean(select.value));
        selects.forEach((select) => {
            select.disabled = Boolean(selected && select !== selected);
            if (jQuery(select).hasClass('select2-hidden-accessible')) {
                jQuery(select).trigger('change.select2');
            }
        });
    });
};

const destroyEnhancedUi = (root) => {
    elementsIn(root, 'select.select2-hidden-accessible').forEach((element) => {
        const $element = jQuery(element);
        $element.off('.biscuitFactory');
        $element.select2('destroy');
    });

    elementsIn(root, 'table.table').forEach((table) => {
        if (DataTable.isDataTable(table)) {
            new DataTable(table).destroy();
        }
    });
};

const initEnhancedUi = (root = document) => {
    initTooltips(root);
    initSelect2(root);
    initDataTables(root);
    syncCompanyFilters(root);
    syncExclusiveScopes(root);
    if (typeof initItemUnitSelectors === 'function') initItemUnitSelectors(root);
    if (typeof initContextualHelp === 'function') initContextualHelp(root);
    if (typeof initGlossarySearch === 'function') initGlossarySearch(root);
    if (typeof initDashboardCharts === 'function') initDashboardCharts(root);
};

document.addEventListener('DOMContentLoaded', () => {
    initEnhancedUi();

    const storedTheme = localStorage.getItem('bf-theme');
    if (storedTheme) {
        document.documentElement.setAttribute('data-bs-theme', storedTheme);
    }
});

document.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-theme-toggle]');

    if (!toggle) {
        return;
    }

    const current = document.documentElement.getAttribute('data-bs-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-bs-theme', next);
    localStorage.setItem('bf-theme', next);
});

document.addEventListener('change', (event) => {
    if (event.target.matches('[data-company-select]')) {
        syncCompanyFilters(event.target.closest('form') || document);
    }
    if (event.target.matches('[data-exclusive-scope]')) {
        syncExclusiveScopes(event.target.closest('form') || document);
    }
});

document.addEventListener('livewire:init', () => {
    if (!window.Livewire?.hook) {
        return;
    }

    window.Livewire.hook('morph', ({ el }) => destroyEnhancedUi(el));
    window.Livewire.hook('morphed', ({ el }) => initEnhancedUi(el));
});

document.addEventListener('biscuit-factory:refresh-ui', (event) => {
    initEnhancedUi(event.detail?.root ?? document);
});

const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
            if (node instanceof Element) {
                initEnhancedUi(node);

                const parentTable = node.closest('table.table:not([data-datatable="false"])');
                if (parentTable) {
                    initDataTables(parentTable);
                }
            }
        });
    });
});

observer.observe(document.documentElement, { childList: true, subtree: true });

const refreshWorkflowBadges = async () => {
    if (!window.biscuitFactoryWorkflowSummaryUrl) {
        return;
    }

    try {
        const response = await fetch(window.biscuitFactoryWorkflowSummaryUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin',
        });
        if (!response.ok) return;
        const summary = await response.json();
        summary.alerts_total = Number(summary.alerts || 0) + Number(summary.unread_notifications || 0);

        document.querySelectorAll('[data-workflow-badge]').forEach((badge) => {
            const value = Number(summary[badge.dataset.workflowBadge] || 0);
            badge.textContent = value > 99 ? '99+' : String(value);
            badge.classList.toggle('d-none', value === 0);
        });
    } catch (_) {
        // The page remains fully usable when the realtime refresh endpoint is temporarily unavailable.
    }
};

document.addEventListener('DOMContentLoaded', () => {
    refreshWorkflowBadges();
    window.setInterval(refreshWorkflowBadges, 60000);

    if (window.Echo && window.biscuitFactoryUserId) {
        window.Echo.private(`users.${window.biscuitFactoryUserId}`)
            .listen('WorkflowInboxUpdated', refreshWorkflowBadges);
        window.Echo.private('dashboard')
            .listen('DashboardUpdated', refreshWorkflowBadges);
    }
});

const initGlobalSearch = () => {
    const container = document.querySelector('[data-global-search]');
    const input = container?.querySelector('[data-global-search-input]');
    const menu = container?.querySelector('[data-global-search-results]');
    if (!container || !input || !menu || !window.biscuitFactoryGlobalSearchUrl) return;

    let timer;
    let controller;
    const close = () => menu.classList.remove('show');
    const render = (results) => {
        menu.replaceChildren();
        if (!results.length) {
            const empty = document.createElement('div');
            empty.className = 'dropdown-item-text text-secondary';
            empty.textContent = uiTranslations.search_no_result || 'No results';
            menu.append(empty);
        } else {
            results.forEach((result) => {
                const link = document.createElement('a');
                link.className = 'dropdown-item global-search-result';
                link.href = result.url;
                let visual;
                if (result.image_url) {
                    visual = document.createElement('img');
                    visual.src = result.image_url;
                    visual.alt = '';
                    visual.className = 'global-search-thumbnail';
                    visual.loading = 'lazy';
                } else {
                    visual = document.createElement('i');
                    visual.className = `ti ${result.icon}`;
                }
                const body = document.createElement('span');
                const title = document.createElement('strong');
                title.textContent = result.title;
                const subtitle = document.createElement('small');
                subtitle.textContent = `${result.group}${result.subtitle ? ` · ${result.subtitle}` : ''}`;
                body.append(title, subtitle);
                link.append(visual, body);
                menu.append(link);
            });
        }
        menu.classList.add('show');
    };

    input.addEventListener('input', () => {
        window.clearTimeout(timer);
        const query = input.value.trim();
        if (query.length < 2) { close(); return; }
        timer = window.setTimeout(async () => {
            controller?.abort();
            controller = new AbortController();
            try {
                const url = new URL(window.biscuitFactoryGlobalSearchUrl, window.location.origin);
                url.searchParams.set('q', query);
                const response = await fetch(url, { headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, signal: controller.signal });
                if (!response.ok) return;
                const data = await response.json();
                render(data.results || []);
            } catch (error) {
                if (error.name !== 'AbortError') close();
            }
        }, 250);
    });
    input.addEventListener('focus', () => { if (menu.childElementCount) menu.classList.add('show'); });
    document.addEventListener('click', (event) => { if (!container.contains(event.target)) close(); });
    document.addEventListener('keydown', (event) => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
            event.preventDefault(); input.focus(); input.select();
        }
        if (event.key === 'Escape' && document.activeElement === input) { close(); input.blur(); }
    });
};

document.addEventListener('DOMContentLoaded', initGlobalSearch);

const normalizeFieldHelpKey = (element) => {
    const explicit = element.dataset.helpKey;
    if (explicit) return explicit;
    const raw = element.getAttribute('name') || element.id || '';
    const parts = raw.replaceAll(']', '').split(/[.\[]/).filter(Boolean).filter((part) => !/^\d+$/.test(part));
    let key = parts.at(-1) || raw.replace(/^field-[^-]+-/, '');
    key = key.replace(/-+/g, '_');
    return key;
};

const contextualHelpText = (definition) => [
    definition.description,
    definition.format ? `${uiTranslations.help_format || 'Format'}: ${definition.format}` : null,
    definition.example ? `${uiTranslations.help_example || 'Example'}: ${definition.example}` : null,
].filter(Boolean).join('\n');

const initItemUnitSelectors = (root = document) => {
    elementsIn(root, 'form[data-item-unit-scope]').forEach((form) => {
        if (form.dataset.itemUnitsInitialized === 'true') return;
        const itemSelect = form.querySelector('[data-item-selector]');
        const unitSelect = form.querySelector('[data-unit-selector]');
        const factorInput = form.querySelector('[data-factor-to-base]');
        if (!itemSelect || !unitSelect) return;

        const synchronize = () => {
            const selectedItem = itemSelect.selectedOptions[0];
            let units = [];
            try { units = JSON.parse(selectedItem?.dataset.itemUnits || '[]'); } catch { units = []; }
            const current = unitSelect.value;
            unitSelect.replaceChildren();
            if (!units.length) {
                const empty = document.createElement('option');
                empty.value = '';
                empty.textContent = '—';
                unitSelect.append(empty);
            } else {
                units.forEach((entry) => {
                    const option = document.createElement('option');
                    option.value = entry.id;
                    option.textContent = `${entry.code || entry.symbol || ''}${entry.symbol && entry.symbol !== entry.code ? ` — ${entry.symbol}` : ''}`;
                    option.dataset.factorToBase = entry.factor;
                    option.dataset.preferred = entry.preferred ? '1' : '0';
                    unitSelect.append(option);
                });
                const preferred = Array.from(unitSelect.options).find((option) => option.dataset.preferred === '1');
                const retained = Array.from(unitSelect.options).find((option) => option.value === current);
                unitSelect.value = (retained || preferred || unitSelect.options[0])?.value || '';
            }
            unitSelect.dispatchEvent(new Event('change', { bubbles: true }));
            if (window.jQuery && jQuery(unitSelect).hasClass('select2-hidden-accessible')) {
                jQuery(unitSelect).trigger('change.select2');
            }
        };
        const synchronizeFactor = () => {
            if (!factorInput) return;
            factorInput.value = unitSelect.selectedOptions[0]?.dataset.factorToBase || '';
        };
        itemSelect.addEventListener('change', synchronize);
        unitSelect.addEventListener('change', synchronizeFactor);
        form.dataset.itemUnitsInitialized = 'true';
        if (itemSelect.value) synchronize(); else synchronizeFactor();
    });
};

const initContextualHelp = (root = document) => {
    const definitions = window.biscuitFactoryFieldHelp || {};
    elementsIn(root, 'input, select, textarea').forEach((element) => {
        if (element.type === 'hidden' || element.dataset.helpInitialized === 'true') return;
        const key = normalizeFieldHelpKey(element);
        const definition = definitions[key];
        if (!definition) return;
        const label = element.id ? (element.closest('form') || document).querySelector(`label[for="${CSS.escape(element.id)}"]`) : null;
        if (!label || label.querySelector('[data-field-help-icon]')) {
            element.dataset.helpInitialized = 'true';
            return;
        }
        const icon = document.createElement('span');
        icon.className = 'field-help-icon ms-1 text-info';
        icon.tabIndex = 0;
        icon.setAttribute('role', 'button');
        icon.setAttribute('aria-label', definition.description);
        icon.setAttribute('data-bs-toggle', 'tooltip');
        icon.setAttribute('data-bs-placement', 'top');
        icon.setAttribute('data-bs-title', contextualHelpText(definition));
        icon.dataset.fieldHelpIcon = key;
        icon.innerHTML = '<i class="ti ti-info-circle"></i>';
        label.append(icon);
        Tooltip.getOrCreateInstance(icon);
        element.dataset.helpInitialized = 'true';
    });
};

const initGlossarySearch = (root = document) => {
    elementsIn(root, '[data-glossary-search]').forEach((input) => {
        if (input.dataset.searchInitialized === 'true') return;
        input.dataset.searchInitialized = 'true';
        input.addEventListener('input', () => {
            const query = input.value.trim().toLocaleLowerCase();
            document.querySelectorAll('[data-glossary-entry]').forEach((entry) => {
                entry.classList.toggle('d-none', query !== '' && !entry.dataset.glossaryEntry.includes(query));
            });
        });
    });
};


const chartPalette = {
    primary: '#1f7a68',
    teal: '#1f9d86',
    blue: '#3b82f6',
    azure: '#2299dd',
    green: '#2fb344',
    success: '#2fb344',
    orange: '#f59f00',
    yellow: '#f6c344',
    red: '#d63939',
    danger: '#d63939',
    purple: '#8b5cf6',
    pink: '#d63384',
    secondary: '#667085',
};

const svgElement = (name, attributes = {}) => {
    const node = document.createElementNS('http://www.w3.org/2000/svg', name);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, String(value)));
    return node;
};

const chartNumber = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
const chartText = (value) => new Intl.NumberFormat(document.documentElement.lang || undefined, {
    notation: Math.abs(value) >= 1000000 ? 'compact' : 'standard',
    maximumFractionDigits: 1,
}).format(value);

const createChartSvg = (width, height) => {
    const svg = svgElement('svg', { viewBox: `0 0 ${width} ${height}`, role: 'img', preserveAspectRatio: 'none' });
    svg.classList.add('bf-chart-svg');
    return svg;
};

const renderEmptyChart = (container, text) => {
    const empty = document.createElement('div');
    empty.className = 'bf-chart-empty';
    empty.innerHTML = '<i class="ti ti-chart-bar-off"></i>';
    const label = document.createElement('span');
    label.textContent = text || '—';
    empty.append(label);
    container.replaceChildren(empty);
};

const renderLineChart = (container, data, width, height) => {
    const values = (data.values || []).map(chartNumber);
    if (!values.length) return renderEmptyChart(container, data.emptyText);
    const labels = data.labels || [];
    const padding = { top: 12, right: 12, bottom: 34, left: 42 };
    const plotW = Math.max(1, width - padding.left - padding.right);
    const plotH = Math.max(1, height - padding.top - padding.bottom);
    const minValue = Math.min(0, ...values);
    const maxValue = Math.max(1, ...values);
    const range = Math.max(1, maxValue - minValue);
    const color = chartPalette[data.tone] || chartPalette.primary;
    const svg = createChartSvg(width, height);

    for (let index = 0; index <= 4; index += 1) {
        const y = padding.top + (plotH / 4) * index;
        svg.append(svgElement('line', { x1: padding.left, y1: y, x2: width - padding.right, y2: y, class: 'bf-chart-grid' }));
        const value = maxValue - (range / 4) * index;
        const text = svgElement('text', { x: padding.left - 8, y: y + 4, 'text-anchor': 'end', class: 'bf-chart-axis-label' });
        text.textContent = chartText(value);
        svg.append(text);
    }

    const points = values.map((value, index) => {
        const x = padding.left + (values.length === 1 ? plotW / 2 : (plotW * index) / (values.length - 1));
        const y = padding.top + ((maxValue - value) / range) * plotH;
        return { x, y, value, label: labels[index] || '' };
    });
    const path = points.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ');
    const area = `${path} L ${points.at(-1).x} ${padding.top + plotH} L ${points[0].x} ${padding.top + plotH} Z`;
    const gradientId = `gradient-${Math.random().toString(36).slice(2)}`;
    const defs = svgElement('defs');
    const gradient = svgElement('linearGradient', { id: gradientId, x1: '0', y1: '0', x2: '0', y2: '1' });
    gradient.append(svgElement('stop', { offset: '0%', 'stop-color': color, 'stop-opacity': '.28' }));
    gradient.append(svgElement('stop', { offset: '100%', 'stop-color': color, 'stop-opacity': '.02' }));
    defs.append(gradient); svg.append(defs);
    svg.append(svgElement('path', { d: area, fill: `url(#${gradientId})`, class: 'bf-chart-area' }));
    svg.append(svgElement('path', { d: path, fill: 'none', stroke: color, 'stroke-width': 3, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', class: 'bf-chart-line' }));

    points.forEach((point, index) => {
        const circle = svgElement('circle', { cx: point.x, cy: point.y, r: 4, fill: color, class: 'bf-chart-point' });
        const title = svgElement('title');
        title.textContent = `${point.label}: ${chartText(point.value)}${data.valueSuffix || ''}`;
        circle.append(title); svg.append(circle);
        if (index === 0 || index === points.length - 1 || points.length <= 7) {
            const label = svgElement('text', { x: point.x, y: height - 10, 'text-anchor': index === 0 ? 'start' : (index === points.length - 1 ? 'end' : 'middle'), class: 'bf-chart-axis-label' });
            label.textContent = point.label;
            svg.append(label);
        }
    });
    container.replaceChildren(svg);
};

const renderBarChart = (container, data, width, height, horizontal = false) => {
    const values = (data.values || []).map(chartNumber);
    if (!values.length) return renderEmptyChart(container, data.emptyText);
    const labels = data.labels || [];
    const color = chartPalette[data.tone] || chartPalette.primary;
    const svg = createChartSvg(width, height);
    if (horizontal) {
        const padding = { top: 10, right: 48, bottom: 10, left: Math.min(150, width * .34) };
        const plotW = Math.max(1, width - padding.left - padding.right);
        const maxValue = Math.max(1, ...values.map(Math.abs));
        const rowH = Math.max(30, (height - padding.top - padding.bottom) / values.length);
        values.forEach((value, index) => {
            const y = padding.top + index * rowH;
            const label = svgElement('text', { x: padding.left - 10, y: y + rowH * .55, 'text-anchor': 'end', class: 'bf-chart-label' });
            label.textContent = labels[index] || '';
            svg.append(label);
            svg.append(svgElement('rect', { x: padding.left, y: y + rowH * .2, width: plotW, height: rowH * .42, rx: 5, class: 'bf-chart-track' }));
            const bar = svgElement('rect', { x: padding.left, y: y + rowH * .2, width: Math.max(2, plotW * Math.abs(value) / maxValue), height: rowH * .42, rx: 5, fill: color, class: 'bf-chart-bar' });
            const title = svgElement('title'); title.textContent = `${labels[index] || ''}: ${chartText(value)}${data.valueSuffix || ''}`; bar.append(title); svg.append(bar);
            const valueText = svgElement('text', { x: width - padding.right + 8, y: y + rowH * .55, class: 'bf-chart-value' });
            valueText.textContent = `${chartText(value)}${data.valueSuffix || ''}`; svg.append(valueText);
        });
    } else {
        const padding = { top: 16, right: 12, bottom: 40, left: 42 };
        const plotW = Math.max(1, width - padding.left - padding.right);
        const plotH = Math.max(1, height - padding.top - padding.bottom);
        const maxValue = Math.max(1, ...values.map(Math.abs));
        const slot = plotW / values.length;
        const barWidth = Math.min(52, slot * .62);
        for (let index = 0; index <= 4; index += 1) {
            const y = padding.top + plotH / 4 * index;
            svg.append(svgElement('line', { x1: padding.left, y1: y, x2: width - padding.right, y2: y, class: 'bf-chart-grid' }));
        }
        values.forEach((value, index) => {
            const barHeight = plotH * Math.abs(value) / maxValue;
            const x = padding.left + slot * index + (slot - barWidth) / 2;
            const y = padding.top + plotH - barHeight;
            const bar = svgElement('rect', { x, y, width: barWidth, height: Math.max(2, barHeight), rx: 7, fill: color, class: 'bf-chart-bar' });
            const title = svgElement('title'); title.textContent = `${labels[index] || ''}: ${chartText(value)}${data.valueSuffix || ''}`; bar.append(title); svg.append(bar);
            const label = svgElement('text', { x: x + barWidth / 2, y: height - 12, 'text-anchor': 'middle', class: 'bf-chart-axis-label' });
            label.textContent = labels[index] || ''; svg.append(label);
        });
    }
    container.replaceChildren(svg);
};

const renderDonutChart = (container, data) => {
    const values = (data.values || []).map(chartNumber);
    if (!values.length || values.every((value) => value === 0)) return renderEmptyChart(container, data.emptyText);
    const labels = data.labels || [];
    const total = values.reduce((sum, value) => sum + Math.max(0, value), 0) || 1;
    const colors = ['#1f9d86', '#3b82f6', '#f59f00', '#8b5cf6', '#d63939', '#667085'];
    let cursor = 0;
    const stops = values.map((value, index) => {
        const start = cursor;
        cursor += Math.max(0, value) / total * 100;
        return `${colors[index % colors.length]} ${start}% ${cursor}%`;
    });
    const wrapper = document.createElement('div'); wrapper.className = 'bf-donut-chart';
    const donut = document.createElement('div'); donut.className = 'bf-donut-chart__visual'; donut.style.background = `conic-gradient(${stops.join(',')})`;
    const center = document.createElement('div'); center.className = 'bf-donut-chart__center'; center.innerHTML = `<strong>${chartText(total)}</strong><span>${data.valueSuffix || ''}</span>`; donut.append(center);
    const legend = document.createElement('div'); legend.className = 'bf-donut-chart__legend';
    values.forEach((value, index) => {
        const row = document.createElement('div'); row.className = 'bf-donut-chart__legend-row';
        const dot = document.createElement('span'); dot.className = 'bf-donut-chart__dot'; dot.style.background = colors[index % colors.length];
        const label = document.createElement('span'); label.className = 'flex-fill text-truncate'; label.textContent = labels[index] || '';
        const amount = document.createElement('strong'); amount.textContent = `${Math.round(Math.max(0, value) / total * 100)}%`;
        row.append(dot, label, amount); legend.append(row);
    });
    wrapper.append(donut, legend); container.replaceChildren(wrapper);
};

const renderDashboardChart = (container) => {
    const source = container.querySelector('[data-bf-chart-data]');
    if (!source) return;
    let data;
    try { data = JSON.parse(source.textContent || '{}'); } catch { return renderEmptyChart(container, '—'); }
    const width = Math.max(320, Math.round(container.getBoundingClientRect().width || 640));
    const height = Math.max(170, Number.parseInt(container.style.minHeight || '230', 10));
    if (data.type === 'donut') return renderDonutChart(container, data);
    if (data.type === 'horizontal-bar') return renderBarChart(container, data, width, height, true);
    if (data.type === 'bar') return renderBarChart(container, data, width, height, false);
    return renderLineChart(container, data, width, height);
};

const initDashboardCharts = (root = document) => {
    elementsIn(root, '[data-bf-chart]').forEach((container) => {
        if (container.dataset.bfChartInitialized === 'true') return;
        container.dataset.bfChartInitialized = 'true';
        window.requestAnimationFrame(() => renderDashboardChart(container));
        if (window.ResizeObserver) {
            const observer = new ResizeObserver(() => {
                window.clearTimeout(container._bfChartTimer);
                container._bfChartTimer = window.setTimeout(() => {
                    const data = container.dataset.bfChartPayload;
                    if (data) {
                        const script = document.createElement('script');
                        script.type = 'application/json'; script.dataset.bfChartData = ''; script.textContent = data;
                        container.append(script);
                    }
                    renderDashboardChart(container);
                }, 100);
            });
            observer.observe(container);
        }
        const source = container.querySelector('[data-bf-chart-data]');
        if (source) container.dataset.bfChartPayload = source.textContent || '{}';
    });
};
