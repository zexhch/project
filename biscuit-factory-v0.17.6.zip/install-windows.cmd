@echo off
call "%~dp0scripts\windows\init.cmd" %*
exit /b %errorlevel%
