# Biscuit Factory — v0.17.6

Socle d’une application de gestion industrielle pour une fabrique de biscuits.


## Corrective v0.17.6 — diagnostic du déploiement

Cette version chronomètre chaque phase et commande d’installation, écrit des marqueurs immédiats, classe les opérations lentes et capture automatiquement l’état Docker en cas d’échec. Elle corrige également le healthcheck Nginx bloquant, la casse PSR-4 du seeder Administration et la création répétée du lien `public/storage`.

Documentation : `docs/UPGRADE_0.17.6.md`, `docs/INSTALLATION_TRACING.md`, `docs/UPGRADE_0.17.5.md` et `docs/RESOURCE_ALLOCATION.md`.

## Stack

- Laravel 13
- Blade
- Livewire 4
- Tabler 1.4 / Bootstrap 5
- Select2 4.0
- DataTables 2.3 / Responsive 3.0
- PostgreSQL
- Redis
- Laravel Horizon
- Laravel Reverb
- Nginx
- MinIO compatible S3
- Docker Compose

## Démarrage rapide

### Prérequis

- Docker Desktop sous Windows ou Docker Engine sous Linux
- Plugin Docker Compose v2
- PowerShell 5.1/7 sous Windows, ou Bash sous Linux/macOS

### Installation sous Windows

```powershell
.\install-windows.cmd
```

Réinitialisation complète du Docker de test :

```powershell
.\install-windows.cmd -Fresh -ConfirmReset
```

### Installation sous Linux/macOS

```bash
cp .env.example .env
bash scripts/init.sh
```

Réinitialisation complète :

```bash
BISCUIT_FACTORY_CONFIRM_RESET=YES bash scripts/init.sh --fresh
```

Le guide Windows complet est disponible dans `docs/WINDOWS.md`. Après installation, exécutez `security-audit-windows.cmd` pour contrôler les secrets et les sessions.

## Accès

| Service | URL |
|---|---|
| Application | http://localhost:8080 |
| Mailpit | http://localhost:8025 |
| Adminer | http://localhost:8082 |
| MinIO | http://localhost:9001 |
| Vite | http://localhost:5173 |

Identifiants initiaux :

```text
Email : admin@biscuit-factory.local
Mot de passe : ChangeMe123!
```

Les valeurs sont modifiables dans `.env` avant le premier `migrate --seed`.

## Commandes principales

```bash
make up
make down
make logs
make shell
make test
make lint
make audit
make module-sync
make module-check
make reports-run
make productivity-prune
make doctor
make health
make resources
make install-report
make validate-static
make backup
make security-audit
```

Diagnostic rapide après démarrage :

```bash
make doctor
make health
make resources
make install-report
```

Validation complète après démarrage :

```bash
bash scripts/validate-release.sh
```

Contrôle statique complet, sans Docker :

```bash
bash scripts/validate-static.sh
```

Test destructif d’une installation totalement neuve sur le Docker de test :

```bash
BISCUIT_FACTORY_CONFIRM_RESET=YES bash scripts/validate-installation.sh
```

## Fonctionnalités de la version 0.17.6

- Marqueurs `START`, `END`, `SLOW`, `WAIT` et `FAIL` pour chaque phase et commande d’installation.
- Journal complet, chronométrage structuré et résumé JSON dans `storage/logs/installer`.
- Rapport des opérations les plus lentes via `installation-report-windows.cmd` ou `scripts/installation-report.sh`.
- Capture automatique de l’état Compose, de `docker stats` et des logs après un échec.
- Healthcheck Nginx statique, attente readiness instrumentée, seeder Administration conforme PSR-4 et lien `public/storage` idempotent.

## Fonctionnalités héritées de la version 0.17.5

- Allocation CPU, mémoire et PID isolée pour chaque service Docker.
- Paramétrage centralisé dans `.env` avec profil équilibré par défaut.
- PostgreSQL, Redis et Horizon dimensionnés en cohérence avec leurs limites de conteneur.
- OPcache production optimisé et rapport de consommation disponible sous Windows/Linux.
- Précontrôle avertissant lorsque Docker Desktop dispose de moins de 4 vCPU ou 6 Gio.

## Fonctionnalités héritées de la version 0.17.4

- Pages Qualité corrigées et couvertes par les tests fonctionnels.
- Horizon compatible avec les démarrages lents de Docker Desktop grâce au timeout de 45 secondes.
- Pool PHP-FPM renforcé à 10 workers pour limiter les saturations.
- Build Docker protégé contre les liens et fichiers temporaires générés à l’exécution.
- Durées d’arrêt converties en secondes entières malgré les microsecondes Carbon 3.
- Validateur statique dédié aux correctifs de recette.

## Fonctionnalités héritées de la version 0.17.3

- Shell applicatif modernisé avec navigation par workflow, recherche globale et en-tête allégé.
- Cartes KPI et composants de tableau de bord réutilisables sur les écrans clés.
- Graphiques SVG natifs : courbes, barres, barres horizontales et donuts.
- Tableaux de bord principal, Stocks, Production, Ventes et Facturation/Finance refondus.
- Chargement asynchrone des compteurs et cache court des agrégats de pilotage.
- Cache en mémoire des permissions et suppression des requêtes inutiles dans l’en-tête.
- Interface responsive, sombre, RTL et accessible au clavier.

## Fonctionnalités héritées de la version 0.17.2

- Hiérarchie dynamique des unités et conditionnements par article : unité de base, parent, facteur et facteur calculé vers la base.
- Rôles d’unité d’achat, vente, production et inventaire, avec poids, dimensions, codes-barres, validité et arrondi.
- Recalcul transactionnel des descendants, prévention des cycles, historisation et protection des conversions utilisées.
- Sélecteurs d’unités dynamiques et facteurs figés sur les documents commerciaux et d’achat.
- Images principales et galeries PNG nommées à partir du code article, miniatures et import groupé ZIP.
- Import/export CSV/XLSX des conditionnements avec prévisualisation et modèle téléchargeable.
- Tooltips accessibles et glossaire centralisé FR/EN/AR.

## Fonctionnalités héritées de la version 0.17.1

- Identité légale complète des sociétés, clients et fournisseurs : RC, NIF, NIS et AI.
- Logo société, activité, banque, agence et numéro de compte configurables.
- Factures et bons de livraison A4 avec prix unitaire HT, TVA, montants HT/TTC et montant en lettres.
- Prix du bon de livraison affichés par défaut mais masquables par modèle documentaire.
- Mise à jour des fiches, recherches, exports CSV historiques et échanges CSV/XLSX.
- Tests et validateur autonome des documents légaux.

## Fonctionnalités héritées de la version 0.17.0

- Module Planification industrielle activable et intégré au workflow Production.
- Plan directeur calculé depuis les commandes clients confirmées sur un horizon configurable.
- Besoins nets chronologiques intégrant stock libéré non périmé, réceptions prévues et stock de sécurité.
- Explosion MRP des recettes approuvées, pénuries matières et conversions manquantes.
- Capacités produit/ligne, cadences, temps de changement, équipes, maintenances et machines critiques.
- Ordonnancement automatique sur la ligne la moins chargée et détection des surcharges.
- Scénarios de demande/capacité, approbation contrôlée et génération transactionnelle des OF.
- Calcul historisé du TRS/OEE par ligne, avec disponibilité, performance et qualité.

## Fonctionnalités héritées de la version 0.16.0


- Nouveau module Productivité activable avec permissions et migration dédiées.
- Imports CSV/XLSX des articles, clients et fournisseurs avec modèles téléchargeables.
- Prévisualisation ligne par ligne, modes mise à jour/ignorer/échec et rapport d’erreurs XLSX.
- Imports et exports asynchrones sur des files Horizon dédiées, avec notifications et rétention planifiée.
- Exports CSV/XLSX privés avec protection contre les formules de tableur.
- Actions groupées d’activation, désactivation et restauration, limitées et auditées.
- Duplication contrôlée des devis, commandes clients, demandes d’achat et commandes fournisseurs.
- Recherche globale selon les permissions, raccourci `Ctrl/Cmd + K`, favoris et raccourcis personnels.
- Contrôle croisé des permissions Productivité et des droits métier source.

## Fonctionnalités héritées de la version 0.15.0

- Périodes comptables mensuelles, clôture, réouverture motivée et blocage des écritures sur période fermée.
- Numérotation légale configurable par société et document, avec remise à zéro annuelle, mensuelle ou continue.
- Circuits d'approbation multi-niveaux des factures clients et fournisseurs, par seuil, devise, rôle, permission et quorum.
- Rejet, correction et nouvelle soumission des factures sans perte d'historique.
- Annulations contrôlées par avoir de contrepartie ; aucune suppression silencieuse d'une facture émise.
- Modèles A4 FR/EN/AR configurables pour devis, commandes, livraisons, achats, réceptions, factures, avoirs et règlements.
- Historique immuable des versions, impressions, validations et contre-écritures.
- Boutons d'impression et actions de gouvernance intégrés aux parcours Ventes, Achats et Finance.

## Fonctionnalités héritées de la version 0.14.0

- Politique de mots de passe configurable, expiration, changement forcé et verrouillage des comptes.
- Gestion des sessions actives avec révocation utilisateur ou administrateur.
- Nouveau centre Administration → Sécurité et exploitation.
- Diagnostic de sécurité `security:audit` sous Linux et Windows.
- Sauvegardes PostgreSQL 17 et fichiers privés, manuelles ou planifiées, avec SHA-256, rétention et restauration atomique sécurisée.
- Instantanés de santé, suivi des files et historique des exécutions.
- Audit enrichi par sévérité, corrélation et métadonnées structurées.
- Sessions chiffrées par défaut, en-têtes Nginx renforcés et stockage privé partagé en production.

- Installation Docker Desktop pilotée par PowerShell 5.1 ou PowerShell 7.
- Lanceurs `.cmd` utilisables sans modifier la stratégie d’exécution Windows.
- Précontrôle du moteur Linux, de Docker Compose, des ports, du disque et des secrets.
- Validation destructive complète d’une installation neuve sous Windows.
- Sauvegarde et restauration PostgreSQL/documentaire sans redirection binaire PowerShell.
- Procédure Windows détaillée et commandes équivalentes aux scripts Linux.
- Endpoints de liveness et readiness exploitables par Docker, Nginx ou un superviseur.
- Commande `app:doctor` et scripts de pré-contrôle, santé et validation d’installation neuve.
- Installation idempotente avec réinitialisation destructive explicitement confirmée.
- Interface d’administration Tabler responsive, claire/sombre et RTL.
- Select2 sur les listes déroulantes et DataTables sur les tableaux, avec intégration Livewire et traductions FR/EN/AR.
- CRUD génériques sécurisés pour l’organisation, les articles, les ressources de production et les paramètres.
- Gestion des utilisateurs, rôles et permissions.
- Recherche, pagination, validation et protections contre les suppressions incohérentes.
- Journal d’audit atomique pour chaque création, modification et suppression.
- Diffusion temps réel des changements avec repli par polling sur le tableau de bord.
- Registre de stock par article, lot et emplacement avec comptabilisation atomique.
- Réceptions, sorties et transferts en deux étapes : brouillon puis comptabilisation.
- Lots, dates de fabrication/péremption, statuts configurables et sélection FEFO.
- Inventaires à l’aveugle, gel du théorique, saisie des comptages et ajustements automatiques.
- Alertes dynamiques de stock minimum et de péremption.
- Coût moyen pondéré à la réception et conservé lors des transferts.

- Module Recettes complet : création, versions brouillon, duplication, ingrédients, pertes prévues, rendement, gamme, validité et approbation.
- Versions approuvées figées ; toute évolution passe par une nouvelle version afin de préserver l’historique des OF.
- Prix de revient théorique séparant matières, emballages, main-d’œuvre, machines, énergie, sous-traitance et frais indirects.
- Charges de transformation configurables par quantité, montant fixe ou pourcentage du sous-total.
- Historique des calculs théoriques et alertes lorsque le CUMP ou une conversion d’unité manque.
- Prix de revient réel calculé depuis les sorties de stock valorisées, les charges réelles, les rejets et la quantité conforme.
- Contrôle de gestion avec centres de coûts, taux horaires historisés, simulations, budgets et analyse des écarts.
- Marges par client et produit utilisant le dernier coût réel disponible, avec repli sur le coût théorique.
- Navigation latérale repliable organisée selon le workflow métier de bout en bout.
- Tableau « Mes tâches » dérivé des statuts réels, avec priorités, filtres, report et masquage réversible.
- Centre d’alertes opérationnelles et financières avec notifications sans doublons.
- Bouton « Étape suivante » sur les principaux documents métier et ouverture directe de la zone d’action.
- Timeline unifiée des transitions de statut et du journal d’audit.
- Compteurs de tâches, alertes et notifications mis à jour par WebSocket avec repli toutes les 60 secondes.
- Registre de modules activables et désactivables avec état persistant et audit des changements.
- Manifestes, routes, permissions et migrations rattachés explicitement à chaque domaine.
- Dépendances strictes entre Stocks, Production, Qualité, Maintenance, Achats, Ventes et Finance.
- Masquage automatique des menus, raccourcis, tâches et alertes des modules désactivés.
- Blocage des URL directes et suspension des traitements planifiés lorsque le domaine est inactif.
- Écran Administration → Modules et commandes de synchronisation, diagnostic, activation et désactivation.
- Module Rapports autonome avec huit vues : direction, ventes, achats, production, stocks, qualité, maintenance et finance.
- Tableaux de bord adaptés au rôle et aux permissions, avec indicateurs et tendances contextuels.
- Filtres société, site et période, exports CSV protégés et vues d’impression/PDF.
- Rapports programmés quotidiens, hebdomadaires ou mensuels, fichiers privés et historique d’exécution.
- Génération planifiée sans doublon concurrent et notification lorsque le fichier est disponible.
- Coût réel figé automatiquement à la clôture de l’OF et affecté à l’entrée en stock du lot fini.
- Comparaison standard/réel et analyse de l’écart sur chaque ordre de fabrication.
- Ordres de fabrication calculant automatiquement les besoins matière.
- Consommations multi-emplacements d’un même entrepôt en FEFO, production de lots finis et pertes/rejets.
- Arrêts de ligne et de machine chronométrés côté serveur.
- Maintenance préventive et corrective avec ordres, actions, techniciens et coûts.
- Consommation FEFO des pièces de rechange avec mouvement de stock automatique.
- Génération quotidienne des interventions préventives et notifications.
- Indicateurs MTBF, MTTR, disponibilité et échéances proches.
- Plans de contrôle versionnés, paramètres et points critiques HACCP.
- Contrôles de réception, en cours et de produit fini avec résultats par critère.
- Décisions qualité de libération, blocage ou rejet des lots.
- Non-conformités, analyse des causes, actions CAPA et vérification d’efficacité.
- Garde qualité intégré à la production, aux réceptions, aux sorties de stock et à FEFO.
- Fournisseurs, contacts, catalogues fournisseur et évaluations multicritères.
- Demandes d’achat, consultations multi-fournisseurs et sélection d’offre.
- Tarifs d’achat approuvés avec périodes, priorités et paliers de quantité.
- Commandes d’achat directes ou issues d’une offre, avec approbation et suivi des reliquats.
- Réceptions fournisseurs atomiques avec lots en quarantaine, stock, coût moyen et contrôle qualité automatique.
- Retours fournisseurs tracés par réception, article et lot.
- Clients, contacts, groupes, canaux et conditions commerciales.
- Tarifs de vente HT/TTC ciblés par client, groupe ou canal, avec périodes, priorités et paliers.
- Devis, acceptation et conversion en commande sans perte de l’historique tarifaire.
- Commandes clients, confirmation et réservations atomiques multi-lots selon FEFO.
- Livraisons totales ou partielles avec affectation de lots et sorties de stock automatiques.
- Traçabilité lot fini → livraison → client et exports CSV protégés.
- Retours clients isolés dans de nouveaux lots en quarantaine avec contrôle qualité automatique.
- Factures clients générées à partir des quantités réellement expédiées, avec émission et échéance calculée.
- Factures fournisseurs rapprochées avec la commande et la réception, avec acceptation explicite des écarts.
- Avoirs clients et fournisseurs imputés sans altérer le montant historique des factures.
- Règlements complets ou partiels, multi-factures, avec plusieurs règlements possibles sur une même facture.
- Comptes bancaires et caisses configurables, modes de règlement dynamiques et références externes.
- Annulation auditée d’un règlement comptabilisé, sans suppression, avec recalcul automatique des soldes.
- Balance âgée clients/fournisseurs, statuts Émise, Partiellement réglée, Réglée et Échue, et registre de relances clients.
- Rafraîchissement horaire des statuts échus et recalcul par lots des factures ouvertes.
- Audit d’intégrité du grand livre auxiliaire avec contrôle des totaux, soldes, statuts et ventilations, plus réparation explicite des seules valeurs dérivées.
- Verrouillage déterministe des règlements et contrôles renforcés société/tiers/devise/compte financier.
- Parcours utilisateur allégés : création repliée, options avancées, résumés compacts et étapes visuelles.
- Documentation fonctionnelle distincte pour chaque module dans `docs/modules/`.

## Structure documentaire

- `docs/INSTALLATION.md`
- `docs/WINDOWS.md`
- `docs/ARCHITECTURE.md`
- `docs/DATABASE.md`
- `docs/MODULES.md`
- `docs/ROLES_PERMISSIONS.md`
- `docs/REALTIME.md`
- `docs/I18N.md`
- `docs/BACKUP_RESTORE.md`
- `docs/OPERATIONS.md`
- `docs/SECURITY.md`
- `docs/ROADMAP.md`
- `docs/UPGRADE_0.2.md`
- `docs/UPGRADE_0.3.md`
- `docs/UPGRADE_0.5.md`
- `docs/UPGRADE_0.5.1.md`
- `docs/UPGRADE_0.6.md`
- `docs/UPGRADE_0.7.md`
- `docs/UPGRADE_0.8.md`
- `docs/UPGRADE_0.9.md`
- `docs/UPGRADE_0.9.1.md`
- `docs/UPGRADE_0.10.md`
- `docs/UPGRADE_0.10.1.md`
- `docs/UPGRADE_0.11.md`
- `docs/UPGRADE_0.12.md`
- `docs/UPGRADE_0.13.md`
- `docs/UPGRADE_0.13.1.md`
- `docs/UPGRADE_0.13.2.md`
- `docs/UPGRADE_0.14.md`
- `docs/modules/README.md`

## Principes

- Tous les référentiels métier sont configurables.
- Les valeurs initiales sont des données de démonstration.
- L’application doit évoluer vers plusieurs sociétés, sites, entrepôts et lignes.
- Les mouvements de stock, lots, production, qualité, maintenance et finance sont auditables.
- Chaque livraison est une archive complète versionnée.
