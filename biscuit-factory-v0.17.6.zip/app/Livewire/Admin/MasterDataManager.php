<?php

namespace App\Livewire\Admin;

use App\Events\DashboardUpdated;
use App\Models\Company;
use App\Models\Language;
use App\Models\Item;
use App\Models\ItemUnitConversion;
use App\Models\MaintenancePlan;
use App\Models\Permission;
use App\Models\ReferenceValue;
use App\Models\Role;
use App\Models\SystemSetting;
use App\Models\TaxRate;
use App\Models\User;
use App\Models\WorkShift;
use App\Support\MasterDataRegistry;
use App\Services\Catalog\ItemImageService;
use App\Services\Catalog\ItemPackagingService;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Throwable;

class MasterDataManager extends Component
{
    use WithFileUploads, WithPagination;

    protected $paginationTheme = 'bootstrap';

    public string $resource;

    public string $search = '';

    public int $perPage = 15;

    public bool $formOpen = false;

    public ?string $editingId = null;

    public array $form = [];

    public mixed $logoUpload = null;

    public mixed $itemImageUpload = null;

    public ?string $existingLogoPath = null;

    public ?string $existingItemImagePath = null;

    private ?array $grantedPermissions = null;

    public function mount(string $resource): void
    {
        $this->resource = $resource;

        abort_unless($this->can('view'), 403, __('messages.forbidden'));
    }

    public function updatingSearch(): void
    {
        $this->resetPage();
    }

    public function updatedPerPage(): void
    {
        if (! in_array($this->perPage, [10, 15, 25, 50], true)) {
            $this->perPage = 15;
        }

        $this->resetPage();
    }

    public function create(): void
    {
        $this->authorizeAction('create');
        $this->resetValidation();
        $this->editingId = null;
        $this->logoUpload = null;
        $this->itemImageUpload = null;
        $this->existingLogoPath = null;
        $this->existingItemImagePath = null;
        $this->form = $this->defaultForm();
        $this->formOpen = true;
    }

    public function edit(string $id): void
    {
        $this->authorizeAction('update');
        $this->resetValidation();

        $configuration = $this->configuration();
        $modelClass = $configuration['model'];
        $model = $modelClass::query()
            ->with($configuration['with'] ?? [])
            ->findOrFail($id);

        $this->editingId = $model->getKey();
        $this->logoUpload = null;
        $this->itemImageUpload = null;
        $this->existingLogoPath = $model instanceof Company ? $model->logo_path : null;
        $this->existingItemImagePath = $model instanceof Item ? $model->main_image_path : null;
        $this->form = $this->formFromModel($model, $configuration);
        $this->formOpen = true;
    }

    public function cancel(): void
    {
        $this->resetValidation();
        $this->editingId = null;
        $this->logoUpload = null;
        $this->itemImageUpload = null;
        $this->existingLogoPath = null;
        $this->existingItemImagePath = null;
        $this->form = [];
        $this->formOpen = false;
    }

    public function save(): void
    {
        $action = $this->editingId ? 'update' : 'create';
        $this->authorizeAction($action);
        $configuration = $this->configuration();
        $this->normalizeForm($configuration);
        $this->validate($this->rules(), [], $this->validationAttributes());

        $uploadedLogoPath = null;
        if ($configuration['model'] === Company::class && $this->logoUpload) {
            $uploadedLogoPath = $this->logoUpload->storePublicly('company-logos', 'public');
        }

        if ($configuration['model'] === MaintenancePlan::class
            && empty($this->form['machine_id']) && empty($this->form['production_line_id'])) {
            $this->addError('form.machine_id', __('maintenance.asset_required'));
            return;
        }

        if ($configuration['model'] === Permission::class && (
            preg_match('/^[a-z][a-z0-9_-]*\.[a-z][a-z0-9_-]*$/', (string) $this->form['code']) !== 1
            || Str::before((string) $this->form['code'], '.') !== (string) $this->form['module']
        )) {
            $this->addError('form.code', __('admin.invalid_permission_code'));

            return;
        }

        $modelClass = $configuration['model'];
        $model = $this->editingId
            ? $modelClass::query()->findOrFail($this->editingId)
            : new $modelClass;

        if ($model instanceof Item && $model->exists
            && $model->base_unit_id !== ($this->form['base_unit_id'] ?? null)
            ) {
            $this->addError('form.base_unit_id', __('packaging.base_unit_change_blocked'));
            return;
        }

        if ($model instanceof Item && filled($this->form['barcode'] ?? null)
            && ItemUnitConversion::query()
                ->where('barcode', trim((string) $this->form['barcode']))
                ->where(fn ($query) => $query
                    ->where('item_id', '!=', $model->id)
                    ->orWhere('unit_id', '!=', $model->base_unit_id))
                ->exists()) {
            $this->addError('form.barcode', __('packaging.barcode_already_used'));
            return;
        }

        $oldItemCode = $model instanceof Item && $model->exists ? $model->code : null;
        $oldValues = $model->exists ? $this->auditSnapshot($model) : [];

        try {
            DB::transaction(function () use ($action, $configuration, $model, $oldValues, $uploadedLogoPath): void {
                $data = $this->modelData($configuration, $model);

                if ($model instanceof Company && $uploadedLogoPath) {
                    $data['logo_path'] = $uploadedLogoPath;
                }

                if ($model instanceof Language && ($data['is_default'] ?? false)) {
                    Language::query()
                        ->when($model->exists, fn ($query) => $query->where($model->getKeyName(), '!=', $model->getKey()))
                        ->update(['is_default' => false]);
                }

                if ($model instanceof TaxRate && ($data['is_default'] ?? false)) {
                    TaxRate::query()
                        ->where('company_id', $data['company_id'] ?? null)
                        ->when($model->exists, fn ($query) => $query->where($model->getKeyName(), '!=', $model->getKey()))
                        ->update(['is_default' => false]);
                }

                if ($model instanceof Role && $model->exists && $model->system) {
                    $data['system'] = true;
                    $data['code'] = $model->getOriginal('code');
                }

                if ($model instanceof ReferenceValue && $model->exists && $model->system) {
                    $data['system'] = true;
                    $data['domain'] = $model->getOriginal('domain');
                    $data['code'] = $model->getOriginal('code');
                }

                if ($model instanceof Permission && $model->exists && $model->system) {
                    $data['system'] = true;
                    $data['module'] = $model->getOriginal('module');
                    $data['code'] = $model->getOriginal('code');
                }

                if ($model instanceof User && $model->is(auth()->user())) {
                    $data['active'] = true;
                }

                $model->fill($data);
                $model->save();

                if ($model instanceof User) {
                    $roleIds = $model->is(auth()->user())
                        ? $model->roles()->pluck('roles.id')->all()
                        : ($this->form['role_ids'] ?? []);
                    $model->roles()->sync($roleIds);
                }

                if ($model instanceof Role) {
                    $model->permissions()->sync($this->form['permission_ids'] ?? []);
                }

                $model->refresh();
                $this->writeAudit(
                    event: $action === 'create' ? 'created' : 'updated',
                    model: $model,
                    oldValues: $oldValues,
                    newValues: $this->auditSnapshot($model),
                );
            });
        } catch (Throwable $exception) {
            if ($uploadedLogoPath) {
                Storage::disk('public')->delete($uploadedLogoPath);
            }

            throw $exception;
        }

        if ($uploadedLogoPath && $this->existingLogoPath && $this->existingLogoPath !== $uploadedLogoPath) {
            Storage::disk('public')->delete($this->existingLogoPath);
        }

        if ($model instanceof Item) {
            app(ItemPackagingService::class)->ensureBaseConversion($model, auth()->user());
            if ($oldItemCode && $oldItemCode !== $model->code) {
                app(ItemImageService::class)->renameForCodeChange($model, $oldItemCode, auth()->user());
            }
            if ($this->itemImageUpload) {
                app(ItemImageService::class)->storeMain($model, $this->itemImageUpload, auth()->user());
            }
        }

        $this->broadcastChange($action, $model);

        session()->flash('success', __('admin.saved_successfully'));
        $this->cancel();
    }

    public function delete(string $id): void
    {
        $this->authorizeAction('delete');
        $configuration = $this->configuration();
        $modelClass = $configuration['model'];
        $model = $modelClass::query()->findOrFail($id);

        if ($model instanceof User && $model->is(auth()->user())) {
            $this->addError('delete', __('admin.cannot_delete_current_user'));

            return;
        }

        if (($model instanceof Role || $model instanceof ReferenceValue || $model instanceof Permission) && $model->system) {
            $this->addError('delete', __('admin.cannot_delete_system_record'));

            return;
        }

        if ($model instanceof Language && $model->is_default) {
            $this->addError('delete', __('admin.cannot_delete_default_language'));

            return;
        }

        $oldValues = $this->auditSnapshot($model);

        try {
            DB::transaction(function () use ($model, $oldValues): void {
                $model->delete();
                $this->writeAudit('deleted', $model, $oldValues, []);
            });
        } catch (QueryException) {
            $this->addError('delete', __('admin.record_is_in_use'));

            return;
        }

        $this->broadcastChange('delete', $model);
        session()->flash('success', __('admin.deleted_successfully'));

        if ($this->editingId === $id) {
            $this->cancel();
        }
    }

    public function render()
    {
        $configuration = $this->configuration();
        $modelClass = $configuration['model'];
        $query = $modelClass::query()->with($configuration['with'] ?? []);

        if ($this->search !== '') {
            $term = '%'.mb_substr(trim($this->search), 0, 100).'%';
            $operator = DB::connection()->getDriverName() === 'pgsql' ? 'ilike' : 'like';
            $query->where(function ($searchQuery) use ($configuration, $operator, $term): void {
                foreach ($configuration['search'] as $index => $column) {
                    $method = $index === 0 ? 'where' : 'orWhere';
                    $searchQuery->{$method}($column, $operator, $term);
                }
            });
        }

        $rows = $query
            ->orderBy($configuration['order_by'] ?? 'created_at', $configuration['order_direction'] ?? 'asc')
            ->paginate($this->perPage);

        return view('livewire.admin.master-data-manager', [
            'configuration' => $configuration,
            'rows' => $rows,
            'options' => $this->resolveOptions($configuration),
            'canCreate' => $this->can('create'),
            'canUpdate' => $this->can('update'),
            'canDelete' => $this->can('delete'),
        ]);
    }

    private function configuration(): array
    {
        return MasterDataRegistry::get($this->resource);
    }

    private function defaultForm(): array
    {
        return collect($this->configuration()['fields'])
            ->mapWithKeys(fn (array $field, string $name): array => [
                $name => $field['default'] ?? match ($field['type']) {
                    'checkbox' => false,
                    'multiselect', 'multicheckbox' => [],
                    default => '',
                },
            ])
            ->all();
    }

    private function formFromModel(Model $model, array $configuration): array
    {
        $form = $this->defaultForm();

        foreach ($configuration['fields'] as $name => $field) {
            $value = match (true) {
                $model instanceof User && $name === 'role_ids' => $model->roles->pluck('id')->all(),
                $model instanceof Role && $name === 'permission_ids' => $model->permissions->pluck('id')->all(),
                $model instanceof ReferenceValue && str_starts_with($name, 'label_') => $model->labels[substr($name, 6)] ?? '',
                $name === 'password' => '',
                default => $model->getAttribute($name),
            };

            if ($value instanceof DateTimeInterface) {
                $value = $value->format('Y-m-d');
            }

            if ($field['type'] === 'time' && is_string($value)) {
                $value = substr($value, 0, 5);
            }

            if ($model instanceof SystemSetting && $name === 'value') {
                $value = is_array($value)
                    ? json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
                    : match (true) {
                        $value === true => 'true',
                        $value === false => 'false',
                        $value === null => '',
                        default => (string) $value,
                    };
            }

            $form[$name] = $value ?? match ($field['type']) {
                'checkbox' => false,
                'multiselect', 'multicheckbox' => [],
                default => '',
            };
        }

        return $form;
    }

    private function rules(): array
    {
        $configuration = $this->configuration();
        $rules = [];

        foreach ($configuration['fields'] as $name => $field) {
            $fieldRules = [];
            $required = ($field['required'] ?? false)
                || (($field['required_on_create'] ?? false) && ! $this->editingId);

            $fieldRules[] = $required ? 'required' : 'nullable';

            $fieldRules = array_merge($fieldRules, match ($field['type']) {
                'email' => ['email:rfc', 'max:'.($field['max'] ?? 255)],
                'password' => ['string', 'min:'.($field['min'] ?? 8), 'max:'.($field['max'] ?? 255)],
                'textarea' => ['string', 'max:10000'],
                'checkbox' => ['boolean'],
                'number' => array_values(array_filter([
                    'numeric',
                    isset($field['min']) ? 'min:'.$field['min'] : null,
                    isset($field['max']) ? 'max:'.$field['max'] : null,
                ])),
                'date' => ['date_format:Y-m-d'],
                'time' => ['date_format:H:i'],
                'multiselect', 'multicheckbox' => ['array'],
                default => ['string', 'max:'.($field['max'] ?? 255)],
            });

            if ($field['unique'] ?? false) {
                $unique = Rule::unique($configuration['table'], $name)
                    ->ignore($this->editingId);
                $scopes = is_array($field['unique']) ? $field['unique'] : [];

                foreach ($scopes as $scope) {
                    $unique->where(fn ($query) => $query->where($scope, $this->emptyToNull($this->form[$scope] ?? null)));
                }

                $fieldRules[] = $unique;
            }

            if (isset($field['options'])) {
                $optionDefinition = $field['options'];

                if ($optionDefinition['source'] === 'static' && $field['type'] !== 'multicheckbox') {
                    $fieldRules[] = Rule::in(array_keys($optionDefinition['values']));
                }

                if ($optionDefinition['source'] === 'model' && $field['type'] === 'select') {
                    $optionModelClass = $optionDefinition['model'];
                    $optionModel = new $optionModelClass;
                    $exists = Rule::exists($optionModel->getTable(), $optionDefinition['value']);

                    if ($optionDefinition['active_only']) {
                        $exists->where(fn ($query) => $query->where('active', true));
                    }

                    $fieldRules[] = $exists;
                }

                if ($optionDefinition['source'] === 'reference' && $field['type'] === 'select') {
                    $fieldRules[] = Rule::exists('reference_values', 'code')
                        ->where(fn ($query) => $query
                            ->where('domain', $optionDefinition['domain'])
                            ->where('active', true));
                }
            }

            if ($configuration['model'] === SystemSetting::class
                && $name === 'value') {
                $fieldRules = array_merge($fieldRules, match ($this->form['value_type'] ?? 'string') {
                    'integer' => ['integer'],
                    'decimal' => ['numeric'],
                    'boolean' => [Rule::in(['true', 'false', '1', '0'])],
                    'json' => ['json'],
                    default => [],
                });
            }

            $rules['form.'.$name] = $fieldRules;

            if (isset($field['options'])
                && $field['options']['source'] === 'model'
                && $field['type'] === 'multiselect') {
                $optionModelClass = $field['options']['model'];
                $optionModel = new $optionModelClass;
                $exists = Rule::exists($optionModel->getTable(), $field['options']['value']);

                if ($field['options']['active_only']) {
                    $exists->where(fn ($query) => $query->where('active', true));
                }

                $rules['form.'.$name.'.*'] = [
                    'string',
                    $exists,
                ];
            }

            if (isset($field['options'])
                && $field['options']['source'] === 'static'
                && $field['type'] === 'multicheckbox') {
                $rules['form.'.$name.'.*'] = [Rule::in(array_keys($field['options']['values']))];
            }
        }

        if ($configuration['model'] === TaxRate::class
            && ($this->form['valid_from'] ?? '') !== ''
            && ($this->form['valid_to'] ?? '') !== '') {
            $rules['form.valid_to'][] = 'after_or_equal:form.valid_from';
        }

        if ($configuration['model'] === Company::class) {
            $rules['logoUpload'] = ['nullable', 'image', 'mimes:png,jpg,jpeg,webp', 'max:2048'];
        }

        if ($configuration['model'] === Item::class) {
            $rules['form.code'][] = 'regex:/^[A-Z0-9._-]+$/i';
            $rules['itemImageUpload'] = ['nullable', 'image', 'mimes:png,jpg,jpeg', 'max:'.(int) config('catalog.item_images.max_file_kb', 8192)];
        }

        return $rules;
    }

    private function normalizeForm(array $configuration): void
    {
        foreach ($configuration['fields'] as $name => $field) {
            if (isset($this->form[$name])
                && is_string($this->form[$name])
                && ! in_array($field['type'], ['password', 'textarea'], true)) {
                $this->form[$name] = trim($this->form[$name]);
            }
        }

        if ($configuration['model'] === User::class && isset($this->form['email'])) {
            $this->form['email'] = Str::lower(trim((string) $this->form['email']));
        }

        if ($configuration['model'] === Permission::class) {
            $this->form['module'] = Str::lower((string) ($this->form['module'] ?? ''));
            $this->form['code'] = Str::lower((string) ($this->form['code'] ?? ''));
        }
    }

    private function validationAttributes(): array
    {
        $attributes = collect($this->configuration()['fields'])
            ->mapWithKeys(fn (array $field, string $name): array => ['form.'.$name => __($field['label'])])
            ->all();

        if ($this->configuration()['model'] === Company::class) {
            $attributes['logoUpload'] = __('admin.company_logo');
        }

        if ($this->configuration()['model'] === Item::class) {
            $attributes['itemImageUpload'] = __('packaging.main_image');
        }

        return $attributes;
    }

    private function modelData(array $configuration, Model $model): array
    {
        $special = ['role_ids', 'permission_ids', 'label_fr', 'label_ar', 'label_en'];
        $data = [];

        foreach ($configuration['fields'] as $name => $field) {
            if (in_array($name, $special, true) || ($field['readonly'] ?? false)) {
                continue;
            }

            if ($name === 'password' && ($this->form[$name] ?? '') === '') {
                continue;
            }

            $value = $this->form[$name] ?? null;

            if (is_string($value) && ! in_array($field['type'], ['password', 'textarea'], true)) {
                $value = trim($value);
            }

            if ($field['type'] === 'checkbox') {
                $value = (bool) $value;
            } elseif ($field['type'] === 'multicheckbox') {
                $value = array_map('intval', $value ?? []);
            } elseif (! ($field['required'] ?? false)) {
                $value = $this->emptyToNull($value);
            }

            $data[$name] = $value;
        }

        if ($model instanceof ReferenceValue) {
            $data['labels'] = [
                'fr' => trim((string) $this->form['label_fr']),
                'ar' => trim((string) $this->form['label_ar']),
                'en' => trim((string) $this->form['label_en']),
            ];
        }

        if ($model instanceof User) {
            $data['email'] = Str::lower(trim((string) $data['email']));
            if (array_key_exists('password', $data)) {
                $data['password_changed_at'] = now();
                $data['force_password_change'] = true;
            }
        }

        if ($model instanceof SystemSetting) {
            $data['value'] = $this->castSettingValue(
                (string) ($this->form['value'] ?? ''),
                (string) ($this->form['value_type'] ?? 'string'),
            );
        }

        if ($model instanceof WorkShift) {
            $data['work_days'] = array_values(array_map('intval', $this->form['work_days'] ?? []));
        }

        return $data;
    }

    private function castSettingValue(string $value, string $type): mixed
    {
        return match ($type) {
            'boolean' => filter_var($value, FILTER_VALIDATE_BOOLEAN),
            'integer' => (int) $value,
            'decimal' => (float) $value,
            'json' => json_decode($value, true, 512, JSON_THROW_ON_ERROR),
            default => $value,
        };
    }

    private function resolveOptions(array $configuration): array
    {
        $resolved = [];

        foreach ($configuration['fields'] as $name => $field) {
            if (! isset($field['options'])) {
                continue;
            }

            $definition = $field['options'];

            if ($definition['source'] === 'static') {
                $resolved[$name] = collect($definition['values'])
                    ->map(fn (string $label, string|int $value): array => [
                        'value' => $value,
                        'label' => __($label),
                        'group' => null,
                    ])
                    ->values()
                    ->all();

                continue;
            }

            if ($definition['source'] === 'reference') {
                $resolved[$name] = ReferenceValue::query()
                    ->where('domain', $definition['domain'])
                    ->where('active', true)
                    ->orderBy('sort_order')
                    ->orderBy('code')
                    ->get()
                    ->map(fn (ReferenceValue $item): array => [
                        'value' => $item->code,
                        'label' => $item->localized_label,
                        'group' => null,
                    ])
                    ->all();

                continue;
            }

            $modelClass = $definition['model'];
            $labelColumn = $definition['label'];
            $items = $modelClass::query()
                ->when($definition['active_only'], fn ($query) => $query->where('active', true))
                ->orderBy($labelColumn)
                ->get();
            $resolved[$name] = $items->map(function (Model $item) use ($definition): array {
                $label = (string) $item->getAttribute($definition['label']);

                if ($definition['suffix']) {
                    $label .= ' — '.$item->getAttribute($definition['suffix']);
                }

                return [
                    'value' => $item->getAttribute($definition['value']),
                    'label' => $label,
                    'group' => $definition['group'] ? $item->getAttribute($definition['group']) : null,
                ];
            })->all();
        }

        return $resolved;
    }

    private function can(string $action): bool
    {
        if (($this->configuration()['read_only'] ?? false) && $action !== 'view') {
            return false;
        }

        $this->grantedPermissions ??= auth()->user()?->permissions()->pluck('code')->all() ?? [];

        return in_array($this->configuration()['module'].'.'.$action, $this->grantedPermissions, true);
    }

    private function authorizeAction(string $action): void
    {
        abort_unless($this->can($action), 403, __('messages.forbidden'));
    }

    private function emptyToNull(mixed $value): mixed
    {
        return $value === '' ? null : $value;
    }

    private function writeAudit(string $event, Model $model, array $oldValues, array $newValues): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->getKey(),
            'old_values' => $oldValues === [] ? null : json_encode($oldValues, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'new_values' => $newValues === [] ? null : json_encode($newValues, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'ip_address' => request()->ip(),
            'user_agent' => Str::limit((string) request()->userAgent(), 1000, ''),
            'created_at' => now(),
        ]);
    }

    private function auditValues(array $values): array
    {
        unset($values['password'], $values['remember_token']);

        return $values;
    }

    private function auditSnapshot(Model $model): array
    {
        $values = $this->auditValues($model->getAttributes());

        if ($model instanceof User) {
            $values['role_ids'] = $model->roles()->orderBy('roles.code')->pluck('roles.id')->all();
        }

        if ($model instanceof Role) {
            $values['permission_ids'] = $model->permissions()->orderBy('permissions.code')->pluck('permissions.id')->all();
        }

        return $values;
    }

    private function broadcastChange(string $action, Model $model): void
    {
        try {
            DashboardUpdated::dispatch([
                'resource' => $this->resource,
                'action' => $action,
                'id' => $model->getKey(),
            ]);
        } catch (Throwable $exception) {
            report($exception);
        }
    }
}
