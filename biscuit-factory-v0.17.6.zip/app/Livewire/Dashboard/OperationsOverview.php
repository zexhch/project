<?php

namespace App\Livewire\Dashboard;

use App\Models\Company;
use App\Services\Modules\ModuleRegistry;
use App\Services\Reporting\RoleDashboardService;
use App\Services\Workflow\WorkflowInboxService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\On;
use Livewire\Component;

class OperationsOverview extends Component
{
    public string $lastUpdated = '';

    public function mount(): void
    {
        $this->touch();
    }

    #[On('echo-private:dashboard,DashboardUpdated')]
    public function refreshFromBroadcast(array $event = []): void
    {
        $this->touch();
    }

    public function refreshDashboard(): void
    {
        $this->touch();
    }

    private function touch(): void
    {
        $this->lastUpdated = now()->format('d/m/Y H:i:s');
    }

    public function render()
    {
        $user = auth()->user();
        $permissions = $user->permissions()->pluck('code')->flip();
        $modules = app(ModuleRegistry::class);
        $dashboard = Cache::remember(
            'dashboard:operations:v173:'.app()->getLocale().':'.today()->toDateString(),
            now()->addSeconds(30),
            fn (): array => $this->dashboardData(),
        );

        $kpis = collect([
            ['module' => 'sales', 'permission' => 'sales.view', 'icon' => 'ti-shopping-bag', 'label' => __('sales.pending_orders'), 'value' => $dashboard['stats']['open_sales_orders'], 'tone' => 'teal', 'meta' => __('sales.sales_orders'), 'href' => route('sales.index')],
            ['module' => 'production', 'permission' => 'production.view', 'icon' => 'ti-settings-automation', 'label' => __('production.status_in_progress'), 'value' => $dashboard['stats']['production_in_progress'], 'tone' => 'blue', 'meta' => __('production.production_orders'), 'href' => route('production.index', ['status' => 'IN_PROGRESS'])],
            ['module' => 'stocks', 'permission' => 'stocks.view', 'icon' => 'ti-package-off', 'label' => __('stock.low_stock_alerts'), 'value' => $dashboard['stats']['low_stock'], 'tone' => $dashboard['stats']['low_stock'] > 0 ? 'orange' : 'green', 'meta' => __('stock.stocks'), 'href' => route('stocks.index')],
            ['module' => 'stocks', 'permission' => 'stocks.view', 'icon' => 'ti-calendar-alert', 'label' => __('stock.expiry'), 'value' => $dashboard['stats']['expiring_lots'], 'tone' => $dashboard['stats']['expiring_lots'] > 0 ? 'orange' : 'green', 'meta' => trans_choice('workflow.alert_lots_count', $dashboard['stats']['expiring_lots'], ['count' => $dashboard['stats']['expiring_lots']]), 'href' => route('stocks.index', ['expiry' => 'soon'])],
            ['module' => 'finance', 'permission' => 'finance.view', 'icon' => 'ti-file-invoice', 'label' => __('billing.overdue'), 'value' => $dashboard['stats']['overdue_invoices'], 'tone' => $dashboard['stats']['overdue_invoices'] > 0 ? 'red' : 'green', 'meta' => number_format($dashboard['stats']['overdue_amount'], 2, ',', ' ').' '.$dashboard['currency'], 'href' => route('finance.billing.index', ['status' => 'OVERDUE'])],
            ['module' => 'maintenance', 'permission' => 'maintenance.view', 'icon' => 'ti-tool', 'label' => __('maintenance.work_orders'), 'value' => $dashboard['stats']['open_maintenance'], 'tone' => 'purple', 'meta' => __('reports.open_work_orders'), 'href' => route('maintenance.index')],
        ])->filter(fn (array $metric): bool => $permissions->has($metric['permission']) && $modules->enabled($metric['module']))->values();

        $operationalMetrics = collect([
            ['module' => 'stocks', 'permission' => 'stocks.view', 'label' => 'stock.current_stock', 'value' => $dashboard['stats']['stock_lots'], 'icon' => 'ti-packages'],
            ['module' => 'stocks', 'permission' => 'stocks.view', 'label' => 'stock.expiry', 'value' => $dashboard['stats']['expiring_lots'], 'icon' => 'ti-calendar-alert'],
            ['module' => 'production', 'permission' => 'production.view', 'label' => 'maintenance.active_downtimes', 'value' => $dashboard['stats']['active_downtimes'], 'icon' => 'ti-player-pause'],
            ['module' => 'maintenance', 'permission' => 'maintenance.view', 'label' => 'maintenance.work_orders', 'value' => $dashboard['stats']['open_maintenance'], 'icon' => 'ti-tool'],
            ['module' => 'purchasing', 'permission' => 'purchasing.view', 'label' => 'purchasing.open_orders', 'value' => $dashboard['stats']['open_purchase_orders'], 'icon' => 'ti-shopping-cart'],
            ['module' => 'sales', 'permission' => 'sales.view', 'label' => 'sales.pending_orders', 'value' => $dashboard['stats']['open_sales_orders'], 'icon' => 'ti-shopping-bag'],
        ])->filter(fn (array $metric): bool => $permissions->has($metric['permission']) && $modules->enabled($metric['module']));

        $referenceMetrics = collect([
            ['module' => 'master-data', 'permission' => 'settings.view', 'label' => 'messages.companies', 'value' => $dashboard['stats']['companies']],
            ['module' => 'master-data', 'permission' => 'settings.view', 'label' => 'messages.sites', 'value' => $dashboard['stats']['sites']],
            ['module' => 'master-data', 'permission' => 'settings.view', 'label' => 'messages.warehouses', 'value' => $dashboard['stats']['warehouses']],
            ['module' => 'production', 'permission' => 'production.view', 'label' => 'messages.production_lines', 'value' => $dashboard['stats']['production_lines']],
            ['module' => 'production', 'permission' => 'maintenance.view', 'label' => 'messages.machines', 'value' => $dashboard['stats']['machines']],
            ['module' => 'master-data', 'permission' => 'catalog.view', 'label' => 'messages.items', 'value' => $dashboard['stats']['items']],
            ['module' => 'production', 'permission' => 'production.view', 'label' => 'messages.recipes', 'value' => $dashboard['stats']['recipes']],
            ['module' => 'administration', 'permission' => 'users.view', 'label' => 'messages.users', 'value' => $dashboard['stats']['users']],
        ])->filter(fn (array $metric): bool => $permissions->has($metric['permission']) && $modules->enabled($metric['module']));

        $quickLinks = collect([
            ['module' => 'stocks', 'permission' => 'stocks.view', 'route' => 'stocks.index', 'icon' => 'ti-packages', 'title' => 'stock.stocks', 'description' => 'messages.stocks_module_description'],
            ['module' => 'production', 'permission' => 'production.view', 'route' => 'production.index', 'icon' => 'ti-settings-automation', 'title' => 'production.production', 'description' => 'messages.production_module_description'],
            ['module' => 'sales', 'permission' => 'sales.view', 'route' => 'sales.index', 'icon' => 'ti-shopping-bag', 'title' => 'sales.sales', 'description' => 'sales.sales_description'],
            ['module' => 'finance', 'permission' => 'finance.view', 'route' => 'finance.billing.index', 'icon' => 'ti-cash-banknote', 'title' => 'billing.billing', 'description' => 'finance.management_control_description'],
        ])->filter(fn (array $link): bool => $permissions->has($link['permission']) && $modules->enabled($link['module']));

        $workflow = app(WorkflowInboxService::class);

        return view('livewire.dashboard.operations-overview', [
            'stats' => $dashboard['stats'],
            'kpis' => $kpis,
            'activityChart' => $dashboard['activity_chart'],
            'distributionChart' => $dashboard['distribution_chart'],
            'recentActivity' => $dashboard['recent_activity'],
            'operationalMetrics' => $operationalMetrics,
            'referenceMetrics' => $referenceMetrics,
            'quickLinks' => $quickLinks,
            'workflowSummary' => $workflow->summary($user),
            'priorityTasks' => $workflow->tasks($user)->take(5),
            'priorityAlerts' => $workflow->alerts($user)->take(5),
            'roleDashboard' => app(RoleDashboardService::class)->for($user),
        ]);
    }

    private function dashboardData(): array
    {
        $expiryRaw = DB::table('system_settings')->where('group', 'stock')->where('key', 'expiry_alert_days')->value('value');
        $expiryDays = (int) (json_decode((string) $expiryRaw, true) ?: 30);
        $lowStockQuery = DB::table('items')
            ->leftJoin('stock_balances', 'stock_balances.item_id', '=', 'items.id')
            ->where('items.active', true)
            ->where('items.minimum_stock', '>', 0)
            ->groupBy('items.id', 'items.minimum_stock')
            ->havingRaw('COALESCE(SUM(stock_balances.quantity - stock_balances.reserved_quantity), 0) <= items.minimum_stock')
            ->select('items.id');

        $stats = [
            'companies' => DB::table('companies')->where('active', true)->count(),
            'sites' => DB::table('sites')->where('active', true)->count(),
            'warehouses' => DB::table('warehouses')->where('active', true)->count(),
            'production_lines' => DB::table('production_lines')->where('active', true)->count(),
            'machines' => DB::table('machines')->where('active', true)->count(),
            'items' => DB::table('items')->where('active', true)->count(),
            'recipes' => DB::table('recipes')->where('active', true)->count(),
            'users' => DB::table('users')->where('active', true)->count(),
            'stock_lots' => DB::table('stock_balances')->where('quantity', '>', 0)->count(),
            'low_stock' => DB::query()->fromSub($lowStockQuery, 'dashboard_low_stock')->count(),
            'expiring_lots' => DB::table('lots')->whereBetween('expiry_date', [today(), today()->addDays($expiryDays)])->count(),
            'active_downtimes' => DB::table('production_downtimes')->whereNull('ended_at')->count(),
            'open_maintenance' => DB::table('maintenance_work_orders')->whereNotIn('status', ['COMPLETED', 'CANCELLED'])->count(),
            'open_purchase_orders' => DB::table('purchase_orders')->whereIn('status', ['SUBMITTED', 'APPROVED', 'PARTIALLY_RECEIVED'])->count(),
            'open_sales_orders' => DB::table('sales_orders')->whereIn('status', ['SUBMITTED', 'CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED', 'PARTIALLY_DELIVERED'])->count(),
            'production_in_progress' => DB::table('production_orders')->where('status', 'IN_PROGRESS')->count(),
            'overdue_invoices' => DB::table('customer_invoices')->where('status', 'OVERDUE')->count(),
            'overdue_amount' => (float) DB::table('customer_invoices')->where('status', 'OVERDUE')->sum('balance_amount'),
        ];

        $currency = Company::query()->where('active', true)->value('currency_code') ?: 'DZD';

        return [
            'stats' => $stats,
            'currency' => $currency,
            'activity_chart' => $this->activityChart(),
            'distribution_chart' => [
                'labels' => [__('sales.sales_orders'), __('purchasing.purchase_orders'), __('production.production_orders'), __('maintenance.work_orders'), __('stock.expiry')],
                'values' => [$stats['open_sales_orders'], $stats['open_purchase_orders'], $stats['production_in_progress'], $stats['open_maintenance'], $stats['expiring_lots']],
            ],
            'recent_activity' => $this->recentActivity(),
        ];
    }

    private function activityChart(): array
    {
        $start = today()->subDays(6);
        $end = today();
        $queries = [
            DB::table('sales_orders')->selectRaw('order_date::date AS day, COUNT(*) AS total')->whereBetween('order_date', [$start, $end])->groupByRaw('order_date::date')->pluck('total', 'day'),
            DB::table('production_orders')->selectRaw('planned_date::date AS day, COUNT(*) AS total')->whereBetween('planned_date', [$start, $end])->groupByRaw('planned_date::date')->pluck('total', 'day'),
            DB::table('stock_movements')->selectRaw('movement_at::date AS day, COUNT(*) AS total')->whereBetween('movement_at', [$start->startOfDay(), $end->endOfDay()])->groupByRaw('movement_at::date')->pluck('total', 'day'),
        ];

        $labels = [];
        $values = [];
        for ($day = $start->copy(); $day->lte($end); $day->addDay()) {
            $key = $day->toDateString();
            $labels[] = $day->translatedFormat('D d');
            $values[] = collect($queries)->sum(fn (Collection $series): int => (int) ($series[$key] ?? 0));
        }

        return compact('labels', 'values');
    }

    private function recentActivity(): Collection
    {
        $sales = DB::table('sales_orders')->leftJoin('customers', 'customers.id', '=', 'sales_orders.customer_id')
            ->latest('sales_orders.created_at')->limit(5)
            ->get(['sales_orders.id', 'sales_orders.order_number as reference', 'sales_orders.status', 'sales_orders.created_at as activity_at', 'customers.name as subject'])
            ->map(fn ($row): array => ['type' => 'sales', 'icon' => 'ti-shopping-bag', 'reference' => $row->reference, 'subject' => $row->subject, 'status' => $row->status, 'date' => Carbon::parse($row->activity_at), 'url' => route('sales.orders.show', $row->id)]);
        $production = DB::table('production_orders')->leftJoin('items', 'items.id', '=', 'production_orders.finished_item_id')
            ->latest('production_orders.created_at')->limit(5)
            ->get(['production_orders.id', 'production_orders.order_number as reference', 'production_orders.status', 'production_orders.created_at as activity_at', 'items.name as subject'])
            ->map(fn ($row): array => ['type' => 'production', 'icon' => 'ti-settings-automation', 'reference' => $row->reference, 'subject' => $row->subject, 'status' => $row->status, 'date' => Carbon::parse($row->activity_at), 'url' => route('production.show', $row->id)]);
        $stocks = DB::table('stock_movements')->latest('created_at')->limit(5)
            ->get(['id', 'movement_number as reference', 'status', 'created_at as activity_at', 'movement_type as subject'])
            ->map(fn ($row): array => ['type' => 'stocks', 'icon' => 'ti-packages', 'reference' => $row->reference, 'subject' => __('stock.type_'.strtolower($row->subject)), 'status' => $row->status, 'date' => Carbon::parse($row->activity_at), 'url' => route('stocks.index')]);
        $finance = DB::table('customer_invoices')->leftJoin('customers', 'customers.id', '=', 'customer_invoices.customer_id')
            ->latest('customer_invoices.created_at')->limit(5)
            ->get(['customer_invoices.id', 'customer_invoices.invoice_number as reference', 'customer_invoices.status', 'customer_invoices.created_at as activity_at', 'customers.name as subject'])
            ->map(fn ($row): array => ['type' => 'finance', 'icon' => 'ti-file-invoice', 'reference' => $row->reference, 'subject' => $row->subject, 'status' => $row->status, 'date' => Carbon::parse($row->activity_at), 'url' => route('finance.billing.customer-invoices.show', $row->id)]);

        return collect()->concat($sales)->concat($production)->concat($stocks)->concat($finance)
            ->sortByDesc('date')->take(8)->values();
    }
}
