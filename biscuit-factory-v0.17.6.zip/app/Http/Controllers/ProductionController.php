<?php

namespace App\Http\Controllers;

use App\Models\Lot;
use App\Models\ProductionLine;
use App\Models\ProductionOrder;
use App\Models\RecipeVersion;
use App\Models\StockMovement;
use App\Services\Stock\FefoService;
use App\Services\Stock\StockPostingService;
use App\Services\Modules\ModuleRegistry;
use App\Services\Quality\QualityInspectionPlanner;
use App\Services\Production\ProductionCostService;
use App\Models\Unit;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ProductionController extends Controller
{
    public function index(Request $request): View
    {
        $status = trim((string) $request->query('status'));
        $search = trim((string) $request->query('search'));

        $dashboard = Cache::remember('production:dashboard:v173:'.app()->getLocale().':'.today()->toDateString(), now()->addSeconds(30), function (): array {
            $output = DB::table('production_outputs')
                ->join('production_orders', 'production_orders.id', '=', 'production_outputs.production_order_id')
                ->whereDate('production_orders.planned_date', today())
                ->selectRaw('COALESCE(SUM(production_outputs.produced_quantity), 0) AS produced, COALESCE(SUM(production_outputs.accepted_quantity), 0) AS accepted, COALESCE(SUM(production_outputs.rejected_quantity), 0) AS rejected')
                ->first();
            $plannedToday = (float) DB::table('production_orders')->whereDate('planned_date', today())->sum('planned_quantity');
            $produced = (float) $output->produced;
            $accepted = (float) $output->accepted;
            $rejected = (float) $output->rejected;
            $completionRate = $plannedToday > 0 ? min(100, ($produced / $plannedToday) * 100) : 0;
            $qualityRate = ($accepted + $rejected) > 0 ? ($accepted / ($accepted + $rejected)) * 100 : 100;

            $statusRows = DB::table('production_orders')->selectRaw('status AS label, COUNT(*) AS total')->groupBy('status')->orderByDesc('total')->get();
            $trendRows = DB::table('production_orders')
                ->leftJoin('production_outputs', 'production_outputs.production_order_id', '=', 'production_orders.id')
                ->selectRaw('production_orders.planned_date::date AS day, COALESCE(SUM(production_outputs.accepted_quantity), 0) AS total')
                ->whereBetween('production_orders.planned_date', [today()->subDays(6), today()])
                ->groupByRaw('production_orders.planned_date::date')->pluck('total', 'day');
            $trendLabels = [];
            $trendValues = [];
            for ($day = today()->subDays(6); $day->lte(today()); $day->addDay()) {
                $trendLabels[] = $day->translatedFormat('D d');
                $trendValues[] = (float) ($trendRows[$day->toDateString()] ?? 0);
            }
            $lineRows = DB::table('production_lines')
                ->leftJoin('production_orders', function ($join): void {
                    $join->on('production_orders.production_line_id', '=', 'production_lines.id')
                        ->whereIn('production_orders.status', ['PLANNED', 'IN_PROGRESS'])
                        ->whereDate('production_orders.planned_date', today());
                })
                ->where('production_lines.active', true)
                ->selectRaw('production_lines.name AS label, COALESCE(SUM(production_orders.planned_quantity), 0) AS total')
                ->groupBy('production_lines.id', 'production_lines.name')->orderByDesc('total')->limit(8)->get();

            return [
                'metrics' => [
                    'planned' => ProductionOrder::where('status', 'PLANNED')->count(),
                    'in_progress' => ProductionOrder::where('status', 'IN_PROGRESS')->count(),
                    'completed_today' => ProductionOrder::where('status', 'COMPLETED')->whereDate('actual_end', today())->count(),
                    'planned_today' => $plannedToday,
                    'produced_today' => $produced,
                    'rejected_today' => $rejected,
                    'completion_rate' => $completionRate,
                    'quality_rate' => $qualityRate,
                    'active_downtimes' => DB::table('production_downtimes')->whereNull('ended_at')->count(),
                ],
                'status_chart' => ['labels' => $statusRows->pluck('label')->all(), 'values' => $statusRows->pluck('total')->map(fn ($value) => (int) $value)->all()],
                'trend_chart' => ['labels' => $trendLabels, 'values' => $trendValues],
                'line_chart' => ['labels' => $lineRows->pluck('label')->all(), 'values' => $lineRows->pluck('total')->map(fn ($value) => (float) $value)->all()],
            ];
        });

        return view('production.index', [
            'orders' => ProductionOrder::with(['item.baseUnit', 'productionLine', 'recipeVersion.recipe'])
                ->when($status, fn ($query) => $query->where('status', $status))
                ->when($search, fn ($query) => $query->where(fn ($nested) => $nested
                    ->where('order_number', 'ilike', "%{$search}%")
                    ->orWhereHas('item', fn ($item) => $item->where('code', 'ilike', "%{$search}%")
                        ->orWhere('name', 'ilike', "%{$search}%"))))
                ->latest('planned_date')->paginate(25)->withQueryString(),
            'versions' => RecipeVersion::with('recipe.finishedItem')->where('status', 'APPROVED')->get(),
            'lines' => ProductionLine::where('active', true)->get(),
            'status' => $status,
            'search' => $search,
            'statuses' => DB::table('reference_values')->where('domain', 'production_order_status')
                ->where('active', true)->orderBy('sort_order')->get(),
            'metrics' => $dashboard['metrics'],
            'dashboard' => $dashboard,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(['recipe_version_id' => ['required', 'exists:recipe_versions,id'], 'planned_quantity' => ['required', 'numeric', 'gt:0'], 'planned_date' => ['required', 'date'], 'production_line_id' => ['nullable', 'exists:production_lines,id']]);
        $version = RecipeVersion::with(['recipe.finishedItem', 'lines.ingredient'])->findOrFail($data['recipe_version_id']);
        abort_unless($version->status === 'APPROVED', 422);

        $order = DB::transaction(function () use ($data, $version): ProductionOrder {
            $order = ProductionOrder::create($data + ['order_number' => 'OF-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)), 'finished_item_id' => $version->recipe->finished_item_id, 'unit_id' => $version->reference_unit_id, 'process_template_id' => $version->process_template_id, 'status' => 'PLANNED']);
            $expectedOutput = max(0.000001, (float) $version->reference_quantity * ((float) $version->expected_yield_percent / 100));
            foreach ($version->lines as $line) {
                $factorToBase = $line->unit_id === $line->ingredient->base_unit_id
                    ? 1.0
                    : (float) DB::table('item_unit_conversions')->where([
                        'item_id' => $line->ingredient_item_id,
                        'unit_id' => $line->unit_id,
                    ])->value('factor_to_base');
                abort_if($factorToBase <= 0, 422, __('production.missing_conversion', ['item' => $line->ingredient->code]));
                $planned = (float) $line->quantity
                    * (1 + ((float) $line->loss_percentage / 100))
                    * ((float) $data['planned_quantity'] / $expectedOutput)
                    * $factorToBase;
                $order->consumptions()->create(['item_id' => $line->ingredient_item_id, 'planned_quantity' => $planned, 'consumed_quantity' => 0, 'unit_id' => $line->ingredient->base_unit_id]);
            }
            return $order;
        });
        return redirect()->route('production.show', $order);
    }

    public function show(ProductionOrder $order, ProductionCostService $costing): View
    {
        $order->load([
            'item.baseUnit', 'recipeVersion.recipe', 'productionLine',
            'consumptions.item.baseUnit', 'consumptions.lot', 'outputs.lot', 'losses',
            'qualityInspections', 'costEntries.unit', 'costCalculations.calculator',
        ]);

        return view('production.show', [
            'order' => $order,
            'theoreticalCost' => $costing->theoretical($order->recipeVersion),
            'actualCost' => in_array($order->status, ['IN_PROGRESS', 'COMPLETED'], true) ? $costing->actual($order) : null,
            'locations' => \App\Models\WarehouseLocation::with('warehouse')->where('active', true)->orderBy('code')->get(),
            'warehouses' => \App\Models\Warehouse::where('active', true)->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'costTypes' => DB::table('reference_values')->where('domain', 'cost_type')->where('active', true)->orderBy('sort_order')->get(),
            'costBases' => DB::table('reference_values')->where('domain', 'cost_basis')->where('active', true)->orderBy('sort_order')->get(),
        ]);
    }

    public function start(Request $request, ProductionOrder $order, FefoService $fefo, StockPostingService $posting): RedirectResponse
    {
        $data = $request->validate([
            'source_warehouse_id' => ['nullable', 'required_without:source_location_id', 'exists:warehouses,id'],
            'source_location_id' => ['nullable', 'required_without:source_warehouse_id', 'exists:warehouse_locations,id'],
        ]);
        $order->loadMissing('consumptions');
        DB::transaction(function () use ($order, $data, $fefo, $posting): void {
            abort_unless($order->status === 'PLANNED', 409);
            $movement = StockMovement::create(['movement_number' => 'CON-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)), 'movement_type' => 'ISSUE', 'movement_at' => now(), 'source_type' => ProductionOrder::class, 'source_id' => $order->id, 'status' => 'DRAFT', 'created_by' => auth()->id()]);
            foreach ($order->consumptions as $consumption) {
                $allocations = isset($data['source_warehouse_id'])
                    ? $fefo->allocateInWarehouse($consumption->item_id, $data['source_warehouse_id'], (float) $consumption->planned_quantity)
                    : $fefo->allocate($consumption->item_id, $data['source_location_id'], (float) $consumption->planned_quantity);
                foreach ($allocations as $allocation) {
                    $movement->lines()->create(['item_id' => $consumption->item_id, 'lot_id' => $allocation['lot_id'], 'source_location_id' => $allocation['location_id'], 'quantity' => $allocation['quantity'], 'unit_id' => $consumption->unit_id]);
                }
                $consumption->update(['lot_id' => $allocations->count() === 1 ? $allocations->first()['lot_id'] : null, 'consumed_quantity' => $allocations->sum('quantity')]);
            }
            $posting->post($movement, (string) auth()->id());
            $order->update(['status' => 'IN_PROGRESS', 'actual_start' => now()]);
        });
        return back();
    }

    public function complete(
        Request $request,
        ProductionOrder $order,
        StockPostingService $posting,
        QualityInspectionPlanner $qualityPlanner,
        ProductionCostService $costing,
        ModuleRegistry $modules,
    ): RedirectResponse
    {
        $data = $request->validate(['destination_location_id' => ['required', 'exists:warehouse_locations,id'], 'produced_quantity' => ['required', 'numeric', 'gt:0'], 'rejected_quantity' => ['nullable', 'numeric', 'gte:0', 'lt:produced_quantity'], 'lot_number' => ['required', 'string', 'max:120']]);
        $order->loadMissing('item');
        DB::transaction(function () use ($order, $data, $posting, $qualityPlanner, $costing, $modules): void {
            abort_unless($order->status === 'IN_PROGRESS', 409);
            abort_if(Lot::where('item_id', $order->finished_item_id)->where('lot_number', $data['lot_number'])->exists(), 422);
            $rejected = (float) ($data['rejected_quantity'] ?? 0);
            $accepted = (float) $data['produced_quantity'] - $rejected;
            $lot = Lot::create(['item_id' => $order->finished_item_id, 'lot_number' => $data['lot_number'], 'manufacturing_date' => today(), 'expiry_date' => $order->item->shelf_life_days ? today()->addDays($order->item->shelf_life_days) : null, 'status' => $modules->enabled('quality') ? 'QUARANTINE' : 'RELEASED', 'attributes' => ['quality_module_enabled' => $modules->enabled('quality')]]);
            $order->outputs()->create(['item_id' => $order->finished_item_id, 'lot_id' => $lot->id, 'produced_quantity' => $data['produced_quantity'], 'accepted_quantity' => $accepted, 'rejected_quantity' => $rejected, 'unit_id' => $order->unit_id]);
            if ($rejected > 0) $order->losses()->create(['item_id' => $order->finished_item_id, 'quantity' => $rejected, 'unit_id' => $order->unit_id, 'loss_type' => 'REJECTED_OUTPUT']);
            $costSummary = $costing->actual($order->fresh());
            $movement = StockMovement::create(['movement_number' => 'PRO-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)), 'movement_type' => 'RECEIPT', 'movement_at' => now(), 'source_type' => ProductionOrder::class, 'source_id' => $order->id, 'status' => 'DRAFT', 'created_by' => auth()->id()]);
            $movement->lines()->create(['item_id' => $order->finished_item_id, 'lot_id' => $lot->id, 'destination_location_id' => $data['destination_location_id'], 'quantity' => $accepted, 'unit_id' => $order->unit_id, 'unit_cost' => $costSummary['unit_cost']]);
            $posting->post($movement, (string) auth()->id());
            $order->update(['status' => 'COMPLETED', 'actual_end' => now()]);
            $calculation = $costing->storeActual($order->fresh(), auth()->id());
            DB::table('audit_logs')->insert([
                'id' => (string) Str::uuid(),
                'user_id' => auth()->id(),
                'event' => 'production.cost.actual_saved',
                'auditable_type' => $calculation::class,
                'auditable_id' => $calculation->id,
                'old_values' => null,
                'new_values' => json_encode($calculation->toArray()),
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
                'created_at' => now(),
            ]);
            if ($modules->enabled('quality')) {
                $qualityPlanner->createForLot(
                    $lot,
                    'FINISHED_GOOD',
                    $order->id,
                    $movement->id,
                    $order->production_line_id,
                    (string) auth()->id(),
                );
            }
        });
        return back();
    }
}
