<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Item;
use App\Models\LineProduct;
use App\Models\OeeSnapshot;
use App\Models\ProductionLine;
use App\Models\ProductionPlan;
use App\Models\Site;
use App\Models\Unit;
use App\Services\Planning\IndustrialPlanningService;
use App\Services\Planning\OeeService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class IndustrialPlanningController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = $request->query('company_id');
        $plans = ProductionPlan::query()
            ->with(['company', 'site'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->latest('horizon_start')
            ->paginate(20)
            ->withQueryString();

        return view('planning.index', [
            'plans' => $plans,
            'companies' => Company::query()->where('active', true)->orderBy('name')->get(),
            'sites' => Site::query()->where('active', true)->orderBy('name')->get(),
            'metrics' => [
                'draft' => ProductionPlan::query()->where('status', 'DRAFT')->count(),
                'calculated' => ProductionPlan::query()->where('status', 'CALCULATED')->count(),
                'critical' => ProductionPlan::query()
                    ->whereHas('conflicts', fn ($query) => $query
                        ->where('severity', 'CRITICAL')
                        ->where('status', 'OPEN'))
                    ->count(),
            ],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'site_id' => ['required', 'exists:sites,id'],
            'name' => ['required', 'string', 'max:255'],
            'horizon_start' => ['required', 'date'],
            'horizon_end' => ['required', 'date', 'after_or_equal:horizon_start'],
            'safety_stock_days' => ['required', 'integer', 'between:0,90'],
        ]);
        abort_unless(
            Site::query()->whereKey($data['site_id'])->where('company_id', $data['company_id'])->exists(),
            422
        );
        $plan = ProductionPlan::create($data + [
            'code' => 'PDP-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)),
            'demand_source' => 'SALES',
            'status' => 'DRAFT',
            'created_by' => auth()->id(),
        ]);

        return redirect()->route('planning.show', $plan);
    }

    public function show(ProductionPlan $plan): View
    {
        $plan->load([
            'company',
            'site',
            'demands.item',
            'materials.ingredient',
            'capacities.productionLine',
            'capacities.item',
            'capacities.productionOrder',
            'conflicts',
            'scenarios',
        ]);

        return view('planning.show', ['plan' => $plan]);
    }

    public function calculate(ProductionPlan $plan, IndustrialPlanningService $service): RedirectResponse
    {
        $service->calculate($plan);

        return back()->with('success', __('planning.calculation_completed'));
    }

    public function approve(ProductionPlan $plan, IndustrialPlanningService $service): RedirectResponse
    {
        $service->approve($plan, (string) auth()->id());

        return back()->with('success', __('planning.plan_approved'));
    }

    public function generateOrders(ProductionPlan $plan, IndustrialPlanningService $service): RedirectResponse
    {
        $count = $service->generateOrders($plan, (string) auth()->id());

        return back()->with('success', __('planning.orders_generated', ['count' => $count]));
    }

    public function storeScenario(
        Request $request,
        ProductionPlan $plan,
        IndustrialPlanningService $service
    ): RedirectResponse {
        $data = $request->validate([
            'code' => [
                'required',
                'alpha_dash',
                'max:80',
                Rule::unique('planning_scenarios', 'code')->where('production_plan_id', $plan->id),
            ],
            'name' => ['required', 'string', 'max:255'],
            'demand_multiplier' => ['required', 'numeric', 'between:0.1,5'],
            'capacity_multiplier' => ['required', 'numeric', 'between:0.1,5'],
            'safety_stock_days' => ['required', 'integer', 'between:0,90'],
        ]);
        $service->createScenario($plan, $data, (string) auth()->id());

        return back()->with('success', __('planning.scenario_calculated'));
    }

    public function capabilities(): View
    {
        return view('planning.capabilities', [
            'capabilities' => LineProduct::query()
                ->with(['productionLine.site', 'productionLine.machines', 'item', 'rateUnit'])
                ->orderBy('production_line_id')
                ->paginate(25),
            'lines' => ProductionLine::query()
                ->with(['site', 'machines'])
                ->where('active', true)
                ->orderBy('code')
                ->get(),
            'items' => Item::query()
                ->where('active', true)
                ->whereIn('item_type', ['FINISHED_GOOD', 'SEMI_FINISHED'])
                ->orderBy('code')
                ->get(),
            'units' => Unit::query()->where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function storeCapability(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'production_line_id' => ['required', 'exists:production_lines,id'],
            'item_id' => ['required', 'exists:items,id'],
            'production_rate_per_hour' => ['required', 'numeric', 'gt:0'],
            'rate_unit_id' => ['required', 'exists:units,id'],
            'setup_time_minutes' => ['required', 'integer', 'between:0,1440'],
            'active' => ['nullable', 'boolean'],
        ]);
        LineProduct::updateOrCreate(
            [
                'production_line_id' => $data['production_line_id'],
                'item_id' => $data['item_id'],
            ],
            $data + ['active' => $request->boolean('active', true)]
        );

        return back()->with('success', __('planning.capability_saved'));
    }

    public function destroyCapability(LineProduct $capability): RedirectResponse
    {
        $capability->loadMissing('productionLine');
        abort_if($capability->productionLine?->status === 'RUNNING', 409);
        $capability->delete();

        return back()->with('success', __('planning.capability_deleted'));
    }

    public function oee(Request $request): View
    {
        $siteId = $request->query('site_id') ?: Site::query()->where('active', true)->value('id');
        $start = Carbon::parse($request->query('start', today()->startOfMonth()->toDateString()));
        $end = Carbon::parse($request->query('end', today()->toDateString()));

        return view('planning.oee', [
            'sites' => Site::query()->where('active', true)->orderBy('name')->get(),
            'siteId' => $siteId,
            'start' => $start,
            'end' => $end,
            'snapshots' => OeeSnapshot::query()
                ->with('productionLine')
                ->when($siteId, fn ($query) => $query->where('site_id', $siteId))
                ->where('period_start', $start->toDateString())
                ->where('period_end', $end->toDateString())
                ->orderByDesc('oee_percent')
                ->get(),
        ]);
    }

    public function calculateOee(Request $request, OeeService $service): RedirectResponse
    {
        $data = $request->validate([
            'site_id' => ['required', 'exists:sites,id'],
            'start' => ['required', 'date'],
            'end' => ['required', 'date', 'after_or_equal:start'],
        ]);
        $count = $service->calculate(
            $data['site_id'],
            Carbon::parse($data['start']),
            Carbon::parse($data['end'])
        );

        return redirect()->route('planning.oee', $data)
            ->with('success', __('planning.oee_calculated', ['count' => $count]));
    }
}
