<?php

namespace App\Http\Controllers;

use App\Services\System\SystemHealthService;
use Illuminate\Http\JsonResponse;

class HealthController extends Controller
{
    public function live(SystemHealthService $health): JsonResponse
    {
        return response()->json($health->liveness());
    }

    public function ready(SystemHealthService $health): JsonResponse
    {
        $result = $health->readiness(app()->environment('local', 'testing'));

        return response()->json($result, $result['ready'] ? 200 : 503);
    }
}
