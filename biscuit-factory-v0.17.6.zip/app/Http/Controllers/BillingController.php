<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Customer;
use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\CustomerPaymentReminder;
use App\Models\DeliveryNote;
use App\Models\FinancialAccount;
use App\Models\GoodsReceipt;
use App\Models\ReferenceValue;
use App\Models\Supplier;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use App\Services\Finance\BillingService;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\DocumentRevisionService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class BillingController extends Controller
{
    public function index(Request $request, BillingService $service): View
    {
        $companies = Company::query()->where('active', true)->orderBy('name')->get();
        $companyId = $companies->contains('id', $request->string('company_id')->toString())
            ? $request->string('company_id')->toString()
            : $companies->first()?->id;

        $service->refreshOverdueStatuses($companyId);

        $customerInvoices = CustomerInvoice::query()->with(['customer', 'deliveryNote'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->string('status')->toString()))
            ->latest('invoice_date')->latest()->limit(100)->get();
        $supplierInvoices = SupplierInvoice::query()->with(['supplier', 'goodsReceipt'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->string('status')->toString()))
            ->latest('invoice_date')->latest()->limit(100)->get();
        $customerPayments = CustomerPayment::query()->with(['customer', 'financialAccount', 'allocations.invoice'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->latest('payment_date')->latest()->limit(50)->get();
        $supplierPayments = SupplierPayment::query()->with(['supplier', 'financialAccount', 'allocations.invoice'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->latest('payment_date')->latest()->limit(50)->get();

        $openCustomerInvoices = CustomerInvoice::query()->with('customer')
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])->where('balance_amount', '>', 0)
            ->orderBy('due_date')->get();
        $openSupplierInvoices = SupplierInvoice::query()->with('supplier')
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])->where('balance_amount', '>', 0)
            ->orderBy('due_date')->get();

        $customerAging = $service->agingSummary('customer', $companyId);
        $supplierAging = $service->agingSummary('supplier', $companyId);
        $totals = [
            'receivable' => (float) $openCustomerInvoices->sum('balance_amount'),
            'payable' => (float) $openSupplierInvoices->sum('balance_amount'),
            'overdue_receivable' => (float) $openCustomerInvoices->where('status', 'OVERDUE')->sum('balance_amount'),
            'overdue_payable' => (float) $openSupplierInvoices->where('status', 'OVERDUE')->sum('balance_amount'),
        ];
        $currency = $companies->firstWhere('id', $companyId)?->currency_code ?? 'DZD';
        $dashboard = Cache::remember(
            'billing:dashboard:v173:'.app()->getLocale().':'.($companyId ?: 'all').':'.today()->toDateString(),
            now()->addSeconds(30),
            function () use ($companyId, $customerAging, $totals, $currency): array {
                $invoiceTrend = DB::table('customer_invoices')
                    ->selectRaw('invoice_date::date AS day, COALESCE(SUM(total_amount), 0) AS total')
                    ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
                    ->whereBetween('invoice_date', [today()->subDays(6), today()])
                    ->whereNotIn('status', ['CANCELLED'])
                    ->groupByRaw('invoice_date::date')
                    ->pluck('total', 'day');
                $paymentTrend = DB::table('customer_payments')
                    ->selectRaw('payment_date::date AS day, COALESCE(SUM(amount), 0) AS total')
                    ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
                    ->whereBetween('payment_date', [today()->subDays(6), today()])
                    ->where('status', 'POSTED')
                    ->groupByRaw('payment_date::date')
                    ->pluck('total', 'day');
                $labels = [];
                $invoiceValues = [];
                $paymentValues = [];
                for ($day = today()->subDays(6); $day->lte(today()); $day->addDay()) {
                    $labels[] = $day->translatedFormat('D d');
                    $invoiceValues[] = (float) ($invoiceTrend[$day->toDateString()] ?? 0);
                    $paymentValues[] = (float) ($paymentTrend[$day->toDateString()] ?? 0);
                }
                $statusRows = DB::table('customer_invoices')
                    ->selectRaw('status AS label, COUNT(*) AS total')
                    ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
                    ->groupBy('status')->orderByDesc('total')->get();
                $agingLabels = ['current', 'days_1_30', 'days_31_60', 'days_61_90', 'days_90_plus'];

                return [
                    'currency' => $currency,
                    'collection_rate' => $totals['receivable'] > 0
                        ? round(100 * max(0, 1 - ($totals['overdue_receivable'] / max(0.0001, $totals['receivable']))), 1)
                        : 100.0,
                    'invoice_trend' => ['labels' => $labels, 'values' => $invoiceValues],
                    'payment_trend' => ['labels' => $labels, 'values' => $paymentValues],
                    'status_chart' => [
                        'labels' => $statusRows->pluck('label')->map(fn ($status) => __('billing.status_'.strtolower((string) $status)))->all(),
                        'values' => $statusRows->pluck('total')->map(fn ($value) => (int) $value)->all(),
                    ],
                    'aging_chart' => [
                        'labels' => collect($agingLabels)->map(fn ($bucket) => __('billing.'.$bucket))->all(),
                        'values' => collect($agingLabels)->map(fn ($bucket) => (float) ($customerAging[$bucket] ?? 0))->all(),
                    ],
                ];
            }
        );

        return view('finance.billing.index', [
            'companies' => $companies,
            'selectedCompanyId' => $companyId,
            'customerInvoices' => $customerInvoices,
            'supplierInvoices' => $supplierInvoices,
            'customerPayments' => $customerPayments,
            'supplierPayments' => $supplierPayments,
            'openCustomerInvoices' => $openCustomerInvoices,
            'openSupplierInvoices' => $openSupplierInvoices,
            'eligibleDeliveries' => DeliveryNote::query()->with(['customer', 'salesOrder'])
                ->where('status', 'POSTED')->whereDoesntHave('customerInvoice')
                ->when($companyId, fn ($query) => $query->whereHas('salesOrder', fn ($order) => $order->where('company_id', $companyId)))
                ->latest('delivered_at')->get(),
            'eligibleReceipts' => GoodsReceipt::query()->with(['supplier', 'purchaseOrder'])
                ->where('status', 'POSTED')->whereDoesntHave('supplierInvoice')
                ->when($companyId, fn ($query) => $query->whereHas('purchaseOrder', fn ($order) => $order->where('company_id', $companyId)))
                ->latest('received_at')->get(),
            'customers' => Customer::query()->when($companyId, fn ($query) => $query->where('company_id', $companyId))->where('active', true)->orderBy('name')->get(),
            'suppliers' => Supplier::query()->when($companyId, fn ($query) => $query->where('company_id', $companyId))->where('active', true)->orderBy('name')->get(),
            'accounts' => FinancialAccount::query()->when($companyId, fn ($query) => $query->where('company_id', $companyId))->where('active', true)->orderBy('code')->get(),
            'paymentMethods' => ReferenceValue::query()->where('domain', 'payment_method')->where('active', true)->orderBy('sort_order')->get(),
            'customerAging' => $customerAging,
            'supplierAging' => $supplierAging,
            'totals' => $totals,
            'dashboard' => $dashboard,
        ]);
    }

    public function storeCustomerInvoice(Request $request, BillingService $service): RedirectResponse
    {
        $data = $request->validate([
            'delivery_note_id' => ['required', 'exists:delivery_notes,id'],
            'invoice_date' => ['required', 'date'],
            'notes' => ['nullable', 'string'],
        ]);
        $invoice = $service->createCustomerInvoice(
            DeliveryNote::findOrFail($data['delivery_note_id']), Carbon::parse($data['invoice_date']), $data['notes'] ?? null, auth()->id()
        );
        return redirect()->route('finance.billing.customer-invoices.show', $invoice)->with('success', __('billing.customer_invoice_created'));
    }

    public function showCustomerInvoice(CustomerInvoice $invoice, BillingService $service): View
    {
        $service->recalculateCustomerInvoice($invoice);
        return view('finance.billing.customer-invoice', [
            'invoice' => $invoice->fresh()->load(['company', 'customer', 'salesOrder', 'deliveryNote', 'lines.item', 'lines.unit', 'creditNotes', 'allocations.payment', 'reminders.creator']),
            'reminderChannels' => ReferenceValue::query()->where('domain', 'collection_channel')->where('active', true)->orderBy('sort_order')->get(),
            'creditReasons' => ReferenceValue::query()->where('domain', 'credit_note_reason')->where('active', true)->orderBy('sort_order')->get(),
        ]);
    }

    public function issueCustomerInvoice(CustomerInvoice $invoice, BillingService $service): RedirectResponse
    {
        $invoice = $service->issueCustomerInvoice($invoice, auth()->id());
        $message = $invoice->status === 'PENDING_APPROVAL'
            ? __('governance.submitted_for_approval')
            : __('billing.customer_invoice_issued');

        return back()->with('success', $message);
    }

    public function storeCustomerCredit(Request $request, CustomerInvoice $invoice, BillingService $service): RedirectResponse
    {
        $data = $request->validate([
            'total_amount' => ['required', 'numeric', 'gt:0'],
            'reason_code' => ['nullable', $this->referenceRule('credit_note_reason')],
            'reason' => ['required', 'string', 'max:2000'],
        ]);
        $service->issueCustomerCredit($invoice, (float) $data['total_amount'], $data['reason'], $data['reason_code'] ?? null, auth()->id());
        return back()->with('success', __('billing.customer_credit_issued'));
    }

    public function storeCustomerReminder(Request $request, CustomerInvoice $invoice, BillingService $service): RedirectResponse
    {
        $invoice = $service->recalculateCustomerInvoice($invoice);
        if (! in_array($invoice->status, ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'], true) || (float) $invoice->balance_amount <= 0) {
            throw ValidationException::withMessages(['invoice' => __('billing.invoice_not_open')]);
        }
        $data = $request->validate([
            'reminder_date' => ['required', 'date'],
            'channel_code' => ['required', $this->referenceRule('collection_channel')],
            'next_action_date' => ['nullable', 'date', 'after_or_equal:reminder_date'],
            'notes' => ['nullable', 'string', 'max:3000'],
        ]);
        $reminder = $invoice->reminders()->create([
            ...$data,
            'reminder_number' => $this->number('REL'),
            'status' => 'SENT',
            'created_by' => auth()->id(),
        ]);
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(), 'user_id' => auth()->id(), 'event' => 'finance.customer_payment_reminder.created',
            'auditable_type' => CustomerPaymentReminder::class, 'auditable_id' => $reminder->id,
            'old_values' => null, 'new_values' => json_encode($reminder->fresh()->toArray()),
            'ip_address' => $request->ip(), 'user_agent' => $request->userAgent(), 'created_at' => now(),
        ]);
        return back()->with('success', __('billing.reminder_created'));
    }

    public function storeSupplierInvoice(Request $request, BillingService $service): RedirectResponse
    {
        $data = $request->validate([
            'goods_receipt_id' => ['required', 'exists:goods_receipts,id'],
            'supplier_invoice_number' => ['required', 'string', 'max:120'],
            'invoice_date' => ['required', 'date'],
            'total_amount' => ['required', 'numeric', 'gt:0'],
            'notes' => ['nullable', 'string'],
        ]);
        $receipt = GoodsReceipt::findOrFail($data['goods_receipt_id']);
        if (SupplierInvoice::query()->where('supplier_id', $receipt->supplier_id)->where('supplier_invoice_number', $data['supplier_invoice_number'])->exists()) {
            throw ValidationException::withMessages(['supplier_invoice_number' => __('billing.supplier_number_exists')]);
        }
        $invoice = $service->createSupplierInvoice(
            $receipt, Carbon::parse($data['invoice_date']), $data['supplier_invoice_number'], (float) $data['total_amount'], $data['notes'] ?? null, auth()->id()
        );
        return redirect()->route('finance.billing.supplier-invoices.show', $invoice)->with('success', __('billing.supplier_invoice_created'));
    }

    public function showSupplierInvoice(SupplierInvoice $invoice, BillingService $service): View
    {
        $service->recalculateSupplierInvoice($invoice);
        return view('finance.billing.supplier-invoice', [
            'invoice' => $invoice->fresh()->load(['company', 'supplier', 'purchaseOrder', 'goodsReceipt', 'lines.item', 'lines.unit', 'creditNotes', 'allocations.payment']),
            'creditReasons' => ReferenceValue::query()->where('domain', 'credit_note_reason')->where('active', true)->orderBy('sort_order')->get(),
        ]);
    }

    public function approveSupplierInvoice(Request $request, SupplierInvoice $invoice, BillingService $service): RedirectResponse
    {
        $invoice = $service->approveSupplierInvoice($invoice, auth()->id(), $request->boolean('accept_variance'));
        $message = $invoice->status === 'PENDING_APPROVAL'
            ? __('governance.submitted_for_approval')
            : __('billing.supplier_invoice_approved');

        return back()->with('success', $message);
    }

    public function storeSupplierCredit(Request $request, SupplierInvoice $invoice, BillingService $service): RedirectResponse
    {
        $data = $request->validate([
            'total_amount' => ['required', 'numeric', 'gt:0'],
            'supplier_credit_note_number' => ['nullable', 'string', 'max:120'],
            'reason_code' => ['nullable', $this->referenceRule('credit_note_reason')],
            'reason' => ['required', 'string', 'max:2000'],
        ]);
        $service->approveSupplierCredit($invoice, (float) $data['total_amount'], $data['reason'], $data['reason_code'] ?? null, $data['supplier_credit_note_number'] ?? null, auth()->id());
        return back()->with('success', __('billing.supplier_credit_approved'));
    }

    public function storeCustomerPayment(Request $request, DocumentNumberService $numbers, DocumentRevisionService $revisions): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'customer_id' => ['required', Rule::exists('customers', 'id')->where('company_id', $request->input('company_id'))],
            'financial_account_id' => ['nullable', Rule::exists('financial_accounts', 'id')->where('company_id', $request->input('company_id'))],
            'payment_date' => ['required', 'date'],
            'payment_method_code' => ['required', $this->referenceRule('payment_method')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'external_reference' => ['nullable', 'string', 'max:160'],
            'notes' => ['nullable', 'string'],
            'allocations' => ['nullable', 'array'],
            'allocations.*' => ['nullable', 'numeric', 'gte:0'],
        ]);

        $payment = DB::transaction(function () use ($data, $numbers, $revisions): CustomerPayment {
            $customer = Customer::findOrFail($data['customer_id']);
            if ($customer->currency_code !== $data['currency_code']) {
                throw ValidationException::withMessages(['currency_code' => __('billing.party_currency_mismatch')]);
            }
            if (! empty($data['financial_account_id'])) {
                $account = FinancialAccount::findOrFail($data['financial_account_id']);
                if ($account->currency_code !== $data['currency_code']) {
                    throw ValidationException::withMessages(['financial_account_id' => __('billing.account_currency_mismatch')]);
                }
            }
            $payment = CustomerPayment::create([
                ...collect($data)->except('allocations')->all(),
                'payment_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::CUSTOMER_PAYMENT, $data['payment_date']),
                'allocated_amount' => 0,
                'unallocated_amount' => $data['amount'],
                'status' => 'DRAFT',
                'created_by' => auth()->id(),
            ]);
            foreach (($data['allocations'] ?? []) as $invoiceId => $amount) {
                if ((float) $amount <= 0) continue;
                $invoice = CustomerInvoice::findOrFail($invoiceId);
                if ($invoice->customer_id !== $payment->customer_id || $invoice->currency_code !== $payment->currency_code) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
                }
                $payment->allocations()->create(['customer_invoice_id' => $invoiceId, 'amount' => $amount]);
            }
            $revisions->record($payment, 'CREATED', auth()->id());
            return $payment;
        });
        return redirect()->route('finance.billing.index', ['tab' => 'customer-payments'])->with('success', __('billing.customer_payment_created', ['number' => $payment->payment_number]));
    }

    public function postCustomerPayment(CustomerPayment $payment, BillingService $service): RedirectResponse
    {
        $service->postCustomerPayment($payment, auth()->id());
        return back()->with('success', __('billing.customer_payment_posted'));
    }

    public function reverseCustomerPayment(Request $request, CustomerPayment $payment, BillingService $service): RedirectResponse
    {
        $data = $request->validate(['reversal_reason' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->reverseCustomerPayment($payment, $data['reversal_reason'], auth()->id());
        return back()->with('success', __('billing.customer_payment_reversed'));
    }

    public function storeSupplierPayment(Request $request, DocumentNumberService $numbers, DocumentRevisionService $revisions): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'supplier_id' => ['required', Rule::exists('suppliers', 'id')->where('company_id', $request->input('company_id'))],
            'financial_account_id' => ['nullable', Rule::exists('financial_accounts', 'id')->where('company_id', $request->input('company_id'))],
            'payment_date' => ['required', 'date'],
            'payment_method_code' => ['required', $this->referenceRule('payment_method')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'external_reference' => ['nullable', 'string', 'max:160'],
            'notes' => ['nullable', 'string'],
            'allocations' => ['nullable', 'array'],
            'allocations.*' => ['nullable', 'numeric', 'gte:0'],
        ]);

        $payment = DB::transaction(function () use ($data, $numbers, $revisions): SupplierPayment {
            $supplier = Supplier::findOrFail($data['supplier_id']);
            if ($supplier->currency_code !== $data['currency_code']) {
                throw ValidationException::withMessages(['currency_code' => __('billing.party_currency_mismatch')]);
            }
            if (! empty($data['financial_account_id'])) {
                $account = FinancialAccount::findOrFail($data['financial_account_id']);
                if ($account->currency_code !== $data['currency_code']) {
                    throw ValidationException::withMessages(['financial_account_id' => __('billing.account_currency_mismatch')]);
                }
            }
            $payment = SupplierPayment::create([
                ...collect($data)->except('allocations')->all(),
                'payment_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::SUPPLIER_PAYMENT, $data['payment_date']),
                'allocated_amount' => 0,
                'unallocated_amount' => $data['amount'],
                'status' => 'DRAFT',
                'created_by' => auth()->id(),
            ]);
            foreach (($data['allocations'] ?? []) as $invoiceId => $amount) {
                if ((float) $amount <= 0) continue;
                $invoice = SupplierInvoice::findOrFail($invoiceId);
                if ($invoice->supplier_id !== $payment->supplier_id || $invoice->currency_code !== $payment->currency_code) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
                }
                $payment->allocations()->create(['supplier_invoice_id' => $invoiceId, 'amount' => $amount]);
            }
            $revisions->record($payment, 'CREATED', auth()->id());
            return $payment;
        });
        return redirect()->route('finance.billing.index', ['tab' => 'supplier-payments'])->with('success', __('billing.supplier_payment_created', ['number' => $payment->payment_number]));
    }

    public function postSupplierPayment(SupplierPayment $payment, BillingService $service): RedirectResponse
    {
        $service->postSupplierPayment($payment, auth()->id());
        return back()->with('success', __('billing.supplier_payment_posted'));
    }

    public function reverseSupplierPayment(Request $request, SupplierPayment $payment, BillingService $service): RedirectResponse
    {
        $data = $request->validate(['reversal_reason' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->reverseSupplierPayment($payment, $data['reversal_reason'], auth()->id());
        return back()->with('success', __('billing.supplier_payment_reversed'));
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query->where('domain', $domain)->where('active', true));
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

}
