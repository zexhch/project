<?php

namespace App\Http\Controllers;

use App\Events\WorkflowInboxUpdated;
use App\Models\WorkflowTaskPreference;
use App\Services\Workflow\WorkflowInboxService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WorkflowController extends Controller
{
    public function summary(Request $request, WorkflowInboxService $inbox): JsonResponse
    {
        return response()->json($inbox->summary($request->user()));
    }

    public function tasks(Request $request, WorkflowInboxService $inbox): View
    {
        $category = trim((string) $request->query('category'));
        $priority = trim((string) $request->query('priority'));
        $tasks = $inbox->tasks($request->user())
            ->when($category !== '', fn ($items) => $items->where('category', $category))
            ->when($priority !== '', fn ($items) => $items->where('priority', $priority))
            ->values();

        return view('workflow.tasks', [
            'tasks' => $tasks,
            'summary' => $inbox->summary($request->user()),
            'category' => $category,
            'priority' => $priority,
        ]);
    }

    public function alerts(Request $request, WorkflowInboxService $inbox): View
    {
        return view('workflow.alerts', [
            'alerts' => $inbox->alerts($request->user()),
            'summary' => $inbox->summary($request->user()),
            'notifications' => $request->user()->notifications()->latest()->limit(30)->get(),
        ]);
    }

    public function snooze(Request $request, string $taskKey): RedirectResponse
    {
        $data = $request->validate(['days' => ['required', 'integer', 'in:1,3,7,14']]);
        WorkflowTaskPreference::query()->updateOrCreate(
            ['user_id' => $request->user()->id, 'task_key' => $taskKey],
            ['state' => 'SNOOZED', 'snoozed_until' => now()->addDays((int) $data['days'])],
        );
        $this->broadcast($request, ['task_key' => $taskKey, 'action' => 'snoozed']);

        return back()->with('success', __('workflow.task_snoozed'));
    }

    public function dismiss(Request $request, string $taskKey): RedirectResponse
    {
        WorkflowTaskPreference::query()->updateOrCreate(
            ['user_id' => $request->user()->id, 'task_key' => $taskKey],
            ['state' => 'DISMISSED', 'snoozed_until' => null],
        );
        $this->broadcast($request, ['task_key' => $taskKey, 'action' => 'dismissed']);

        return back()->with('success', __('workflow.task_dismissed'));
    }

    public function restoreAll(Request $request): RedirectResponse
    {
        WorkflowTaskPreference::query()->where('user_id', $request->user()->id)->delete();
        $this->broadcast($request, ['action' => 'restored']);

        return back()->with('success', __('workflow.tasks_restored'));
    }

    public function markNotificationRead(Request $request, string $notification): RedirectResponse
    {
        $record = $request->user()->notifications()->findOrFail($notification);
        $record->markAsRead();
        $this->broadcast($request, ['notification_id' => $notification, 'action' => 'read']);

        $url = data_get($record->data, 'url');

        return $url ? redirect()->to($url) : back();
    }

    public function markAllNotificationsRead(Request $request): RedirectResponse
    {
        $request->user()->unreadNotifications->markAsRead();
        $this->broadcast($request, ['action' => 'all_notifications_read']);

        return back()->with('success', __('workflow.notifications_marked_read'));
    }

    private function broadcast(Request $request, array $payload): void
    {
        event(new WorkflowInboxUpdated((string) $request->user()->id, $payload));
    }
}
