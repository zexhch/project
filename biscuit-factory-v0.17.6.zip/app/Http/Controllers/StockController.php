<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Lot;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Models\Unit;
use App\Models\WarehouseLocation;
use App\Services\Stock\StockPostingService;
use App\Services\Modules\ModuleRegistry;
use App\Services\Stock\FefoService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class StockController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim((string) $request->query('search'));
        $balances = StockBalance::query()->with(['item.baseUnit', 'lot', 'location.warehouse'])
            ->when($search, fn ($q) => $q->whereHas('item', fn ($i) => $i->where('code', 'ilike', "%{$search}%")->orWhere('name', 'ilike', "%{$search}%")))
            ->orderByDesc('quantity')->paginate(20)->withQueryString();
        $lowStock = Item::query()->where('active', true)->where('minimum_stock', '>', 0)
            ->withSum('balances', 'quantity')->get()->filter(fn ($item) => (float) $item->balances_sum_quantity < (float) $item->minimum_stock);
        $expiryDays = (int) $this->setting('stock', 'expiry_alert_days', 30);
        $expiring = Lot::query()->with('item')->whereIn('status', ['RELEASED', 'QUARANTINE'])
            ->whereBetween('expiry_date', [today(), today()->addDays($expiryDays)])->orderBy('expiry_date')->limit(20)->get();
        $movements = StockMovement::query()->withCount('lines')->latest('movement_at')->limit(12)->get();
        $lotStatuses = DB::table('reference_values')->where('domain', 'lot_status')->where('active', true)->orderBy('sort_order')->get();
        $dashboard = Cache::remember('stocks:dashboard:v173:'.app()->getLocale().':'.today()->toDateString(), now()->addSeconds(30), function () use ($lowStock, $expiring): array {
            $totals = DB::table('stock_balances')->selectRaw('COALESCE(SUM(quantity), 0) AS total_quantity, COALESCE(SUM(reserved_quantity), 0) AS reserved_quantity, COALESCE(SUM(quantity * COALESCE(average_unit_cost, 0)), 0) AS stock_value')->first();
            $categories = DB::table('stock_balances')
                ->join('items', 'items.id', '=', 'stock_balances.item_id')
                ->leftJoin('item_categories', 'item_categories.id', '=', 'items.category_id')
                ->selectRaw("COALESCE(item_categories.name, 'Sans catégorie') AS label, SUM(stock_balances.quantity) AS total")
                ->where('stock_balances.quantity', '>', 0)
                ->groupByRaw("COALESCE(item_categories.name, 'Sans catégorie')")
                ->orderByDesc('total')->limit(6)->get();
            $lotStatuses = DB::table('lots')
                ->join('stock_balances', 'stock_balances.lot_id', '=', 'lots.id')
                ->where('stock_balances.quantity', '>', 0)
                ->selectRaw('lots.status AS label, COUNT(DISTINCT lots.id) AS total')
                ->groupBy('lots.status')->orderByDesc('total')->get();
            $movementRows = DB::table('stock_movements')
                ->selectRaw('movement_at::date AS day, COUNT(*) AS total')
                ->whereBetween('movement_at', [today()->subDays(6)->startOfDay(), today()->endOfDay()])
                ->groupByRaw('movement_at::date')->pluck('total', 'day');
            $movementLabels = [];
            $movementValues = [];
            for ($day = today()->subDays(6); $day->lte(today()); $day->addDay()) {
                $movementLabels[] = $day->translatedFormat('D d');
                $movementValues[] = (int) ($movementRows[$day->toDateString()] ?? 0);
            }

            return [
                'metrics' => [
                    'total_quantity' => (float) $totals->total_quantity,
                    'reserved_quantity' => (float) $totals->reserved_quantity,
                    'available_quantity' => (float) $totals->total_quantity - (float) $totals->reserved_quantity,
                    'stock_value' => (float) $totals->stock_value,
                    'low_stock' => $lowStock->count(),
                    'expiring' => $expiring->count(),
                    'open_inventories' => DB::table('inventory_counts')->whereNotIn('status', ['POSTED', 'CANCELLED'])->count(),
                    'pending_receipts' => DB::table('goods_receipts')->where('status', 'DRAFT')->count(),
                    'currency' => DB::table('companies')->where('active', true)->value('currency_code') ?: 'DZD',
                ],
                'category_chart' => ['labels' => $categories->pluck('label')->all(), 'values' => $categories->pluck('total')->map(fn ($value) => (float) $value)->all()],
                'lot_status_chart' => ['labels' => $lotStatuses->pluck('label')->all(), 'values' => $lotStatuses->pluck('total')->map(fn ($value) => (int) $value)->all()],
                'movement_chart' => ['labels' => $movementLabels, 'values' => $movementValues],
            ];
        });

        return view('stock.index', compact('balances', 'lowStock', 'expiring', 'movements', 'search', 'expiryDays', 'lotStatuses', 'dashboard'));
    }

    public function create(Request $request): View
    {
        $type = in_array($request->query('type'), ['RECEIPT', 'ISSUE', 'TRANSFER'], true) ? $request->query('type') : 'RECEIPT';
        return view('stock.create', [
            'type' => $type, 'items' => Item::with('baseUnit')->where('active', true)->orderBy('name')->get(),
            'locations' => WarehouseLocation::with('warehouse')->where('active', true)->orderBy('code')->get(),
            'lots' => Lot::with('item')->whereIn('status', $type === 'ISSUE' ? ['RELEASED'] : ['RELEASED', 'QUARANTINE'])->orderBy('expiry_date')->get(),
        ]);
    }

    public function store(Request $request, ModuleRegistry $modules): RedirectResponse
    {
        $data = $request->validate([
            'movement_type' => ['required', 'in:RECEIPT,ISSUE,TRANSFER'], 'movement_at' => ['required', 'date'],
            'item_id' => ['required', 'exists:items,id'], 'lot_id' => ['nullable', 'exists:lots,id'],
            'lot_number' => ['nullable', 'string', 'max:120'], 'manufacturing_date' => ['nullable', 'date'],
            'expiry_date' => ['nullable', 'date', 'after_or_equal:manufacturing_date'],
            'source_location_id' => ['nullable', 'exists:warehouse_locations,id'],
            'destination_location_id' => ['nullable', 'exists:warehouse_locations,id', 'different:source_location_id'],
            'quantity' => ['required', 'numeric', 'gt:0'], 'unit_cost' => ['nullable', 'numeric', 'gte:0'], 'notes' => ['nullable', 'string'],
        ]);
        $movement = DB::transaction(function () use ($data, $request, $modules): StockMovement {
            $item = Item::findOrFail($data['item_id']);
            $lotId = $data['lot_id'] ?? null;
            $fefoAllocations = null;
            if ($lotId && !Lot::whereKey($lotId)->where('item_id', $item->id)->exists()) abort(422, __('stock.lot_item_mismatch'));
            if ($data['movement_type'] === 'ISSUE' && $lotId && ! Lot::whereKey($lotId)->where('status', 'RELEASED')->exists()) {
                abort(422, __('stock.lot_not_released'));
            }
            if ($data['movement_type'] === 'ISSUE' && $item->lot_managed && !$lotId) {
                $fefoAllocations = app(FefoService::class)->allocate($item->id, $data['source_location_id'], (float) $data['quantity']);
            }
            if ($data['movement_type'] === 'TRANSFER' && $item->lot_managed && !$lotId) abort(422, __('stock.lot_required'));
            if ($data['movement_type'] === 'RECEIPT' && $item->lot_managed && !$lotId) {
                $request->validate(['lot_number' => ['required', 'string', 'max:120']]);
                if ($item->expiry_managed) $request->validate(['expiry_date' => ['required', 'date']]);
                $lotId = Lot::firstOrCreate(['item_id' => $item->id, 'lot_number' => $data['lot_number']], [
                    'manufacturing_date' => $data['manufacturing_date'] ?? null, 'expiry_date' => $data['expiry_date'] ?? null,
                    'status' => $modules->enabled('quality') ? 'QUARANTINE' : 'RELEASED',
                    'attributes' => ['quality_module_enabled' => $modules->enabled('quality')],
                ])->id;
            }
            $movement = StockMovement::create([
                'movement_number' => $this->number($data['movement_type']), 'movement_type' => $data['movement_type'],
                'movement_at' => $data['movement_at'], 'status' => 'DRAFT', 'notes' => $data['notes'] ?? null,
                'created_by' => auth()->id(),
            ]);
            if ($fefoAllocations) {
                foreach ($fefoAllocations as $allocation) {
                    $movement->lines()->create([
                        'item_id' => $item->id, 'lot_id' => $allocation['lot_id'],
                        'source_location_id' => $data['source_location_id'], 'destination_location_id' => null,
                        'quantity' => $allocation['quantity'], 'unit_id' => $item->base_unit_id,
                    ]);
                }
                return $movement;
            }
            $movement->lines()->create([
                'item_id' => $item->id, 'lot_id' => $lotId,
                'source_location_id' => $data['source_location_id'] ?? null,
                'destination_location_id' => $data['destination_location_id'] ?? null,
                'quantity' => $data['quantity'], 'unit_id' => $item->base_unit_id, 'unit_cost' => $data['unit_cost'] ?? null,
            ]);
            return $movement;
        });
        return redirect()->route('stocks.index')->with('success', __('stock.movement_created', ['number' => $movement->movement_number]));
    }

    public function post(StockMovement $movement, StockPostingService $service): RedirectResponse
    {
        $service->post($movement, (string) auth()->id());
        return back()->with('success', __('stock.posted_successfully'));
    }

    public function updateLotStatus(Request $request, Lot $lot): RedirectResponse
    {
        $data = $request->validate(['status' => ['required', 'string', 'max:30']]);
        abort_unless(DB::table('reference_values')->where('domain', 'lot_status')->where('code', $data['status'])->where('active', true)->exists(), 422);
        if ($data['status'] === 'RELEASED') {
            $lot->loadMissing('item');
            $applicablePlanIds = DB::table('quality_control_plans')
                ->where('status', 'APPROVED')
                ->where('active', true)
                ->where(fn ($query) => $query->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
                ->where(fn ($query) => $query->whereNull('valid_to')->orWhereDate('valid_to', '>=', today()))
                ->where(function ($query) use ($lot): void {
                    $query->where('item_id', $lot->item_id);
                    if ($lot->item->category_id) {
                        $query->orWhere('item_category_id', $lot->item->category_id);
                    }
                    $query->orWhere(fn ($generic) => $generic->whereNull('item_id')->whereNull('item_category_id'));
                })
                ->pluck('id');
            $qualityReleaseExists = $applicablePlanIds->isEmpty() || DB::table('quality_inspections')
                ->where('lot_id', $lot->id)
                ->whereIn('quality_control_plan_id', $applicablePlanIds)
                ->where('status', 'CONFORMING')
                ->where('decision', 'RELEASE')
                ->exists();
            abort_unless($qualityReleaseExists, 422, __('stock.quality_release_required'));
        }
        $old = $lot->status;
        DB::transaction(function () use ($lot, $data, $old): void {
            $lot->update(['status' => $data['status']]);
            DB::table('audit_logs')->insert([
                'id' => (string) Str::uuid(), 'user_id' => auth()->id(), 'event' => 'stock.lot.status_changed',
                'auditable_type' => Lot::class, 'auditable_id' => $lot->id,
                'old_values' => json_encode(['status' => $old]), 'new_values' => json_encode(['status' => $data['status']]),
                'ip_address' => request()->ip(), 'user_agent' => request()->userAgent(), 'created_at' => now(),
            ]);
        });
        return back()->with('success', __('stock.lot_status_updated'));
    }

    private function number(string $type): string
    {
        $prefix = ['RECEIPT' => 'REC', 'ISSUE' => 'SOR', 'TRANSFER' => 'TRF'][$type];
        return $prefix.'-'.now()->format('YmdHis').'-'.strtoupper(substr((string) \Illuminate\Support\Str::uuid(), 0, 4));
    }

    private function setting(string $group, string $key, mixed $default): mixed
    {
        $value = DB::table('system_settings')->where(compact('group', 'key'))->value('value');
        return $value === null ? $default : json_decode($value, true);
    }
}
