<?php

namespace App\Http\Controllers;

use App\Jobs\GenerateDataExport;
use App\Jobs\ProcessDataImport;
use App\Models\Company;
use App\Models\DataExportRun;
use App\Models\DataImportJob;
use App\Models\UserWorkspaceLink;
use App\Services\Productivity\BulkOperationService;
use App\Services\Productivity\DataExchangeCatalog;
use App\Services\Productivity\DataImportService;
use App\Services\Productivity\DocumentDuplicationService;
use App\Services\Productivity\GlobalSearchService;
use App\Services\Productivity\SpreadsheetFileService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class ProductivityController extends Controller
{
    public function index(Request $request, DataExchangeCatalog $catalog, BulkOperationService $bulk): View
    {
        return view('productivity.index', [
            'catalog' => $catalog->available($request->user()),
            'importCatalog' => $catalog->available($request->user(), 'write'),
            'exportCatalog' => $catalog->available($request->user(), 'read'),
            'companies' => Company::query()->where('active', true)->orderBy('name')->get(),
            'imports' => DataImportJob::query()->where('user_id', $request->user()->id)->latest()->limit(15)->get(),
            'exports' => DataExportRun::query()->where('user_id', $request->user()->id)->latest()->limit(15)->get(),
            'favorites' => UserWorkspaceLink::query()->where('user_id', $request->user()->id)->where('link_type', 'FAVORITE')->orderBy('sort_order')->get(),
            'shortcuts' => UserWorkspaceLink::query()->where('user_id', $request->user()->id)->where('link_type', 'SHORTCUT')->orderBy('sort_order')->get(),
            'bulkResources' => $bulk->availableResources($request->user()),
        ]);
    }

    public function previewImport(Request $request, DataExchangeCatalog $catalog, DataImportService $imports): RedirectResponse
    {
        $available = array_keys($catalog->available($request->user(), 'write'));
        $data = $request->validate([
            'import_type' => ['required', Rule::in($available)],
            'company_id' => ['nullable', 'uuid', 'exists:companies,id'],
            'existing_mode' => ['required', Rule::in(['UPDATE', 'SKIP', 'FAIL'])],
            'file' => ['required', 'file', 'max:20480', 'mimes:csv,txt,xlsx'],
            'abort_on_error' => ['nullable', 'boolean'],
        ]);
        $catalog->assertAuthorized($request->user(), $data['import_type'], 'write');
        $definition = $catalog->definition($data['import_type']);
        if ($definition['company_scoped'] && empty($data['company_id'])) {
            return back()->withErrors(['company_id' => __('productivity.company_required')]);
        }

        $extension = Str::lower($request->file('file')->getClientOriginalExtension());
        $format = $extension === 'xlsx' ? 'xlsx' : 'csv';
        $job = DataImportJob::create([
            'user_id' => $request->user()->id, 'company_id' => $data['company_id'] ?? null,
            'import_type' => $data['import_type'], 'source_format' => $format,
            'existing_mode' => $data['existing_mode'], 'status' => 'UPLOADED',
            'file_disk' => 'local', 'file_path' => '', 'original_name' => $request->file('file')->getClientOriginalName(),
            'options' => ['abort_on_error' => (bool) ($data['abort_on_error'] ?? false)],
        ]);
        $path = $request->file('file')->storeAs('imports/productivity/'.$job->id, 'source.'.$format, 'local');
        $job->update(['file_path' => $path]);

        try {
            $imports->preview($job);
        } catch (\Throwable $exception) {
            $job->update(['status' => 'FAILED', 'error_message' => $exception->getMessage(), 'completed_at' => now()]);
            return redirect()->route('productivity.imports.show', $job)->withErrors(['file' => $exception->getMessage()]);
        }

        return redirect()->route('productivity.imports.show', $job)->with('success', __('productivity.preview_ready'));
    }

    public function showImport(Request $request, DataImportJob $importJob): View
    {
        $this->assertOwner($request, $importJob->user_id);
        return view('productivity.import-show', [
            'job' => $importJob->load(['company:id,name,code']),
            'rows' => $importJob->rows()->orderBy('row_number')->paginate(100),
        ]);
    }

    public function confirmImport(Request $request, DataImportJob $importJob): RedirectResponse
    {
        $this->assertOwner($request, $importJob->user_id);
        abort_unless($importJob->status === 'PREVIEW' && $importJob->valid_rows > 0, 422);
        $importJob->update(['status' => 'QUEUED', 'confirmed_at' => now()]);
        ProcessDataImport::dispatch($importJob->id);
        return back()->with('success', __('productivity.import_queued'));
    }

    public function cancelImport(Request $request, DataImportJob $importJob): RedirectResponse
    {
        $this->assertOwner($request, $importJob->user_id);
        abort_unless(in_array($importJob->status, ['UPLOADED', 'PREVIEW', 'FAILED'], true), 422);
        $importJob->update(['status' => 'CANCELLED', 'completed_at' => now()]);
        return back()->with('success', __('productivity.import_cancelled'));
    }

    public function errorFile(Request $request, DataImportJob $importJob, SpreadsheetFileService $spreadsheets)
    {
        $this->assertOwner($request, $importJob->user_id);
        $rows = $importJob->rows()->whereIn('status', ['INVALID', 'FAILED'])->orderBy('row_number')->get();
        abort_if($rows->isEmpty(), 404);
        $path = Storage::disk('local')->path('exports/productivity/import-errors-'.$importJob->id.'.xlsx');
        if (! is_dir(dirname($path))) {
            mkdir(dirname($path), 0775, true);
        }
        $spreadsheets->write($path, ['row_number', 'status', 'payload', 'errors'], $rows->map(fn ($row) => [
            $row->row_number, $row->status, json_encode($row->payload, JSON_UNESCAPED_UNICODE), json_encode($row->errors, JSON_UNESCAPED_UNICODE),
        ]), 'xlsx', 'Errors');
        return response()->download($path, 'import-errors-'.$importJob->id.'.xlsx')->deleteFileAfterSend();
    }

    public function template(Request $request, string $type, string $format, DataExchangeCatalog $catalog, SpreadsheetFileService $spreadsheets)
    {
        abort_unless(in_array($format, ['csv', 'xlsx'], true), 404);
        $catalog->assertAuthorized($request->user(), $type, 'read');
        $definition = $catalog->definition($type);
        $path = Storage::disk('local')->path('exports/productivity/template-'.$type.'-'.$request->user()->id.'.'.$format);
        if (! is_dir(dirname($path))) {
            mkdir(dirname($path), 0775, true);
        }
        $spreadsheets->write($path, array_keys($definition['columns']), $catalog->exampleRows($type), $format, __($definition['label']));
        return response()->download($path, 'template-'.$type.'.'.$format)->deleteFileAfterSend();
    }

    public function export(Request $request, DataExchangeCatalog $catalog): RedirectResponse
    {
        $data = $request->validate([
            'export_type' => ['required', Rule::in(array_keys($catalog->available($request->user(), 'read')))],
            'format' => ['required', Rule::in(['csv', 'xlsx'])],
            'company_id' => ['nullable', 'uuid', 'exists:companies,id'],
        ]);
        $catalog->assertAuthorized($request->user(), $data['export_type'], 'read');
        $definition = $catalog->definition($data['export_type']);
        if ($definition['company_scoped'] && empty($data['company_id'])) {
            return back()->withErrors(['company_id' => __('productivity.company_required')]);
        }
        $run = DataExportRun::create([
            'user_id' => $request->user()->id, 'company_id' => $data['company_id'] ?? null,
            'export_type' => $data['export_type'], 'format' => Str::upper($data['format']), 'status' => 'QUEUED',
        ]);
        GenerateDataExport::dispatch($run->id);
        return redirect()->route('productivity.index')->with('success', __('productivity.export_queued'));
    }

    public function downloadExport(Request $request, DataExportRun $exportRun)
    {
        $this->assertOwner($request, $exportRun->user_id);
        abort_unless($exportRun->status === 'COMPLETED' && $exportRun->file_disk && $exportRun->file_path, 404);
        abort_unless(Storage::disk($exportRun->file_disk)->exists($exportRun->file_path), 404);
        return Storage::disk($exportRun->file_disk)->download($exportRun->file_path, $exportRun->file_name);
    }

    public function search(Request $request, GlobalSearchService $search): JsonResponse
    {
        $data = $request->validate(['q' => ['required', 'string', 'min:2', 'max:120']]);
        return response()->json(['results' => $search->search($request->user(), $data['q'])]);
    }

    public function storeLink(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'link_type' => ['required', Rule::in(['FAVORITE', 'SHORTCUT'])],
            'label' => ['required', 'string', 'max:160'],
            'route_name' => ['required', 'string', 'max:160'],
            'route_parameters' => ['nullable', 'string', 'max:4000'],
        ]);
        abort_unless(Route::has($data['route_name']), 422, __('productivity.invalid_route'));

        try {
            $parameters = $data['route_parameters']
                ? json_decode($data['route_parameters'], true, 32, JSON_THROW_ON_ERROR)
                : [];
        } catch (\JsonException) {
            throw ValidationException::withMessages([
                'route_parameters' => __('productivity.invalid_route_parameters'),
            ]);
        }

        if (! is_array($parameters)) {
            throw ValidationException::withMessages([
                'route_parameters' => __('productivity.invalid_route_parameters'),
            ]);
        }

        try {
            route($data['route_name'], $parameters);
        } catch (\Throwable) {
            throw ValidationException::withMessages([
                'route_parameters' => __('productivity.invalid_route_parameters'),
            ]);
        }

        $fingerprint = hash('sha256', $data['route_name'].'|'.json_encode($parameters));
        UserWorkspaceLink::updateOrCreate(
            ['user_id' => $request->user()->id, 'link_type' => $data['link_type'], 'fingerprint' => $fingerprint],
            ['label' => $data['label'], 'route_name' => $data['route_name'], 'route_parameters' => $parameters],
        );
        return back()->with('success', __('productivity.link_saved'));
    }

    public function destroyLink(Request $request, UserWorkspaceLink $workspaceLink): RedirectResponse
    {
        $this->assertOwner($request, $workspaceLink->user_id);
        $workspaceLink->delete();
        return back()->with('success', __('productivity.link_deleted'));
    }

    public function duplicate(Request $request, string $type, string $id, DocumentDuplicationService $duplication): RedirectResponse
    {
        $result = $duplication->duplicate($request->user(), $type, $id);
        return redirect()->route($result['route'], $result['model'])->with('success', __('productivity.document_duplicated'));
    }

    public function bulk(Request $request, BulkOperationService $bulk): RedirectResponse
    {
        $data = $request->validate([
            'resource' => ['required', Rule::in(array_keys($bulk->resources()))],
            'action' => ['required', Rule::in(['ACTIVATE', 'DEACTIVATE', 'RESTORE'])],
            'codes' => ['required', 'string', 'max:50000'],
        ]);
        $codes = preg_split('/[\r\n,;]+/', $data['codes'], -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $run = $bulk->execute($request->user(), $data['resource'], $data['action'], $codes);
        return back()->with('success', __('productivity.bulk_completed', ['processed' => $run->processed_count, 'failed' => $run->failed_count]));
    }

    private function assertOwner(Request $request, ?string $ownerId): void
    {
        abort_unless($ownerId === $request->user()->id || $request->user()->hasRole('ADMINISTRATOR'), 403);
    }
}
