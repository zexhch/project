<?php

namespace App\Http\Controllers;

use App\Events\DashboardUpdated;
use App\Models\Item;
use App\Models\DowntimeReason;
use App\Models\Machine;
use App\Models\MaintenancePlan;
use App\Models\MaintenanceWorkOrder;
use App\Models\ProductionDowntime;
use App\Models\ProductionLine;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Models\User;
use App\Models\WarehouseLocation;
use App\Services\Maintenance\MaintenanceMetricsService;
use App\Services\Stock\FefoService;
use App\Services\Stock\StockPostingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class MaintenanceController extends Controller
{
    public function index(Request $request, MaintenanceMetricsService $metrics): View
    {
        $status = $request->query('status');
        $orders = MaintenanceWorkOrder::with(['machine', 'productionLine', 'assignee'])
            ->when($status, fn ($q) => $q->where('status', $status))
            ->orderByRaw("CASE priority WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'NORMAL' THEN 3 ELSE 4 END")
            ->latest('planned_start')->paginate(20)->withQueryString();

        return view('maintenance.index', [
            'orders' => $orders,
            'metrics' => $metrics->calculate($this->setting('metrics_period_days', 30)),
            'activeDowntimes' => ProductionDowntime::with(['productionLine', 'machine', 'reason'])->whereNull('ended_at')->latest('started_at')->get(),
            'duePlans' => MaintenancePlan::with('machine')->where('active', true)->where('next_due_at', '<=', now()->addDays($this->setting('due_alert_days', 7)))->orderBy('next_due_at')->get(),
            'machines' => Machine::where('active', true)->orderBy('name')->get(),
            'lines' => ProductionLine::where('active', true)->orderBy('name')->get(),
            'technicians' => User::where('active', true)->orderBy('name')->get(),
            'reasons' => DowntimeReason::where('active', true)->orderBy('name')->get(),
            'openOrders' => MaintenanceWorkOrder::whereNotIn('status', ['COMPLETED', 'CANCELLED'])->orderBy('work_order_number')->get(),
            'status' => $status,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'production_line_id' => ['nullable', 'exists:production_lines,id'], 'machine_id' => ['nullable', 'exists:machines,id'],
            'maintenance_type' => ['required', 'string', 'max:40'], 'priority' => ['required', 'in:LOW,NORMAL,HIGH,CRITICAL'],
            'description' => ['required', 'string'], 'planned_start' => ['nullable', 'date'],
            'assigned_to' => ['nullable', 'exists:users,id'],
        ]);
        abort_if(empty($data['machine_id']) && empty($data['production_line_id']), 422, __('maintenance.asset_required'));
        $order = MaintenanceWorkOrder::create($data + [
            'work_order_number' => 'OT-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)), 'status' => 'PLANNED',
        ]);
        $this->audit('maintenance.work_order.created', $order->id, null, $order->toArray());
        return redirect()->route('maintenance.show', $order)->with('success', __('maintenance.created'));
    }

    public function show(MaintenanceWorkOrder $order): View
    {
        $order->load(['plan', 'machine', 'productionLine', 'assignee', 'actions.performer', 'parts.item', 'downtimes.reason']);
        return view('maintenance.show', [
            'order' => $order,
            'items' => Item::where('item_type', 'SPARE_PART')->where('active', true)->orderBy('name')->get(),
            'locations' => WarehouseLocation::where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function start(MaintenanceWorkOrder $order): RedirectResponse
    {
        abort_unless(in_array($order->status, ['DRAFT', 'PLANNED'], true), 409);
        $old = $order->status;
        $order->update(['status' => 'IN_PROGRESS', 'actual_start' => now()]);
        if ($order->machine) $order->machine->update(['status' => 'MAINTENANCE']);
        $this->audit('maintenance.work_order.started', $order->id, ['status' => $old], ['status' => 'IN_PROGRESS']);
        event(new DashboardUpdated(['maintenance_work_order_id' => $order->id]));
        return back()->with('success', __('maintenance.started'));
    }

    public function complete(Request $request, MaintenanceWorkOrder $order): RedirectResponse
    {
        abort_unless($order->status === 'IN_PROGRESS', 409);
        $data = $request->validate(['observations' => ['required', 'string'], 'labor_cost' => ['nullable', 'numeric', 'gte:0']]);
        DB::transaction(function () use ($order, $data): void {
            $order->update(['status' => 'COMPLETED', 'actual_end' => now(), 'observations' => $data['observations'], 'labor_cost' => $data['labor_cost'] ?? 0]);
            if ($order->machine && !ProductionDowntime::where('machine_id', $order->machine_id)->whereNull('ended_at')->exists()) {
                $order->machine->update(['status' => 'AVAILABLE']);
            }
            $this->audit('maintenance.work_order.completed', $order->id, ['status' => 'IN_PROGRESS'], ['status' => 'COMPLETED']);
        });
        event(new DashboardUpdated(['maintenance_work_order_id' => $order->id]));
        return back()->with('success', __('maintenance.completed'));
    }

    public function addAction(Request $request, MaintenanceWorkOrder $order): RedirectResponse
    {
        abort_if($order->status === 'COMPLETED', 409);
        $data = $request->validate(['action_description' => ['required', 'string'], 'result' => ['nullable', 'string', 'max:50']]);
        $order->actions()->create($data + ['performed_by' => auth()->id(), 'performed_at' => now()]);
        return back()->with('success', __('maintenance.action_added'));
    }

    public function addPart(Request $request, MaintenanceWorkOrder $order, FefoService $fefo, StockPostingService $posting): RedirectResponse
    {
        abort_if($order->status === 'COMPLETED', 409);
        $data = $request->validate(['item_id' => ['required', 'exists:items,id'], 'location_id' => ['required', 'exists:warehouse_locations,id'], 'quantity' => ['required', 'numeric', 'gt:0']]);
        $item = Item::where('item_type', 'SPARE_PART')->findOrFail($data['item_id']);
        DB::transaction(function () use ($order, $data, $item, $fefo, $posting): void {
            $movement = StockMovement::create([
                'movement_number' => 'MNT-'.now()->format('YmdHis').'-'.strtoupper(Str::random(3)), 'movement_type' => 'ISSUE',
                'movement_at' => now(), 'source_type' => MaintenanceWorkOrder::class, 'source_id' => $order->id,
                'status' => 'DRAFT', 'created_by' => auth()->id(),
            ]);
            $totalCost = 0;
            foreach ($fefo->allocate($item->id, $data['location_id'], (float) $data['quantity']) as $allocation) {
                $balance = StockBalance::findOrFail($allocation['balance_id']);
                $movement->lines()->create(['item_id' => $item->id, 'lot_id' => $allocation['lot_id'], 'source_location_id' => $data['location_id'], 'quantity' => $allocation['quantity'], 'unit_id' => $item->base_unit_id]);
                $totalCost += $allocation['quantity'] * (float) ($balance->average_unit_cost ?? 0);
            }
            $posting->post($movement, (string) auth()->id());
            $order->parts()->create(['item_id' => $item->id, 'quantity' => $data['quantity'], 'unit_id' => $item->base_unit_id, 'unit_cost' => $data['quantity'] > 0 ? $totalCost / $data['quantity'] : 0]);
            $partsCost = $order->parts()->get()->sum(fn ($part) => (float) $part->quantity * (float) ($part->unit_cost ?? 0));
            $order->update(['parts_cost' => $partsCost]);
        });
        return back()->with('success', __('maintenance.part_added'));
    }

    private function audit(string $event, string $id, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert(['id' => (string) Str::uuid(), 'user_id' => auth()->id(), 'event' => $event, 'auditable_type' => MaintenanceWorkOrder::class, 'auditable_id' => $id, 'old_values' => $old ? json_encode($old) : null, 'new_values' => $new ? json_encode($new) : null, 'ip_address' => request()->ip(), 'user_agent' => request()->userAgent(), 'created_at' => now()]);
    }

    private function setting(string $key, int $default): int
    {
        $raw = DB::table('system_settings')->where('group', 'maintenance')->where('key', $key)->value('value');
        return (int) ($raw === null ? $default : json_decode($raw, true));
    }
}
