<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Security\SecurityAuditService;
use App\Services\Security\SecurityPolicyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    public function create(): View
    {
        return view('auth.login');
    }

    public function store(
        Request $request,
        SecurityPolicyService $policy,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $email = Str::lower($credentials['email']);
        $throttleKey = 'login:'.hash('sha256', $email.'|'.$request->ip());

        if (RateLimiter::tooManyAttempts($throttleKey, $policy->lockoutThreshold())) {
            $seconds = RateLimiter::availableIn($throttleKey);
            throw ValidationException::withMessages(['email' => __('auth.throttle', ['seconds' => $seconds])]);
        }

        $user = User::query()->where('email', $email)->first();
        if ($user?->locked_until?->isFuture()) {
            $audit->record('security.login.blocked_locked', $user, 'warning', ['locked_until' => $user->locked_until->toIso8601String()]);
            throw ValidationException::withMessages(['email' => __('security.account_locked', ['minutes' => max(1, now()->diffInMinutes($user->locked_until))])]);
        }

        if (! Auth::attempt(['email' => $email, 'password' => $credentials['password'], 'active' => true], $request->boolean('remember'))) {
            RateLimiter::hit($throttleKey, $policy->lockoutSeconds());

            if ($user) {
                DB::transaction(function () use ($user, $policy): void {
                    $locked = User::query()->lockForUpdate()->findOrFail($user->id);
                    $attempts = $locked->failed_login_attempts + 1;
                    $locked->forceFill([
                        'failed_login_attempts' => $attempts,
                        'locked_until' => $attempts >= $policy->lockoutThreshold()
                            ? now()->addSeconds($policy->lockoutSeconds())
                            : null,
                    ])->save();
                });
                $audit->record('security.login.failed', $user, 'warning');
            }

            throw ValidationException::withMessages(['email' => __('auth.failed')]);
        }

        RateLimiter::clear($throttleKey);
        $request->session()->regenerate();
        $authenticated = $request->user();
        $authenticated->forceFill([
            'failed_login_attempts' => 0,
            'locked_until' => null,
            'last_login_at' => now(),
            'last_login_ip' => $request->ip(),
        ])->save();
        $audit->record('security.login.succeeded', $authenticated, 'info');

        return redirect()->intended(route('dashboard'));
    }

    public function destroy(Request $request, SecurityAuditService $audit): RedirectResponse
    {
        $user = $request->user();
        $audit->record('security.logout', $user, 'info');

        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
