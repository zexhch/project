<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Currency;
use App\Models\GoodsReceipt;
use App\Models\Item;
use App\Models\ItemUnitConversion;
use App\Models\Lot;
use App\Models\PurchaseOrder;
use App\Models\PurchasePriceList;
use App\Models\PurchaseRequisition;
use App\Models\PurchaseRequisitionLine;
use App\Models\Site;
use App\Models\Supplier;
use App\Models\SupplierEvaluation;
use App\Models\SupplierItem;
use App\Models\SupplierQuotation;
use App\Models\SupplierReturn;
use App\Models\TaxRate;
use App\Models\Unit;
use App\Models\Warehouse;
use App\Models\WarehouseLocation;
use App\Services\Catalog\ItemPackagingService;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use App\Services\Purchasing\PurchasePricingService;
use App\Services\Purchasing\PurchasingWorkflowService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class PurchasingController extends Controller
{
    public function index(Request $request): View
    {
        $status = trim((string) $request->query('status'));
        $search = trim((string) $request->query('search'));
        $orders = PurchaseOrder::query()
            ->with(['supplier', 'warehouse'])
            ->withCount('lines')
            ->when($status, fn (Builder $query) => $query->where('status', $status))
            ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                ->where('order_number', 'ilike', "%{$search}%")
                ->orWhereHas('supplier', fn (Builder $supplier) => $supplier
                    ->where('code', 'ilike', "%{$search}%")
                    ->orWhere('name', 'ilike', "%{$search}%"))))
            ->latest('order_date')
            ->paginate(25)
            ->withQueryString();

        return view('purchasing.index', [
            'orders' => $orders,
            'status' => $status,
            'search' => $search,
            'statuses' => $this->references('purchase_order_status'),
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'suppliers' => Supplier::where('active', true)->where('status', 'APPROVED')->orderBy('name')->get(),
            'warehouses' => Warehouse::with('site')->where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'metrics' => [
                'approved_suppliers' => Supplier::where('status', 'APPROVED')->where('active', true)->count(),
                'pending_requisitions' => PurchaseRequisition::whereIn('status', ['SUBMITTED', 'APPROVED'])->count(),
                'open_orders' => PurchaseOrder::whereIn('status', ['SUBMITTED', 'APPROVED', 'PARTIALLY_RECEIVED'])->count(),
                'late_orders' => PurchaseOrder::whereIn('status', ['APPROVED', 'PARTIALLY_RECEIVED'])
                    ->whereDate('expected_date', '<', today())->count(),
                'draft_receipts' => GoodsReceipt::where('status', 'DRAFT')->count(),
            ],
        ]);
    }

    public function storeOrder(Request $request, DocumentNumberService $numbers): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'supplier_id' => ['required', 'exists:suppliers,id'],
            'warehouse_id' => ['required', 'exists:warehouses,id'],
            'order_date' => ['required', 'date'],
            'expected_date' => ['nullable', 'date', 'after_or_equal:order_date'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'exchange_rate' => ['required', 'numeric', 'gt:0'],
            'tax_included' => ['nullable', 'boolean'],
            'notes' => ['nullable', 'string'],
        ]);
        $supplier = Supplier::whereKey($data['supplier_id'])->where('company_id', $data['company_id'])->firstOrFail();
        $warehouse = Warehouse::with('site')->findOrFail($data['warehouse_id']);
        abort_unless($warehouse->site->company_id === $data['company_id'], 422, __('purchasing.warehouse_company_mismatch'));

        $order = PurchaseOrder::create($data + [
            'site_id' => $warehouse->site_id,
            'supplier_id' => $supplier->id,
            'order_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::PURCHASE_ORDER, $data['order_date']),
            'tax_included' => $request->boolean('tax_included'),
            'status' => 'DRAFT',
            'payment_terms_days' => $supplier->payment_terms_days,
            'incoterm' => $supplier->incoterm,
            'created_by' => auth()->id(),
        ]);
        $this->audit('purchasing.order.created', $order, null, $order->toArray());

        return redirect()->route('purchasing.orders.show', $order)->with('success', __('purchasing.order_created'));
    }

    public function showOrder(PurchaseOrder $order): View
    {
        $order->load([
            'company', 'site', 'warehouse.locations', 'supplier.items', 'requisition', 'quotation',
            'lines.item.baseUnit', 'lines.unit', 'lines.taxRate', 'receipts.lines', 'creator', 'approver',
        ]);

        return view('purchasing.orders.show', [
            'order' => $order,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'taxRates' => TaxRate::where(fn (Builder $query) => $query
                ->whereNull('company_id')->orWhere('company_id', $order->company_id))
                ->where('active', true)->orderBy('code')->get(),
            'locations' => $order->warehouse->locations->where('active', true),
        ]);
    }

    public function addOrderLine(
        Request $request,
        PurchaseOrder $order,
        PurchasePricingService $pricing,
        PurchasingWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($order->status === 'DRAFT', 409, __('purchasing.order_not_draft'));
        $data = $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            'ordered_quantity' => ['required', 'numeric', 'gt:0'],
            'unit_id' => ['required', 'exists:units,id'],
            'factor_to_base' => ['nullable', 'numeric', 'gt:0'],
            'unit_price' => ['nullable', 'numeric', 'gte:0'],
            'discount_percentage' => ['nullable', 'numeric', 'between:0,100'],
            'tax_rate_id' => ['nullable', $this->taxRateRule($order->company_id)],
            'expected_date' => ['nullable', 'date', 'after_or_equal:'.$order->order_date->format('Y-m-d')],
            'notes' => ['nullable', 'string'],
        ]);
        $item = Item::with('baseUnit')->findOrFail($data['item_id']);
        $data['ordered_quantity'] = $this->packagingQuantity(
            $item,
            (string) $data['unit_id'],
            (float) $data['ordered_quantity'],
            'ordered_quantity',
        );
        $supplierItem = SupplierItem::query()->where([
            'supplier_id' => $order->supplier_id,
            'item_id' => $item->id,
            'purchasing_unit_id' => $data['unit_id'],
            'active' => true,
        ])->first();
        $factor = $this->packagingFactor($item, (string) $data['unit_id'], $supplierItem?->factor_to_base ?? ($data['factor_to_base'] ?? null));
        if ($factor <= 0) {
            throw ValidationException::withMessages(['factor_to_base' => __('purchasing.conversion_factor_required')]);
        }

        $resolved = null;
        if (($data['unit_price'] ?? null) === null) {
            $resolved = $pricing->resolve(
                $order->supplier()->firstOrFail(),
                $item,
                (float) $data['ordered_quantity'],
                $data['unit_id'],
                $order->order_date,
            );
            if (! $resolved) {
                throw ValidationException::withMessages(['unit_price' => __('purchasing.no_applicable_price')]);
            }
            if ($resolved['currency_code'] !== $order->currency_code) {
                throw ValidationException::withMessages(['currency_code' => __('purchasing.price_currency_mismatch')]);
            }
            if ($resolved['tax_included'] !== $order->tax_included) {
                throw ValidationException::withMessages(['tax_included' => __('purchasing.price_tax_mode_mismatch')]);
            }
        }

        $unitPrice = (float) ($data['unit_price'] ?? $resolved['unit_price']);
        $discount = (float) ($data['discount_percentage'] ?? $resolved['discount_percentage'] ?? 0);
        $taxRateId = $data['tax_rate_id'] ?? $resolved['tax_rate_id'] ?? null;
        $taxRate = $taxRateId ? (float) TaxRate::findOrFail($taxRateId)->rate : 0;
        $amounts = $pricing->calculate(
            (float) $data['ordered_quantity'],
            $unitPrice,
            $discount,
            $taxRate,
            $order->tax_included,
        );

        $line = $order->lines()->create([
            'item_id' => $item->id,
            'description' => $item->name,
            'ordered_quantity' => $data['ordered_quantity'],
            'unit_id' => $data['unit_id'],
            'factor_to_base' => $factor,
            'unit_price' => $unitPrice,
            'discount_percentage' => $discount,
            'tax_rate_id' => $taxRateId,
            'net_unit_price' => $amounts['net_unit_price'],
            'line_subtotal' => $amounts['line_subtotal'],
            'tax_amount' => $amounts['tax_amount'],
            'line_total' => $amounts['line_total'],
            'expected_date' => $data['expected_date'] ?? $order->expected_date,
            'status' => 'OPEN',
            'notes' => $data['notes'] ?? null,
        ]);
        $workflow->recalculateOrder($order);
        $this->audit('purchasing.order.line_created', $line, null, $line->toArray());

        return back()->with('success', __('purchasing.line_added'));
    }

    public function submitOrder(PurchaseOrder $order, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->submitOrder($order, (string) auth()->id());

        return back()->with('success', __('purchasing.order_submitted'));
    }

    public function approveOrder(PurchaseOrder $order, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->approveOrder($order, (string) auth()->id());

        return back()->with('success', __('purchasing.order_approved'));
    }

    public function suppliers(Request $request): View
    {
        $search = trim((string) $request->query('search'));

        return view('purchasing.suppliers.index', [
            'suppliers' => Supplier::query()->with('company')->withAvg('evaluations', 'total_score')
                ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                    ->where('code', 'ilike', "%{$search}%")
                    ->orWhere('name', 'ilike', "%{$search}%")
                    ->orWhere('legal_name', 'ilike', "%{$search}%")
                    ->orWhere('registration_number', 'ilike', "%{$search}%")
                    ->orWhere('tax_identifier', 'ilike', "%{$search}%")
                    ->orWhere('statistical_identification_number', 'ilike', "%{$search}%")
                    ->orWhere('article_of_imposition_number', 'ilike', "%{$search}%")))
                ->orderBy('name')->paginate(25)->withQueryString(),
            'search' => $search,
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'supplierTypes' => $this->references('supplier_type'),
            'supplierStatuses' => $this->references('supplier_status'),
            'countries' => $this->references('country'),
        ]);
    }

    public function storeSupplier(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'code' => ['required', 'string', 'max:80', Rule::unique('suppliers')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'legal_name' => ['nullable', 'string', 'max:255'],
            'supplier_type' => ['required', $this->referenceRule('supplier_type')],
            'tax_identifier' => ['nullable', 'string', 'max:120'],
            'registration_number' => ['nullable', 'string', 'max:120'],
            'statistical_identification_number' => ['nullable', 'string', 'max:120'],
            'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            'country_code' => ['required', $this->referenceRule('country')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'payment_terms_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'incoterm' => ['nullable', 'string', 'max:20'],
            'lead_time_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'minimum_order_value' => ['required', 'numeric', 'gte:0'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'preferred' => ['nullable', 'boolean'],
        ]);
        $supplier = Supplier::create($data + [
            'status' => 'PROSPECT',
            'preferred' => $request->boolean('preferred'),
            'active' => true,
        ]);
        $this->audit('purchasing.supplier.created', $supplier, null, $supplier->toArray());

        return redirect()->route('purchasing.suppliers.show', $supplier)->with('success', __('purchasing.supplier_created'));
    }

    public function showSupplier(Supplier $supplier): View
    {
        $supplier->load([
            'company', 'contacts', 'items.item.baseUnit', 'items.purchasingUnit',
            'priceLists.lines', 'evaluations.evaluator', 'purchaseOrders',
        ]);

        return view('purchasing.suppliers.show', [
            'supplier' => $supplier,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'statuses' => $this->references('supplier_status'),
            'supplierTypes' => $this->references('supplier_type'),
            'countries' => $this->references('country'),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function updateSupplier(Request $request, Supplier $supplier): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', Rule::unique('suppliers')->where('company_id', $supplier->company_id)->ignore($supplier->id)],
            'name' => ['required', 'string', 'max:255'],
            'legal_name' => ['nullable', 'string', 'max:255'],
            'supplier_type' => ['required', $this->referenceRule('supplier_type')],
            'tax_identifier' => ['nullable', 'string', 'max:120'],
            'registration_number' => ['nullable', 'string', 'max:120'],
            'statistical_identification_number' => ['nullable', 'string', 'max:120'],
            'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            'country_code' => ['required', $this->referenceRule('country')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'payment_terms_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'incoterm' => ['nullable', 'string', 'max:20'],
            'lead_time_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'minimum_order_value' => ['required', 'numeric', 'gte:0'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'preferred' => ['nullable', 'boolean'],
        ]);
        $old = $supplier->toArray();
        $supplier->update($data + ['preferred' => $request->boolean('preferred')]);
        $this->audit('purchasing.supplier.updated', $supplier, $old, $supplier->fresh()->toArray());

        return back()->with('success', __('purchasing.supplier_updated'));
    }

    public function updateSupplierStatus(Request $request, Supplier $supplier): RedirectResponse
    {
        $data = $request->validate(['status' => ['required', $this->referenceRule('supplier_status')]]);
        $old = $supplier->status;
        $supplier->update(['status' => $data['status'], 'active' => $data['status'] !== 'BLOCKED']);
        $this->audit('purchasing.supplier.status_changed', $supplier, ['status' => $old], ['status' => $data['status']]);

        return back()->with('success', __('purchasing.supplier_status_updated'));
    }

    public function storeSupplierContact(Request $request, Supplier $supplier): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'job_title' => ['nullable', 'string', 'max:255'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'mobile' => ['nullable', 'string', 'max:80'],
            'is_primary' => ['nullable', 'boolean'],
        ]);
        if ($request->boolean('is_primary')) {
            $supplier->contacts()->update(['is_primary' => false]);
        }
        $contact = $supplier->contacts()->create($data + [
            'is_primary' => $request->boolean('is_primary'),
            'active' => true,
        ]);
        $this->audit('purchasing.supplier.contact_created', $contact, null, $contact->toArray());

        return back()->with('success', __('purchasing.contact_added'));
    }

    public function storeSupplierItem(Request $request, Supplier $supplier): RedirectResponse
    {
        $data = $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            'purchasing_unit_id' => ['required', 'exists:units,id'],
            'supplier_reference' => ['nullable', 'string', 'max:120'],
            'factor_to_base' => ['nullable', 'numeric', 'gt:0'],
            'minimum_order_quantity' => ['required', 'numeric', 'gte:0'],
            'pack_quantity' => ['required', 'numeric', 'gt:0'],
            'lead_time_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'preferred' => ['nullable', 'boolean'],
        ]);
        if (SupplierItem::where('supplier_id', $supplier->id)
            ->where('item_id', $data['item_id'])
            ->where('purchasing_unit_id', $data['purchasing_unit_id'])->exists()) {
            throw ValidationException::withMessages(['item_id' => __('purchasing.supplier_item_exists')]);
        }
        $item = Item::with('baseUnit')->findOrFail($data['item_id']);
        $data['factor_to_base'] = $this->packagingFactor($item, (string) $data['purchasing_unit_id'], $data['factor_to_base'] ?? null);
        $supplierItem = $supplier->items()->create($data + [
            'preferred' => $request->boolean('preferred'),
            'active' => true,
        ]);
        $this->audit('purchasing.supplier.item_created', $supplierItem, null, $supplierItem->toArray());

        return back()->with('success', __('purchasing.supplier_item_added'));
    }

    public function storeEvaluation(Request $request, Supplier $supplier): RedirectResponse
    {
        $data = $request->validate([
            'period_from' => ['required', 'date'],
            'period_to' => ['required', 'date', 'after_or_equal:period_from'],
            'quality_score' => ['required', 'numeric', 'between:0,100'],
            'delivery_score' => ['required', 'numeric', 'between:0,100'],
            'commercial_score' => ['required', 'numeric', 'between:0,100'],
            'service_score' => ['required', 'numeric', 'between:0,100'],
            'comments' => ['nullable', 'string'],
        ]);
        $exists = SupplierEvaluation::where('supplier_id', $supplier->id)
            ->whereDate('period_from', $data['period_from'])->whereDate('period_to', $data['period_to'])->exists();
        throw_if($exists, ValidationException::withMessages(['period_from' => __('purchasing.evaluation_period_exists')]));
        $total = collect(['quality_score', 'delivery_score', 'commercial_score', 'service_score'])
            ->avg(fn (string $key) => (float) $data[$key]);
        $evaluation = $supplier->evaluations()->create($data + [
            'company_id' => $supplier->company_id,
            'evaluation_number' => $this->number('EVF'),
            'total_score' => round($total, 2),
            'status' => 'COMPLETED',
            'evaluated_by' => auth()->id(),
            'completed_at' => now(),
        ]);
        $this->audit('purchasing.supplier.evaluated', $evaluation, null, $evaluation->toArray());

        return back()->with('success', __('purchasing.evaluation_created'));
    }

    public function priceLists(): View
    {
        return view('purchasing.price-lists.index', [
            'priceLists' => PurchasePriceList::with(['supplier', 'company'])->withCount('lines')
                ->orderByDesc('valid_from')->paginate(25),
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'suppliers' => Supplier::where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function storePriceList(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'supplier_id' => ['required', 'exists:suppliers,id'],
            'code' => ['required', 'string', 'max:80', Rule::unique('purchase_price_lists')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'tax_included' => ['nullable', 'boolean'],
            'priority' => ['required', 'integer', 'min:1', 'max:9999'],
            'valid_from' => ['required', 'date'],
            'valid_to' => ['nullable', 'date', 'after_or_equal:valid_from'],
        ]);
        abort_unless(Supplier::whereKey($data['supplier_id'])->where('company_id', $data['company_id'])->exists(), 422);
        $priceList = PurchasePriceList::create($data + [
            'tax_included' => $request->boolean('tax_included'),
            'status' => 'DRAFT',
            'created_by' => auth()->id(),
        ]);
        $this->audit('purchasing.price_list.created', $priceList, null, $priceList->toArray());

        return redirect()->route('purchasing.price-lists.show', $priceList)->with('success', __('purchasing.price_list_created'));
    }

    public function showPriceList(PurchasePriceList $priceList): View
    {
        $priceList->load(['supplier.items', 'company', 'lines.item', 'lines.unit', 'lines.taxRate', 'creator', 'approver']);

        return view('purchasing.price-lists.show', [
            'priceList' => $priceList,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'taxRates' => TaxRate::where(fn (Builder $query) => $query
                ->whereNull('company_id')->orWhere('company_id', $priceList->company_id))
                ->where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function addPriceListLine(Request $request, PurchasePriceList $priceList): RedirectResponse
    {
        abort_unless($priceList->status === 'DRAFT', 409, __('purchasing.price_list_not_draft'));
        $data = $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            'unit_id' => ['required', 'exists:units,id'],
            'minimum_quantity' => ['required', 'numeric', 'gte:0'],
            'unit_price' => ['required', 'numeric', 'gte:0'],
            'discount_percentage' => ['required', 'numeric', 'between:0,100'],
            'tax_rate_id' => ['nullable', $this->taxRateRule($priceList->company_id)],
            'lead_time_days' => ['nullable', 'integer', 'min:0', 'max:3650'],
        ]);
        $priceItem = Item::findOrFail($data['item_id']);
        $data['minimum_quantity'] = $this->packagingQuantity(
            $priceItem,
            (string) $data['unit_id'],
            (float) $data['minimum_quantity'],
            'minimum_quantity',
        );
        $duplicate = $priceList->lines()->where('item_id', $data['item_id'])
            ->where('unit_id', $data['unit_id'])->where('minimum_quantity', $data['minimum_quantity'])->exists();
        throw_if($duplicate, ValidationException::withMessages(['minimum_quantity' => __('purchasing.price_tier_exists')]));
        $supplierItemId = SupplierItem::where('supplier_id', $priceList->supplier_id)
            ->where('item_id', $data['item_id'])->where('purchasing_unit_id', $data['unit_id'])->value('id');
        $line = $priceList->lines()->create($data + ['supplier_item_id' => $supplierItemId]);
        $this->audit('purchasing.price_list.line_created', $line, null, $line->toArray());

        return back()->with('success', __('purchasing.line_added'));
    }

    public function approvePriceList(PurchasePriceList $priceList, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->approvePriceList($priceList, (string) auth()->id());

        return back()->with('success', __('purchasing.price_list_approved'));
    }

    public function requisitions(): View
    {
        return view('purchasing.requisitions.index', [
            'requisitions' => PurchaseRequisition::with(['company', 'site', 'requester'])->withCount('lines')
                ->latest('request_date')->paginate(25),
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'sites' => Site::where('active', true)->orderBy('name')->get(),
            'priorities' => $this->references('purchase_priority'),
        ]);
    }

    public function storeRequisition(Request $request, DocumentNumberService $numbers): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'site_id' => ['nullable', 'exists:sites,id'],
            'request_date' => ['required', 'date'],
            'required_date' => ['nullable', 'date', 'after_or_equal:request_date'],
            'priority' => ['required', $this->referenceRule('purchase_priority')],
            'notes' => ['nullable', 'string'],
        ]);
        if (! empty($data['site_id'])) {
            abort_unless(Site::whereKey($data['site_id'])->where('company_id', $data['company_id'])->exists(), 422);
        }
        $requisition = PurchaseRequisition::create($data + [
            'requisition_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::PURCHASE_REQUISITION, $data['request_date']),
            'status' => 'DRAFT',
            'requested_by' => auth()->id(),
        ]);
        $this->audit('purchasing.requisition.created', $requisition, null, $requisition->toArray());

        return redirect()->route('purchasing.requisitions.show', $requisition)->with('success', __('purchasing.requisition_created'));
    }

    public function showRequisition(PurchaseRequisition $requisition): View
    {
        $requisition->load([
            'company', 'site', 'requester', 'approver', 'lines.item.baseUnit', 'lines.unit',
            'lines.suggestedSupplier', 'quotations.supplier', 'quotations.lines.item', 'quotations.lines.unit',
        ]);

        return view('purchasing.requisitions.show', [
            'requisition' => $requisition,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'suppliers' => Supplier::where('company_id', $requisition->company_id)->where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'taxRates' => TaxRate::where(fn (Builder $query) => $query
                ->whereNull('company_id')->orWhere('company_id', $requisition->company_id))
                ->where('active', true)->orderBy('code')->get(),
            'warehouses' => Warehouse::whereHas('site', fn (Builder $query) => $query
                ->where('company_id', $requisition->company_id))->where('active', true)->orderBy('name')->get(),
        ]);
    }

    public function addRequisitionLine(Request $request, PurchaseRequisition $requisition): RedirectResponse
    {
        abort_unless($requisition->status === 'DRAFT', 409, __('purchasing.requisition_not_draft'));
        $data = $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'unit_id' => ['required', 'exists:units,id'],
            'suggested_supplier_id' => [
                'nullable',
                Rule::exists('suppliers', 'id')->where(fn ($query) => $query
                    ->where('company_id', $requisition->company_id)
                    ->where('active', true)),
            ],
            'estimated_unit_price' => ['nullable', 'numeric', 'gte:0'],
            'currency_code' => ['nullable', 'exists:currencies,code'],
            'notes' => ['nullable', 'string'],
        ]);
        $item = Item::findOrFail($data['item_id']);
        $data['quantity'] = $this->packagingQuantity(
            $item,
            (string) $data['unit_id'],
            (float) $data['quantity'],
            'quantity',
        );
        $line = $requisition->lines()->create($data + ['description' => $item->name]);
        $this->audit('purchasing.requisition.line_created', $line, null, $line->toArray());

        return back()->with('success', __('purchasing.line_added'));
    }

    public function submitRequisition(PurchaseRequisition $requisition, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->submitRequisition($requisition, (string) auth()->id());

        return back()->with('success', __('purchasing.requisition_submitted'));
    }

    public function approveRequisition(PurchaseRequisition $requisition, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->approveRequisition($requisition, (string) auth()->id());

        return back()->with('success', __('purchasing.requisition_approved'));
    }

    public function storeQuotation(Request $request, PurchaseRequisition $requisition): RedirectResponse
    {
        abort_unless(in_array($requisition->status, ['APPROVED', 'ORDERED'], true), 409, __('purchasing.requisition_not_approved'));
        $data = $request->validate([
            'supplier_id' => ['required', 'exists:suppliers,id'],
            'supplier_reference' => ['nullable', 'string', 'max:120'],
            'quotation_date' => ['required', 'date'],
            'valid_until' => ['nullable', 'date', 'after_or_equal:quotation_date'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'exchange_rate' => ['required', 'numeric', 'gt:0'],
            'tax_included' => ['nullable', 'boolean'],
            'payment_terms_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'delivery_lead_time_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'notes' => ['nullable', 'string'],
        ]);
        abort_unless(Supplier::whereKey($data['supplier_id'])->where('company_id', $requisition->company_id)->exists(), 422);
        $quotation = $requisition->quotations()->create($data + [
            'company_id' => $requisition->company_id,
            'quotation_number' => $this->number('OFF'),
            'tax_included' => $request->boolean('tax_included'),
            'status' => 'RECEIVED',
            'created_by' => auth()->id(),
        ]);
        $this->audit('purchasing.quotation.created', $quotation, null, $quotation->toArray());

        return back()->with('success', __('purchasing.quotation_created'));
    }

    public function addQuotationLine(
        Request $request,
        SupplierQuotation $quotation,
        PurchasePricingService $pricing,
        PurchasingWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($quotation->status === 'RECEIVED', 409, __('purchasing.quotation_not_editable'));
        $data = $request->validate([
            'purchase_requisition_line_id' => ['required', 'exists:purchase_requisition_lines,id'],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'unit_price' => ['required', 'numeric', 'gte:0'],
            'discount_percentage' => ['required', 'numeric', 'between:0,100'],
            'tax_rate_id' => ['nullable', $this->taxRateRule($quotation->company_id)],
        ]);
        $requisitionLine = $quotation->requisition()->firstOrFail()->lines()
            ->with('item')->findOrFail($data['purchase_requisition_line_id']);
        $data['quantity'] = $this->packagingQuantity(
            $requisitionLine->item,
            (string) $requisitionLine->unit_id,
            (float) $data['quantity'],
            'quantity',
        );
        if ((float) $data['quantity'] > (float) $requisitionLine->quantity + 0.0005) {
            throw ValidationException::withMessages(['quantity' => __('purchasing.quotation_quantity_exceeds_request')]);
        }
        if ($quotation->lines()->where('purchase_requisition_line_id', $requisitionLine->id)->exists()) {
            throw ValidationException::withMessages(['purchase_requisition_line_id' => __('purchasing.quotation_line_exists')]);
        }
        $taxRate = ! empty($data['tax_rate_id']) ? (float) TaxRate::findOrFail($data['tax_rate_id'])->rate : 0;
        $amounts = $pricing->calculate(
            (float) $data['quantity'],
            (float) $data['unit_price'],
            (float) $data['discount_percentage'],
            $taxRate,
            $quotation->tax_included,
        );
        $line = $quotation->lines()->create([
            'purchase_requisition_line_id' => $requisitionLine->id,
            'item_id' => $requisitionLine->item_id,
            'description' => $requisitionLine->description,
            'quantity' => $data['quantity'],
            'unit_id' => $requisitionLine->unit_id,
            'unit_price' => $data['unit_price'],
            'discount_percentage' => $data['discount_percentage'],
            'tax_rate_id' => $data['tax_rate_id'] ?? null,
            'line_subtotal' => $amounts['line_subtotal'],
            'tax_amount' => $amounts['tax_amount'],
            'line_total' => $amounts['line_total'],
        ]);
        $workflow->recalculateQuotation($quotation);
        $this->audit('purchasing.quotation.line_created', $line, null, $line->toArray());

        return back()->with('success', __('purchasing.line_added'));
    }

    public function selectQuotation(Request $request, SupplierQuotation $quotation, DocumentNumberService $numbers): RedirectResponse
    {
        $data = $request->validate([
            'warehouse_id' => ['required', 'exists:warehouses,id'],
            'expected_date' => ['nullable', 'date', 'after_or_equal:today'],
        ]);
        $order = DB::transaction(function () use ($quotation, $data, $numbers): PurchaseOrder {
            $quotation = SupplierQuotation::query()
                ->with(['supplier', 'requisition.lines', 'lines.item'])
                ->lockForUpdate()->findOrFail($quotation->id);
            abort_unless($quotation->status === 'RECEIVED' && $quotation->lines->isNotEmpty(), 409, __('purchasing.quotation_not_selectable'));
            abort_unless($quotation->supplier->status === 'APPROVED' && $quotation->supplier->active, 422, __('purchasing.supplier_not_approved'));
            $warehouse = Warehouse::with('site')->findOrFail($data['warehouse_id']);
            abort_unless($warehouse->site->company_id === $quotation->company_id, 422, __('purchasing.warehouse_company_mismatch'));

            $order = PurchaseOrder::create([
                'company_id' => $quotation->company_id,
                'site_id' => $warehouse->site_id,
                'warehouse_id' => $warehouse->id,
                'supplier_id' => $quotation->supplier_id,
                'purchase_requisition_id' => $quotation->purchase_requisition_id,
                'supplier_quotation_id' => $quotation->id,
                'order_number' => $numbers->next($quotation->company_id, FinancialDocumentCatalog::PURCHASE_ORDER, today()),
                'order_date' => today(),
                'expected_date' => $data['expected_date'] ?? today()->addDays($quotation->delivery_lead_time_days),
                'currency_code' => $quotation->currency_code,
                'exchange_rate' => $quotation->exchange_rate,
                'tax_included' => $quotation->tax_included,
                'status' => 'DRAFT',
                'payment_terms_days' => $quotation->payment_terms_days,
                'subtotal' => $quotation->subtotal,
                'discount_amount' => $quotation->discount_amount,
                'tax_amount' => $quotation->tax_amount,
                'total_amount' => $quotation->total_amount,
                'created_by' => auth()->id(),
            ]);
            foreach ($quotation->lines as $quotationLine) {
                $supplierItem = SupplierItem::where('supplier_id', $quotation->supplier_id)
                    ->where('item_id', $quotationLine->item_id)
                    ->where('purchasing_unit_id', $quotationLine->unit_id)->first();
                $factor = $this->packagingFactor(
                    $quotationLine->item,
                    (string) $quotationLine->unit_id,
                    $supplierItem?->factor_to_base,
                );
                if ($factor <= 0) {
                    throw ValidationException::withMessages(['quotation' => __('purchasing.quotation_conversion_missing')]);
                }
                $netUnitPrice = (float) $quotationLine->quantity > 0
                    ? (float) $quotationLine->line_subtotal / (float) $quotationLine->quantity
                    : 0;
                $order->lines()->create([
                    'purchase_requisition_line_id' => $quotationLine->purchase_requisition_line_id,
                    'item_id' => $quotationLine->item_id,
                    'description' => $quotationLine->description,
                    'ordered_quantity' => $quotationLine->quantity,
                    'unit_id' => $quotationLine->unit_id,
                    'factor_to_base' => $factor,
                    'unit_price' => $quotationLine->unit_price,
                    'discount_percentage' => $quotationLine->discount_percentage,
                    'tax_rate_id' => $quotationLine->tax_rate_id,
                    'net_unit_price' => $netUnitPrice,
                    'line_subtotal' => $quotationLine->line_subtotal,
                    'tax_amount' => $quotationLine->tax_amount,
                    'line_total' => $quotationLine->line_total,
                    'expected_date' => $order->expected_date,
                    'status' => 'OPEN',
                ]);
                if ($quotationLine->purchase_requisition_line_id) {
                    $requisitionLine = PurchaseRequisitionLine::query()
                        ->lockForUpdate()
                        ->findOrFail($quotationLine->purchase_requisition_line_id);
                    $remaining = (float) $requisitionLine->quantity - (float) $requisitionLine->quantity_ordered;
                    if ((float) $quotationLine->quantity > $remaining + 0.0005) {
                        throw ValidationException::withMessages(['quotation' => __('purchasing.quotation_exceeds_remaining_request')]);
                    }
                    $requisitionLine->increment('quantity_ordered', (float) $quotationLine->quantity);
                }
            }
            $quotation->update(['status' => 'SELECTED']);
            $quotation->requisition?->update(['status' => 'ORDERED']);
            $this->audit('purchasing.quotation.selected', $quotation, ['status' => 'RECEIVED'], ['status' => 'SELECTED']);
            $this->audit('purchasing.order.created_from_quotation', $order, null, $order->toArray());

            return $order;
        }, 3);

        return redirect()->route('purchasing.orders.show', $order)->with('success', __('purchasing.order_created_from_quotation'));
    }

    public function storeReceipt(Request $request, PurchaseOrder $order, DocumentNumberService $numbers): RedirectResponse
    {
        abort_unless(in_array($order->status, ['APPROVED', 'PARTIALLY_RECEIVED'], true), 409, __('purchasing.order_not_receivable'));
        $data = $request->validate([
            'destination_location_id' => ['required', 'exists:warehouse_locations,id'],
            'received_at' => ['required', 'date'],
            'supplier_delivery_note' => ['nullable', 'string', 'max:120'],
            'notes' => ['nullable', 'string'],
            'lines' => ['required', 'array'],
            'lines.*.accepted_quantity' => ['nullable', 'numeric', 'gte:0'],
            'lines.*.rejected_quantity' => ['nullable', 'numeric', 'gte:0'],
            'lines.*.lot_number' => ['nullable', 'string', 'max:120'],
            'lines.*.manufacturing_date' => ['nullable', 'date'],
            'lines.*.expiry_date' => ['nullable', 'date'],
            'lines.*.rejection_reason' => ['nullable', 'string'],
        ]);
        abort_unless(WarehouseLocation::whereKey($data['destination_location_id'])
            ->where('warehouse_id', $order->warehouse_id)->exists(), 422, __('purchasing.location_warehouse_mismatch'));

        $receipt = DB::transaction(function () use ($order, $data, $numbers): GoodsReceipt {
            $receipt = GoodsReceipt::create([
                'purchase_order_id' => $order->id,
                'supplier_id' => $order->supplier_id,
                'warehouse_id' => $order->warehouse_id,
                'destination_location_id' => $data['destination_location_id'],
                'receipt_number' => $numbers->next($order->company_id, FinancialDocumentCatalog::GOODS_RECEIPT, $data['received_at']),
                'received_at' => $data['received_at'],
                'supplier_delivery_note' => $data['supplier_delivery_note'] ?? null,
                'status' => 'DRAFT',
                'notes' => $data['notes'] ?? null,
                'created_by' => auth()->id(),
            ]);
            foreach ($data['lines'] as $lineId => $values) {
                $accepted = (float) ($values['accepted_quantity'] ?? 0);
                $rejected = (float) ($values['rejected_quantity'] ?? 0);
                if ($accepted <= 0 && $rejected <= 0) {
                    continue;
                }
                $orderLine = $order->lines()->with('item')->findOrFail($lineId);
                $accepted = $this->packagingQuantity($orderLine->item, (string) $orderLine->unit_id, $accepted, 'lines');
                $rejected = $this->packagingQuantity($orderLine->item, (string) $orderLine->unit_id, $rejected, 'lines');
                $remaining = (float) $orderLine->ordered_quantity - (float) $orderLine->received_quantity;
                if (($accepted + $rejected) > $remaining + 0.0005) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.delivery_quantity_exceeds_remaining')]);
                }
                if ($rejected > 0 && blank($values['rejection_reason'] ?? null)) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.rejection_reason_required')]);
                }
                if ((float) $orderLine->factor_to_base <= 0) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.invalid_conversion_factor')]);
                }
                if ($accepted > 0 && $orderLine->item->lot_managed && blank($values['lot_number'] ?? null)) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.lot_number_required')]);
                }
                if ($accepted > 0 && $orderLine->item->expiry_managed && blank($values['expiry_date'] ?? null)) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.expiry_date_required')]);
                }
                if (! blank($values['manufacturing_date'] ?? null) && ! blank($values['expiry_date'] ?? null)
                    && Carbon::parse($values['expiry_date'])->lt(Carbon::parse($values['manufacturing_date']))) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.expiry_before_manufacturing')]);
                }
                if ($accepted > 0 && ! blank($values['lot_number'] ?? null)) {
                    $existingLot = Lot::where('item_id', $orderLine->item_id)
                        ->where('lot_number', $values['lot_number'])
                        ->first();
                    $expiryMismatch = $existingLot && ($values['expiry_date'] ?? null)
                        && ! $existingLot->expiry_date?->equalTo(Carbon::parse($values['expiry_date']));
                    $manufacturingMismatch = $existingLot && ($values['manufacturing_date'] ?? null)
                        && ! $existingLot->manufacturing_date?->equalTo(Carbon::parse($values['manufacturing_date']));
                    if ($expiryMismatch || $manufacturingMismatch) {
                        throw ValidationException::withMessages(['lines' => __('purchasing.lot_dates_mismatch')]);
                    }
                }
                $receipt->lines()->create([
                    'purchase_order_line_id' => $orderLine->id,
                    'item_id' => $orderLine->item_id,
                    'lot_number' => $values['lot_number'] ?? null,
                    'manufacturing_date' => $values['manufacturing_date'] ?? null,
                    'expiry_date' => $values['expiry_date'] ?? null,
                    'accepted_quantity' => $accepted,
                    'rejected_quantity' => $rejected,
                    'unit_id' => $orderLine->unit_id,
                    'factor_to_base' => $orderLine->factor_to_base,
                    'unit_cost' => $orderLine->net_unit_price,
                    'base_unit_cost' => (float) $orderLine->net_unit_price * (float) $order->exchange_rate / (float) $orderLine->factor_to_base,
                    'rejection_reason' => $values['rejection_reason'] ?? null,
                ]);
            }
            if ($receipt->lines()->doesntExist()) {
                throw ValidationException::withMessages(['lines' => __('purchasing.received_quantity_required')]);
            }
            $this->audit('purchasing.receipt.created', $receipt, null, $receipt->toArray());

            return $receipt;
        });

        return redirect()->route('purchasing.receipts.show', $receipt)->with('success', __('purchasing.receipt_created'));
    }

    public function receipts(): View
    {
        return view('purchasing.receipts.index', [
            'receipts' => GoodsReceipt::with(['purchaseOrder', 'supplier', 'warehouse', 'creator'])
                ->withCount('lines')->latest('received_at')->paginate(25),
        ]);
    }

    public function showReceipt(GoodsReceipt $receipt): View
    {
        $receipt->load([
            'purchaseOrder.company', 'supplier', 'warehouse.locations', 'destinationLocation', 'creator', 'poster',
            'lines.item.baseUnit', 'lines.unit', 'lines.lot', 'lines.purchaseOrderLine', 'stockMovement', 'supplierInvoice',
        ]);

        return view('purchasing.receipts.show', [
            'receipt' => $receipt,
            'returnReasons' => $this->references('supplier_return_reason'),
            'returns' => SupplierReturn::with(['lines', 'sourceLocation'])
                ->where('goods_receipt_id', $receipt->id)->latest('return_date')->get(),
        ]);
    }

    public function postReceipt(GoodsReceipt $receipt, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->postReceipt($receipt, (string) auth()->id());

        return back()->with('success', __('purchasing.receipt_posted'));
    }

    public function storeReturn(Request $request, GoodsReceipt $receipt): RedirectResponse
    {
        abort_unless($receipt->status === 'POSTED', 409, __('purchasing.receipt_not_posted'));
        $data = $request->validate([
            'source_location_id' => ['required', 'exists:warehouse_locations,id'],
            'return_date' => ['required', 'date'],
            'reason_code' => ['required', $this->referenceRule('supplier_return_reason')],
            'notes' => ['nullable', 'string'],
            'lines' => ['required', 'array'],
            'lines.*.quantity' => ['nullable', 'numeric', 'gte:0'],
            'lines.*.reason' => ['nullable', 'string'],
        ]);
        abort_unless(WarehouseLocation::whereKey($data['source_location_id'])
            ->where('warehouse_id', $receipt->warehouse_id)->exists(), 422, __('purchasing.location_warehouse_mismatch'));

        $supplierReturn = DB::transaction(function () use ($receipt, $data): SupplierReturn {
            $supplierReturn = SupplierReturn::create([
                'supplier_id' => $receipt->supplier_id,
                'goods_receipt_id' => $receipt->id,
                'warehouse_id' => $receipt->warehouse_id,
                'source_location_id' => $data['source_location_id'],
                'return_number' => $this->number('RF'),
                'return_date' => $data['return_date'],
                'status' => 'DRAFT',
                'reason_code' => $data['reason_code'],
                'notes' => $data['notes'] ?? null,
                'created_by' => auth()->id(),
            ]);
            foreach ($data['lines'] as $lineId => $values) {
                $quantity = (float) ($values['quantity'] ?? 0);
                if ($quantity <= 0) {
                    continue;
                }
                $receiptLine = $receipt->lines()->with('item')->findOrFail($lineId);
                $quantity = $this->packagingQuantity(
                    $receiptLine->item,
                    (string) $receiptLine->unit_id,
                    $quantity,
                    'lines',
                );
                $alreadyReturned = DB::table('supplier_return_lines')
                    ->join('supplier_returns', 'supplier_returns.id', '=', 'supplier_return_lines.supplier_return_id')
                    ->where('supplier_return_lines.goods_receipt_line_id', $receiptLine->id)
                    ->where('supplier_returns.status', 'POSTED')
                    ->sum('supplier_return_lines.quantity');
                if ($quantity > ((float) $receiptLine->accepted_quantity - (float) $alreadyReturned) + 0.0005) {
                    throw ValidationException::withMessages(['lines' => __('purchasing.return_exceeds_receipt')]);
                }
                $supplierReturn->lines()->create([
                    'goods_receipt_line_id' => $receiptLine->id,
                    'item_id' => $receiptLine->item_id,
                    'lot_id' => $receiptLine->lot_id,
                    'quantity' => $quantity,
                    'unit_id' => $receiptLine->unit_id,
                    'factor_to_base' => $receiptLine->factor_to_base,
                    'base_quantity' => $quantity * (float) $receiptLine->factor_to_base,
                    'unit_cost' => $receiptLine->unit_cost,
                    'reason' => $values['reason'] ?? null,
                ]);
            }
            if ($supplierReturn->lines()->doesntExist()) {
                throw ValidationException::withMessages(['lines' => __('purchasing.return_quantity_required')]);
            }
            $this->audit('purchasing.return.created', $supplierReturn, null, $supplierReturn->toArray());

            return $supplierReturn;
        });

        return back()->with('success', __('purchasing.return_created', ['number' => $supplierReturn->return_number]));
    }

    public function postReturn(SupplierReturn $supplierReturn, PurchasingWorkflowService $workflow): RedirectResponse
    {
        $workflow->postReturn($supplierReturn, (string) auth()->id());

        return redirect()->route('purchasing.receipts.show', $supplierReturn->goods_receipt_id)
            ->with('success', __('purchasing.return_posted'));
    }

    public function export(string $type): StreamedResponse
    {
        abort_unless(in_array($type, ['suppliers', 'orders'], true), 404);

        return response()->streamDownload(function () use ($type): void {
            $output = fopen('php://output', 'wb');
            fwrite($output, "\xEF\xBB\xBF");
            if ($type === 'suppliers') {
                $this->writeCsv($output, ['code', 'name', 'legal_name', 'registration_number', 'tax_identifier', 'statistical_identification_number', 'article_of_imposition_number', 'status', 'currency', 'payment_terms_days', 'lead_time_days', 'email', 'phone']);
                Supplier::orderBy('code')->chunk(500, function ($suppliers) use ($output): void {
                    foreach ($suppliers as $supplier) {
                        $this->writeCsv($output, $supplier->only(['code', 'name', 'legal_name', 'registration_number', 'tax_identifier', 'statistical_identification_number', 'article_of_imposition_number', 'status', 'currency_code', 'payment_terms_days', 'lead_time_days', 'email', 'phone']));
                    }
                });
            } else {
                $this->writeCsv($output, ['order_number', 'supplier', 'order_date', 'expected_date', 'currency', 'total', 'status']);
                PurchaseOrder::with('supplier')->orderBy('order_date')->chunk(500, function ($orders) use ($output): void {
                    foreach ($orders as $order) {
                        $this->writeCsv($output, [
                            $order->order_number, $order->supplier->code, $order->order_date->format('Y-m-d'),
                            $order->expected_date?->format('Y-m-d'), $order->currency_code, $order->total_amount, $order->status,
                        ]);
                    }
                });
            }
            fclose($output);
        }, 'purchasing-'.$type.'-'.now()->format('Ymd-His').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    private function packagingQuantity(Item $item, string $unitId, float $quantity, string $field): float
    {
        try {
            return app(ItemPackagingService::class)->normalizeQuantity($item, $unitId, $quantity);
        } catch (\DomainException $exception) {
            throw ValidationException::withMessages([$field => $exception->getMessage()]);
        }
    }

    private function packagingFactor(Item $item, string $unitId, mixed $fallback = null): float
    {
        if ($unitId === $item->base_unit_id) {
            return 1.0;
        }

        $factor = 0.0;
        $packagingGraphEnabled = Schema::hasTable('item_unit_conversions')
            && Schema::hasColumn('item_unit_conversions', 'parent_unit_id');
        if (Schema::hasTable('item_unit_conversions')) {
            $factor = (float) ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('unit_id', $unitId)
                ->where('active', true)
                ->when($packagingGraphEnabled, fn (Builder $query) => $query
                    ->where(fn (Builder $scope) => $scope->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
                    ->where(fn (Builder $scope) => $scope->whereNull('valid_to')->orWhereDate('valid_to', '>=', today())))
                ->value('factor_to_base');
        }

        if ($factor <= 0 && ! $packagingGraphEnabled) {
            $factor = (float) ($fallback ?? 0);
        }

        if ($factor <= 0) {
            throw ValidationException::withMessages(['factor_to_base' => __('purchasing.conversion_factor_required')]);
        }

        return $factor;
    }

    private function references(string $domain)
    {
        return DB::table('reference_values')->where('domain', $domain)->where('active', true)->orderBy('sort_order')->get();
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query
            ->where('domain', $domain)->where('active', true));
    }

    private function taxRateRule(string $companyId)
    {
        return Rule::exists('tax_rates', 'id')->where(fn ($query) => $query
            ->where('active', true)
            ->where(fn ($nested) => $nested->whereNull('company_id')->orWhere('company_id', $companyId)));
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

    private function writeCsv(mixed $output, array $values): void
    {
        fputcsv($output, array_map(function (mixed $value): string {
            $value = (string) ($value ?? '');

            return preg_match('/^[=+\-@]/', $value) ? "'".$value : $value;
        }, $values), ';', '"', '');
    }

    private function audit(string $event, object $model, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $old ? json_encode($old, JSON_THROW_ON_ERROR) : null,
            'new_values' => $new ? json_encode($new, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
