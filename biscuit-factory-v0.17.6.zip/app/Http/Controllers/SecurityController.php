<?php

namespace App\Http\Controllers;

use App\Services\Security\SecurityAuditService;
use App\Services\Security\SecurityPolicyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\View\View;

class SecurityController extends Controller
{
    public function editPassword(SecurityPolicyService $policy): View
    {
        return view('security.password', ['policy' => $policy->all()]);
    }

    public function updatePassword(
        Request $request,
        SecurityPolicyService $policy,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $data = $request->validate([
            'current_password' => ['required', 'current_password'],
            'password' => $policy->passwordRules(),
        ]);

        $user = $request->user();
        $user->forceFill([
            'password' => Hash::make($data['password']),
            'password_changed_at' => now(),
            'force_password_change' => false,
            'remember_token' => Str::random(60),
        ])->save();

        DB::table('sessions')
            ->where('user_id', $user->id)
            ->where('id', '!=', $request->session()->getId())
            ->delete();

        $audit->record('security.password.changed', $user, 'notice');

        return redirect()->route('dashboard')->with('status', __('security.password_updated'));
    }

    public function sessions(Request $request): View
    {
        $sessions = DB::table('sessions')
            ->where('user_id', $request->user()->id)
            ->orderByDesc('last_activity')
            ->get()
            ->map(function (object $session) use ($request): object {
                $session->current = hash_equals($request->session()->getId(), $session->id);
                $session->last_activity_at = now()->setTimestamp((int) $session->last_activity);

                return $session;
            });

        return view('security.sessions', compact('sessions'));
    }

    public function destroySession(Request $request, string $sessionId, SecurityAuditService $audit): RedirectResponse
    {
        abort_if(hash_equals($request->session()->getId(), $sessionId), 422, __('security.current_session_cannot_revoke'));

        $deleted = DB::table('sessions')
            ->where('id', $sessionId)
            ->where('user_id', $request->user()->id)
            ->delete();

        abort_unless($deleted === 1, 404);
        $audit->record('security.session.revoked', $request->user(), 'notice', ['session_id' => hash('sha256', $sessionId)]);

        return back()->with('status', __('security.session_revoked'));
    }

    public function destroyOtherSessions(Request $request, SecurityAuditService $audit): RedirectResponse
    {
        $count = DB::table('sessions')
            ->where('user_id', $request->user()->id)
            ->where('id', '!=', $request->session()->getId())
            ->delete();

        $audit->record('security.sessions.revoked_all', $request->user(), 'notice', ['count' => $count]);

        return back()->with('status', __('security.other_sessions_revoked', ['count' => $count]));
    }
}
