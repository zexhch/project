<?php

namespace App\Http\Controllers;

use App\Models\InventoryCount;
use App\Models\Warehouse;
use App\Services\Stock\InventoryService;
use App\Services\Stock\StockPostingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class InventoryController extends Controller
{
    public function index(): View
    {
        return view('inventory.index', ['inventories' => InventoryCount::with('warehouse')->withCount('lines')->latest('count_date')->paginate(20)]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(['warehouse_id' => ['required', 'exists:warehouses,id'], 'count_date' => ['required', 'date'], 'blind_count' => ['nullable', 'boolean'], 'notes' => ['nullable', 'string']]);
        $inventory = InventoryCount::create($data + [
            'inventory_number' => 'INV-'.now()->format('YmdHis').'-'.strtoupper(substr((string) \Illuminate\Support\Str::uuid(), 0, 4)),
            'status' => 'DRAFT', 'blind_count' => $request->boolean('blind_count'), 'created_by' => auth()->id(),
        ]);
        return redirect()->route('inventories.show', $inventory)->with('success', __('stock.inventory_created'));
    }

    public function show(InventoryCount $inventory): View
    {
        $inventory->load(['warehouse', 'lines.item.baseUnit', 'lines.lot', 'lines.location']);
        return view('inventory.show', compact('inventory'));
    }

    public function freeze(InventoryCount $inventory, InventoryService $service): RedirectResponse
    {
        $service->freeze($inventory);
        return back()->with('success', __('stock.inventory_frozen'));
    }

    public function updateCounts(Request $request, InventoryCount $inventory): RedirectResponse
    {
        abort_unless($inventory->status === 'COUNTING', 409);
        $data = $request->validate(['counts' => ['required', 'array'], 'counts.*' => ['required', 'numeric', 'gte:0']]);
        foreach ($data['counts'] as $lineId => $quantity) {
            $line = $inventory->lines()->findOrFail($lineId);
            $line->update(['counted_quantity' => $quantity, 'variance_quantity' => (float) $quantity - (float) $line->expected_quantity]);
        }
        return back()->with('success', __('stock.counts_saved'));
    }

    public function post(InventoryCount $inventory, InventoryService $service, StockPostingService $posting): RedirectResponse
    {
        $service->post($inventory, (string) auth()->id(), $posting);
        return back()->with('success', __('stock.inventory_posted'));
    }

    public static function warehouses()
    {
        return Warehouse::where('active', true)->orderBy('name')->get();
    }
}
