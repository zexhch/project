<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Currency;
use App\Models\Customer;
use App\Models\CustomerReturn;
use App\Models\DeliveryAllocation;
use App\Models\DeliveryNote;
use App\Models\Item;
use App\Models\ItemUnitConversion;
use App\Models\SalesOrder;
use App\Models\SalesOrderLine;
use App\Models\SalesPriceList;
use App\Models\SalesPriceListLine;
use App\Models\SalesQuotation;
use App\Models\SalesQuotationLine;
use App\Models\TaxRate;
use App\Models\Unit;
use App\Models\Warehouse;
use App\Models\WarehouseLocation;
use App\Services\Catalog\ItemPackagingService;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use App\Services\Sales\SalesPricingService;
use App\Services\Sales\SalesWorkflowService;
use App\Services\Sales\StockReservationService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SalesController extends Controller
{
    public function index(Request $request): View
    {
        $status = trim((string) $request->query('status'));
        $search = trim((string) $request->query('search'));
        $orders = SalesOrder::query()
            ->with(['customer', 'warehouse'])
            ->withCount('lines')
            ->when($status, fn (Builder $query) => $query->where('status', $status))
            ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                ->where('order_number', 'ilike', "%{$search}%")
                ->orWhere('customer_reference', 'ilike', "%{$search}%")
                ->orWhereHas('customer', fn (Builder $customer) => $customer
                    ->where('code', 'ilike', "%{$search}%")
                    ->orWhere('name', 'ilike', "%{$search}%"))))
            ->latest('order_date')
            ->paginate(25)
            ->withQueryString();

        $dashboard = Cache::remember('sales:dashboard:v173:'.app()->getLocale().':'.today()->toDateString(), now()->addSeconds(30), function (): array {
            $currency = Company::query()->where('active', true)->value('currency_code') ?: 'DZD';
            $trendRows = DB::table('sales_orders')
                ->selectRaw('order_date::date AS day, COALESCE(SUM(total_amount), 0) AS total')
                ->whereBetween('order_date', [today()->subDays(6), today()])
                ->whereNotIn('status', ['CANCELLED'])
                ->groupByRaw('order_date::date')->pluck('total', 'day');
            $trendLabels = [];
            $trendValues = [];
            for ($day = today()->subDays(6); $day->lte(today()); $day->addDay()) {
                $trendLabels[] = $day->translatedFormat('D d');
                $trendValues[] = (float) ($trendRows[$day->toDateString()] ?? 0);
            }
            $statusRows = DB::table('sales_orders')->selectRaw('status AS label, COUNT(*) AS total')->groupBy('status')->orderByDesc('total')->get();
            $customers = DB::table('sales_orders')
                ->join('customers', 'customers.id', '=', 'sales_orders.customer_id')
                ->whereNotIn('sales_orders.status', ['CANCELLED'])
                ->selectRaw('customers.name AS label, COALESCE(SUM(sales_orders.total_amount), 0) AS total')
                ->groupBy('customers.id', 'customers.name')->orderByDesc('total')->limit(6)->get();

            return [
                'currency' => $currency,
                'metrics' => [
                    'active_customers' => Customer::where('active', true)->whereIn('status', ['APPROVED', 'ACTIVE'])->count(),
                    'pending_orders' => SalesOrder::whereIn('status', ['SUBMITTED', 'CONFIRMED', 'PARTIALLY_RESERVED'])->count(),
                    'ready_orders' => SalesOrder::where('status', 'RESERVED')->count(),
                    'late_orders' => SalesOrder::whereIn('status', ['CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED', 'PARTIALLY_DELIVERED'])->whereDate('requested_delivery_date', '<', today())->count(),
                    'picked_deliveries' => DeliveryNote::where('status', 'PICKED')->count(),
                    'order_value_today' => (float) DB::table('sales_orders')->whereDate('order_date', today())->whereNotIn('status', ['CANCELLED'])->sum('total_amount'),
                    'deliveries_today' => DB::table('delivery_notes')->whereDate('delivered_at', today())->count(),
                    'invoiced_today' => (float) DB::table('customer_invoices')->whereDate('invoice_date', today())->whereNotIn('status', ['CANCELLED'])->sum('total_amount'),
                    'received_today' => (float) DB::table('customer_payments')->whereDate('payment_date', today())->where('status', 'POSTED')->sum('amount'),
                    'overdue_count' => DB::table('customer_invoices')->where('status', 'OVERDUE')->count(),
                    'overdue_amount' => (float) DB::table('customer_invoices')->where('status', 'OVERDUE')->sum('balance_amount'),
                ],
                'trend_chart' => ['labels' => $trendLabels, 'values' => $trendValues],
                'status_chart' => ['labels' => $statusRows->pluck('label')->all(), 'values' => $statusRows->pluck('total')->map(fn ($value) => (int) $value)->all()],
                'customer_chart' => ['labels' => $customers->pluck('label')->all(), 'values' => $customers->pluck('total')->map(fn ($value) => (float) $value)->all()],
            ];
        });

        return view('sales.index', [
            'orders' => $orders,
            'status' => $status,
            'search' => $search,
            'statuses' => $this->references('sales_order_status'),
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'customers' => Customer::where('active', true)->whereIn('status', ['APPROVED', 'ACTIVE'])->orderBy('name')->get(),
            'warehouses' => Warehouse::with('site')->where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'metrics' => $dashboard['metrics'],
            'dashboard' => $dashboard,
        ]);
    }

    public function storeOrder(Request $request, DocumentNumberService $numbers): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'customer_id' => ['required', 'exists:customers,id'],
            'warehouse_id' => ['required', 'exists:warehouses,id'],
            'order_date' => ['required', 'date'],
            'requested_delivery_date' => ['nullable', 'date', 'after_or_equal:order_date'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'exchange_rate' => ['required', 'numeric', 'gt:0'],
            'tax_included' => ['nullable', 'boolean'],
            'customer_reference' => ['nullable', 'string', 'max:120'],
            'delivery_address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);
        $customer = Customer::whereKey($data['customer_id'])->where('company_id', $data['company_id'])->firstOrFail();
        $warehouse = Warehouse::with('site')->findOrFail($data['warehouse_id']);
        abort_unless($warehouse->site->company_id === $data['company_id'], 422, __('sales.warehouse_company_mismatch'));
        $order = SalesOrder::create($data + [
            'site_id' => $warehouse->site_id,
            'order_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::SALES_ORDER, $data['order_date']),
            'tax_included' => $request->boolean('tax_included'),
            'status' => 'DRAFT',
            'payment_terms_days' => $customer->payment_terms_days,
            'delivery_address' => $data['delivery_address'] ?? $customer->shipping_address,
            'created_by' => auth()->id(),
        ]);
        $this->audit('sales.order.created', $order, null, $order->toArray());

        return redirect()->route('sales.orders.show', $order)->with('success', __('sales.order_created'));
    }

    public function showOrder(SalesOrder $order): View
    {
        $order->load([
            'company', 'warehouse.locations', 'customer.contacts', 'quotation',
            'lines.item.baseUnit', 'lines.unit', 'lines.taxRate',
            'lines.reservations.lot', 'lines.reservations.location',
            'deliveries.lines.allocations.lot',
        ]);

        return view('sales.orders.show', [
            'order' => $order,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->whereIn('item_type', ['FINISHED_GOOD', 'SEMI_FINISHED'])->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'taxRates' => $this->taxRates($order->company_id),
        ]);
    }

    public function addOrderLine(
        Request $request,
        SalesOrder $order,
        SalesPricingService $pricing,
        SalesWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($order->status === 'DRAFT', 409, __('sales.order_not_draft'));
        $data = $this->validateCommercialLine($request, $order->company_id);
        $values = $this->commercialLineValues(
            $data,
            $order->customer()->firstOrFail(),
            $order->currency_code,
            $order->tax_included,
            $order->order_date,
            $pricing,
            'ordered_quantity',
        );
        $line = $order->lines()->create($values + ['status' => 'OPEN']);
        $workflow->recalculateOrder($order);
        $this->audit('sales.order.line_created', $line, null, $line->toArray());

        return back()->with('success', __('sales.line_added'));
    }

    public function removeOrderLine(
        SalesOrder $order,
        SalesOrderLine $line,
        SalesWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($order->status === 'DRAFT', 409, __('sales.order_not_draft'));
        abort_unless($line->sales_order_id === $order->id, 404);
        $oldValues = $line->toArray();
        $line->delete();
        $workflow->recalculateOrder($order);
        $this->audit('sales.order.line_deleted', $line, $oldValues, null);

        return back()->with('success', __('sales.line_removed'));
    }

    public function submitOrder(SalesOrder $order, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->submitOrder($order, (string) auth()->id());

        return back()->with('success', __('sales.order_submitted'));
    }

    public function confirmOrder(SalesOrder $order, SalesWorkflowService $workflow): RedirectResponse
    {
        $confirmed = $workflow->confirmOrder($order, (string) auth()->id());
        $message = $confirmed->status === 'RESERVED'
            ? __('sales.order_confirmed_and_reserved')
            : __('sales.order_confirmed_partial_stock');

        return back()->with('success', $message);
    }

    public function reserveOrder(SalesOrder $order, StockReservationService $reservations): RedirectResponse
    {
        $reserved = $reservations->reserveOrder($order, (string) auth()->id());

        return back()->with(
            $reserved->status === 'RESERVED' ? 'success' : 'warning',
            $reserved->status === 'RESERVED' ? __('sales.stock_fully_reserved') : __('sales.stock_partially_reserved'),
        );
    }

    public function cancelOrder(Request $request, SalesOrder $order, SalesWorkflowService $workflow): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:2000']]);
        $workflow->cancelOrder($order, (string) auth()->id(), $data['reason']);

        return back()->with('success', __('sales.order_cancelled'));
    }

    public function storeDelivery(Request $request, SalesOrder $order, SalesWorkflowService $workflow): RedirectResponse
    {
        $data = $request->validate([
            'delivered_at' => ['required', 'date'],
            'carrier' => ['nullable', 'string', 'max:255'],
            'vehicle_registration' => ['nullable', 'string', 'max:80'],
            'driver_name' => ['nullable', 'string', 'max:255'],
            'customer_reference' => ['nullable', 'string', 'max:120'],
            'delivery_address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'lines' => ['required', 'array'],
            'lines.*' => ['nullable', 'numeric', 'gte:0'],
        ]);
        $order->loadMissing('lines.item');
        foreach ($data['lines'] as $lineId => $quantity) {
            $line = $order->lines->firstWhere('id', (string) $lineId);
            if ($line) {
                $data['lines'][$lineId] = $this->packagingQuantity(
                    $line->item,
                    (string) $line->unit_id,
                    (float) ($quantity ?? 0),
                    'lines',
                );
            }
        }
        $delivery = $workflow->createDelivery(
            $order,
            $data['lines'],
            collect($data)->except('lines')->all(),
            (string) auth()->id(),
        );

        return redirect()->route('sales.deliveries.show', $delivery)->with('success', __('sales.delivery_prepared'));
    }

    public function quotations(Request $request): View
    {
        $search = trim((string) $request->query('search'));

        return view('sales.quotations.index', [
            'quotations' => SalesQuotation::query()->with(['customer', 'warehouse'])->withCount('lines')
                ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                    ->where('quotation_number', 'ilike', "%{$search}%")
                    ->orWhereHas('customer', fn (Builder $customer) => $customer->where('name', 'ilike', "%{$search}%"))))
                ->latest('quotation_date')->paginate(25)->withQueryString(),
            'search' => $search,
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'customers' => Customer::where('active', true)->whereIn('status', ['APPROVED', 'ACTIVE'])->orderBy('name')->get(),
            'warehouses' => Warehouse::with('site')->where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function storeQuotation(Request $request, DocumentNumberService $numbers): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'customer_id' => ['required', 'exists:customers,id'],
            'warehouse_id' => ['required', 'exists:warehouses,id'],
            'quotation_date' => ['required', 'date'],
            'valid_until' => ['nullable', 'date', 'after_or_equal:quotation_date'],
            'requested_delivery_date' => ['nullable', 'date', 'after_or_equal:quotation_date'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'exchange_rate' => ['required', 'numeric', 'gt:0'],
            'tax_included' => ['nullable', 'boolean'],
            'delivery_address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);
        $customer = Customer::whereKey($data['customer_id'])->where('company_id', $data['company_id'])->firstOrFail();
        $warehouse = Warehouse::with('site')->findOrFail($data['warehouse_id']);
        abort_unless($warehouse->site->company_id === $data['company_id'], 422);
        $quotation = SalesQuotation::create($data + [
            'site_id' => $warehouse->site_id,
            'quotation_number' => $numbers->next($data['company_id'], FinancialDocumentCatalog::SALES_QUOTATION, $data['quotation_date']),
            'tax_included' => $request->boolean('tax_included'),
            'status' => 'DRAFT',
            'delivery_address' => $data['delivery_address'] ?? $customer->shipping_address,
            'created_by' => auth()->id(),
        ]);
        $this->audit('sales.quotation.created', $quotation, null, $quotation->toArray());

        return redirect()->route('sales.quotations.show', $quotation)->with('success', __('sales.quotation_created'));
    }

    public function showQuotation(SalesQuotation $quotation): View
    {
        $quotation->load(['company', 'warehouse', 'customer', 'lines.item.baseUnit', 'lines.unit', 'lines.taxRate', 'salesOrder']);

        return view('sales.quotations.show', [
            'quotation' => $quotation,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->whereIn('item_type', ['FINISHED_GOOD', 'SEMI_FINISHED'])->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'taxRates' => $this->taxRates($quotation->company_id),
        ]);
    }

    public function addQuotationLine(
        Request $request,
        SalesQuotation $quotation,
        SalesPricingService $pricing,
        SalesWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($quotation->status === 'DRAFT', 409, __('sales.quotation_not_draft'));
        $data = $this->validateCommercialLine($request, $quotation->company_id, 'quantity');
        $values = $this->commercialLineValues(
            $data,
            $quotation->customer()->firstOrFail(),
            $quotation->currency_code,
            $quotation->tax_included,
            $quotation->quotation_date,
            $pricing,
            'quantity',
        );
        $line = $quotation->lines()->create($values);
        $workflow->recalculateQuotation($quotation);
        $this->audit('sales.quotation.line_created', $line, null, $line->toArray());

        return back()->with('success', __('sales.line_added'));
    }

    public function removeQuotationLine(
        SalesQuotation $quotation,
        SalesQuotationLine $line,
        SalesWorkflowService $workflow,
    ): RedirectResponse {
        abort_unless($quotation->status === 'DRAFT', 409, __('sales.quotation_not_draft'));
        abort_unless($line->sales_quotation_id === $quotation->id, 404);
        $oldValues = $line->toArray();
        $line->delete();
        $workflow->recalculateQuotation($quotation);
        $this->audit('sales.quotation.line_deleted', $line, $oldValues, null);

        return back()->with('success', __('sales.line_removed'));
    }

    public function sendQuotation(SalesQuotation $quotation, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->sendQuotation($quotation, (string) auth()->id());

        return back()->with('success', __('sales.quotation_sent'));
    }

    public function acceptQuotation(SalesQuotation $quotation, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->acceptQuotation($quotation, (string) auth()->id());

        return back()->with('success', __('sales.quotation_accepted'));
    }

    public function convertQuotation(SalesQuotation $quotation, SalesWorkflowService $workflow): RedirectResponse
    {
        $order = $workflow->convertQuotation($quotation, (string) auth()->id());

        return redirect()->route('sales.orders.show', $order)->with('success', __('sales.quotation_converted'));
    }

    public function customers(Request $request): View
    {
        $search = trim((string) $request->query('search'));

        return view('sales.customers.index', [
            'customers' => Customer::query()->with('company')->withCount('salesOrders')
                ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                    ->where('code', 'ilike', "%{$search}%")
                    ->orWhere('name', 'ilike', "%{$search}%")
                    ->orWhere('legal_name', 'ilike', "%{$search}%")
                    ->orWhere('registration_number', 'ilike', "%{$search}%")
                    ->orWhere('tax_identifier', 'ilike', "%{$search}%")
                    ->orWhere('statistical_identification_number', 'ilike', "%{$search}%")
                    ->orWhere('article_of_imposition_number', 'ilike', "%{$search}%")))
                ->orderBy('name')->paginate(25)->withQueryString(),
            'search' => $search,
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'customerGroups' => $this->references('customer_group'),
            'salesChannels' => $this->references('sales_channel'),
            'countries' => $this->references('country'),
        ]);
    }

    public function storeCustomer(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'code' => ['required', 'string', 'max:80', Rule::unique('customers')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'legal_name' => ['nullable', 'string', 'max:255'],
            'customer_group_code' => ['nullable', $this->referenceRule('customer_group')],
            'sales_channel_code' => ['nullable', $this->referenceRule('sales_channel')],
            'tax_identifier' => ['nullable', 'string', 'max:120'],
            'registration_number' => ['nullable', 'string', 'max:120'],
            'statistical_identification_number' => ['nullable', 'string', 'max:120'],
            'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            'country_code' => ['required', $this->referenceRule('country')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'payment_terms_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'credit_limit' => ['required', 'numeric', 'gte:0'],
            'tax_exempt' => ['nullable', 'boolean'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'billing_address' => ['nullable', 'string'],
            'shipping_address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);
        $customer = Customer::create($data + [
            'tax_exempt' => $request->boolean('tax_exempt'), 'status' => 'PROSPECT', 'active' => true,
        ]);
        $this->audit('sales.customer.created', $customer, null, $customer->toArray());

        return redirect()->route('sales.customers.show', $customer)->with('success', __('sales.customer_created'));
    }

    public function showCustomer(Customer $customer): View
    {
        $customer->load(['company', 'contacts', 'priceLists.lines', 'quotations', 'salesOrders', 'deliveries']);

        return view('sales.customers.show', [
            'customer' => $customer,
            'statuses' => $this->references('customer_status'),
            'customerGroups' => $this->references('customer_group'),
            'salesChannels' => $this->references('sales_channel'),
            'countries' => $this->references('country'),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
        ]);
    }

    public function updateCustomer(Request $request, Customer $customer): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', Rule::unique('customers')->where('company_id', $customer->company_id)->ignore($customer->id)],
            'name' => ['required', 'string', 'max:255'],
            'legal_name' => ['nullable', 'string', 'max:255'],
            'customer_group_code' => ['nullable', $this->referenceRule('customer_group')],
            'sales_channel_code' => ['nullable', $this->referenceRule('sales_channel')],
            'tax_identifier' => ['nullable', 'string', 'max:120'],
            'registration_number' => ['nullable', 'string', 'max:120'],
            'statistical_identification_number' => ['nullable', 'string', 'max:120'],
            'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            'country_code' => ['required', $this->referenceRule('country')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'payment_terms_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'credit_limit' => ['required', 'numeric', 'gte:0'],
            'tax_exempt' => ['nullable', 'boolean'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'billing_address' => ['nullable', 'string'],
            'shipping_address' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);
        $old = $customer->toArray();
        $customer->update($data + ['tax_exempt' => $request->boolean('tax_exempt')]);
        $this->audit('sales.customer.updated', $customer, $old, $customer->fresh()->toArray());

        return back()->with('success', __('sales.customer_updated'));
    }

    public function updateCustomerStatus(Request $request, Customer $customer): RedirectResponse
    {
        $data = $request->validate(['status' => ['required', $this->referenceRule('customer_status')]]);
        $old = $customer->status;
        $customer->update(['status' => $data['status'], 'active' => $data['status'] !== 'BLOCKED']);
        $this->audit('sales.customer.status_changed', $customer, ['status' => $old], ['status' => $data['status']]);

        return back()->with('success', __('sales.customer_status_updated'));
    }

    public function storeCustomerContact(Request $request, Customer $customer): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'job_title' => ['nullable', 'string', 'max:255'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:80'],
            'mobile' => ['nullable', 'string', 'max:80'],
            'is_primary' => ['nullable', 'boolean'],
        ]);
        if ($request->boolean('is_primary')) {
            $customer->contacts()->update(['is_primary' => false]);
        }
        $contact = $customer->contacts()->create($data + [
            'is_primary' => $request->boolean('is_primary'), 'active' => true,
        ]);
        $this->audit('sales.customer.contact_created', $contact, null, $contact->toArray());

        return back()->with('success', __('sales.contact_added'));
    }

    public function priceLists(): View
    {
        return view('sales.price-lists.index', [
            'priceLists' => SalesPriceList::with(['customer', 'company'])->withCount('lines')
                ->orderByDesc('valid_from')->paginate(25),
            'companies' => Company::where('active', true)->orderBy('name')->get(),
            'customers' => Customer::where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::where('active', true)->orderBy('code')->get(),
            'customerGroups' => $this->references('customer_group'),
            'salesChannels' => $this->references('sales_channel'),
            'priceTypes' => $this->references('sales_price_type'),
        ]);
    }

    public function storePriceList(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'customer_id' => ['nullable', 'exists:customers,id'],
            'customer_group_code' => ['nullable', $this->referenceRule('customer_group')],
            'sales_channel_code' => ['nullable', $this->referenceRule('sales_channel')],
            'code' => ['required', 'string', 'max:80', Rule::unique('sales_price_lists')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'price_type' => ['required', $this->referenceRule('sales_price_type')],
            'currency_code' => ['required', 'exists:currencies,code'],
            'tax_included' => ['nullable', 'boolean'],
            'priority' => ['required', 'integer', 'min:1', 'max:9999'],
            'valid_from' => ['required', 'date'],
            'valid_to' => ['nullable', 'date', 'after_or_equal:valid_from'],
        ]);
        $scopeCount = collect(['customer_id', 'customer_group_code', 'sales_channel_code'])
            ->filter(fn (string $key): bool => filled($data[$key] ?? null))
            ->count();
        if ($scopeCount > 1) {
            throw ValidationException::withMessages(['scope' => __('sales.single_price_scope')]);
        }
        if ($data['customer_id'] ?? null) {
            abort_unless(Customer::whereKey($data['customer_id'])->where('company_id', $data['company_id'])->exists(), 422);
        }
        $priceList = SalesPriceList::create($data + [
            'tax_included' => $request->boolean('tax_included'), 'status' => 'DRAFT', 'created_by' => auth()->id(),
        ]);
        $this->audit('sales.price_list.created', $priceList, null, $priceList->toArray());

        return redirect()->route('sales.price-lists.show', $priceList)->with('success', __('sales.price_list_created'));
    }

    public function showPriceList(SalesPriceList $priceList): View
    {
        $priceList->load(['company', 'customer', 'lines.item.baseUnit', 'lines.unit', 'lines.taxRate']);

        return view('sales.price-lists.show', [
            'priceList' => $priceList,
            'items' => Item::with(['baseUnit', 'unitConversions.unit'])->where('active', true)->whereIn('item_type', ['FINISHED_GOOD', 'SEMI_FINISHED'])->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'taxRates' => $this->taxRates($priceList->company_id),
            'customerGroups' => $this->references('customer_group'),
            'salesChannels' => $this->references('sales_channel'),
        ]);
    }

    public function addPriceListLine(Request $request, SalesPriceList $priceList): RedirectResponse
    {
        abort_unless($priceList->status === 'DRAFT', 409, __('sales.price_list_not_draft'));
        $data = $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            'unit_id' => ['required', 'exists:units,id'],
            'factor_to_base' => ['nullable', 'numeric', 'gt:0'],
            'minimum_quantity' => ['required', 'numeric', 'gte:0'],
            'unit_price' => ['required', 'numeric', 'gte:0'],
            'discount_percentage' => ['required', 'numeric', 'between:0,100'],
            'tax_rate_id' => ['nullable', $this->taxRateRule($priceList->company_id)],
            'target_margin_percentage' => ['nullable', 'numeric', 'between:-100,1000'],
        ]);
        $item = Item::with('baseUnit')->findOrFail($data['item_id']);
        $data['minimum_quantity'] = $this->packagingQuantity(
            $item,
            (string) $data['unit_id'],
            (float) $data['minimum_quantity'],
            'minimum_quantity',
        );
        $exists = $priceList->lines()->where('item_id', $data['item_id'])->where('unit_id', $data['unit_id'])
            ->where('minimum_quantity', $data['minimum_quantity'])->exists();
        throw_if($exists, ValidationException::withMessages(['minimum_quantity' => __('sales.price_tier_exists')]));
        $data['factor_to_base'] = $this->packagingFactor($item, (string) $data['unit_id'], $data['factor_to_base'] ?? null);
        $line = $priceList->lines()->create($data);
        $this->audit('sales.price_list.line_created', $line, null, $line->toArray());

        return back()->with('success', __('sales.price_line_added'));
    }

    public function removePriceListLine(SalesPriceList $priceList, SalesPriceListLine $line): RedirectResponse
    {
        abort_unless($priceList->status === 'DRAFT', 409, __('sales.price_list_not_draft'));
        abort_unless($line->sales_price_list_id === $priceList->id, 404);
        $oldValues = $line->toArray();
        $line->delete();
        $this->audit('sales.price_list.line_deleted', $line, $oldValues, null);

        return back()->with('success', __('sales.line_removed'));
    }

    public function approvePriceList(SalesPriceList $priceList, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->approvePriceList($priceList, (string) auth()->id());

        return back()->with('success', __('sales.price_list_approved'));
    }

    public function deliveries(Request $request): View
    {
        $search = trim((string) $request->query('search'));

        return view('sales.deliveries.index', [
            'deliveries' => DeliveryNote::query()->with(['customer', 'salesOrder', 'warehouse'])->withCount('lines')
                ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                    ->where('delivery_number', 'ilike', "%{$search}%")
                    ->orWhereHas('customer', fn (Builder $customer) => $customer->where('name', 'ilike', "%{$search}%"))))
                ->latest('delivered_at')->paginate(25)->withQueryString(),
            'search' => $search,
        ]);
    }

    public function showDelivery(DeliveryNote $delivery): View
    {
        $delivery->load([
            'salesOrder', 'customer', 'warehouse.locations', 'stockMovement',
            'lines.item.baseUnit', 'lines.unit', 'lines.allocations.lot', 'lines.allocations.sourceLocation',
            'returns.lines', 'customerInvoice',
        ]);

        return view('sales.deliveries.show', [
            'delivery' => $delivery,
            'quarantineLocations' => $delivery->warehouse->locations->where('active', true)->where('quarantine', true),
            'returnReasons' => $this->references('customer_return_reason'),
            'returnConditions' => $this->references('customer_return_condition'),
        ]);
    }

    public function postDelivery(DeliveryNote $delivery, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->postDelivery($delivery, (string) auth()->id());

        return back()->with('success', __('sales.delivery_posted'));
    }

    public function storeReturn(Request $request, DeliveryNote $delivery): RedirectResponse
    {
        abort_unless($delivery->status === 'POSTED', 409, __('sales.delivery_not_posted'));
        $data = $request->validate([
            'destination_location_id' => ['required', 'exists:warehouse_locations,id'],
            'return_date' => ['required', 'date'],
            'reason_code' => ['required', $this->referenceRule('customer_return_reason')],
            'notes' => ['nullable', 'string'],
            'allocations' => ['required', 'array'],
            'allocations.*.quantity' => ['nullable', 'numeric', 'gte:0'],
            'allocations.*.condition_code' => ['nullable', $this->referenceRule('customer_return_condition')],
            'allocations.*.reason' => ['nullable', 'string'],
        ]);
        $location = WarehouseLocation::findOrFail($data['destination_location_id']);
        abort_unless($location->warehouse_id === $delivery->warehouse_id && $location->quarantine, 422, __('sales.return_requires_quarantine'));

        $customerReturn = DB::transaction(function () use ($delivery, $data): CustomerReturn {
            $customerReturn = CustomerReturn::create([
                'delivery_note_id' => $delivery->id,
                'sales_order_id' => $delivery->sales_order_id,
                'customer_id' => $delivery->customer_id,
                'warehouse_id' => $delivery->warehouse_id,
                'destination_location_id' => $data['destination_location_id'],
                'return_number' => $this->number('RC'),
                'return_date' => $data['return_date'],
                'status' => 'DRAFT',
                'reason_code' => $data['reason_code'],
                'notes' => $data['notes'] ?? null,
                'created_by' => auth()->id(),
            ]);
            foreach ($data['allocations'] as $allocationId => $input) {
                $quantity = (float) ($input['quantity'] ?? 0);
                if ($quantity <= 0) {
                    continue;
                }
                $allocation = DeliveryAllocation::with('deliveryNoteLine.salesOrderLine.item')->findOrFail($allocationId);
                abort_unless($allocation->deliveryNoteLine->delivery_note_id === $delivery->id, 422);
                $item = $allocation->deliveryNoteLine->salesOrderLine->item;
                $quantity = $this->packagingQuantity($item, (string) $item->base_unit_id, $quantity, 'allocations');
                $customerReturn->lines()->create([
                    'delivery_note_line_id' => $allocation->delivery_note_line_id,
                    'delivery_allocation_id' => $allocation->id,
                    'item_id' => $allocation->item_id,
                    'quantity' => $quantity,
                    'base_quantity' => $quantity,
                    'unit_id' => $item->base_unit_id,
                    'factor_to_base' => 1,
                    'unit_cost' => $allocation->unit_cost,
                    'condition_code' => $input['condition_code'] ?? 'UNOPENED',
                    'reason' => $input['reason'] ?? null,
                ]);
            }
            if (! $customerReturn->lines()->exists()) {
                throw ValidationException::withMessages(['allocations' => __('sales.return_line_required')]);
            }
            $this->audit('sales.return.created', $customerReturn, null, $customerReturn->toArray());

            return $customerReturn;
        }, 3);

        return back()->with('success', __('sales.return_created', ['number' => $customerReturn->return_number]));
    }

    public function postReturn(CustomerReturn $customerReturn, SalesWorkflowService $workflow): RedirectResponse
    {
        $workflow->postCustomerReturn($customerReturn, (string) auth()->id());

        return back()->with('success', __('sales.return_posted'));
    }

    public function export(string $type): StreamedResponse
    {
        $filename = 'sales-'.$type.'-'.now()->format('Ymd-His').'.csv';

        return response()->streamDownload(function () use ($type): void {
            $stream = fopen('php://output', 'wb');
            fwrite($stream, "\xEF\xBB\xBF");
            if ($type === 'customers') {
                fputcsv($stream, ['Code', 'Client', 'Raison sociale', 'RC', 'NIF', 'NIS', 'AI', 'Groupe', 'Canal', 'Devise', 'Statut'], ';');
                Customer::with('company')->orderBy('code')->chunk(500, function ($customers) use ($stream): void {
                    foreach ($customers as $customer) {
                        fputcsv($stream, array_map([$this, 'csvSafe'], [
                            $customer->code, $customer->name, $customer->legal_name,
                            $customer->registration_number, $customer->tax_identifier,
                            $customer->statistical_identification_number, $customer->article_of_imposition_number,
                            $customer->customer_group_code, $customer->sales_channel_code,
                            $customer->currency_code, $customer->status,
                        ]), ';');
                    }
                });
            } else {
                fputcsv($stream, ['Commande', 'Date', 'Client', 'Devise', 'Total', 'Statut'], ';');
                SalesOrder::with('customer')->orderBy('order_number')->chunk(500, function ($orders) use ($stream): void {
                    foreach ($orders as $order) {
                        fputcsv($stream, array_map([$this, 'csvSafe'], [
                            $order->order_number, $order->order_date->format('Y-m-d'), $order->customer->name,
                            $order->currency_code, $order->total_amount, $order->status,
                        ]), ';');
                    }
                });
            }
            fclose($stream);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    private function validateCommercialLine(Request $request, string $companyId, string $quantityKey = 'ordered_quantity'): array
    {
        return $request->validate([
            'item_id' => ['required', 'exists:items,id'],
            $quantityKey => ['required', 'numeric', 'gt:0'],
            'unit_id' => ['required', 'exists:units,id'],
            'factor_to_base' => ['nullable', 'numeric', 'gt:0'],
            'unit_price' => ['nullable', 'numeric', 'gte:0'],
            'discount_percentage' => ['nullable', 'numeric', 'between:0,100'],
            'tax_rate_id' => ['nullable', $this->taxRateRule($companyId)],
            'notes' => ['nullable', 'string'],
        ]);
    }

    private function commercialLineValues(
        array $data,
        Customer $customer,
        string $currencyCode,
        bool $taxIncluded,
        $date,
        SalesPricingService $pricing,
        string $quantityKey,
    ): array {
        $item = Item::with('baseUnit')->findOrFail($data['item_id']);
        $quantity = $this->packagingQuantity(
            $item,
            (string) $data['unit_id'],
            (float) $data[$quantityKey],
            $quantityKey,
        );
        $resolved = null;
        if (($data['unit_price'] ?? null) === null) {
            $resolved = $pricing->resolve($customer, $item, $quantity, $data['unit_id'], $date);
            if (! $resolved) {
                throw ValidationException::withMessages(['unit_price' => __('sales.no_applicable_price')]);
            }
            if ($resolved['currency_code'] !== $currencyCode) {
                throw ValidationException::withMessages(['currency_code' => __('sales.price_currency_mismatch')]);
            }
            if ($resolved['tax_included'] !== $taxIncluded) {
                throw ValidationException::withMessages(['tax_included' => __('sales.price_tax_mode_mismatch')]);
            }
        }
        $factor = $this->packagingFactor(
            $item,
            (string) $data['unit_id'],
            $resolved['factor_to_base'] ?? ($data['factor_to_base'] ?? null),
        );
        if ($factor <= 0) {
            throw ValidationException::withMessages(['factor_to_base' => __('sales.conversion_factor_required')]);
        }
        $unitPrice = (float) ($data['unit_price'] ?? $resolved['unit_price']);
        $discount = (float) ($data['discount_percentage'] ?? $resolved['discount_percentage'] ?? 0);
        $taxRateId = $data['tax_rate_id'] ?? $resolved['tax_rate_id'] ?? null;
        $taxRate = $taxRateId ? (float) TaxRate::findOrFail($taxRateId)->rate : 0;
        $amounts = $pricing->calculate($quantity, $unitPrice, $discount, $taxRate, $taxIncluded);

        return [
            'item_id' => $item->id,
            'description' => $item->name,
            $quantityKey => $quantity,
            'unit_id' => $data['unit_id'],
            'factor_to_base' => $factor,
            'unit_price' => $unitPrice,
            'discount_percentage' => $discount,
            'tax_rate_id' => $taxRateId,
            'net_unit_price' => $amounts['net_unit_price'],
            'line_subtotal' => $amounts['line_subtotal'],
            'tax_amount' => $amounts['tax_amount'],
            'line_total' => $amounts['line_total'],
            'notes' => $data['notes'] ?? null,
        ];
    }

    private function packagingQuantity(Item $item, string $unitId, float $quantity, string $field): float
    {
        try {
            return app(ItemPackagingService::class)->normalizeQuantity($item, $unitId, $quantity);
        } catch (\DomainException $exception) {
            throw ValidationException::withMessages([$field => $exception->getMessage()]);
        }
    }

    private function packagingFactor(Item $item, string $unitId, mixed $fallback = null): float
    {
        if ($unitId === $item->base_unit_id) {
            return 1.0;
        }

        $factor = 0.0;
        $packagingGraphEnabled = Schema::hasTable('item_unit_conversions')
            && Schema::hasColumn('item_unit_conversions', 'parent_unit_id');
        if (Schema::hasTable('item_unit_conversions')) {
            $factor = (float) ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('unit_id', $unitId)
                ->where('active', true)
                ->when($packagingGraphEnabled, fn (Builder $query) => $query
                    ->where(fn (Builder $scope) => $scope->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
                    ->where(fn (Builder $scope) => $scope->whereNull('valid_to')->orWhereDate('valid_to', '>=', today())))
                ->value('factor_to_base');
        }

        if ($factor <= 0 && ! $packagingGraphEnabled) {
            $factor = (float) ($fallback ?? 0);
        }

        if ($factor <= 0) {
            throw ValidationException::withMessages(['factor_to_base' => __('sales.conversion_factor_required')]);
        }

        return $factor;
    }

    private function taxRates(string $companyId)
    {
        return TaxRate::where(fn (Builder $query) => $query->whereNull('company_id')->orWhere('company_id', $companyId))
            ->where('active', true)->orderBy('code')->get();
    }

    private function taxRateRule(string $companyId)
    {
        return Rule::exists('tax_rates', 'id')->where(fn ($query) => $query
            ->where('active', true)->where(fn ($scope) => $scope->whereNull('company_id')->orWhere('company_id', $companyId)));
    }

    private function references(string $domain)
    {
        return DB::table('reference_values')->where('domain', $domain)->where('active', true)->orderBy('sort_order')->get();
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query
            ->where('domain', $domain)->where('active', true));
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

    private function audit(string $event, object $model, ?array $oldValues, ?array $newValues): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(), 'user_id' => auth()->id(), 'event' => $event,
            'auditable_type' => $model::class, 'auditable_id' => $model->id,
            'old_values' => $oldValues ? json_encode($oldValues, JSON_THROW_ON_ERROR) : null,
            'new_values' => $newValues ? json_encode($newValues, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()?->ip(), 'user_agent' => request()?->userAgent(), 'created_at' => now(),
        ]);
    }

    public function csvSafe(mixed $value): string
    {
        $text = (string) $value;

        return preg_match('/^[=+\-@]/', $text) ? "'".$text : $text;
    }
}
