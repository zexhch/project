<?php

namespace App\Http\Controllers;

use App\Models\CustomerCreditNote;
use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\DeliveryNote;
use App\Models\FinancialAccount;
use App\Models\GoodsReceipt;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\SupplierCreditNote;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use App\Services\Finance\Documents\MoneyToWordsService;
use App\Services\Finance\Governance\DocumentRevisionService;
use App\Services\Finance\Governance\DocumentTemplateService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class FinancialDocumentController extends Controller
{
    public function salesQuotation(SalesQuotation $quotation, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $quotation->load(['company', 'site', 'customer', 'warehouse', 'lines.item', 'lines.unit', 'lines.taxRate']);

        return $this->render($quotation, FinancialDocumentCatalog::SALES_QUOTATION, $templates, $revisions, $words);
    }

    public function salesOrder(SalesOrder $order, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $order->load(['company', 'site', 'customer', 'warehouse', 'quotation', 'lines.item', 'lines.unit', 'lines.taxRate']);

        return $this->render($order, FinancialDocumentCatalog::SALES_ORDER, $templates, $revisions, $words);
    }

    public function deliveryNote(DeliveryNote $delivery, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $delivery->load([
            'salesOrder.company', 'salesOrder.site', 'customer', 'warehouse',
            'lines.item', 'lines.unit', 'lines.salesOrderLine.taxRate',
        ]);

        return $this->render($delivery, FinancialDocumentCatalog::DELIVERY_NOTE, $templates, $revisions, $words);
    }

    public function purchaseRequisition(PurchaseRequisition $requisition, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $requisition->load(['company', 'site', 'requester', 'lines.item', 'lines.unit', 'lines.suggestedSupplier']);

        return $this->render($requisition, FinancialDocumentCatalog::PURCHASE_REQUISITION, $templates, $revisions, $words);
    }

    public function purchaseOrder(PurchaseOrder $order, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $order->load(['company', 'site', 'supplier', 'warehouse', 'requisition', 'quotation', 'lines.item', 'lines.unit', 'lines.taxRate']);

        return $this->render($order, FinancialDocumentCatalog::PURCHASE_ORDER, $templates, $revisions, $words);
    }

    public function goodsReceipt(GoodsReceipt $receipt, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $receipt->load([
            'purchaseOrder.company', 'purchaseOrder.site', 'supplier', 'warehouse', 'destinationLocation',
            'lines.item', 'lines.unit', 'lines.purchaseOrderLine.taxRate',
        ]);

        return $this->render($receipt, FinancialDocumentCatalog::GOODS_RECEIPT, $templates, $revisions, $words);
    }

    public function customerInvoice(CustomerInvoice $invoice, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $invoice->load(['company', 'site', 'customer', 'salesOrder', 'deliveryNote', 'lines.item', 'lines.unit', 'lines.taxRate', 'creator', 'issuer']);

        return $this->render($invoice, FinancialDocumentCatalog::CUSTOMER_INVOICE, $templates, $revisions, $words);
    }

    public function supplierInvoice(SupplierInvoice $invoice, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $invoice->load(['company', 'site', 'supplier', 'purchaseOrder', 'goodsReceipt', 'lines.item', 'lines.unit', 'lines.taxRate', 'creator', 'approver']);

        return $this->render($invoice, FinancialDocumentCatalog::SUPPLIER_INVOICE, $templates, $revisions, $words);
    }

    public function customerCredit(CustomerCreditNote $credit, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $credit->load(['invoice.company', 'invoice.site', 'customer', 'creator', 'issuer']);

        return $this->render($credit, FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE, $templates, $revisions, $words);
    }

    public function supplierCredit(SupplierCreditNote $credit, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $credit->load(['invoice.company', 'invoice.site', 'supplier', 'creator', 'approver']);

        return $this->render($credit, FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE, $templates, $revisions, $words);
    }

    public function customerPayment(CustomerPayment $payment, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $payment->load(['company', 'customer', 'financialAccount', 'allocations.invoice', 'creator', 'poster']);

        return $this->render($payment, FinancialDocumentCatalog::CUSTOMER_PAYMENT, $templates, $revisions, $words);
    }

    public function supplierPayment(SupplierPayment $payment, DocumentTemplateService $templates, DocumentRevisionService $revisions, MoneyToWordsService $words): View
    {
        $payment->load(['company', 'supplier', 'financialAccount', 'allocations.invoice', 'creator', 'poster']);

        return $this->render($payment, FinancialDocumentCatalog::SUPPLIER_PAYMENT, $templates, $revisions, $words);
    }

    private function render(
        Model $document,
        string $documentType,
        DocumentTemplateService $templates,
        DocumentRevisionService $revisions,
        MoneyToWordsService $words,
    ): View {
        $definition = FinancialDocumentCatalog::definition($documentType);
        $company = $this->company($document, $documentType);
        $template = $templates->resolve($documentType, $company?->id, app()->getLocale());
        $lines = $this->lines($document, $documentType);
        $totals = $this->totals($document, $documentType, $lines);
        $showAmounts = $template?->show_amounts;
        if ($showAmounts === null) {
            $showAmounts = (bool) ($definition['show_amounts'] ?? true);
        }

        $revisions->record($document, 'PRINTED', auth()->id(), null, $documentType);

        return view('finance.documents.print', [
            'document' => $document,
            'documentType' => $documentType,
            'definition' => $definition,
            'company' => $company,
            'template' => $template,
            'party' => $this->party($document, $documentType),
            'partyLabel' => $this->partyLabel($documentType),
            'number' => FinancialDocumentCatalog::number($document, $documentType),
            'date' => $document->getAttribute($definition['date_attribute']),
            'lines' => $lines,
            'totals' => $totals,
            'showAmounts' => (bool) $showAmounts,
            'companyIdentity' => $this->companyIdentity($company),
            'partyIdentity' => $this->partyIdentity($this->party($document, $documentType)),
            'bankDetails' => $this->bankDetails($company),
            'companyLogoUrl' => $this->companyLogoUrl($company),
            'amountInWords' => $showAmounts
                && in_array($documentType, [
                    FinancialDocumentCatalog::CUSTOMER_INVOICE,
                    FinancialDocumentCatalog::SUPPLIER_INVOICE,
                    FinancialDocumentCatalog::DELIVERY_NOTE,
                    FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE,
                    FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE,
                ], true)
                && ($template?->show_amount_in_words ?? true)
                && $totals['total'] != 0.0
                    ? $words->convert($totals['total'], (string) ($totals['currency'] ?: 'DZD'))
                    : null,
        ]);
    }

    private function company(Model $document, string $type): mixed
    {
        return match ($type) {
            FinancialDocumentCatalog::DELIVERY_NOTE => $document->salesOrder?->company,
            FinancialDocumentCatalog::GOODS_RECEIPT => $document->purchaseOrder?->company,
            FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE, FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE => $document->invoice?->company,
            default => $document->company,
        };
    }

    private function party(Model $document, string $type): mixed
    {
        return match ($type) {
            FinancialDocumentCatalog::SALES_QUOTATION,
            FinancialDocumentCatalog::SALES_ORDER,
            FinancialDocumentCatalog::DELIVERY_NOTE,
            FinancialDocumentCatalog::CUSTOMER_INVOICE,
            FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE,
            FinancialDocumentCatalog::CUSTOMER_PAYMENT => $document->customer,
            FinancialDocumentCatalog::PURCHASE_ORDER,
            FinancialDocumentCatalog::GOODS_RECEIPT,
            FinancialDocumentCatalog::SUPPLIER_INVOICE,
            FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE,
            FinancialDocumentCatalog::SUPPLIER_PAYMENT => $document->supplier,
            FinancialDocumentCatalog::PURCHASE_REQUISITION => $document->requester,
        };
    }

    private function partyLabel(string $type): string
    {
        return match ($type) {
            FinancialDocumentCatalog::PURCHASE_REQUISITION => __('governance.requester'),
            FinancialDocumentCatalog::PURCHASE_ORDER,
            FinancialDocumentCatalog::GOODS_RECEIPT,
            FinancialDocumentCatalog::SUPPLIER_INVOICE,
            FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE,
            FinancialDocumentCatalog::SUPPLIER_PAYMENT => __('purchasing.supplier'),
            default => __('sales.customer'),
        };
    }

    /** @return array<int, array<string, mixed>> */
    private function lines(Model $document, string $type): array
    {
        $rows = match ($type) {
            FinancialDocumentCatalog::SALES_QUOTATION => $document->lines->map(fn ($line): array => $this->line(
                $line->item?->code,
                $line->description ?: $line->item?->name,
                (float) $line->quantity,
                $line->unit?->symbol,
                $this->unitPriceExcludingTax((float) $line->unit_price, (float) ($line->taxRate?->rate ?? 0), (bool) $document->tax_included),
                (float) ($line->discount_percentage ?? 0),
                (float) ($line->taxRate?->rate ?? 0),
                (float) $line->line_subtotal,
                (float) $line->tax_amount,
                (float) $line->line_total,
            )),
            FinancialDocumentCatalog::SALES_ORDER => $document->lines->map(fn ($line): array => $this->line(
                $line->item?->code,
                $line->description ?: $line->item?->name,
                (float) $line->ordered_quantity,
                $line->unit?->symbol,
                $this->unitPriceExcludingTax((float) $line->unit_price, (float) ($line->taxRate?->rate ?? 0), (bool) $document->tax_included),
                (float) ($line->discount_percentage ?? 0),
                (float) ($line->taxRate?->rate ?? 0),
                (float) $line->line_subtotal,
                (float) $line->tax_amount,
                (float) $line->line_total,
            )),
            FinancialDocumentCatalog::DELIVERY_NOTE => $document->lines->map(function ($line) use ($document): array {
                $source = $line->salesOrderLine;
                $quantity = (float) $line->quantity;
                $taxRate = (float) ($source?->taxRate?->rate ?? 0);
                $unitPrice = $this->unitPriceExcludingTax(
                    (float) ($source?->unit_price ?? 0),
                    $taxRate,
                    (bool) ($document->salesOrder?->tax_included ?? false),
                );
                $discount = (float) ($source?->discount_percentage ?? 0);
                $netPrice = (float) ($source?->net_unit_price ?? ($unitPrice * (1 - ($discount / 100))));
                $subtotal = round($quantity * $netPrice, 4);
                $tax = round($subtotal * $taxRate / 100, 4);

                return $this->line(
                    $line->item?->code,
                    $source?->description ?: $line->item?->name,
                    $quantity,
                    $line->unit?->symbol,
                    $unitPrice,
                    $discount,
                    $taxRate,
                    $subtotal,
                    $tax,
                    round($subtotal + $tax, 4),
                );
            }),
            FinancialDocumentCatalog::PURCHASE_REQUISITION => $document->lines->map(function ($line): array {
                $subtotal = (float) $line->quantity * (float) ($line->estimated_unit_price ?? 0);

                return $this->line($line->item?->code, $line->description ?: $line->item?->name, (float) $line->quantity, $line->unit?->symbol, (float) ($line->estimated_unit_price ?? 0), 0, 0, $subtotal, 0, $subtotal);
            }),
            FinancialDocumentCatalog::PURCHASE_ORDER => $document->lines->map(fn ($line): array => $this->line(
                $line->item?->code,
                $line->description ?: $line->item?->name,
                (float) $line->ordered_quantity,
                $line->unit?->symbol,
                $this->unitPriceExcludingTax((float) $line->unit_price, (float) ($line->taxRate?->rate ?? 0), (bool) $document->tax_included),
                (float) ($line->discount_percentage ?? 0),
                (float) ($line->taxRate?->rate ?? 0),
                (float) $line->line_subtotal,
                (float) $line->tax_amount,
                (float) $line->line_total,
            )),
            FinancialDocumentCatalog::GOODS_RECEIPT => $document->lines->map(function ($line) use ($document): array {
                $source = $line->purchaseOrderLine;
                $quantity = (float) $line->accepted_quantity;
                $taxRate = (float) ($source?->taxRate?->rate ?? 0);
                $unitPrice = $this->unitPriceExcludingTax(
                    (float) ($source?->unit_price ?? 0),
                    $taxRate,
                    (bool) ($document->purchaseOrder?->tax_included ?? false),
                );
                $discount = (float) ($source?->discount_percentage ?? 0);
                $netPrice = (float) ($source?->net_unit_price ?? ($unitPrice * (1 - ($discount / 100))));
                $subtotal = round($quantity * $netPrice, 4);
                $tax = round($subtotal * $taxRate / 100, 4);
                $description = trim(($line->item?->name ?? '').($line->lot_number ? ' · '.$line->lot_number : ''));

                return $this->line($line->item?->code, $description, $quantity, $line->unit?->symbol, $unitPrice, $discount, $taxRate, $subtotal, $tax, round($subtotal + $tax, 4));
            }),
            FinancialDocumentCatalog::CUSTOMER_INVOICE,
            FinancialDocumentCatalog::SUPPLIER_INVOICE => $document->lines->map(fn ($line): array => $this->line(
                $line->item?->code,
                $line->description,
                (float) $line->quantity,
                $line->unit?->symbol,
                $this->unitPriceExcludingTax(
                    (float) $line->unit_price,
                    (float) ($line->taxRate?->rate ?? 0),
                    (bool) ($type === FinancialDocumentCatalog::CUSTOMER_INVOICE
                        ? ($document->salesOrder?->tax_included ?? false)
                        : ($document->purchaseOrder?->tax_included ?? false)),
                ),
                (float) ($line->discount_percentage ?? 0),
                (float) ($line->taxRate?->rate ?? 0),
                (float) $line->line_subtotal,
                (float) $line->tax_amount,
                (float) $line->line_total,
            )),
            FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE,
            FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE => collect([$this->line($document->reason_code, $document->reason, 1, null, (float) $document->total_amount, 0, 0, (float) $document->total_amount, 0, (float) $document->total_amount)]),
            FinancialDocumentCatalog::CUSTOMER_PAYMENT,
            FinancialDocumentCatalog::SUPPLIER_PAYMENT => $document->allocations->map(fn ($allocation): array => $this->line(
                $allocation->invoice?->invoice_number,
                __('governance.payment_allocation'),
                1,
                null,
                (float) $allocation->amount,
                0,
                0,
                (float) $allocation->amount,
                0,
                (float) $allocation->amount,
            )),
        };

        return $rows->values()->map(function (array $line, int $index): array {
            $line['number'] = $index + 1;

            return $line;
        })->all();
    }

    /** @param array<int, array<string, mixed>> $lines
     *  @return array{subtotal: float, discount: float, tax: float, total: float, balance: float, currency: ?string}
     */
    private function totals(Model $document, string $type, array $lines): array
    {
        return match ($type) {
            FinancialDocumentCatalog::SALES_QUOTATION,
            FinancialDocumentCatalog::SALES_ORDER,
            FinancialDocumentCatalog::PURCHASE_ORDER,
            FinancialDocumentCatalog::CUSTOMER_INVOICE,
            FinancialDocumentCatalog::SUPPLIER_INVOICE => $this->totalSet(
                (float) $document->subtotal,
                (float) ($document->discount_amount ?? 0),
                (float) $document->tax_amount,
                (float) $document->total_amount,
                (float) ($document->balance_amount ?? 0),
                $document->currency_code,
            ),
            FinancialDocumentCatalog::PURCHASE_REQUISITION => $this->totalFromLines($lines, $document->lines->pluck('currency_code')->filter()->first() ?: $document->company?->currency_code),
            FinancialDocumentCatalog::DELIVERY_NOTE => $this->totalFromLines($lines, $document->salesOrder?->currency_code ?: $this->company($document, $type)?->currency_code),
            FinancialDocumentCatalog::GOODS_RECEIPT => $this->totalFromLines($lines, $document->purchaseOrder?->currency_code ?: $this->company($document, $type)?->currency_code),
            FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE,
            FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE => $this->totalSet((float) $document->total_amount, 0, 0, (float) $document->total_amount, 0, $document->currency_code),
            FinancialDocumentCatalog::CUSTOMER_PAYMENT,
            FinancialDocumentCatalog::SUPPLIER_PAYMENT => $this->totalSet((float) $document->allocated_amount, 0, 0, (float) $document->amount, (float) $document->unallocated_amount, $document->currency_code),
        };
    }

    /** @return array<string, mixed> */
    private function line(
        ?string $reference,
        ?string $description,
        float $quantity,
        ?string $unit,
        float $unitPrice,
        float $discountPercentage,
        float $taxRate,
        float $subtotal,
        float $tax,
        float $total,
    ): array {
        $grossSubtotal = round($quantity * $unitPrice, 4);
        $discountAmount = max(0.0, round($grossSubtotal - $subtotal, 4));

        return compact('reference', 'description', 'quantity', 'unit', 'tax', 'subtotal', 'total') + [
            'unit_price' => $unitPrice,
            'discount_percentage' => $discountPercentage,
            'discount_amount' => $discountAmount,
            'tax_rate' => $taxRate,
        ];
    }

    /** @return array{subtotal: float, discount: float, tax: float, total: float, balance: float, currency: ?string} */
    private function totalSet(float $subtotal, float $discount, float $tax, float $total, float $balance, ?string $currency): array
    {
        return compact('subtotal', 'discount', 'tax', 'total', 'balance', 'currency');
    }

    /** @param array<int, array<string, mixed>> $lines
     *  @return array{subtotal: float, discount: float, tax: float, total: float, balance: float, currency: ?string}
     */
    private function totalFromLines(array $lines, ?string $currency): array
    {
        return $this->totalSet(
            (float) collect($lines)->sum('subtotal'),
            (float) collect($lines)->sum('discount_amount'),
            (float) collect($lines)->sum('tax'),
            (float) collect($lines)->sum('total'),
            0,
            $currency,
        );
    }

    private function unitPriceExcludingTax(float $unitPrice, float $taxRate, bool $taxIncluded): float
    {
        if (! $taxIncluded || $taxRate <= 0) {
            return $unitPrice;
        }

        return round($unitPrice / (1 + ($taxRate / 100)), 6);
    }

    /** @return array<string, ?string> */
    private function companyIdentity(mixed $company): array
    {
        return [
            'name' => $company?->legal_name ?: $company?->name,
            'activity' => $company?->business_activity,
            'address' => $company?->address,
            'phone' => $company?->phone,
            'email' => $company?->email,
            'registration_number' => $company?->trade_register_number,
            'tax_identifier' => $company?->tax_identification_number,
            'statistical_identifier' => $company?->statistical_identification_number,
            'article_of_imposition' => $company?->article_of_imposition_number,
        ];
    }

    /** @return array<string, ?string> */
    private function partyIdentity(mixed $party): array
    {
        return [
            'code' => $party?->code,
            'name' => $party?->legal_name ?: $party?->name,
            'address' => $party?->billing_address ?: ($party?->address ?: $party?->shipping_address),
            'phone' => $party?->phone,
            'email' => $party?->email,
            'registration_number' => $party?->registration_number,
            'tax_identifier' => $party?->tax_identifier,
            'statistical_identifier' => $party?->statistical_identification_number,
            'article_of_imposition' => $party?->article_of_imposition_number,
        ];
    }

    /** @return array<string, ?string> */
    private function bankDetails(mixed $company): array
    {
        $account = null;
        if ($company && (! $company->bank_name || ! $company->bank_account_number)) {
            $account = FinancialAccount::query()
                ->where('company_id', $company->id)
                ->where('active', true)
                ->where('account_type', 'BANK')
                ->orderBy('code')
                ->first();
        }

        return [
            'bank_name' => $company?->bank_name ?: $account?->bank_name,
            'bank_branch' => $company?->bank_branch,
            'account_number' => $company?->bank_account_number ?: $account?->account_number,
            'iban' => $account?->iban,
        ];
    }

    private function companyLogoUrl(mixed $company): ?string
    {
        if (! $company?->logo_path || ! Storage::disk('public')->exists($company->logo_path)) {
            return null;
        }

        return Storage::disk('public')->url($company->logo_path);
    }
}
