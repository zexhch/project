<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\ItemImage;
use App\Models\ItemUnitConversion;
use App\Models\Unit;
use App\Services\Catalog\ItemImageService;
use App\Services\Catalog\ItemPackagingService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Throwable;

class ItemPackagingController extends Controller
{
    public function index(Request $request, Item $item, ItemPackagingService $service): View
    {
        $this->authorizePermission($request, 'catalog.view');
        $item->load(['baseUnit', 'category', 'images', 'unitConversions.unit', 'unitConversions.parentUnit']);
        $editing = null;
        if ($request->filled('edit')) {
            $editing = $item->unitConversions->firstWhere('id', $request->string('edit')->toString());
        }
        $stock = (float) $item->balances()->sum('quantity');

        return view('admin.item-packaging', [
            'item' => $item,
            'editing' => $editing,
            'units' => Unit::query()->where('active', true)->orderBy('name')->get(),
            'decomposition' => $service->decompose($item, $stock),
            'stockBaseQuantity' => $stock,
            'canUpdate' => $request->user()->hasPermission('catalog.update'),
        ]);
    }

    public function store(Request $request, Item $item, ItemPackagingService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        $data = $this->validatedPackaging($request, $item);
        try {
            $service->save($item, $data, null, $request->user());
        } catch (DomainException $exception) {
            return back()->withInput()->withErrors(['packaging' => $exception->getMessage()]);
        }
        return redirect()->route('admin.items.packaging', $item)->with('success', __('packaging.saved'));
    }

    public function update(Request $request, Item $item, ItemUnitConversion $conversion, ItemPackagingService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        abort_unless($conversion->item_id === $item->id, 404);
        $data = $this->validatedPackaging($request, $item, $conversion);
        try {
            $service->save($item, $data, $conversion, $request->user());
        } catch (DomainException $exception) {
            return back()->withInput()->withErrors(['packaging' => $exception->getMessage()]);
        }
        return redirect()->route('admin.items.packaging', $item)->with('success', __('packaging.saved'));
    }

    public function destroy(Request $request, Item $item, ItemUnitConversion $conversion, ItemPackagingService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        abort_unless($conversion->item_id === $item->id, 404);
        try {
            $service->delete($item, $conversion, $request->user());
        } catch (DomainException $exception) {
            return back()->withErrors(['packaging' => $exception->getMessage()]);
        }
        return back()->with('success', __('packaging.deleted'));
    }

    public function uploadMain(Request $request, Item $item, ItemImageService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        $data = $request->validate(['image' => ['required', 'image', 'mimes:png,jpg,jpeg', 'max:'.(int) config('catalog.item_images.max_file_kb', 8192)]]);
        try {
            $service->storeMain($item, $data['image'], $request->user());
        } catch (Throwable $exception) {
            report($exception);
            return back()->withErrors(['image' => $exception->getMessage()]);
        }
        return back()->with('success', __('packaging.main_image_saved'));
    }

    public function deleteMain(Request $request, Item $item, ItemImageService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        $service->deleteMain($item, $request->user());

        return back()->with('success', __('packaging.main_image_deleted'));
    }

    public function uploadGallery(Request $request, Item $item, ItemImageService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        $data = $request->validate(['images' => ['required', 'array', 'max:'.(int) config('catalog.item_images.gallery_max_files', 10)], 'images.*' => ['image', 'mimes:png,jpg,jpeg', 'max:'.(int) config('catalog.item_images.max_file_kb', 8192)]]);
        try {
            foreach ($data['images'] as $image) {
                $service->addGallery($item, $image, $request->user());
            }
        } catch (Throwable $exception) {
            report($exception);
            return back()->withErrors(['images' => $exception->getMessage()]);
        }
        return back()->with('success', __('packaging.gallery_saved'));
    }

    public function deleteGallery(Request $request, Item $item, ItemImage $image, ItemImageService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        abort_unless($image->item_id === $item->id, 404);
        $service->deleteGallery($image, $request->user());
        return back()->with('success', __('packaging.gallery_deleted'));
    }

    public function importImages(Request $request, ItemImageService $service): RedirectResponse
    {
        $this->authorizePermission($request, 'catalog.update');
        $data = $request->validate(['archive' => ['required', 'file', 'mimes:zip', 'max:'.(int) config('catalog.item_images.archive_max_kb', 51200)]]);
        try {
            $result = $service->importZip($data['archive'], $request->user());
        } catch (Throwable $exception) {
            report($exception);
            return back()->withErrors(['archive' => $exception->getMessage()]);
        }
        return back()->with('image_import_result', $result)->with('success', __('packaging.image_archive_imported', ['count' => $result['imported']]));
    }

    private function validatedPackaging(Request $request, Item $item, ?ItemUnitConversion $conversion = null): array
    {
        return $request->validate([
            'unit_id' => ['required', 'uuid', 'exists:units,id', Rule::unique('item_unit_conversions', 'unit_id')->where('item_id', $item->id)->ignore($conversion?->id)],
            'parent_unit_id' => ['nullable', 'uuid', 'exists:units,id', 'different:unit_id'],
            'factor_to_parent' => ['required', 'numeric', 'gt:0', 'max:1000000000'],
            'barcode' => ['nullable', 'string', 'max:120'],
            'net_weight_kg' => ['nullable', 'numeric', 'min:0', 'max:1000000'],
            'gross_weight_kg' => ['nullable', 'numeric', 'min:0', 'max:1000000', 'gte:net_weight_kg'],
            'tare_weight_kg' => ['nullable', 'numeric', 'min:0', 'max:1000000'],
            'length_cm' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'width_cm' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'height_cm' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'purchasing_unit' => ['nullable', 'boolean'],
            'sales_unit' => ['nullable', 'boolean'],
            'production_unit' => ['nullable', 'boolean'],
            'inventory_unit' => ['nullable', 'boolean'],
            'fractional_allowed' => ['nullable', 'boolean'],
            'rounding_mode' => ['required', Rule::in(['NONE', 'UP', 'DOWN', 'NEAREST'])],
            'valid_from' => ['nullable', 'date_format:Y-m-d'],
            'valid_to' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:valid_from'],
            'active' => ['nullable', 'boolean'],
        ]);
    }

    private function authorizePermission(Request $request, string $permission): void
    {
        abort_unless($request->user()?->hasPermission($permission), 403, __('messages.forbidden'));
    }
}
