<?php

namespace App\Http\Controllers;

use App\Support\FieldHelp;
use Illuminate\View\View;

class HelpController extends Controller
{
    public function __invoke(): View
    {
        return view('help.glossary', [
            'glossary' => FieldHelp::glossary(),
            'fields' => FieldHelp::fields(),
        ]);
    }
}
