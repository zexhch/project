<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Item;
use App\Models\ProcessTemplate;
use App\Models\Recipe;
use App\Models\RecipeCostComponent;
use App\Models\RecipeLine;
use App\Models\RecipeVersion;
use App\Models\Unit;
use App\Services\Production\ProductionCostService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class RecipeController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim((string) $request->query('search'));
        $status = trim((string) $request->query('status'));

        $recipes = Recipe::query()
            ->with(['finishedItem.baseUnit', 'latestVersion', 'approvedVersion'])
            ->withCount('versions')
            ->when($search, fn (Builder $query) => $query->where(fn (Builder $nested) => $nested
                ->where('code', 'ilike', "%{$search}%")
                ->orWhere('name', 'ilike', "%{$search}%")
                ->orWhereHas('finishedItem', fn (Builder $item) => $item
                    ->where('code', 'ilike', "%{$search}%")
                    ->orWhere('name', 'ilike', "%{$search}%"))))
            ->when($status === 'ACTIVE', fn (Builder $query) => $query->where('active', true))
            ->when($status === 'INACTIVE', fn (Builder $query) => $query->where('active', false))
            ->orderBy('name')
            ->paginate(25)
            ->withQueryString();

        return view('production.recipes.index', [
            'recipes' => $recipes,
            'search' => $search,
            'status' => $status,
            'finishedItems' => Item::with('baseUnit')->where('item_type', 'FINISHED_GOOD')
                ->where('active', true)->orderBy('name')->get(),
            'metrics' => [
                'active' => Recipe::where('active', true)->count(),
                'drafts' => RecipeVersion::where('status', 'DRAFT')->count(),
                'approved' => RecipeVersion::where('status', 'APPROVED')->count(),
                'without_approved' => Recipe::where('active', true)
                    ->whereDoesntHave('versions', fn (Builder $query) => $query->where('status', 'APPROVED'))->count(),
            ],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', 'unique:recipes,code'],
            'name' => ['required', 'string', 'max:255'],
            'finished_item_id' => ['required', Rule::exists('items', 'id')->where('item_type', 'FINISHED_GOOD')->where('active', true)],
            'description' => ['nullable', 'string'],
        ]);

        $recipe = Recipe::create($data + ['active' => true]);
        $this->audit('production.recipe.created', $recipe, null, $recipe->toArray());

        return redirect()->route('recipes.show', $recipe)->with('success', __('production.recipe_created'));
    }

    public function show(Request $request, Recipe $recipe, ProductionCostService $costing): View
    {
        $recipe->load([
            'finishedItem.baseUnit',
            'versions' => fn ($query) => $query->with(['approver', 'processTemplate', 'referenceUnit'])->orderByDesc('version_number'),
        ]);

        $versionId = (string) $request->query('version');
        $selectedVersion = $recipe->versions->firstWhere('id', $versionId) ?? $recipe->versions->first();
        if ($selectedVersion) {
            $selectedVersion->load([
                'lines.ingredient.baseUnit', 'lines.unit', 'costComponents.unit',
                'costCalculations.calculator', 'productionOrders',
            ]);
        }

        $tab = in_array($request->query('tab'), ['overview', 'ingredients', 'process', 'costs', 'history'], true)
            ? $request->query('tab')
            : 'overview';

        return view('production.recipes.show', [
            'recipe' => $recipe,
            'selectedVersion' => $selectedVersion,
            'tab' => $tab,
            'costing' => $selectedVersion ? $costing->theoretical($selectedVersion) : null,
            'ingredients' => Item::with('baseUnit')->where('active', true)
                ->whereIn('item_type', ['RAW_MATERIAL', 'PACKAGING', 'SEMI_FINISHED'])
                ->orderBy('name')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'processTemplates' => ProcessTemplate::where('active', true)
                ->where(fn (Builder $query) => $query->whereNull('finished_item_id')
                    ->orWhere('finished_item_id', $recipe->finished_item_id))
                ->orderBy('name')->get(),
            'currencyCode' => $this->currencyCode(),
            'costTypes' => $this->references('cost_type'),
            'costBases' => $this->references('cost_basis'),
        ]);
    }

    public function update(Request $request, Recipe $recipe): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', Rule::unique('recipes', 'code')->ignore($recipe->id)],
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'active' => ['nullable', 'boolean'],
        ]);
        $old = $recipe->toArray();
        $recipe->update($data + ['active' => $request->boolean('active')]);
        $this->audit('production.recipe.updated', $recipe, $old, $recipe->fresh()->toArray());

        return back()->with('success', __('production.recipe_updated'));
    }

    public function storeVersion(Request $request, Recipe $recipe): RedirectResponse
    {
        $data = $this->validateVersion($request, $recipe);

        $version = DB::transaction(function () use ($recipe, $data): RecipeVersion {
            $next = (int) RecipeVersion::where('recipe_id', $recipe->id)->lockForUpdate()->max('version_number') + 1;

            return $recipe->versions()->create($data + ['version_number' => $next, 'status' => 'DRAFT']);
        });
        $this->audit('production.recipe_version.created', $version, null, $version->toArray());

        return redirect()->route('recipes.show', ['recipe' => $recipe, 'version' => $version->id, 'tab' => 'ingredients'])
            ->with('success', __('production.version_created'));
    }

    public function updateVersion(Request $request, Recipe $recipe, RecipeVersion $version): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        $this->ensureDraft($version);
        $data = $this->validateVersion($request, $recipe);
        $old = $version->toArray();
        $version->update($data);
        $this->audit('production.recipe_version.updated', $version, $old, $version->fresh()->toArray());

        return back()->with('success', __('production.version_updated'));
    }

    public function duplicateVersion(Recipe $recipe, RecipeVersion $version): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        $version->load(['lines', 'costComponents']);

        $copy = DB::transaction(function () use ($recipe, $version): RecipeVersion {
            $next = (int) RecipeVersion::where('recipe_id', $recipe->id)->lockForUpdate()->max('version_number') + 1;
            $copy = $recipe->versions()->create([
                'version_number' => $next,
                'reference_quantity' => $version->reference_quantity,
                'reference_unit_id' => $version->reference_unit_id,
                'expected_yield_percent' => $version->expected_yield_percent,
                'valid_from' => today(),
                'valid_to' => null,
                'status' => 'DRAFT',
                'process_template_id' => $version->process_template_id,
                'notes' => __('production.copied_from_version', ['version' => $version->version_number]),
            ]);
            foreach ($version->lines as $line) {
                $copy->lines()->create($line->only(['ingredient_item_id', 'quantity', 'unit_id', 'loss_percentage', 'optional']));
            }
            foreach ($version->costComponents as $component) {
                $copy->costComponents()->create($component->only([
                    'cost_type', 'label', 'calculation_basis', 'quantity', 'unit_id',
                    'unit_cost', 'percentage', 'currency_code', 'notes',
                ]));
            }

            return $copy;
        });
        $this->audit('production.recipe_version.duplicated', $copy, null, ['source_version_id' => $version->id]);

        return redirect()->route('recipes.show', ['recipe' => $recipe, 'version' => $copy->id, 'tab' => 'ingredients'])
            ->with('success', __('production.version_duplicated'));
    }

    public function approveVersion(
        Recipe $recipe,
        RecipeVersion $version,
        ProductionCostService $costing,
    ): RedirectResponse {
        $this->ensureVersionBelongsTo($recipe, $version);
        $this->ensureDraft($version);
        $version->load('lines');
        if ($version->lines->isEmpty()) {
            throw ValidationException::withMessages(['ingredients' => __('production.ingredient_required')]);
        }

        DB::transaction(function () use ($recipe, $version, $costing): void {
            $approvalDate = $version->valid_from ?? today();
            RecipeVersion::where('recipe_id', $recipe->id)->where('status', 'APPROVED')
                ->where('id', '!=', $version->id)->update([
                    'status' => 'ARCHIVED',
                    'valid_to' => $approvalDate,
                    'updated_at' => now(),
                ]);
            $version->update([
                'status' => 'APPROVED',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'valid_from' => $approvalDate,
            ]);
            $costing->storeTheoretical($version->fresh(), auth()->id());
        });
        $this->audit('production.recipe_version.approved', $version, ['status' => 'DRAFT'], ['status' => 'APPROVED']);

        return back()->with('success', __('production.version_approved'));
    }

    public function archiveVersion(Recipe $recipe, RecipeVersion $version): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        abort_unless(in_array($version->status, ['DRAFT', 'APPROVED'], true), 409);
        $oldStatus = $version->status;
        $version->update(['status' => 'ARCHIVED', 'valid_to' => $version->valid_to ?? today()]);
        $this->audit('production.recipe_version.archived', $version, ['status' => $oldStatus], ['status' => 'ARCHIVED']);

        return back()->with('success', __('production.version_archived'));
    }

    public function storeLine(Request $request, Recipe $recipe, RecipeVersion $version): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        $this->ensureDraft($version);
        $data = $this->validateLine($request, $version);
        $line = $version->lines()->create(array_merge($data, [
            'loss_percentage' => $data['loss_percentage'] ?? 0,
            'optional' => $request->boolean('optional'),
        ]));
        $this->audit('production.recipe_line.created', $line, null, $line->toArray());

        return back()->with('success', __('production.ingredient_added'));
    }

    public function updateLine(Request $request, Recipe $recipe, RecipeVersion $version, RecipeLine $line): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        abort_unless($line->recipe_version_id === $version->id, 404);
        $this->ensureDraft($version);
        $data = $this->validateLine($request, $version, $line);
        $old = $line->toArray();
        $line->update(array_merge($data, [
            'loss_percentage' => $data['loss_percentage'] ?? 0,
            'optional' => $request->boolean('optional'),
        ]));
        $this->audit('production.recipe_line.updated', $line, $old, $line->fresh()->toArray());

        return back()->with('success', __('production.ingredient_updated'));
    }

    public function destroyLine(Recipe $recipe, RecipeVersion $version, RecipeLine $line): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        abort_unless($line->recipe_version_id === $version->id, 404);
        $this->ensureDraft($version);
        $old = $line->toArray();
        $line->delete();
        $this->audit('production.recipe_line.deleted', $line, $old, null);

        return back()->with('success', __('production.ingredient_removed'));
    }

    public function storeCostComponent(Request $request, Recipe $recipe, RecipeVersion $version): RedirectResponse
    {
        $this->ensureVersionBelongsTo($recipe, $version);
        $this->ensureDraft($version);
        $data = $request->validate([
            'cost_type' => ['required', $this->referenceRule('cost_type')],
            'label' => ['required', 'string', 'max:255'],
            'calculation_basis' => ['required', $this->referenceRule('cost_basis')],
            'quantity' => ['nullable', 'numeric', 'gte:0'],
            'unit_id' => ['nullable', 'exists:units,id'],
            'unit_cost' => ['nullable', 'numeric', 'gte:0'],
            'percentage' => ['nullable', 'numeric', 'between:0,100'],
            'notes' => ['nullable', 'string'],
        ]);
        if ($data['calculation_basis'] === 'PERCENTAGE' && ! isset($data['percentage'])) {
            throw ValidationException::withMessages(['percentage' => __('production.percentage_required')]);
        }
        $component = $version->costComponents()->create(array_merge($data, [
            'quantity' => $data['quantity'] ?? 1,
            'unit_cost' => $data['unit_cost'] ?? 0,
            'currency_code' => $this->currencyCode(),
        ]));
        $this->audit('production.recipe_cost.created', $component, null, $component->toArray());

        return back()->with('success', __('production.cost_component_added'));
    }

    public function destroyCostComponent(
        Recipe $recipe,
        RecipeVersion $version,
        RecipeCostComponent $component,
    ): RedirectResponse {
        $this->ensureVersionBelongsTo($recipe, $version);
        abort_unless($component->recipe_version_id === $version->id, 404);
        $this->ensureDraft($version);
        $old = $component->toArray();
        $component->delete();
        $this->audit('production.recipe_cost.deleted', $component, $old, null);

        return back()->with('success', __('production.cost_component_removed'));
    }

    private function validateVersion(Request $request, Recipe $recipe): array
    {
        $data = $request->validate([
            'reference_quantity' => ['required', 'numeric', 'gt:0'],
            'reference_unit_id' => ['required', 'exists:units,id'],
            'expected_yield_percent' => ['required', 'numeric', 'gt:0', 'max:100'],
            'valid_from' => ['nullable', 'date'],
            'valid_to' => ['nullable', 'date', 'after_or_equal:valid_from'],
            'process_template_id' => [
                'nullable',
                Rule::exists('process_templates', 'id')->where(fn ($query) => $query
                    ->where('active', true)
                    ->where(fn ($scope) => $scope->whereNull('finished_item_id')
                        ->orWhere('finished_item_id', $recipe->finished_item_id))),
            ],
            'notes' => ['nullable', 'string'],
        ]);

        $baseUnitId = Item::whereKey($recipe->finished_item_id)->value('base_unit_id');
        if ($data['reference_unit_id'] !== $baseUnitId) {
            throw ValidationException::withMessages([
                'reference_unit_id' => __('production.reference_unit_must_be_base'),
            ]);
        }

        return $data;
    }

    private function validateLine(Request $request, RecipeVersion $version, ?RecipeLine $line = null): array
    {
        $data = $request->validate([
            'ingredient_item_id' => [
                'required',
                Rule::exists('items', 'id')->where('active', true),
                Rule::unique('recipe_lines', 'ingredient_item_id')
                    ->where('recipe_version_id', $version->id)->ignore($line?->id),
            ],
            'quantity' => ['required', 'numeric', 'gt:0'],
            'unit_id' => ['required', 'exists:units,id'],
            'loss_percentage' => ['nullable', 'numeric', 'between:0,100'],
            'optional' => ['nullable', 'boolean'],
        ]);

        $ingredient = Item::findOrFail($data['ingredient_item_id']);
        if ($data['unit_id'] !== $ingredient->base_unit_id) {
            $conversionExists = DB::table('item_unit_conversions')->where([
                'item_id' => $ingredient->id,
                'unit_id' => $data['unit_id'],
            ])->exists();
            if (! $conversionExists) {
                throw ValidationException::withMessages([
                    'unit_id' => __('production.missing_conversion', ['item' => $ingredient->code]),
                ]);
            }
        }

        return $data;
    }

    private function ensureVersionBelongsTo(Recipe $recipe, RecipeVersion $version): void
    {
        abort_unless($version->recipe_id === $recipe->id, 404);
    }

    private function ensureDraft(RecipeVersion $version): void
    {
        abort_unless($version->status === 'DRAFT', 409, __('production.version_not_draft'));
    }

    private function references(string $domain)
    {
        return DB::table('reference_values')->where('domain', $domain)->where('active', true)
            ->orderBy('sort_order')->get();
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query
            ->where('domain', $domain)->where('active', true));
    }

    private function currencyCode(): string
    {
        return Company::where('active', true)->orderBy('created_at')->value('currency_code') ?? 'DZD';
    }

    private function audit(string $event, object $model, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) \Illuminate\Support\Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $old ? json_encode($old) : null,
            'new_values' => $new ? json_encode($new) : null,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
