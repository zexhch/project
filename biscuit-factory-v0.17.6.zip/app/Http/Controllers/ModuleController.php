<?php

namespace App\Http\Controllers;

use App\Services\Modules\ModuleRegistry;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ModuleController extends Controller
{
    public function index(ModuleRegistry $modules): View
    {
        $modules->sync();

        return view('admin.modules.index', [
            'modules' => $modules->states(),
        ]);
    }

    public function update(Request $request, string $module, ModuleRegistry $modules): RedirectResponse
    {
        $validated = $request->validate([
            'enabled' => ['required', 'boolean'],
        ]);

        try {
            $updated = $modules->setEnabled($module, (bool) $validated['enabled'], $request->user());
        } catch (DomainException $exception) {
            return back()->withErrors(['module' => $exception->getMessage()]);
        }

        return back()->with('status', $updated->enabled
            ? __('modules.enabled_successfully')
            : __('modules.disabled_successfully'));
    }

    public function sync(ModuleRegistry $modules): RedirectResponse
    {
        $modules->sync();

        return back()->with('status', __('modules.synced_successfully'));
    }
}
