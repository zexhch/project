<?php

namespace App\Http\Controllers;

use App\Events\DashboardUpdated;
use App\Models\DowntimeReason;
use App\Models\Machine;
use App\Models\ProductionDowntime;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DowntimeController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(['production_line_id' => ['required', 'exists:production_lines,id'], 'machine_id' => ['nullable', 'exists:machines,id'], 'downtime_reason_id' => ['required', 'exists:downtime_reasons,id'], 'maintenance_work_order_id' => ['nullable', 'exists:maintenance_work_orders,id'], 'impact_level' => ['required', 'in:LINE_STOP,DEGRADED,NO_IMPACT'], 'description' => ['nullable', 'string']]);
        $reason = DowntimeReason::findOrFail($data['downtime_reason_id']);
        $downtime = ProductionDowntime::create($data + ['started_at' => now(), 'planned' => $reason->planned, 'recorded_by' => auth()->id()]);
        if ($downtime->machine) $downtime->machine->update(['status' => 'STOPPED']);
        $this->audit('maintenance.downtime.started', $downtime, null, ['started_at' => $downtime->started_at]);
        event(new DashboardUpdated(['downtime_id' => $downtime->id]));
        return back()->with('success', __('maintenance.downtime_started'));
    }

    public function stop(ProductionDowntime $downtime): RedirectResponse
    {
        abort_if($downtime->ended_at, 409);
        DB::transaction(function () use ($downtime): void {
            $ended = now();
            $durationSeconds = max(0, (int) round(abs($downtime->started_at->diffInSeconds($ended))));

            $downtime->update([
                'ended_at' => $ended,
                'duration_seconds' => $durationSeconds,
            ]);
            $this->audit('maintenance.downtime.stopped', $downtime, ['ended_at' => null], ['ended_at' => $ended, 'duration_seconds' => $durationSeconds]);
            if ($downtime->machine && !ProductionDowntime::where('machine_id', $downtime->machine_id)->whereNull('ended_at')->where('id', '!=', $downtime->id)->exists()) {
                $downtime->machine->update(['status' => 'AVAILABLE']);
            }
        });
        event(new DashboardUpdated(['downtime_id' => $downtime->id]));
        return back()->with('success', __('maintenance.downtime_stopped'));
    }

    private function audit(string $event, ProductionDowntime $downtime, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert(['id' => (string) Str::uuid(), 'user_id' => auth()->id(), 'event' => $event, 'auditable_type' => ProductionDowntime::class, 'auditable_id' => $downtime->id, 'old_values' => $old ? json_encode($old) : null, 'new_values' => $new ? json_encode($new) : null, 'ip_address' => request()->ip(), 'user_agent' => request()->userAgent(), 'created_at' => now()]);
    }
}
