<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\CostCenter;
use App\Models\CostScenario;
use App\Models\CostScenarioLine;
use App\Models\Currency;
use App\Models\Item;
use App\Models\Machine;
use App\Models\ManagementBudget;
use App\Models\ProductionLine;
use App\Models\RecipeVersion;
use App\Models\ReferenceValue;
use App\Models\Site;
use App\Models\User;
use App\Services\Finance\ManagementControlService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class ManagementControlController extends Controller
{
    public function index(Request $request, ManagementControlService $service): View
    {
        $year = (int) $request->integer('year', now()->year);
        $dateFrom = $request->string('date_from')->toString() ?: "{$year}-01-01";
        $dateTo = $request->string('date_to')->toString() ?: "{$year}-12-31";
        $companies = Company::query()->where('active', true)->orderBy('name')->get();
        $selectedCompanyId = $companies->contains('id', $request->string('company_id')->toString())
            ? $request->string('company_id')->toString()
            : $companies->first()?->id;
        $selectedScenario = $request->filled('scenario')
            ? CostScenario::with(['lines.item.baseUnit', 'lines.recipeVersion.recipe'])
                ->where('company_id', $selectedCompanyId)
                ->find($request->string('scenario')->toString())
            : null;

        $budgets = ManagementBudget::query()
            ->with(['company', 'costCenter'])
            ->where('company_id', $selectedCompanyId)
            ->where('fiscal_year', $year)
            ->orderBy('period')
            ->orderBy('category_code')
            ->get();

        $marginReport = $service->marginReport($dateFrom, $dateTo, $selectedCompanyId);

        return view('finance.control.index', [
            'year' => $year,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'companies' => $companies,
            'selectedCompanyId' => $selectedCompanyId,
            'sites' => Site::query()->where('active', true)->with('company')->orderBy('name')->get(),
            'users' => User::query()->where('active', true)->orderBy('name')->get(),
            'currencies' => Currency::query()->where('active', true)->orderBy('code')->get(),
            'items' => Item::query()->where('active', true)->where('item_type', 'FINISHED_GOOD')->with('baseUnit')->orderBy('name')->get(),
            'recipeVersions' => RecipeVersion::query()->where('status', 'APPROVED')->with('recipe.finishedItem')->latest('approved_at')->get(),
            'productionLines' => ProductionLine::query()->where('active', true)->whereHas('site', fn ($query) => $query->where('company_id', $selectedCompanyId))->with(['site', 'costCenter'])->orderBy('name')->get(),
            'machines' => Machine::query()->where('active', true)->whereHas('site', fn ($query) => $query->where('company_id', $selectedCompanyId))->with(['site', 'costCenter'])->orderBy('name')->get(),
            'costCenters' => CostCenter::query()->where('company_id', $selectedCompanyId)->with(['company', 'site', 'responsibleUser', 'rates' => fn ($query) => $query->latest('valid_from')])->orderBy('code')->get(),
            'scenarios' => CostScenario::query()->where('company_id', $selectedCompanyId)->withCount('lines')->latest()->get(),
            'selectedScenario' => $selectedScenario,
            'budgets' => $budgets,
            'budgetTotals' => [
                'budget' => (float) $budgets->sum('budget_amount'),
                'actual' => (float) $budgets->sum('actual_amount'),
                'variance' => (float) $budgets->sum('variance_amount'),
            ],
            'marginReport' => $marginReport,
            'centerTypes' => $this->references('cost_center_type'),
            'allocationMethods' => $this->references('cost_allocation_method'),
            'rateTypes' => $this->references('cost_rate_type'),
            'budgetCategories' => $this->references('budget_category'),
        ]);
    }

    public function storeCenter(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'site_id' => ['nullable', Rule::exists('sites', 'id')->where('company_id', $request->input('company_id'))],
            'code' => ['required', 'string', 'max:80', Rule::unique('cost_centers')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'center_type' => ['required', $this->referenceRule('cost_center_type')],
            'allocation_method' => ['required', $this->referenceRule('cost_allocation_method')],
            'responsible_user_id' => ['nullable', 'exists:users,id'],
            'description' => ['nullable', 'string'],
            'active' => ['nullable', 'boolean'],
        ]);

        $center = CostCenter::create([...$data, 'active' => $request->boolean('active', true)]);
        $this->audit('finance.cost_center.created', $center, null, $center->toArray());

        return back()->with('success', __('finance.cost_center_created'));
    }

    public function updateCenter(Request $request, CostCenter $center): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'site_id' => ['nullable', Rule::exists('sites', 'id')->where('company_id', $request->input('company_id'))],
            'code' => ['required', 'string', 'max:80', Rule::unique('cost_centers')->where('company_id', $request->input('company_id'))->ignore($center->id)],
            'name' => ['required', 'string', 'max:255'],
            'center_type' => ['required', $this->referenceRule('cost_center_type')],
            'allocation_method' => ['required', $this->referenceRule('cost_allocation_method')],
            'responsible_user_id' => ['nullable', 'exists:users,id'],
            'description' => ['nullable', 'string'],
            'active' => ['nullable', 'boolean'],
        ]);

        $old = $center->toArray();
        $center->update([...$data, 'active' => $request->boolean('active')]);
        $this->audit('finance.cost_center.updated', $center, $old, $center->fresh()->toArray());

        return back()->with('success', __('finance.cost_center_updated'));
    }

    public function assignCenterResources(Request $request, CostCenter $center): RedirectResponse
    {
        $data = $request->validate([
            'production_line_ids' => ['nullable', 'array'],
            'production_line_ids.*' => ['uuid', 'exists:production_lines,id'],
            'machine_ids' => ['nullable', 'array'],
            'machine_ids.*' => ['uuid', 'exists:machines,id'],
        ]);

        $lineIds = array_values(array_unique($data['production_line_ids'] ?? []));
        $machineIds = array_values(array_unique($data['machine_ids'] ?? []));
        $validLineCount = ProductionLine::query()->whereIn('id', $lineIds)
            ->whereHas('site', fn ($query) => $query->where('company_id', $center->company_id))->count();
        $validMachineCount = Machine::query()->whereIn('id', $machineIds)
            ->whereHas('site', fn ($query) => $query->where('company_id', $center->company_id))->count();
        if ($validLineCount !== count($lineIds) || $validMachineCount !== count($machineIds)) {
            throw ValidationException::withMessages(['resources' => __('finance.resource_company_mismatch')]);
        }

        DB::transaction(function () use ($center, $lineIds, $machineIds): void {
            ProductionLine::where('cost_center_id', $center->id)->update(['cost_center_id' => null]);
            Machine::where('cost_center_id', $center->id)->update(['cost_center_id' => null]);
            ProductionLine::whereIn('id', $lineIds)->update(['cost_center_id' => $center->id]);
            Machine::whereIn('id', $machineIds)->update(['cost_center_id' => $center->id]);
        });

        $this->audit('finance.cost_center.resources_assigned', $center, null, $data);

        return back()->with('success', __('finance.resources_assigned'));
    }

    public function storeRate(Request $request, CostCenter $center): RedirectResponse
    {
        $data = $request->validate([
            'rate_type' => ['required', $this->referenceRule('cost_rate_type')],
            'hourly_rate' => ['required', 'numeric', 'gte:0'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'valid_from' => ['required', 'date'],
            'valid_to' => ['nullable', 'date', 'after_or_equal:valid_from'],
            'notes' => ['nullable', 'string'],
            'active' => ['nullable', 'boolean'],
        ]);

        if ($data['currency_code'] !== $center->company->currency_code) {
            throw ValidationException::withMessages(['currency_code' => __('finance.currency_must_match_company')]);
        }

        $rate = $center->rates()->create([...$data, 'active' => $request->boolean('active', true)]);
        $this->audit('finance.cost_center_rate.created', $rate, null, $rate->toArray());

        return back()->with('success', __('finance.rate_created'));
    }

    public function storeScenario(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'code' => ['required', 'string', 'max:80', Rule::unique('cost_scenarios')->where('company_id', $request->input('company_id'))],
            'name' => ['required', 'string', 'max:255'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'valid_from' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $company = Company::findOrFail($data['company_id']);
        if ($data['currency_code'] !== $company->currency_code) {
            throw ValidationException::withMessages(['currency_code' => __('finance.currency_must_match_company')]);
        }

        $scenario = CostScenario::create([...$data, 'created_by' => auth()->id()]);
        $this->audit('finance.cost_scenario.created', $scenario, null, $scenario->toArray());

        return redirect()->route('finance.control.index', ['tab' => 'scenarios', 'scenario' => $scenario->id, 'company_id' => $scenario->company_id])
            ->with('success', __('finance.scenario_created'));
    }

    public function storeScenarioLine(Request $request, CostScenario $scenario, ManagementControlService $service): RedirectResponse
    {
        abort_unless($scenario->status !== 'APPROVED', 409, __('finance.approved_scenario_locked'));
        $data = $request->validate([
            'item_id' => ['required', Rule::exists('items', 'id')->where('item_type', 'FINISHED_GOOD')->where('active', true)],
            'recipe_version_id' => ['nullable', 'exists:recipe_versions,id'],
            'planned_quantity' => ['required', 'numeric', 'gt:0'],
            'sales_unit_price' => ['required', 'numeric', 'gte:0'],
            'material_adjustment_percentage' => ['nullable', 'numeric', 'between:-100,1000'],
            'conversion_adjustment_percentage' => ['nullable', 'numeric', 'between:-100,1000'],
            'overhead_adjustment_percentage' => ['nullable', 'numeric', 'between:-100,1000'],
        ]);

        if (! empty($data['recipe_version_id'])) {
            $recipeMatchesItem = RecipeVersion::query()->whereKey($data['recipe_version_id'])
                ->where('status', 'APPROVED')
                ->whereHas('recipe', fn ($query) => $query->where('finished_item_id', $data['item_id']))
                ->exists();
            if (! $recipeMatchesItem) {
                throw ValidationException::withMessages(['recipe_version_id' => __('finance.recipe_product_mismatch')]);
            }
        }

        $line = $scenario->lines()->create([
            ...$data,
            'material_adjustment_percentage' => $data['material_adjustment_percentage'] ?? 0,
            'conversion_adjustment_percentage' => $data['conversion_adjustment_percentage'] ?? 0,
            'overhead_adjustment_percentage' => $data['overhead_adjustment_percentage'] ?? 0,
        ]);
        $service->recalculateScenarioLine($line);
        $service->recalculateScenario($scenario, auth()->id());
        $this->audit('finance.cost_scenario.line_created', $line, null, $line->fresh()->toArray());

        return back()->with('success', __('finance.scenario_line_created'));
    }

    public function destroyScenarioLine(CostScenario $scenario, CostScenarioLine $line, ManagementControlService $service): RedirectResponse
    {
        abort_unless($line->cost_scenario_id === $scenario->id, 404);
        abort_unless($scenario->status !== 'APPROVED', 409, __('finance.approved_scenario_locked'));
        $old = $line->toArray();
        $line->delete();
        $service->recalculateScenario($scenario, auth()->id());
        $this->audit('finance.cost_scenario.line_deleted', $line, $old, null);

        return back()->with('success', __('finance.scenario_line_deleted'));
    }

    public function calculateScenario(CostScenario $scenario, ManagementControlService $service): RedirectResponse
    {
        abort_unless($scenario->status !== 'APPROVED', 409, __('finance.approved_scenario_locked'));
        $service->recalculateScenario($scenario, auth()->id());
        $this->audit('finance.cost_scenario.calculated', $scenario, null, $scenario->fresh()->toArray());

        return back()->with('success', __('finance.scenario_calculated'));
    }

    public function approveScenario(CostScenario $scenario): RedirectResponse
    {
        abort_unless($scenario->status === 'CALCULATED', 409, __('finance.scenario_must_be_calculated'));
        $scenario->update(['status' => 'APPROVED']);
        $this->audit('finance.cost_scenario.approved', $scenario, null, $scenario->fresh()->toArray());

        return back()->with('success', __('finance.scenario_approved'));
    }

    public function storeBudget(Request $request, ManagementControlService $service): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'cost_center_id' => ['nullable', 'exists:cost_centers,id'],
            'fiscal_year' => ['required', 'integer', 'between:2020,2100'],
            'period' => ['required', 'integer', 'between:0,12'],
            'category_code' => ['required', $this->referenceRule('budget_category')],
            'budget_amount' => ['required', 'numeric', 'gte:0'],
            'currency_code' => ['required', 'exists:currencies,code'],
            'notes' => ['nullable', 'string'],
        ]);

        $budgetQuery = ManagementBudget::query()
            ->where('company_id', $data['company_id'])
            ->where('fiscal_year', $data['fiscal_year'])
            ->where('period', $data['period'])
            ->where('category_code', $data['category_code']);
        $costCenterId = $data['cost_center_id'] ?? null;
        $costCenterId
            ? $budgetQuery->where('cost_center_id', $costCenterId)
            : $budgetQuery->whereNull('cost_center_id');

        $company = Company::findOrFail($data['company_id']);
        if ($data['currency_code'] !== $company->currency_code) {
            throw ValidationException::withMessages(['currency_code' => __('finance.currency_must_match_company')]);
        }
        if (! empty($data['cost_center_id']) && ! CostCenter::query()->whereKey($data['cost_center_id'])->where('company_id', $company->id)->exists()) {
            throw ValidationException::withMessages(['cost_center_id' => __('finance.cost_center_company_mismatch')]);
        }

        $budget = $budgetQuery->firstOrNew();
        abort_if($budget->exists && $budget->status === 'APPROVED', 409, __('finance.approved_budget_locked'));
        $budget->fill([...$data, 'created_by' => $budget->created_by ?: auth()->id(), 'status' => $budget->status ?: 'DRAFT']);
        $budget->save();
        $service->refreshBudget($budget);
        $this->audit('finance.budget.created', $budget, null, $budget->fresh()->toArray());

        return redirect()->route('finance.control.index', ['tab' => 'budgets', 'year' => $budget->fiscal_year, 'company_id' => $budget->company_id])
            ->with('success', __('finance.budget_created'));
    }

    public function refreshBudget(ManagementBudget $budget, ManagementControlService $service): RedirectResponse
    {
        $old = $budget->toArray();
        $service->refreshBudget($budget);
        $this->audit('finance.budget.refreshed', $budget, $old, $budget->fresh()->toArray());

        return back()->with('success', __('finance.budget_refreshed'));
    }

    public function approveBudget(ManagementBudget $budget): RedirectResponse
    {
        $budget->update(['status' => 'APPROVED', 'approved_by' => auth()->id(), 'approved_at' => now()]);
        $this->audit('finance.budget.approved', $budget, null, $budget->fresh()->toArray());

        return back()->with('success', __('finance.budget_approved'));
    }

    private function references(string $domain)
    {
        return ReferenceValue::query()->where('domain', $domain)->where('active', true)->orderBy('sort_order')->get();
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query->where('domain', $domain)->where('active', true));
    }

    private function audit(string $event, object $model, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $old ? json_encode($old) : null,
            'new_values' => $new ? json_encode($new) : null,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
