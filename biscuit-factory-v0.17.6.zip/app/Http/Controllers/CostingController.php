<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\ProductionCostEntry;
use App\Models\ProductionOrder;
use App\Models\RecipeVersion;
use App\Services\Production\ProductionCostService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CostingController extends Controller
{
    public function index(ProductionCostService $costing): View
    {
        $versions = RecipeVersion::query()
            ->with(['recipe.finishedItem.baseUnit', 'lines.ingredient.baseUnit', 'costComponents'])
            ->where('status', 'APPROVED')
            ->orderByDesc('approved_at')
            ->paginate(25);

        $versions->getCollection()->transform(function (RecipeVersion $version) use ($costing): RecipeVersion {
            $version->setAttribute('cost_summary', $costing->theoretical($version));

            return $version;
        });

        return view('production.costing.index', [
            'versions' => $versions,
            'recentActualCosts' => \App\Models\CostCalculation::query()
                ->with(['productionOrder.item', 'recipeVersion.recipe'])
                ->where('calculation_type', 'ACTUAL')->latest('calculated_at')->limit(10)->get(),
            'currencyCode' => $this->currencyCode(),
        ]);
    }

    public function snapshotTheoretical(RecipeVersion $version, ProductionCostService $costing): RedirectResponse
    {
        $calculation = $costing->storeTheoretical($version, auth()->id());
        $this->audit('production.cost.theoretical_saved', $calculation, null, $calculation->toArray());

        return back()->with('success', __('production.theoretical_cost_saved'));
    }

    public function storeEntry(Request $request, ProductionOrder $order): RedirectResponse
    {
        abort_unless(in_array($order->status, ['PLANNED', 'IN_PROGRESS'], true), 409, __('production.cost_entry_locked'));
        $data = $request->validate([
            'cost_type' => ['required', $this->referenceRule('cost_type')],
            'label' => ['required', 'string', 'max:255'],
            'calculation_basis' => ['required', $this->referenceRule('cost_basis')],
            'quantity' => ['nullable', 'numeric', 'gte:0'],
            'unit_id' => ['nullable', 'exists:units,id'],
            'unit_cost' => ['nullable', 'numeric', 'gte:0'],
            'percentage' => ['nullable', 'numeric', 'between:0,100'],
            'notes' => ['nullable', 'string'],
        ]);
        if ($data['calculation_basis'] === 'PERCENTAGE' && ! isset($data['percentage'])) {
            throw ValidationException::withMessages(['percentage' => __('production.percentage_required')]);
        }
        $entry = $order->costEntries()->create(array_merge($data, [
            'quantity' => $data['quantity'] ?? 1,
            'unit_cost' => $data['unit_cost'] ?? 0,
            'currency_code' => $this->currencyCode(),
            'created_by' => auth()->id(),
        ]));
        $this->audit('production.cost.actual_entry_created', $entry, null, $entry->toArray());

        return back()->with('success', __('production.actual_cost_added'));
    }

    public function destroyEntry(ProductionOrder $order, ProductionCostEntry $entry): RedirectResponse
    {
        abort_unless($entry->production_order_id === $order->id, 404);
        abort_unless(in_array($order->status, ['PLANNED', 'IN_PROGRESS'], true), 409, __('production.cost_entry_locked'));
        $old = $entry->toArray();
        $entry->delete();
        $this->audit('production.cost.actual_entry_deleted', $entry, $old, null);

        return back()->with('success', __('production.actual_cost_removed'));
    }

    public function snapshotActual(ProductionOrder $order, ProductionCostService $costing): RedirectResponse
    {
        abort_unless($order->status === 'COMPLETED', 409, __('production.order_not_completed'));
        $calculation = $costing->storeActual($order, auth()->id());
        $this->audit('production.cost.actual_saved', $calculation, null, $calculation->toArray());

        return back()->with('success', __('production.actual_cost_saved'));
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query
            ->where('domain', $domain)->where('active', true));
    }

    private function currencyCode(): string
    {
        return Company::where('active', true)->orderBy('created_at')->value('currency_code') ?? 'DZD';
    }

    private function audit(string $event, object $model, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $old ? json_encode($old) : null,
            'new_values' => $new ? json_encode($new) : null,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
