<?php

namespace App\Http\Controllers;

use App\Support\MasterDataRegistry;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MasterDataController extends Controller
{
    public function __invoke(Request $request, string $resource): View
    {
        $configuration = MasterDataRegistry::get($resource);

        abort_unless(
            $request->user()?->hasPermission($configuration['module'].'.view'),
            403,
            __('messages.forbidden'),
        );

        return view('admin.master-data', compact('resource', 'configuration'));
    }
}
