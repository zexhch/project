<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\ReportRun;
use App\Models\ReportSchedule;
use App\Models\Site;
use App\Services\Reporting\CsvReportExporter;
use App\Services\Reporting\ReportCatalog;
use App\Services\Reporting\ReportFilter;
use App\Services\Reporting\ReportingService;
use App\Services\Reporting\ReportScheduleCalculator;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ReportController extends Controller
{
    public function index(Request $request, ReportCatalog $catalog): RedirectResponse
    {
        return redirect()->route('reports.show', $catalog->defaultFor($request->user()));
    }

    public function show(Request $request, string $reportCode, ReportCatalog $catalog, ReportingService $reports): View
    {
        $definition = $catalog->definitionFor($request->user(), $reportCode);
        $filter = ReportFilter::fromRequest($request);

        return view('reports.show', $this->viewData($request, $catalog, $reportCode, $definition, $filter, $reports->build($reportCode, $filter)));
    }

    public function print(Request $request, string $reportCode, ReportCatalog $catalog, ReportingService $reports): View
    {
        $definition = $catalog->definitionFor($request->user(), $reportCode);
        $filter = ReportFilter::fromRequest($request);

        return view('reports.print', $this->viewData($request, $catalog, $reportCode, $definition, $filter, $reports->build($reportCode, $filter)));
    }

    public function exportCsv(Request $request, string $reportCode, ReportCatalog $catalog, ReportingService $reports, CsvReportExporter $exporter)
    {
        $catalog->definitionFor($request->user(), $reportCode);
        $filter = ReportFilter::fromRequest($request);
        $report = $reports->build($reportCode, $filter);
        $filename = sprintf('%s-%s-%s.csv', $reportCode, $filter->from->toDateString(), $filter->to->toDateString());

        return $exporter->stream($report, $filename);
    }

    public function schedules(Request $request, ReportCatalog $catalog): View
    {
        return view('reports.schedules', [
            'catalog' => $catalog->availableFor($request->user()),
            'companies' => Company::query()->where('active', true)->orderBy('name')->get(),
            'sites' => Site::query()->where('active', true)->with('company:id,name')->orderBy('name')->get(),
            'schedules' => ReportSchedule::query()->where('user_id', $request->user()->id)->with(['company:id,name', 'site:id,name', 'runs' => fn ($query) => $query->limit(3)])->latest()->get(),
            'runs' => ReportRun::query()->where('user_id', $request->user()->id)->latest()->limit(20)->get(),
        ]);
    }

    public function storeSchedule(Request $request, ReportCatalog $catalog, ReportScheduleCalculator $calculator): RedirectResponse
    {
        $available = $catalog->availableFor($request->user())->keys()->all();
        $data = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'report_code' => ['required', Rule::in($available)],
            'frequency' => ['required', Rule::in(['DAILY', 'WEEKLY', 'MONTHLY'])],
            'run_time' => ['required', 'date_format:H:i'],
            'weekday' => ['nullable', 'required_if:frequency,WEEKLY', 'integer', 'between:1,7'],
            'month_day' => ['nullable', 'required_if:frequency,MONTHLY', 'integer', 'between:1,28'],
            'relative_period' => ['required', Rule::in(['TODAY', 'LAST_7_DAYS', 'LAST_30_DAYS', 'THIS_MONTH', 'LAST_MONTH', 'YEAR_TO_DATE'])],
            'company_id' => ['nullable', 'uuid', 'exists:companies,id'],
            'site_id' => ['nullable', 'uuid', 'exists:sites,id'],
        ]);

        if (! empty($data['site_id']) && ! empty($data['company_id'])) {
            abort_unless(Site::query()->whereKey($data['site_id'])->where('company_id', $data['company_id'])->exists(), 422, __('reports.site_company_mismatch'));
        }

        $schedule = new ReportSchedule([
            ...collect($data)->except('relative_period')->all(),
            'user_id' => $request->user()->id,
            'format' => 'CSV',
            'filters' => ['relative_period' => $data['relative_period']],
            'active' => true,
        ]);
        $schedule->next_run_at = $calculator->next($schedule->toArray());
        $schedule->save();

        return back()->with('success', __('reports.schedule_created'));
    }

    public function toggleSchedule(Request $request, ReportSchedule $reportSchedule, ReportScheduleCalculator $calculator): RedirectResponse
    {
        $this->assertOwner($request, $reportSchedule->user_id);
        $active = ! $reportSchedule->active;
        $reportSchedule->update([
            'active' => $active,
            'next_run_at' => $active ? $calculator->next($reportSchedule) : null,
        ]);

        return back()->with('success', __('reports.schedule_updated'));
    }

    public function destroySchedule(Request $request, ReportSchedule $reportSchedule): RedirectResponse
    {
        $this->assertOwner($request, $reportSchedule->user_id);
        $reportSchedule->delete();

        return back()->with('success', __('reports.schedule_deleted'));
    }

    public function downloadRun(Request $request, ReportRun $reportRun)
    {
        $this->assertOwner($request, $reportRun->user_id);
        abort_unless($reportRun->status === 'COMPLETED' && $reportRun->file_disk && $reportRun->file_path, 404);
        abort_unless(Storage::disk($reportRun->file_disk)->exists($reportRun->file_path), 404);

        return Storage::disk($reportRun->file_disk)->download($reportRun->file_path, $reportRun->report_code.'-'.$reportRun->period_from->toDateString().'-'.$reportRun->period_to->toDateString().'.csv');
    }

    private function viewData(Request $request, ReportCatalog $catalog, string $reportCode, array $definition, ReportFilter $filter, array $report): array
    {
        return [
            'reportCode' => $reportCode,
            'definition' => $definition,
            'catalog' => $catalog->availableFor($request->user()),
            'filter' => $filter,
            'report' => $report,
            'companies' => Company::query()->where('active', true)->orderBy('name')->get(),
            'sites' => Site::query()->where('active', true)->orderBy('name')->get(),
            'currency' => Company::query()->when($filter->companyId, fn ($query) => $query->whereKey($filter->companyId))->value('currency_code') ?: 'DZD',
        ];
    }

    private function assertOwner(Request $request, ?string $ownerId): void
    {
        abort_unless($ownerId === $request->user()->id || $request->user()->hasRole('ADMINISTRATOR'), 403);
    }
}
