<?php

namespace App\Http\Controllers;

use App\Models\BackupRun;
use App\Models\BackupSchedule;
use App\Models\User;
use App\Services\Operations\BackupScheduleService;
use App\Services\Operations\BackupService;
use App\Services\Operations\OperationsStatusService;
use App\Services\Security\SecurityAuditService;
use App\Services\Security\SecurityPolicyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class OperationsController extends Controller
{
    public function index(
        OperationsStatusService $status,
        SecurityPolicyService $policy,
    ): View {
        return view('admin.operations.index', [
            'status' => $status->dashboard(),
            'policy' => $policy->all(),
            'schedules' => BackupSchedule::query()->with('notificationUser')->latest()->get(),
            'runs' => BackupRun::query()->with('schedule', 'initiator')->latest('started_at')->limit(25)->get(),
            'users' => User::query()->where('active', true)->orderBy('name')->get(['id', 'name', 'email']),
            'sessions' => DB::table('sessions')
                ->leftJoin('users', 'users.id', '=', 'sessions.user_id')
                ->whereNotNull('sessions.user_id')
                ->orderByDesc('sessions.last_activity')
                ->limit(50)
                ->get(['sessions.id', 'sessions.user_id', 'sessions.ip_address', 'sessions.user_agent', 'sessions.last_activity', 'users.name as user_name', 'users.email as user_email']),
            'lockedAccounts' => User::query()->whereNotNull('locked_until')->where('locked_until', '>', now())->orderBy('locked_until')->get(),
        ]);
    }

    public function updatePolicy(
        Request $request,
        SecurityPolicyService $policy,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $data = $request->validate([
            'password_min_length' => ['required', 'integer', 'min:8', 'max:128'],
            'password_require_uppercase' => ['nullable', 'boolean'],
            'password_require_lowercase' => ['nullable', 'boolean'],
            'password_require_number' => ['nullable', 'boolean'],
            'password_require_symbol' => ['nullable', 'boolean'],
            'password_max_age_days' => ['required', 'integer', 'min:0', 'max:730'],
            'login_max_attempts' => ['required', 'integer', 'min:3', 'max:20'],
            'login_lock_minutes' => ['required', 'integer', 'min:1', 'max:1440'],
            'session_idle_minutes' => ['required', 'integer', 'min:15', 'max:1440'],
            'audit_retention_days' => ['required', 'integer', 'min:30', 'max:3650'],
            'health_snapshot_retention_days' => ['required', 'integer', 'min:7', 'max:365'],
        ]);

        foreach (['password_require_uppercase', 'password_require_lowercase', 'password_require_number', 'password_require_symbol'] as $key) {
            $data[$key] = $request->boolean($key);
        }

        $policy->update($data);
        $audit->record('security.policy.updated', $request->user(), 'warning', ['keys' => array_keys($data)]);

        return back()->with('status', __('operations.security_policy_updated'));
    }

    public function unlockUser(Request $request, User $user, SecurityAuditService $audit): RedirectResponse
    {
        $user->forceFill(['failed_login_attempts' => 0, 'locked_until' => null])->save();
        $audit->record('security.account.unlocked', $request->user(), 'warning', ['target_user_id' => $user->id], $user);

        return back()->with('status', __('operations.user_unlocked'));
    }

    public function revokeSession(Request $request, string $sessionId, SecurityAuditService $audit): RedirectResponse
    {
        $session = DB::table('sessions')->where('id', $sessionId)->first();
        abort_unless($session, 404);
        abort_if(hash_equals($request->session()->getId(), $sessionId), 422, __('security.current_session_cannot_revoke'));

        DB::table('sessions')->where('id', $sessionId)->delete();
        $audit->record('security.session.admin_revoked', $request->user(), 'warning', [
            'target_user_id' => $session->user_id,
            'session_id' => hash('sha256', $sessionId),
        ]);

        return back()->with('status', __('security.session_revoked'));
    }

    public function storeSchedule(
        Request $request,
        BackupScheduleService $scheduleService,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'frequency' => ['required', 'in:DAILY,WEEKLY,MONTHLY'],
            'run_hour' => ['required', 'integer', 'min:0', 'max:23'],
            'weekday' => ['nullable', 'integer', 'min:0', 'max:6'],
            'month_day' => ['nullable', 'integer', 'min:1', 'max:28'],
            'retention_days' => ['required', 'integer', 'min:1', 'max:3650'],
            'notification_user_id' => ['nullable', 'exists:users,id'],
        ]);
        $data['include_files'] = $request->boolean('include_files');
        $data['active'] = true;
        $data['created_by'] = $request->user()->id;
        $data['next_run_at'] = $scheduleService->nextRun($data);

        $schedule = BackupSchedule::query()->create($data);
        $audit->record('operations.backup_schedule.created', $request->user(), 'notice', ['schedule_id' => $schedule->id]);

        return back()->with('status', __('operations.backup_schedule_created'));
    }

    public function toggleSchedule(
        Request $request,
        BackupSchedule $backupSchedule,
        BackupScheduleService $scheduleService,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $active = ! $backupSchedule->active;
        $backupSchedule->update([
            'active' => $active,
            'next_run_at' => $active ? $scheduleService->nextRun($backupSchedule) : null,
        ]);
        $audit->record('operations.backup_schedule.toggled', $request->user(), 'notice', [
            'schedule_id' => $backupSchedule->id,
            'active' => $active,
        ], $backupSchedule);

        return back()->with('status', __('operations.backup_schedule_updated'));
    }

    public function destroySchedule(
        Request $request,
        BackupSchedule $backupSchedule,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $scheduleId = $backupSchedule->id;
        $scheduleName = $backupSchedule->name;
        $backupSchedule->delete();
        $audit->record('operations.backup_schedule.deleted', $request->user(), 'warning', [
            'schedule_id' => $scheduleId,
            'name' => $scheduleName,
        ]);

        return back()->with('status', __('operations.backup_schedule_deleted'));
    }

    public function runBackup(
        Request $request,
        BackupService $backups,
        SecurityAuditService $audit,
    ): RedirectResponse {
        $audit->record('operations.backup.manual_requested', $request->user(), 'notice');
        $run = $backups->run(null, $request->user()->id);

        return back()->with($run->status === 'COMPLETED' ? 'status' : 'error',
            $run->status === 'COMPLETED' ? __('operations.backup_completed') : __('operations.backup_failed'));
    }

    public function downloadBackup(
        Request $request,
        BackupRun $backupRun,
        SecurityAuditService $audit,
    ): BinaryFileResponse {
        abort_unless($backupRun->status === 'COMPLETED' && $backupRun->path, 404);
        abort_unless(Storage::disk($backupRun->disk ?: 'local')->exists($backupRun->path), 404);
        $audit->record('operations.backup.downloaded', $request->user(), 'notice', [
            'backup_run_id' => $backupRun->id,
            'checksum_sha256' => $backupRun->checksum_sha256,
        ], $backupRun);

        return response()->download(Storage::disk($backupRun->disk ?: 'local')->path($backupRun->path));
    }
}
