<?php

namespace App\Http\Controllers;

use App\Models\AccountingPeriod;
use App\Models\ApprovalRequest;
use App\Models\ApprovalWorkflow;
use App\Models\Company;
use App\Models\CustomerInvoice;
use App\Models\DocumentNumberSequence;
use App\Models\DocumentRevision;
use App\Models\DocumentTemplate;
use App\Models\Role;
use App\Models\SupplierInvoice;
use App\Services\Finance\Governance\AccountingPeriodService;
use App\Services\Finance\Governance\ApprovalService;
use App\Services\Finance\Governance\DocumentCancellationService;
use App\Services\Finance\Governance\DocumentTemplateService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class FinancialGovernanceController extends Controller
{
    public function index(Request $request, AccountingPeriodService $periods): View
    {
        $companies = Company::query()->where('active', true)->orderBy('name')->get();
        $companyId = $companies->contains('id', $request->string('company_id')->toString())
            ? $request->string('company_id')->toString()
            : $companies->first()?->id;
        $year = max(2020, min(2100, $request->integer('year', now()->year)));

        $accountingPeriods = AccountingPeriod::query()->with(['closer', 'reopener'])
            ->when($companyId, fn ($query) => $query->where('company_id', $companyId))
            ->where('fiscal_year', $year)->orderBy('period')->get();

        $periodBlockers = $accountingPeriods->mapWithKeys(fn (AccountingPeriod $period): array => [
            $period->id => $period->status === 'OPEN' ? $periods->blockers($period) : ($period->closing_snapshot['blockers'] ?? []),
        ]);

        return view('finance.governance.index', [
            'companies' => $companies,
            'selectedCompanyId' => $companyId,
            'year' => $year,
            'periods' => $accountingPeriods,
            'periodBlockers' => $periodBlockers,
            'sequences' => DocumentNumberSequence::query()->when($companyId, fn ($query) => $query->where('company_id', $companyId))->orderBy('document_type')->orderByDesc('fiscal_year')->orderByDesc('period')->get(),
            'workflows' => ApprovalWorkflow::query()->with('levels')->when($companyId, fn ($query) => $query->where('company_id', $companyId))->orderBy('document_type')->orderBy('minimum_amount')->get(),
            'approvalRequests' => ApprovalRequest::query()->with(['workflow', 'steps', 'submitter', 'approvable'])->when($companyId, fn ($query) => $query->where('company_id', $companyId))->latest('submitted_at')->limit(100)->get(),
            'templates' => DocumentTemplate::query()->with('company')->where(fn ($query) => $query->where('company_id', $companyId)->orWhereNull('company_id'))->orderBy('document_type')->orderBy('locale')->get(),
            'revisions' => DocumentRevision::query()->with('user')->when($companyId, fn ($query) => $query->where('company_id', $companyId))->latest('created_at')->limit(100)->get(),
            'documentTypes' => FinancialDocumentCatalog::all(),
            'approvalDocumentTypes' => FinancialDocumentCatalog::approvalTypes(),
            'roles' => Role::query()->where('active', true)->orderBy('name')->get(),
        ]);
    }

    public function generatePeriods(Request $request, AccountingPeriodService $service): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'fiscal_year' => ['required', 'integer', 'between:2020,2100'],
        ]);
        $created = $service->generateYear($data['company_id'], (int) $data['fiscal_year']);

        return back()->with('success', __('governance.periods_generated', ['count' => $created]));
    }

    public function closePeriod(Request $request, AccountingPeriod $period, AccountingPeriodService $service): RedirectResponse
    {
        $data = $request->validate([
            'reason' => ['required', 'string', 'min:5', 'max:2000'],
            'force' => ['nullable', 'boolean'],
        ]);
        $service->close($period, auth()->id(), $data['reason'], $request->boolean('force'));

        return back()->with('success', __('governance.period_closed'));
    }

    public function reopenPeriod(Request $request, AccountingPeriod $period, AccountingPeriodService $service): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->reopen($period, auth()->id(), $data['reason']);

        return back()->with('success', __('governance.period_reopened'));
    }

    public function storeSequence(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'document_type' => ['required', Rule::in(array_keys(FinancialDocumentCatalog::all()))],
            'prefix' => ['required', 'string', 'max:20', 'regex:/^[A-Z0-9_-]+$/'],
            'pattern' => ['required', 'string', 'max:120', 'regex:/\{NUMBER\}/'],
            'reset_policy' => ['required', Rule::in(['ANNUAL', 'MONTHLY', 'NEVER'])],
            'fiscal_year' => ['nullable', 'integer', 'between:0,2100'],
            'period' => ['nullable', 'integer', 'between:0,12'],
            'next_number' => ['required', 'integer', 'min:1'],
            'padding' => ['required', 'integer', 'between:1,18'],
            'active' => ['nullable', 'boolean'],
        ]);

        [$year, $period] = match ($data['reset_policy']) {
            'NEVER' => [0, 0],
            'MONTHLY' => [(int) ($data['fiscal_year'] ?: now()->year), (int) ($data['period'] ?: now()->month)],
            default => [(int) ($data['fiscal_year'] ?: now()->year), 0],
        };

        DocumentNumberSequence::query()->updateOrCreate(
            ['company_id' => $data['company_id'], 'document_type' => $data['document_type'], 'fiscal_year' => $year, 'period' => $period],
            collect($data)->except(['fiscal_year', 'period'])->merge(['fiscal_year' => $year, 'period' => $period, 'active' => $request->boolean('active', true)])->all(),
        );

        return back()->with('success', __('governance.sequence_saved'));
    }

    public function storeWorkflow(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'exists:companies,id'],
            'code' => ['required', 'string', 'max:80', 'regex:/^[A-Z0-9_-]+$/'],
            'name' => ['required', 'string', 'max:255'],
            'document_type' => ['required', Rule::in(array_keys(FinancialDocumentCatalog::approvalTypes()))],
            'minimum_amount' => ['required', 'numeric', 'min:0'],
            'currency_code' => ['nullable', 'exists:currencies,code'],
            'description' => ['nullable', 'string', 'max:2000'],
            'active' => ['nullable', 'boolean'],
        ]);
        ApprovalWorkflow::query()->updateOrCreate(
            ['company_id' => $data['company_id'], 'code' => $data['code']],
            [...$data, 'active' => $request->boolean('active', true)],
        );

        return back()->with('success', __('governance.workflow_saved'));
    }

    public function storeWorkflowLevel(Request $request, ApprovalWorkflow $workflow): RedirectResponse
    {
        $data = $request->validate([
            'sequence' => ['required', 'integer', 'between:1,20'],
            'name' => ['required', 'string', 'max:255'],
            'permission_code' => ['required', 'string', 'max:120'],
            'role_code' => ['nullable', 'exists:roles,code'],
            'minimum_approvals' => ['required', 'integer', 'between:1,20'],
            'amount_from' => ['nullable', 'numeric', 'min:0'],
            'amount_to' => ['nullable', 'numeric', 'gte:amount_from'],
        ]);
        $workflow->levels()->updateOrCreate(['sequence' => $data['sequence']], $data);

        return back()->with('success', __('governance.workflow_level_saved'));
    }

    public function toggleWorkflow(ApprovalWorkflow $workflow): RedirectResponse
    {
        $workflow->update(['active' => ! $workflow->active]);

        return back()->with('success', __('governance.workflow_saved'));
    }

    public function approveRequest(Request $request, ApprovalRequest $approvalRequest, ApprovalService $service): RedirectResponse
    {
        $data = $request->validate(['comment' => ['nullable', 'string', 'max:2000']]);
        $service->approve($approvalRequest, auth()->user(), $data['comment'] ?? null);

        return back()->with('success', __('governance.approval_recorded'));
    }

    public function rejectRequest(Request $request, ApprovalRequest $approvalRequest, ApprovalService $service): RedirectResponse
    {
        $data = $request->validate(['comment' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->reject($approvalRequest, auth()->user(), $data['comment']);

        return back()->with('success', __('governance.rejection_recorded'));
    }

    public function storeTemplate(Request $request, DocumentTemplateService $service): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['nullable', 'exists:companies,id'],
            'code' => ['required', 'string', 'max:80', 'regex:/^[A-Z0-9_-]+$/'],
            'name' => ['required', 'string', 'max:255'],
            'document_type' => ['required', Rule::in(array_keys(FinancialDocumentCatalog::all()))],
            'locale' => ['required', Rule::in(['fr', 'en', 'ar'])],
            'title' => ['nullable', 'string', 'max:255'],
            'header_text' => ['nullable', 'string', 'max:2000'],
            'footer_text' => ['nullable', 'string', 'max:2000'],
            'terms' => ['nullable', 'string', 'max:5000'],
            'show_company_details' => ['nullable', 'boolean'],
            'show_logo' => ['nullable', 'boolean'],
            'show_legal_identifiers' => ['nullable', 'boolean'],
            'show_bank_details' => ['nullable', 'boolean'],
            'show_line_numbers' => ['nullable', 'boolean'],
            'show_tax_rate' => ['nullable', 'boolean'],
            'show_amount_in_words' => ['nullable', 'boolean'],
            'show_internal_references' => ['nullable', 'boolean'],
            'show_status' => ['nullable', 'boolean'],
            'show_amounts_mode' => ['required', Rule::in(['DEFAULT', 'SHOW', 'HIDE'])],
            'show_signature_blocks' => ['nullable', 'boolean'],
            'is_default' => ['nullable', 'boolean'],
            'active' => ['nullable', 'boolean'],
        ]);

        $showAmounts = match ($data['show_amounts_mode']) {
            'SHOW' => true,
            'HIDE' => false,
            default => null,
        };
        unset($data['show_amounts_mode']);

        $template = DocumentTemplate::query()->updateOrCreate(
            ['company_id' => $data['company_id'] ?? null, 'code' => $data['code']],
            [...$data,
                'show_company_details' => $request->boolean('show_company_details'),
                'show_logo' => $request->boolean('show_logo'),
                'show_legal_identifiers' => $request->boolean('show_legal_identifiers'),
                'show_bank_details' => $request->boolean('show_bank_details'),
                'show_line_numbers' => $request->boolean('show_line_numbers'),
                'show_tax_rate' => $request->boolean('show_tax_rate'),
                'show_amount_in_words' => $request->boolean('show_amount_in_words'),
                'show_internal_references' => $request->boolean('show_internal_references'),
                'show_status' => $request->boolean('show_status'),
                'show_amounts' => $showAmounts,
                'show_signature_blocks' => $request->boolean('show_signature_blocks'),
                'is_default' => $request->boolean('is_default'),
                'active' => $request->boolean('active', true),
            ],
        );
        if ($template->is_default) {
            $service->setDefault($template);
        }

        return back()->with('success', __('governance.template_saved'));
    }

    public function defaultTemplate(DocumentTemplate $template, DocumentTemplateService $service): RedirectResponse
    {
        $service->setDefault($template);

        return back()->with('success', __('governance.template_defaulted'));
    }

    public function cancelCustomerInvoice(Request $request, CustomerInvoice $invoice, DocumentCancellationService $service): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->cancelCustomerInvoice($invoice, $data['reason'], auth()->id());

        return back()->with('success', __('governance.invoice_cancelled'));
    }

    public function cancelSupplierInvoice(Request $request, SupplierInvoice $invoice, DocumentCancellationService $service): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'min:5', 'max:2000']]);
        $service->cancelSupplierInvoice($invoice, $data['reason'], auth()->id());

        return back()->with('success', __('governance.invoice_cancelled'));
    }
}
