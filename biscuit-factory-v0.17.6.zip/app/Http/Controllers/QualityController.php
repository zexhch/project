<?php

namespace App\Http\Controllers;

use App\Events\DashboardUpdated;
use App\Models\HaccpControlPoint;
use App\Models\Item;
use App\Models\ItemCategory;
use App\Models\Lot;
use App\Models\ProcessStep;
use App\Models\ProductionLine;
use App\Models\ProductionOrder;
use App\Models\QualityAttachment;
use App\Models\QualityControlPlan;
use App\Models\QualityControlPlanParameter;
use App\Models\QualityCorrectiveAction;
use App\Models\QualityInspection;
use App\Models\QualityNonConformity;
use App\Models\Unit;
use App\Models\User;
use App\Notifications\SystemAlertNotification;
use App\Services\Quality\QualityInspectionService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class QualityController extends Controller
{
    public function index(Request $request): View
    {
        $status = trim((string) $request->query('status'));
        $search = trim((string) $request->query('search'));
        $inspections = QualityInspection::query()
            ->with(['plan', 'item', 'lot', 'inspector'])
            ->when($status, fn (Builder $query) => $query->where('status', $status))
            ->when($search, fn (Builder $query) => $query
                ->where(fn (Builder $nested) => $nested
                    ->where('inspection_number', 'ilike', "%{$search}%")
                    ->orWhereHas('item', fn (Builder $item) => $item
                        ->where('code', 'ilike', "%{$search}%")
                        ->orWhere('name', 'ilike', "%{$search}%"))
                    ->orWhereHas('lot', fn (Builder $lot) => $lot->where('lot_number', 'ilike', "%{$search}%"))))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('quality.index', [
            'inspections' => $inspections,
            'status' => $status,
            'search' => $search,
            'plans' => QualityControlPlan::approvedAndActive()->with('item')->orderBy('code')->get(),
            'items' => Item::where('active', true)->orderBy('name')->get(),
            'lots' => Lot::with('item')->whereIn('status', ['QUARANTINE', 'BLOCKED', 'RELEASED'])->latest()->get(),
            'productionOrders' => ProductionOrder::with('item')->latest()->limit(100)->get(),
            'lines' => ProductionLine::where('active', true)->orderBy('name')->get(),
            'statuses' => $this->references('quality_inspection_status'),
            'metrics' => [
                'pending' => QualityInspection::where('status', 'PENDING_DECISION')->count(),
                'nonconforming' => QualityInspection::where('status', 'NONCONFORMING')->count(),
                'blocked_lots' => Lot::where('status', 'BLOCKED')->count(),
                'open_nc' => QualityNonConformity::whereNotIn('status', ['CLOSED', 'CANCELLED'])->count(),
            ],
        ]);
    }

    public function plans(): View
    {
        return view('quality.plans', [
            'plans' => QualityControlPlan::with(['item', 'itemCategory', 'productionLine', 'haccpControlPoint', 'parameters.unit'])
                ->orderBy('code')->orderByDesc('version')->get(),
            'haccpPoints' => HaccpControlPoint::with(['processStep', 'productionLine'])->orderBy('code')->get(),
            'items' => Item::where('active', true)->orderBy('name')->get(),
            'categories' => ItemCategory::where('active', true)->orderBy('name')->get(),
            'lines' => ProductionLine::where('active', true)->orderBy('name')->get(),
            'steps' => ProcessStep::where('active', true)->orderBy('sequence_number')->get(),
            'units' => Unit::where('active', true)->orderBy('code')->get(),
            'roles' => DB::table('roles')->where('active', true)->orderBy('name')->get(),
            'references' => $this->referenceGroups([
                'quality_control_stage', 'quality_plan_status', 'quality_parameter_type',
                'quality_frequency', 'quality_sampling_method', 'haccp_hazard_type',
            ]),
        ]);
    }

    public function export(string $type): StreamedResponse
    {
        abort_unless(in_array($type, ['inspections', 'non-conformities'], true), 404);
        $fileName = 'quality-'.$type.'-'.now()->format('Ymd-His').'.csv';

        return response()->streamDownload(function () use ($type): void {
            $output = fopen('php://output', 'wb');
            fwrite($output, "\xEF\xBB\xBF");
            if ($type === 'inspections') {
                $this->writeCsv($output, ['inspection_number', 'plan', 'item', 'lot', 'stage', 'status', 'decision', 'inspector', 'inspected_at']);
                QualityInspection::with(['plan', 'item', 'lot', 'inspector'])->orderBy('created_at')->chunk(500, function ($inspections) use ($output): void {
                    foreach ($inspections as $inspection) {
                        $this->writeCsv($output, [
                            $inspection->inspection_number,
                            $inspection->plan->code.' v'.$inspection->plan->version,
                            $inspection->item->code,
                            $inspection->lot?->lot_number,
                            $inspection->control_stage,
                            $inspection->status,
                            $inspection->decision,
                            $inspection->inspector?->name,
                            $inspection->inspected_at?->toIso8601String(),
                        ]);
                    }
                });
            } else {
                $this->writeCsv($output, ['non_conformity_number', 'title', 'item', 'lot', 'severity', 'category', 'status', 'owner', 'due_date', 'detected_at']);
                QualityNonConformity::with(['item', 'lot', 'owner'])->orderBy('created_at')->chunk(500, function ($nonConformities) use ($output): void {
                    foreach ($nonConformities as $nonConformity) {
                        $this->writeCsv($output, [
                            $nonConformity->non_conformity_number,
                            $nonConformity->title,
                            $nonConformity->item?->code,
                            $nonConformity->lot?->lot_number,
                            $nonConformity->severity,
                            $nonConformity->category,
                            $nonConformity->status,
                            $nonConformity->owner?->name,
                            $nonConformity->due_date?->format('Y-m-d'),
                            $nonConformity->detected_at->toIso8601String(),
                        ]);
                    }
                });
            }
            fclose($output);
        }, $fileName, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function storePlan(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80'],
            'name' => ['required', 'string', 'max:255'],
            'control_stage' => ['required', $this->referenceRule('quality_control_stage')],
            'item_id' => ['nullable', 'exists:items,id'],
            'item_category_id' => ['nullable', 'exists:item_categories,id'],
            'production_line_id' => ['nullable', 'exists:production_lines,id'],
            'haccp_control_point_id' => ['nullable', 'exists:haccp_control_points,id'],
            'sampling_method' => ['required', $this->referenceRule('quality_sampling_method')],
            'sample_size' => ['required', 'numeric', 'gt:0'],
            'frequency_type' => ['required', $this->referenceRule('quality_frequency')],
            'frequency_value' => ['required', 'integer', 'min:1'],
            'instructions' => ['nullable', 'string'],
            'valid_from' => ['nullable', 'date'],
            'valid_to' => ['nullable', 'date', 'after_or_equal:valid_from'],
        ]);

        $version = ((int) QualityControlPlan::where('code', $data['code'])->max('version')) + 1;
        $plan = QualityControlPlan::create($data + [
            'version' => $version,
            'status' => 'DRAFT',
            'active' => true,
            'created_by' => auth()->id(),
        ]);
        $this->audit('quality.plan.created', $plan, null, $plan->toArray());

        return back()->with('success', __('quality.plan_created', ['version' => $version]));
    }

    public function approvePlan(QualityControlPlan $plan): RedirectResponse
    {
        abort_unless($plan->status === 'DRAFT', 409, __('quality.plan_not_draft'));
        throw_if($plan->parameters()->count() === 0, ValidationException::withMessages([
            'plan' => __('quality.plan_requires_parameter'),
        ]));

        DB::transaction(function () use ($plan): void {
            QualityControlPlan::where('code', $plan->code)
                ->where('id', '!=', $plan->id)
                ->where('status', 'APPROVED')
                ->update(['status' => 'RETIRED', 'active' => false]);
            $plan->update([
                'status' => 'APPROVED',
                'approved_by' => auth()->id(),
                'approved_at' => now(),
            ]);
            $this->audit('quality.plan.approved', $plan, ['status' => 'DRAFT'], ['status' => 'APPROVED']);
        });

        return back()->with('success', __('quality.plan_approved'));
    }

    public function addParameter(Request $request, QualityControlPlan $plan): RedirectResponse
    {
        abort_unless($plan->status === 'DRAFT', 409, __('quality.plan_not_draft'));
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', Rule::unique('quality_control_plan_parameters')->where('quality_control_plan_id', $plan->id)],
            'name' => ['required', 'string', 'max:255'],
            'data_type' => ['required', $this->referenceRule('quality_parameter_type')],
            'unit_id' => ['nullable', 'exists:units,id'],
            'minimum_value' => ['nullable', 'numeric'],
            'maximum_value' => ['nullable', 'numeric', 'gte:minimum_value'],
            'target_value' => ['nullable', 'numeric'],
            'expected_value' => ['nullable', 'string', 'max:255'],
            'options_list' => ['nullable', 'string'],
            'method' => ['nullable', 'string', 'max:255'],
            'sequence' => ['required', 'integer', 'min:1', 'max:9999'],
            'required' => ['nullable', 'boolean'],
            'critical' => ['nullable', 'boolean'],
        ]);
        $data['required'] = $request->boolean('required');
        $data['critical'] = $request->boolean('critical');
        $data['options'] = collect(explode(',', (string) ($data['options_list'] ?? '')))
            ->map(fn (string $option) => trim($option))
            ->filter()
            ->unique()
            ->values()
            ->all() ?: null;
        unset($data['options_list']);
        if ($data['data_type'] === 'SELECT' && empty($data['options'])) {
            throw ValidationException::withMessages(['options_list' => __('quality.selection_options_required')]);
        }
        if ($data['data_type'] === 'SELECT'
            && ($data['expected_value'] ?? null) !== null
            && ! in_array($data['expected_value'], $data['options'], true)) {
            throw ValidationException::withMessages(['expected_value' => __('quality.expected_value_not_in_options')]);
        }
        if ($data['data_type'] === 'NUMERIC'
            && ($data['target_value'] ?? null) !== null
            && ((($data['minimum_value'] ?? null) !== null && (float) $data['target_value'] < (float) $data['minimum_value'])
                || (($data['maximum_value'] ?? null) !== null && (float) $data['target_value'] > (float) $data['maximum_value']))) {
            throw ValidationException::withMessages(['target_value' => __('quality.target_outside_limits')]);
        }
        $parameter = $plan->parameters()->create($data);
        $this->audit('quality.plan.parameter_created', $parameter, null, $parameter->toArray());

        return back()->with('success', __('quality.parameter_added'));
    }

    public function storeHaccp(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'max:80', 'unique:haccp_control_points,code'],
            'name' => ['required', 'string', 'max:255'],
            'process_step_id' => ['nullable', 'exists:process_steps,id'],
            'production_line_id' => ['nullable', 'exists:production_lines,id'],
            'hazard_type' => ['required', $this->referenceRule('haccp_hazard_type')],
            'hazard_description' => ['required', 'string'],
            'control_measure' => ['required', 'string'],
            'critical_limits' => ['required', 'string'],
            'monitoring_method' => ['required', 'string', 'max:255'],
            'frequency_type' => ['required', $this->referenceRule('quality_frequency')],
            'frequency_value' => ['required', 'integer', 'min:1'],
            'corrective_action' => ['required', 'string'],
            'verification_method' => ['nullable', 'string'],
            'responsible_role_code' => ['nullable', 'exists:roles,code'],
        ]);
        $point = HaccpControlPoint::create($data + ['active' => true]);
        $this->audit('quality.haccp.created', $point, null, $point->toArray());

        return back()->with('success', __('quality.haccp_created'));
    }

    public function storeInspection(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'quality_control_plan_id' => ['required', 'exists:quality_control_plans,id'],
            'item_id' => ['required', 'exists:items,id'],
            'lot_id' => ['nullable', 'exists:lots,id'],
            'production_order_id' => ['nullable', 'exists:production_orders,id'],
            'production_line_id' => ['nullable', 'exists:production_lines,id'],
            'sample_reference' => ['nullable', 'string', 'max:120'],
            'sample_size' => ['required', 'numeric', 'gt:0'],
            'overall_notes' => ['nullable', 'string'],
        ]);
        $plan = QualityControlPlan::approvedAndActive()->findOrFail($data['quality_control_plan_id']);
        $item = Item::findOrFail($data['item_id']);

        if ($plan->item_id && $plan->item_id !== $item->id) {
            throw ValidationException::withMessages(['item_id' => __('quality.plan_item_mismatch')]);
        }
        if ($plan->item_category_id && $plan->item_category_id !== $item->category_id) {
            throw ValidationException::withMessages(['item_id' => __('quality.plan_category_mismatch')]);
        }
        if (! empty($data['lot_id']) && ! Lot::whereKey($data['lot_id'])->where('item_id', $item->id)->exists()) {
            throw ValidationException::withMessages(['lot_id' => __('quality.lot_item_mismatch')]);
        }
        if (! empty($data['production_order_id'])) {
            $order = ProductionOrder::findOrFail($data['production_order_id']);
            if ($order->finished_item_id !== $item->id) {
                throw ValidationException::withMessages(['production_order_id' => __('quality.production_order_item_mismatch')]);
            }
            $data['production_line_id'] ??= $order->production_line_id;
        }
        $data['production_line_id'] ??= $plan->production_line_id;
        if ($plan->production_line_id && $plan->production_line_id !== ($data['production_line_id'] ?? null)) {
            throw ValidationException::withMessages(['production_line_id' => __('quality.plan_line_mismatch')]);
        }

        $inspection = QualityInspection::create($data + [
            'inspection_number' => $this->number('CQ'),
            'control_stage' => $plan->control_stage,
            'status' => 'DRAFT',
            'inspector_id' => auth()->id(),
        ]);
        $this->audit('quality.inspection.created', $inspection, null, $inspection->toArray());

        return redirect()->route('quality.inspections.show', $inspection)->with('success', __('quality.inspection_created'));
    }

    public function showInspection(QualityInspection $inspection): View
    {
        $inspection->load([
            'plan.parameters.unit', 'plan.haccpControlPoint', 'item.baseUnit', 'lot', 'productionOrder', 'productionLine',
            'inspector', 'decisionMaker', 'results.measuredBy', 'decisions.decisionMaker',
            'nonConformities', 'attachments.uploader',
        ]);
        $results = $inspection->results->keyBy('quality_control_plan_parameter_id');

        return view('quality.inspection', compact('inspection', 'results'));
    }

    public function recordResult(
        Request $request,
        QualityInspection $inspection,
        QualityControlPlanParameter $parameter,
        QualityInspectionService $service,
    ): RedirectResponse {
        $data = $request->validate([
            'value_numeric' => ['nullable', 'numeric'],
            'value_text' => ['nullable', 'string'],
            'value_boolean' => ['nullable', 'boolean'],
            'notes' => ['nullable', 'string'],
        ]);
        $service->recordResult($inspection, $parameter, $data, (string) auth()->id());

        return back()->with('success', __('quality.result_saved'));
    }

    public function submitInspection(QualityInspection $inspection, QualityInspectionService $service): RedirectResponse
    {
        $service->submit($inspection, (string) auth()->id());

        return back()->with('success', __('quality.inspection_submitted'));
    }

    public function decideInspection(Request $request, QualityInspection $inspection, QualityInspectionService $service): RedirectResponse
    {
        $data = $request->validate([
            'decision' => ['required', Rule::in(['RELEASE', 'BLOCK', 'REJECT']), $this->referenceRule('quality_decision')],
            'reason' => ['required', 'string'],
        ]);
        $service->decide($inspection, $data['decision'], $data['reason'], (string) auth()->id());

        return back()->with('success', __('quality.decision_recorded'));
    }

    public function nonConformities(Request $request): View
    {
        $status = trim((string) $request->query('status'));

        return view('quality.non-conformities', [
            'nonConformities' => QualityNonConformity::with(['item', 'lot', 'owner'])
                ->when($status, fn (Builder $query) => $query->where('status', $status))
                ->latest('detected_at')->paginate(20)->withQueryString(),
            'status' => $status,
            'statuses' => $this->references('quality_nc_status'),
            'severities' => $this->references('quality_severity'),
            'categories' => $this->references('quality_nc_category'),
            'items' => Item::where('active', true)->orderBy('name')->get(),
            'lots' => Lot::with('item')->latest()->limit(200)->get(),
            'productionOrders' => ProductionOrder::with('item')->latest()->limit(100)->get(),
            'users' => User::where('active', true)->orderBy('name')->get(),
        ]);
    }

    public function storeNonConformity(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'lot_id' => ['nullable', 'exists:lots,id'],
            'item_id' => ['nullable', 'exists:items,id'],
            'production_order_id' => ['nullable', 'exists:production_orders,id'],
            'severity' => ['required', $this->referenceRule('quality_severity')],
            'category' => ['nullable', $this->referenceRule('quality_nc_category')],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'immediate_action' => ['nullable', 'string'],
            'owner_id' => ['nullable', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
        ]);
        if (! empty($data['lot_id'])) {
            $lot = Lot::findOrFail($data['lot_id']);
            $data['item_id'] ??= $lot->item_id;
            if ($data['item_id'] !== $lot->item_id) {
                throw ValidationException::withMessages(['item_id' => __('quality.lot_item_mismatch')]);
            }
        }
        if (! empty($data['production_order_id'])) {
            $order = ProductionOrder::findOrFail($data['production_order_id']);
            $data['item_id'] ??= $order->finished_item_id;
            if ($data['item_id'] !== $order->finished_item_id) {
                throw ValidationException::withMessages(['item_id' => __('quality.production_order_item_mismatch')]);
            }
        }
        $data['owner_id'] ??= auth()->id();
        $data['due_date'] ??= today()->addDays(max(1, $this->setting('default_due_days', 7)));

        $nonConformity = DB::transaction(function () use ($data): QualityNonConformity {
            $nonConformity = QualityNonConformity::create($data + [
                'non_conformity_number' => $this->number('NC'),
                'status' => 'OPEN',
                'detected_by' => auth()->id(),
                'detected_at' => now(),
            ]);
            if ($nonConformity->lot_id && in_array($nonConformity->severity, ['MAJOR', 'CRITICAL'], true)) {
                $lot = Lot::query()->lockForUpdate()->findOrFail($nonConformity->lot_id);
                $oldStatus = $lot->status;
                $lot->update(['status' => 'BLOCKED']);
                $this->audit(
                    'quality.lot.blocked_by_non_conformity',
                    $lot,
                    ['status' => $oldStatus],
                    ['status' => 'BLOCKED'],
                );
            }
            $this->audit('quality.non_conformity.created', $nonConformity, null, $nonConformity->toArray());

            return $nonConformity;
        });
        event(new DashboardUpdated(['quality_non_conformity_id' => $nonConformity->id]));
        if (in_array($nonConformity->severity, ['MAJOR', 'CRITICAL'], true)) {
            $this->notifyQualityManagers($nonConformity);
        }

        return redirect()->route('quality.non-conformities.show', $nonConformity)->with('success', __('quality.non_conformity_created'));
    }

    public function showNonConformity(QualityNonConformity $nonConformity): View
    {
        $nonConformity->load([
            'inspection', 'item', 'lot', 'productionOrder', 'detector', 'owner', 'closedBy',
            'actions.owner', 'actions.completedBy', 'actions.verifiedBy', 'attachments.uploader',
        ]);

        return view('quality.non-conformity', [
            'nonConformity' => $nonConformity,
            'users' => User::where('active', true)->orderBy('name')->get(),
            'actionTypes' => $this->references('quality_action_type'),
        ]);
    }

    public function updateAnalysis(Request $request, QualityNonConformity $nonConformity): RedirectResponse
    {
        abort_if(in_array($nonConformity->status, ['CLOSED', 'CANCELLED'], true), 409, __('quality.non_conformity_closed'));
        $data = $request->validate([
            'root_cause' => ['required', 'string'],
            'disposition' => ['required', 'string'],
            'owner_id' => ['required', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
        ]);
        $old = $nonConformity->only(['root_cause', 'disposition', 'owner_id', 'due_date', 'status']);
        $nextStatus = $nonConformity->status === 'OPEN' ? 'ANALYSIS' : $nonConformity->status;
        $nonConformity->update($data + ['status' => $nextStatus]);
        $this->audit('quality.non_conformity.analysed', $nonConformity, $old, $nonConformity->fresh()->toArray());

        return back()->with('success', __('quality.analysis_saved'));
    }

    public function addAction(Request $request, QualityNonConformity $nonConformity): RedirectResponse
    {
        abort_if(in_array($nonConformity->status, ['CLOSED', 'CANCELLED'], true), 409, __('quality.non_conformity_closed'));
        $data = $request->validate([
            'action_type' => ['required', $this->referenceRule('quality_action_type')],
            'description' => ['required', 'string'],
            'owner_id' => ['required', 'exists:users,id'],
            'due_date' => ['nullable', 'date'],
            'effectiveness_criteria' => ['required', 'string'],
        ]);
        $action = $nonConformity->actions()->create($data + [
            'action_number' => $this->number('AC'),
            'status' => 'OPEN',
        ]);
        $nonConformity->update(['status' => 'ACTION_PLAN']);
        $this->audit('quality.corrective_action.created', $action, null, $action->toArray());

        return back()->with('success', __('quality.action_added'));
    }

    public function completeAction(Request $request, QualityCorrectiveAction $action): RedirectResponse
    {
        abort_unless(in_array($action->status, ['OPEN', 'IN_PROGRESS'], true), 409, __('quality.action_not_open'));
        $oldStatus = $action->status;
        $data = $request->validate(['completion_notes' => ['required', 'string']]);
        $action->update($data + [
            'status' => 'COMPLETED',
            'completed_by' => auth()->id(),
            'completed_at' => now(),
        ]);
        $action->nonConformity()->update(['status' => 'VERIFYING']);
        $this->audit('quality.corrective_action.completed', $action, ['status' => $oldStatus], ['status' => 'COMPLETED']);

        return back()->with('success', __('quality.action_completed'));
    }

    public function verifyAction(Request $request, QualityCorrectiveAction $action): RedirectResponse
    {
        abort_unless($action->status === 'COMPLETED', 409, __('quality.action_not_completed'));
        $data = $request->validate(['effectiveness_result' => ['required', 'string']]);
        $action->update($data + [
            'status' => 'VERIFIED',
            'verified_by' => auth()->id(),
            'verified_at' => now(),
        ]);
        $this->audit('quality.corrective_action.verified', $action, ['status' => 'COMPLETED'], ['status' => 'VERIFIED']);

        return back()->with('success', __('quality.action_verified'));
    }

    public function closeNonConformity(QualityNonConformity $nonConformity): RedirectResponse
    {
        abort_if(in_array($nonConformity->status, ['CLOSED', 'CANCELLED'], true), 409, __('quality.non_conformity_closed'));
        throw_if(blank($nonConformity->root_cause) || blank($nonConformity->disposition), ValidationException::withMessages([
            'non_conformity' => __('quality.analysis_required_before_close'),
        ]));
        throw_if($nonConformity->actions()->doesntExist(), ValidationException::withMessages([
            'non_conformity' => __('quality.action_required_before_close'),
        ]));
        throw_if($nonConformity->actions()->where('status', '!=', 'VERIFIED')->exists(), ValidationException::withMessages([
            'non_conformity' => __('quality.actions_must_be_verified'),
        ]));

        $nonConformity->update([
            'status' => 'CLOSED',
            'closed_by' => auth()->id(),
            'closed_at' => now(),
        ]);
        $this->audit('quality.non_conformity.closed', $nonConformity, null, ['status' => 'CLOSED']);
        event(new DashboardUpdated(['quality_non_conformity_id' => $nonConformity->id, 'status' => 'CLOSED']));

        return back()->with('success', __('quality.non_conformity_closed_successfully'));
    }

    public function uploadInspectionAttachment(Request $request, QualityInspection $inspection): RedirectResponse
    {
        return $this->uploadAttachment($request, $inspection, 'quality_inspection_id');
    }

    public function uploadNonConformityAttachment(Request $request, QualityNonConformity $nonConformity): RedirectResponse
    {
        return $this->uploadAttachment($request, $nonConformity, 'quality_non_conformity_id');
    }

    public function downloadAttachment(QualityAttachment $attachment): StreamedResponse
    {
        abort_unless(Storage::disk($attachment->storage_disk)->exists($attachment->storage_path), 404);

        return Storage::disk($attachment->storage_disk)->download($attachment->storage_path, $attachment->original_name);
    }

    private function uploadAttachment(Request $request, object $parent, string $foreignKey): RedirectResponse
    {
        $maxKilobytes = max(1, min(100, $this->setting('attachment_max_mb', 10))) * 1024;
        $data = $request->validate([
            'attachment' => ['required', 'file', 'max:'.$maxKilobytes, 'mimes:pdf,jpg,jpeg,png,webp,xlsx,xls,csv,txt'],
        ]);
        $file = $data['attachment'];
        $disk = (string) config('filesystems.quality', 'local');
        $path = $file->storeAs(
            'quality/'.now()->format('Y/m'),
            Str::uuid().'.'.$file->getClientOriginalExtension(),
            $disk,
        );
        throw_if($path === false, ValidationException::withMessages(['attachment' => __('quality.attachment_store_failed')]));

        $attachment = QualityAttachment::create([
            $foreignKey => $parent->id,
            'original_name' => $file->getClientOriginalName(),
            'storage_disk' => $disk,
            'storage_path' => $path,
            'mime_type' => $file->getMimeType(),
            'size_bytes' => $file->getSize(),
            'uploaded_by' => auth()->id(),
        ]);
        $this->audit('quality.attachment.created', $attachment, null, ['original_name' => $attachment->original_name]);

        return back()->with('success', __('quality.attachment_added'));
    }

    private function referenceRule(string $domain)
    {
        return Rule::exists('reference_values', 'code')->where(fn ($query) => $query
            ->where('domain', $domain)
            ->where('active', true));
    }

    private function references(string $domain)
    {
        return DB::table('reference_values')->where('domain', $domain)->where('active', true)->orderBy('sort_order')->get();
    }

    private function referenceGroups(array $domains): array
    {
        return collect($domains)->mapWithKeys(fn (string $domain) => [$domain => $this->references($domain)])->all();
    }

    private function setting(string $key, int $default): int
    {
        $raw = DB::table('system_settings')->where('group', 'quality')->where('key', $key)->value('value');

        return (int) ($raw === null ? $default : json_decode($raw, true));
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

    private function writeCsv(mixed $output, array $values): void
    {
        fputcsv($output, array_map(function (mixed $value): string {
            $value = (string) ($value ?? '');

            return preg_match('/^[=+\-@]/', $value) ? "'".$value : $value;
        }, $values), ';', '"', '');
    }

    private function notifyQualityManagers(QualityNonConformity $nonConformity): void
    {
        User::query()->where('active', true)
            ->whereHas('roles.permissions', fn ($query) => $query->where('code', 'quality.approve'))
            ->each(fn (User $user) => $user->notify(new SystemAlertNotification(
                __('quality.non_conformity_notification_title'),
                __('quality.non_conformity_notification_message', [
                    'number' => $nonConformity->non_conformity_number,
                    'severity' => $nonConformity->severity,
                ]),
                $nonConformity->severity === 'CRITICAL' ? 'danger' : 'warning',
                route('quality.non-conformities.show', $nonConformity),
            )));
    }

    private function audit(string $event, object $model, ?array $old, ?array $new): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => auth()->id(),
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $old ? json_encode($old, JSON_THROW_ON_ERROR) : null,
            'new_values' => $new ? json_encode($new, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
