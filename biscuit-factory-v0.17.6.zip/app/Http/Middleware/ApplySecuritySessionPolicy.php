<?php

namespace App\Http\Middleware;

use App\Services\Security\SecurityPolicyService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\HttpFoundation\Response;

class ApplySecuritySessionPolicy
{
    public function __construct(private readonly SecurityPolicyService $policy)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        try {
            if (Schema::hasTable('system_settings')) {
                config(['session.lifetime' => max(15, min(1440, (int) $this->policy->get('session_idle_minutes')))]);
            }
        } catch (\Throwable) {
            // Installation ou migration en cours.
        }

        return $next($request);
    }
}
