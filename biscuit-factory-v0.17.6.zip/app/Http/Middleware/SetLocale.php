<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $fallback = config('app.locale', 'fr');
        $requested = $request->session()->get('locale', $request->user()?->locale ?? $fallback);
        $allowed = config('app.supported_locales', ['fr', 'ar', 'en']);

        try {
            if (Schema::hasTable('languages')) {
                $allowed = DB::table('languages')
                    ->where('active', true)
                    ->pluck('code')
                    ->all();
            }
        } catch (\Throwable) {
            // La base peut ne pas encore être migrée.
        }

        $locale = in_array($requested, $allowed, true) ? $requested : $fallback;

        App::setLocale($locale);

        return $next($request);
    }
}
