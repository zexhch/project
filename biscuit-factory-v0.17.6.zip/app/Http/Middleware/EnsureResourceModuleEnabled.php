<?php

namespace App\Http\Middleware;

use App\Services\Modules\ModuleRegistry;
use App\Support\MasterDataRegistry;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureResourceModuleEnabled
{
    public function __construct(private readonly ModuleRegistry $modules)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $resource = (string) $request->route('resource');
        $definition = MasterDataRegistry::get($resource);
        $module = MasterDataRegistry::applicationModule($resource, $definition);

        abort_unless($this->modules->enabled($module), 404, __('modules.disabled_access'));

        return $next($request);
    }
}
