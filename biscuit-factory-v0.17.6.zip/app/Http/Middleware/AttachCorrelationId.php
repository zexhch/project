<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class AttachCorrelationId
{
    public function handle(Request $request, Closure $next): Response
    {
        $candidate = (string) $request->headers->get('X-Request-ID', '');
        $correlationId = Str::isUuid($candidate) ? $candidate : (string) Str::uuid();

        $request->attributes->set('correlation_id', $correlationId);
        app()->instance('request.correlation_id', $correlationId);

        $response = $next($request);
        $response->headers->set('X-Request-ID', $correlationId);

        return $response;
    }
}
