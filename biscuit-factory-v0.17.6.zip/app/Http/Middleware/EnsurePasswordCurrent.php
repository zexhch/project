<?php

namespace App\Http\Middleware;

use App\Services\Security\SecurityPolicyService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\HttpFoundation\Response;

class EnsurePasswordCurrent
{
    public function __construct(private readonly SecurityPolicyService $policy)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (! $user || $request->routeIs('security.password.*', 'security.sessions.*', 'logout', 'locale.*')) {
            return $next($request);
        }

        if (! Schema::hasColumn('users', 'force_password_change')) {
            return $next($request);
        }

        if ($this->policy->requiresPasswordChange($user)) {
            return redirect()->route('security.password.edit')
                ->with('warning', __('security.password_change_required'));
        }

        return $next($request);
    }
}
