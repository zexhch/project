<?php

namespace App\Jobs;

use App\Events\WorkflowInboxUpdated;
use App\Models\DataExportRun;
use App\Notifications\SystemAlertNotification;
use App\Services\Modules\ModuleRegistry;
use App\Services\Productivity\DataExportService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Str;
use Throwable;

class GenerateDataExport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public int $timeout = 1800;

    public function __construct(public readonly string $exportRunId)
    {
        $this->onQueue('exports');
    }

    public function handle(DataExportService $service, ModuleRegistry $modules): void
    {
        $run = DataExportRun::query()->findOrFail($this->exportRunId);
        if ($run->status !== 'QUEUED') {
            return;
        }

        if (! $modules->enabled('productivity')) {
            $run->update([
                'status' => 'FAILED',
                'error_message' => __('modules.disabled_access'),
                'completed_at' => now(),
            ]);
            return;
        }

        try {
            $result = $service->generate($run);
            if ($result->user) {
                $result->user->notify(new SystemAlertNotification(
                    __('productivity.export_completed_title'),
                    __('productivity.export_completed_message', ['rows' => $result->row_count]),
                    'success',
                    route('productivity.exports.download', $result),
                    'productivity-export:'.$result->id,
                ));
                event(new WorkflowInboxUpdated($result->user->id, ['export_run_id' => $result->id]));
            }
        } catch (Throwable $exception) {
            $run->refresh();
            if ($run->status !== 'FAILED') {
                $run->update([
                    'status' => 'FAILED',
                    'error_message' => Str::limit($exception->getMessage(), 5000),
                    'completed_at' => now(),
                ]);
            }
            if ($run->user) {
                $run->user->notify(new SystemAlertNotification(
                    __('productivity.export_failed_title'),
                    __('productivity.export_failed_message', ['message' => $run->error_message ?: $exception->getMessage()]),
                    'danger',
                    route('productivity.index'),
                    'productivity-export:'.$run->id,
                ));
            }
            throw $exception;
        }
    }
}
