<?php

namespace App\Jobs;

use App\Events\WorkflowInboxUpdated;
use App\Models\DataImportJob;
use App\Notifications\SystemAlertNotification;
use App\Services\Productivity\DataImportService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

class ProcessDataImport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public int $timeout = 1800;

    public function __construct(public readonly string $importJobId)
    {
        $this->onQueue('imports');
    }

    public function handle(DataImportService $service): void
    {
        $job = DataImportJob::query()->findOrFail($this->importJobId);
        if ($job->status !== 'QUEUED') {
            return;
        }
        if (! app(\App\Services\Modules\ModuleRegistry::class)->enabled('productivity')) {
            $job->update(['status' => 'FAILED', 'error_message' => __('modules.disabled_access'), 'completed_at' => now()]);
            return;
        }
        try {
            $result = $service->process($job);
            if ($result->user) {
                $result->user->notify(new SystemAlertNotification(
                    __('productivity.import_completed_title'),
                    __('productivity.import_completed_message', ['created' => $result->created_rows, 'updated' => $result->updated_rows, 'failed' => $result->failed_rows]),
                    $result->failed_rows > 0 ? 'warning' : 'success',
                    route('productivity.imports.show', $result),
                    'productivity-import:'.$result->id,
                ));
                event(new WorkflowInboxUpdated($result->user->id, ['import_job_id' => $result->id]));
            }
        } catch (Throwable $exception) {
            $job->refresh();
            if (! in_array($job->status, ['FAILED', 'COMPLETED_WITH_ERRORS'], true)) {
                $job->update([
                    'status' => 'FAILED',
                    'error_message' => \Illuminate\Support\Str::limit($exception->getMessage(), 5000),
                    'completed_at' => now(),
                ]);
            }
            if ($job->user) {
                $job->user->notify(new SystemAlertNotification(
                    __('productivity.import_failed_title'),
                    __('productivity.import_failed_message', ['message' => $job->error_message ?: $exception->getMessage()]),
                    'danger',
                    route('productivity.imports.show', $job),
                    'productivity-import:'.$job->id,
                ));
            }
            throw $exception;
        }
    }
}
