<?php

namespace App\Providers;

use App\Models\CustomerInvoice;
use App\Models\DeliveryNote;
use App\Models\GoodsReceipt;
use App\Models\MaintenanceWorkOrder;
use App\Models\ProductionOrder;
use App\Models\ProductionPlan;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\QualityInspection;
use App\Models\QualityNonConformity;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\SupplierInvoice;
use App\Observers\DocumentRevisionObserver;
use App\Observers\WorkflowSubjectObserver;
use App\Services\Modules\ModuleRegistry;
use App\Services\Modules\ModuleRouteLoader;
use App\Services\Workflow\WorkflowInboxService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(ModuleRegistry::class);
        $this->app->singleton(ModuleRouteLoader::class);
        $this->app->scoped(WorkflowInboxService::class);
    }

    public function boot(ModuleRouteLoader $moduleRoutes): void
    {
        foreach ($moduleRoutes->migrationPaths() as $migrationPath) {
            $this->loadMigrationsFrom($migrationPath);
        }

        Model::shouldBeStrict(! app()->isProduction());
        Paginator::useBootstrapFive();

        try {
            if (Schema::hasTable('system_settings')) {
                $idleMinutes = app(\App\Services\Security\SecurityPolicyService::class)->get('session_idle_minutes');
                if (is_numeric($idleMinutes)) {
                    config(['session.lifetime' => max(15, min(1440, (int) $idleMinutes))]);
                }
            }
        } catch (\Throwable) {
            // Les migrations peuvent ne pas encore avoir été exécutées.
        }

        foreach ([
            SalesQuotation::class, SalesOrder::class, DeliveryNote::class,
            PurchaseRequisition::class, PurchaseOrder::class, GoodsReceipt::class,
            ProductionOrder::class, ProductionPlan::class, QualityInspection::class, QualityNonConformity::class,
            MaintenanceWorkOrder::class, CustomerInvoice::class, SupplierInvoice::class,
        ] as $workflowSubject) {
            $workflowSubject::observe(WorkflowSubjectObserver::class);
        }

        foreach ([
            SalesQuotation::class, SalesOrder::class, DeliveryNote::class,
            PurchaseRequisition::class, PurchaseOrder::class, GoodsReceipt::class,
        ] as $governedDocument) {
            $governedDocument::observe(DocumentRevisionObserver::class);
        }
    }
}
