<?php

return [
    'code' => 'productivity',
    'name' => 'modules.productivity_name',
    'description' => 'modules.productivity_description',
    'version' => '0.17.6',
    'icon' => 'ti-bolt',
    'order' => 105,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['productivity'],
    'dependencies' => ['core', 'administration', 'master-data'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
