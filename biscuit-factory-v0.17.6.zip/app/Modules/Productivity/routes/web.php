<?php

use App\Http\Controllers\ProductivityController;
use Illuminate\Support\Facades\Route;

Route::prefix('productivity')->name('productivity.')->group(function (): void {
    Route::get('/', [ProductivityController::class, 'index'])->middleware('permission:productivity.view')->name('index');
    Route::get('/search', [ProductivityController::class, 'search'])->middleware('permission:productivity.view')->name('search');
    Route::get('/templates/{type}.{format}', [ProductivityController::class, 'template'])->whereIn('format', ['csv', 'xlsx'])->middleware('permission:productivity.export')->name('templates.download');
    Route::post('/imports/preview', [ProductivityController::class, 'previewImport'])->middleware('permission:productivity.create')->name('imports.preview');
    Route::get('/imports/{importJob}', [ProductivityController::class, 'showImport'])->middleware('permission:productivity.view')->name('imports.show');
    Route::post('/imports/{importJob}/confirm', [ProductivityController::class, 'confirmImport'])->middleware('permission:productivity.update')->name('imports.confirm');
    Route::post('/imports/{importJob}/cancel', [ProductivityController::class, 'cancelImport'])->middleware('permission:productivity.update')->name('imports.cancel');
    Route::get('/imports/{importJob}/errors.xlsx', [ProductivityController::class, 'errorFile'])->middleware('permission:productivity.export')->name('imports.errors');
    Route::post('/exports', [ProductivityController::class, 'export'])->middleware('permission:productivity.export')->name('exports.store');
    Route::get('/exports/{exportRun}/download', [ProductivityController::class, 'downloadExport'])->middleware('permission:productivity.export')->name('exports.download');
    Route::post('/links', [ProductivityController::class, 'storeLink'])->middleware('permission:productivity.create')->name('links.store');
    Route::delete('/links/{workspaceLink}', [ProductivityController::class, 'destroyLink'])->middleware('permission:productivity.delete')->name('links.destroy');
    Route::post('/duplicate/{type}/{id}', [ProductivityController::class, 'duplicate'])->middleware('permission:productivity.create')->name('duplicate');
    Route::post('/bulk', [ProductivityController::class, 'bulk'])->middleware('permission:productivity.update')->name('bulk');
});
