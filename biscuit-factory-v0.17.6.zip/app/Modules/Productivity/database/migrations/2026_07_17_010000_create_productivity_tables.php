<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('data_import_jobs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('company_id')->nullable()->constrained('companies')->nullOnDelete();
            $table->string('import_type', 50)->index();
            $table->string('source_format', 10);
            $table->string('existing_mode', 20)->default('UPDATE');
            $table->string('status', 30)->default('PREVIEW')->index();
            $table->string('file_disk', 30)->default('local');
            $table->string('file_path');
            $table->string('original_name');
            $table->json('options')->nullable();
            $table->unsignedInteger('total_rows')->default(0);
            $table->unsignedInteger('valid_rows')->default(0);
            $table->unsignedInteger('invalid_rows')->default(0);
            $table->unsignedInteger('processed_rows')->default(0);
            $table->unsignedInteger('created_rows')->default(0);
            $table->unsignedInteger('updated_rows')->default(0);
            $table->unsignedInteger('skipped_rows')->default(0);
            $table->unsignedInteger('failed_rows')->default(0);
            $table->text('error_message')->nullable();
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });

        Schema::create('data_import_rows', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('data_import_job_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('row_number');
            $table->string('status', 20)->default('VALID')->index();
            $table->string('action', 20)->nullable();
            $table->json('payload');
            $table->json('normalized_payload')->nullable();
            $table->json('errors')->nullable();
            $table->timestamps();

            $table->unique(['data_import_job_id', 'row_number']);
        });

        Schema::create('data_export_runs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('company_id')->nullable()->constrained('companies')->nullOnDelete();
            $table->string('export_type', 50)->index();
            $table->string('format', 10);
            $table->string('status', 30)->default('QUEUED')->index();
            $table->json('filters')->nullable();
            $table->unsignedInteger('row_count')->default(0);
            $table->string('file_disk', 30)->nullable();
            $table->string('file_path')->nullable();
            $table->string('file_name')->nullable();
            $table->text('error_message')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'created_at']);
        });

        Schema::create('user_workspace_links', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('link_type', 20)->default('FAVORITE');
            $table->string('label', 160);
            $table->string('route_name', 160);
            $table->json('route_parameters')->nullable();
            $table->string('fingerprint', 64);
            $table->unsignedSmallInteger('sort_order')->default(100);
            $table->timestamps();

            $table->unique(['user_id', 'link_type', 'fingerprint'], 'workspace_link_unique');
            $table->index(['user_id', 'link_type', 'sort_order']);
        });

        Schema::create('bulk_operation_runs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('resource_type', 50)->index();
            $table->string('action', 30);
            $table->unsignedInteger('requested_count')->default(0);
            $table->unsignedInteger('processed_count')->default(0);
            $table->unsignedInteger('failed_count')->default(0);
            $table->json('errors')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bulk_operation_runs');
        Schema::dropIfExists('user_workspace_links');
        Schema::dropIfExists('data_export_runs');
        Schema::dropIfExists('data_import_rows');
        Schema::dropIfExists('data_import_jobs');
    }
};
