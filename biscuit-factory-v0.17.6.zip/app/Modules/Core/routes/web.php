<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\WorkflowController;
use App\Http\Controllers\HelpController;
use Illuminate\Support\Facades\Route;

Route::get('/dashboard', DashboardController::class)
    ->middleware('permission:dashboard.view')
    ->name('dashboard');

Route::get('/help/glossary', HelpController::class)
    ->middleware('permission:dashboard.view')
    ->name('help.glossary');

Route::prefix('workflow')->name('workflow.')->middleware('permission:dashboard.view')->group(function (): void {
    Route::get('/summary', [WorkflowController::class, 'summary'])->name('summary');
    Route::get('/tasks', [WorkflowController::class, 'tasks'])->name('tasks');
    Route::get('/alerts', [WorkflowController::class, 'alerts'])->name('alerts');
    Route::post('/tasks/{taskKey}/snooze', [WorkflowController::class, 'snooze'])->where('taskKey', '[a-f0-9]{64}')->name('tasks.snooze');
    Route::delete('/tasks/{taskKey}', [WorkflowController::class, 'dismiss'])->where('taskKey', '[a-f0-9]{64}')->name('tasks.dismiss');
    Route::delete('/preferences', [WorkflowController::class, 'restoreAll'])->name('preferences.restore');
    Route::post('/notifications/read-all', [WorkflowController::class, 'markAllNotificationsRead'])->name('notifications.read-all');
    Route::post('/notifications/{notification}/read', [WorkflowController::class, 'markNotificationRead'])->name('notifications.read');
});
