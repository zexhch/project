<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('workflow_events', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('event_code', 120)->index();
            $table->string('subject_type', 180);
            $table->uuid('subject_id');
            $table->string('from_status', 40)->nullable();
            $table->string('to_status', 40)->nullable();
            $table->string('label', 180)->nullable();
            $table->json('metadata')->nullable();
            $table->timestamp('occurred_at')->useCurrent()->index();
            $table->timestamps();

            $table->index(['subject_type', 'subject_id', 'occurred_at'], 'workflow_event_subject_idx');
        });

        Schema::create('workflow_task_preferences', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->string('task_key', 64);
            $table->string('state', 20)->default('SNOOZED');
            $table->timestamp('snoozed_until')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'task_key']);
            $table->index(['user_id', 'state', 'snoozed_until'], 'workflow_task_preference_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('workflow_task_preferences');
        Schema::dropIfExists('workflow_events');
    }
};
