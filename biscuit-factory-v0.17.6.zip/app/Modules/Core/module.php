<?php

return [
    'code' => 'core',
    'name' => 'modules.core_name',
    'description' => 'modules.core_description',
    'version' => '0.17.6',
    'icon' => 'ti-layout-dashboard',
    'order' => 10,
    'core' => true,
    'default_enabled' => true,
    'permissions' => ['dashboard'],
    'dependencies' => [],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
