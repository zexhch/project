<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('downtime_reasons', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->string('category', 50)->index();
            $table->boolean('planned')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('maintenance_plans', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->foreignUuid('production_line_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignUuid('machine_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('maintenance_type', 40)->default('PREVENTIVE');
            $table->string('frequency_type', 30);
            $table->unsignedInteger('frequency_value');
            $table->unsignedInteger('estimated_duration_minutes')->nullable();
            $table->timestamp('next_due_at')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('maintenance_work_orders', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('work_order_number', 80)->unique();
            $table->foreignUuid('maintenance_plan_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('machine_id')->nullable()->constrained()->nullOnDelete();
            $table->string('maintenance_type', 40);
            $table->string('priority', 20)->default('NORMAL');
            $table->text('description');
            $table->timestamp('planned_start')->nullable();
            $table->timestamp('planned_end')->nullable();
            $table->timestamp('actual_start')->nullable();
            $table->timestamp('actual_end')->nullable();
            $table->string('status', 30)->default('DRAFT');
            $table->foreignUuid('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $table->decimal('labor_cost', 18, 2)->default(0);
            $table->decimal('parts_cost', 18, 2)->default(0);
            $table->text('observations')->nullable();
            $table->timestamps();
        });

        Schema::create('production_downtimes', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_line_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('machine_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('maintenance_work_order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('downtime_reason_id')->constrained();
            $table->timestamp('started_at');
            $table->timestamp('ended_at')->nullable();
            $table->unsignedInteger('duration_seconds')->nullable();
            $table->boolean('planned')->default(false);
            $table->string('impact_level', 20)->default('LINE_STOP');
            $table->text('description')->nullable();
            $table->foreignUuid('recorded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['production_line_id', 'started_at']);
            $table->index(['ended_at', 'planned']);
        });

        Schema::create('maintenance_actions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('maintenance_work_order_id')->constrained()->cascadeOnDelete();
            $table->text('action_description');
            $table->foreignUuid('performed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('performed_at')->nullable();
            $table->string('result', 50)->nullable();
            $table->timestamps();
        });

        Schema::create('maintenance_parts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('maintenance_work_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->decimal('unit_cost', 18, 4)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('maintenance_parts');
        Schema::dropIfExists('maintenance_actions');
        Schema::dropIfExists('production_downtimes');
        Schema::dropIfExists('maintenance_work_orders');
        Schema::dropIfExists('maintenance_plans');
        Schema::dropIfExists('downtime_reasons');
    }
};
