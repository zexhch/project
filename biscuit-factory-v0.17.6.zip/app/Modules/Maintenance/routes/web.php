<?php

use App\Http\Controllers\DowntimeController;
use App\Http\Controllers\MaintenanceController;
use Illuminate\Support\Facades\Route;

Route::get('/maintenance', [MaintenanceController::class, 'index'])->middleware('permission:maintenance.view')->name('maintenance.index');
Route::post('/maintenance/orders', [MaintenanceController::class, 'store'])->middleware('permission:maintenance.create')->name('maintenance.store');
Route::get('/maintenance/orders/{order}', [MaintenanceController::class, 'show'])->middleware('permission:maintenance.view')->name('maintenance.show');
Route::post('/maintenance/orders/{order}/start', [MaintenanceController::class, 'start'])->middleware('permission:maintenance.update')->name('maintenance.start');
Route::post('/maintenance/orders/{order}/complete', [MaintenanceController::class, 'complete'])->middleware('permission:maintenance.update')->name('maintenance.complete');
Route::post('/maintenance/orders/{order}/actions', [MaintenanceController::class, 'addAction'])->middleware('permission:maintenance.update')->name('maintenance.actions.store');
Route::post('/maintenance/orders/{order}/parts', [MaintenanceController::class, 'addPart'])->middleware('permission:maintenance.update')->name('maintenance.parts.store');
Route::post('/maintenance/downtimes', [DowntimeController::class, 'store'])->middleware('permission:maintenance.create')->name('maintenance.downtimes.store');
Route::post('/maintenance/downtimes/{downtime}/stop', [DowntimeController::class, 'stop'])->middleware('permission:maintenance.update')->name('maintenance.downtimes.stop');
