<?php

return [
    'code' => 'maintenance',
    'name' => 'modules.maintenance_name',
    'description' => 'modules.maintenance_description',
    'version' => '0.17.6',
    'icon' => 'ti-tool',
    'order' => 70,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['maintenance'],
    'dependencies' => ['master-data', 'stocks'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
