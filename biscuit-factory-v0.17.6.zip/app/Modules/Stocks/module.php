<?php

return [
    'code' => 'stocks',
    'name' => 'modules.stocks_name',
    'description' => 'modules.stocks_description',
    'version' => '0.17.6',
    'icon' => 'ti-packages',
    'order' => 40,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['stocks'],
    'dependencies' => ['master-data'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
