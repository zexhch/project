<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('stock_movement_lines', function (Blueprint $table): void {
            $table->string('reference', 120)->nullable()->after('id');
            $table->text('notes')->nullable()->after('unit_cost');
        });

        Schema::create('stock_balances', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignUuid('location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->decimal('quantity', 18, 3)->default(0);
            $table->decimal('reserved_quantity', 18, 3)->default(0);
            $table->decimal('average_unit_cost', 18, 4)->nullable();
            $table->timestamps();
            $table->unique(['item_id', 'lot_id', 'location_id']);
            $table->index(['location_id', 'quantity']);
        });

        Schema::create('inventory_counts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('inventory_number', 80)->unique();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->string('status', 30)->default('DRAFT');
            $table->date('count_date');
            $table->boolean('blind_count')->default(true);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('frozen_at')->nullable();
            $table->timestamp('posted_at')->nullable();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('inventory_count_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('inventory_count_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignUuid('location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->decimal('expected_quantity', 18, 3)->default(0);
            $table->decimal('counted_quantity', 18, 3)->nullable();
            $table->decimal('variance_quantity', 18, 3)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['inventory_count_id', 'item_id', 'lot_id', 'location_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('inventory_count_lines');
        Schema::dropIfExists('inventory_counts');
        Schema::dropIfExists('stock_balances');
        Schema::table('stock_movement_lines', function (Blueprint $table): void {
            $table->dropColumn(['reference', 'notes']);
        });
    }
};
