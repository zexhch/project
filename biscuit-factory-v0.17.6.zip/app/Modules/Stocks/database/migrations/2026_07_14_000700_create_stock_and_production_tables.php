<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lots', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('item_id')->constrained()->cascadeOnDelete();
            $table->string('lot_number', 120);
            $table->date('manufacturing_date')->nullable();
            $table->date('expiry_date')->nullable();
            $table->string('status', 30)->default('QUARANTINE');
            $table->json('attributes')->nullable();
            $table->timestamps();

            $table->unique(['item_id', 'lot_number']);
            $table->index(['status', 'expiry_date']);
        });

        Schema::create('stock_movements', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('movement_number', 80)->unique();
            $table->string('movement_type', 50)->index();
            $table->timestamp('movement_at');
            $table->string('source_type', 80)->nullable();
            $table->uuid('source_id')->nullable();
            $table->string('status', 30)->default('DRAFT');
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['source_type', 'source_id']);
        });

        Schema::create('stock_movement_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('stock_movement_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('source_location_id')->nullable()->constrained('warehouse_locations')->nullOnDelete();
            $table->foreignUuid('destination_location_id')->nullable()->constrained('warehouse_locations')->nullOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->decimal('unit_cost', 18, 4)->nullable();
            $table->timestamps();
        });

        Schema::create('production_orders', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('order_number', 80)->unique();
            $table->foreignUuid('finished_item_id')->constrained('items');
            $table->foreignUuid('recipe_version_id')->constrained();
            $table->foreignUuid('process_template_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('work_shift_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('planned_quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->date('planned_date');
            $table->timestamp('planned_start')->nullable();
            $table->timestamp('planned_end')->nullable();
            $table->timestamp('actual_start')->nullable();
            $table->timestamp('actual_end')->nullable();
            $table->string('status', 30)->default('DRAFT');
            $table->unsignedTinyInteger('priority')->default(5);
            $table->foreignUuid('responsible_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['planned_date', 'status']);
        });

        Schema::create('production_consumptions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('planned_quantity', 18, 3)->default(0);
            $table->decimal('consumed_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->timestamps();
        });

        Schema::create('production_outputs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('produced_quantity', 18, 3)->default(0);
            $table->decimal('accepted_quantity', 18, 3)->default(0);
            $table->decimal('rejected_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->timestamps();
        });

        Schema::create('production_losses', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->string('loss_type', 50);
            $table->string('reason_code', 80)->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('production_losses');
        Schema::dropIfExists('production_outputs');
        Schema::dropIfExists('production_consumptions');
        Schema::dropIfExists('production_orders');
        Schema::dropIfExists('stock_movement_lines');
        Schema::dropIfExists('stock_movements');
        Schema::dropIfExists('lots');
    }
};
