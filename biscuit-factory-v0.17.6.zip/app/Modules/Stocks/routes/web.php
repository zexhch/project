<?php

use App\Http\Controllers\InventoryController;
use App\Http\Controllers\StockController;
use Illuminate\Support\Facades\Route;

Route::get('/stocks', [StockController::class, 'index'])->middleware('permission:stocks.view')->name('stocks.index');
Route::get('/stocks/movements/create', [StockController::class, 'create'])->middleware('permission:stocks.create')->name('stocks.create');
Route::post('/stocks/movements', [StockController::class, 'store'])->middleware('permission:stocks.create')->name('stocks.store');
Route::post('/stocks/movements/{movement}/post', [StockController::class, 'post'])->middleware('permission:stocks.approve')->name('stocks.post');
Route::put('/stocks/lots/{lot}/status', [StockController::class, 'updateLotStatus'])->middleware('permission:stocks.approve')->name('stocks.lots.status');
Route::get('/inventories', [InventoryController::class, 'index'])->middleware('permission:stocks.view')->name('inventories.index');
Route::post('/inventories', [InventoryController::class, 'store'])->middleware('permission:stocks.create')->name('inventories.store');
Route::get('/inventories/{inventory}', [InventoryController::class, 'show'])->middleware('permission:stocks.view')->name('inventories.show');
Route::post('/inventories/{inventory}/freeze', [InventoryController::class, 'freeze'])->middleware('permission:stocks.update')->name('inventories.freeze');
Route::put('/inventories/{inventory}/counts', [InventoryController::class, 'updateCounts'])->middleware('permission:stocks.update')->name('inventories.counts');
Route::post('/inventories/{inventory}/post', [InventoryController::class, 'post'])->middleware('permission:stocks.approve')->name('inventories.post');
