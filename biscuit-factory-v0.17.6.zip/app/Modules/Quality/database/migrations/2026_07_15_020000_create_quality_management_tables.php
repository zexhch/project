<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('haccp_control_points', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->foreignUuid('process_step_id')->nullable()->constrained('process_steps')->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->string('hazard_type', 40)->index();
            $table->text('hazard_description');
            $table->text('control_measure');
            $table->text('critical_limits');
            $table->string('monitoring_method');
            $table->string('frequency_type', 40);
            $table->unsignedInteger('frequency_value')->default(1);
            $table->text('corrective_action');
            $table->text('verification_method')->nullable();
            $table->string('responsible_role_code', 80)->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('quality_control_plans', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80);
            $table->string('name');
            $table->string('control_stage', 40)->index();
            $table->foreignUuid('item_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_category_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('haccp_control_point_id')->nullable()->constrained()->nullOnDelete();
            $table->string('sampling_method', 40);
            $table->decimal('sample_size', 18, 3)->default(1);
            $table->string('frequency_type', 40);
            $table->unsignedInteger('frequency_value')->default(1);
            $table->text('instructions')->nullable();
            $table->unsignedInteger('version')->default(1);
            $table->date('valid_from')->nullable();
            $table->date('valid_to')->nullable();
            $table->string('status', 30)->default('DRAFT');
            $table->boolean('active')->default(true);
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->unique(['code', 'version']);
            $table->index(['status', 'active', 'valid_from', 'valid_to']);
        });

        Schema::create('quality_control_plan_parameters', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('quality_control_plan_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('data_type', 30);
            $table->foreignUuid('unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->decimal('minimum_value', 20, 6)->nullable();
            $table->decimal('maximum_value', 20, 6)->nullable();
            $table->decimal('target_value', 20, 6)->nullable();
            $table->string('expected_value')->nullable();
            $table->json('options')->nullable();
            $table->string('method')->nullable();
            $table->boolean('required')->default(true);
            $table->boolean('critical')->default(false);
            $table->unsignedSmallInteger('sequence')->default(10);
            $table->timestamps();

            $table->unique(['quality_control_plan_id', 'code'], 'quality_plan_parameter_code_unique');
        });

        Schema::create('quality_inspections', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('inspection_number', 80)->unique();
            $table->foreignUuid('quality_control_plan_id')->constrained()->restrictOnDelete();
            $table->string('control_stage', 40)->index();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('stock_movement_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->string('sample_reference', 120)->nullable();
            $table->decimal('sample_size', 18, 3)->default(1);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->timestamp('inspected_at')->nullable();
            $table->foreignUuid('inspector_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('decision', 30)->nullable();
            $table->text('decision_reason')->nullable();
            $table->foreignUuid('decided_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('decided_at')->nullable();
            $table->text('overall_notes')->nullable();
            $table->timestamps();

            $table->index(['item_id', 'lot_id']);
            $table->index(['production_order_id', 'status']);
        });

        Schema::create('quality_inspection_results', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('quality_inspection_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('quality_control_plan_parameter_id')->constrained()->restrictOnDelete();
            $table->decimal('value_numeric', 20, 6)->nullable();
            $table->text('value_text')->nullable();
            $table->boolean('value_boolean')->nullable();
            $table->string('result_status', 20)->default('PENDING')->index();
            $table->decimal('deviation', 20, 6)->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('measured_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('measured_at')->nullable();
            $table->timestamps();

            $table->unique(
                ['quality_inspection_id', 'quality_control_plan_parameter_id'],
                'quality_inspection_parameter_unique'
            );
        });

        Schema::create('quality_decisions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('quality_inspection_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->string('decision', 30);
            $table->string('previous_lot_status', 30)->nullable();
            $table->string('new_lot_status', 30)->nullable();
            $table->text('reason');
            $table->foreignUuid('decided_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('decided_at');
            $table->timestamp('created_at')->useCurrent();

            $table->index(['lot_id', 'decided_at']);
        });

        Schema::create('quality_non_conformities', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('non_conformity_number', 80)->unique();
            $table->foreignUuid('quality_inspection_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_order_id')->nullable()->constrained()->nullOnDelete();
            $table->string('severity', 30)->index();
            $table->string('category', 80)->nullable();
            $table->string('title');
            $table->text('description');
            $table->text('immediate_action')->nullable();
            $table->text('root_cause')->nullable();
            $table->text('disposition')->nullable();
            $table->string('status', 30)->default('OPEN')->index();
            $table->foreignUuid('detected_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('detected_at');
            $table->foreignUuid('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('due_date')->nullable();
            $table->foreignUuid('closed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();

            $table->index(['item_id', 'lot_id']);
            $table->index(['owner_id', 'due_date', 'status']);
        });

        Schema::create('quality_corrective_actions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('quality_non_conformity_id')->constrained()->cascadeOnDelete();
            $table->string('action_number', 80)->unique();
            $table->string('action_type', 30);
            $table->text('description');
            $table->foreignUuid('owner_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('due_date')->nullable();
            $table->string('status', 30)->default('OPEN')->index();
            $table->text('completion_notes')->nullable();
            $table->foreignUuid('completed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('completed_at')->nullable();
            $table->text('effectiveness_criteria')->nullable();
            $table->text('effectiveness_result')->nullable();
            $table->foreignUuid('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();

            $table->index(['owner_id', 'due_date', 'status']);
        });

        Schema::create('quality_attachments', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('quality_inspection_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignUuid('quality_non_conformity_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('original_name');
            $table->string('storage_disk', 40)->default('local');
            $table->string('storage_path');
            $table->string('mime_type', 120)->nullable();
            $table->unsignedBigInteger('size_bytes')->default(0);
            $table->foreignUuid('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quality_attachments');
        Schema::dropIfExists('quality_corrective_actions');
        Schema::dropIfExists('quality_non_conformities');
        Schema::dropIfExists('quality_decisions');
        Schema::dropIfExists('quality_inspection_results');
        Schema::dropIfExists('quality_inspections');
        Schema::dropIfExists('quality_control_plan_parameters');
        Schema::dropIfExists('quality_control_plans');
        Schema::dropIfExists('haccp_control_points');
    }
};
