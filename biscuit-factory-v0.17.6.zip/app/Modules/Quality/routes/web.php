<?php

use App\Http\Controllers\QualityController;
use Illuminate\Support\Facades\Route;

Route::get('/quality', [QualityController::class, 'index'])->middleware('permission:quality.view')->name('quality.index');
Route::get('/quality/export/{type}', [QualityController::class, 'export'])->whereIn('type', ['inspections', 'non-conformities'])->middleware('permission:quality.export')->name('quality.export');
Route::get('/quality/plans', [QualityController::class, 'plans'])->middleware('permission:quality.view')->name('quality.plans');
Route::post('/quality/plans', [QualityController::class, 'storePlan'])->middleware('permission:quality.create')->name('quality.plans.store');
Route::post('/quality/plans/{plan}/approve', [QualityController::class, 'approvePlan'])->middleware('permission:quality.approve')->name('quality.plans.approve');
Route::post('/quality/plans/{plan}/parameters', [QualityController::class, 'addParameter'])->middleware('permission:quality.update')->name('quality.plans.parameters.store');
Route::post('/quality/haccp', [QualityController::class, 'storeHaccp'])->middleware('permission:quality.create')->name('quality.haccp.store');
Route::post('/quality/inspections', [QualityController::class, 'storeInspection'])->middleware('permission:quality.create')->name('quality.inspections.store');
Route::get('/quality/inspections/{inspection}', [QualityController::class, 'showInspection'])->middleware('permission:quality.view')->name('quality.inspections.show');
Route::put('/quality/inspections/{inspection}/results/{parameter}', [QualityController::class, 'recordResult'])->middleware('permission:quality.update')->name('quality.inspections.results.update');
Route::post('/quality/inspections/{inspection}/submit', [QualityController::class, 'submitInspection'])->middleware('permission:quality.update')->name('quality.inspections.submit');
Route::post('/quality/inspections/{inspection}/decision', [QualityController::class, 'decideInspection'])->middleware('permission:quality.approve')->name('quality.inspections.decision');
Route::post('/quality/inspections/{inspection}/attachments', [QualityController::class, 'uploadInspectionAttachment'])->middleware('permission:quality.update')->name('quality.inspections.attachments.store');
Route::get('/quality/non-conformities', [QualityController::class, 'nonConformities'])->middleware('permission:quality.view')->name('quality.non-conformities.index');
Route::post('/quality/non-conformities', [QualityController::class, 'storeNonConformity'])->middleware('permission:quality.create')->name('quality.non-conformities.store');
Route::get('/quality/non-conformities/{nonConformity}', [QualityController::class, 'showNonConformity'])->middleware('permission:quality.view')->name('quality.non-conformities.show');
Route::put('/quality/non-conformities/{nonConformity}/analysis', [QualityController::class, 'updateAnalysis'])->middleware('permission:quality.update')->name('quality.non-conformities.analysis');
Route::post('/quality/non-conformities/{nonConformity}/actions', [QualityController::class, 'addAction'])->middleware('permission:quality.update')->name('quality.non-conformities.actions.store');
Route::post('/quality/non-conformities/{nonConformity}/close', [QualityController::class, 'closeNonConformity'])->middleware('permission:quality.approve')->name('quality.non-conformities.close');
Route::post('/quality/non-conformities/{nonConformity}/attachments', [QualityController::class, 'uploadNonConformityAttachment'])->middleware('permission:quality.update')->name('quality.non-conformities.attachments.store');
Route::post('/quality/actions/{action}/complete', [QualityController::class, 'completeAction'])->middleware('permission:quality.update')->name('quality.actions.complete');
Route::post('/quality/actions/{action}/verify', [QualityController::class, 'verifyAction'])->middleware('permission:quality.approve')->name('quality.actions.verify');
Route::get('/quality/attachments/{attachment}', [QualityController::class, 'downloadAttachment'])->middleware('permission:quality.view')->name('quality.attachments.download');
