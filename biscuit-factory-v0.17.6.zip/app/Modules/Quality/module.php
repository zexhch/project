<?php

return [
    'code' => 'quality',
    'name' => 'modules.quality_name',
    'description' => 'modules.quality_description',
    'version' => '0.17.6',
    'icon' => 'ti-shield-check',
    'order' => 60,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['quality'],
    'dependencies' => ['master-data', 'stocks'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
