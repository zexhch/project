<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('recipes', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->foreignUuid('finished_item_id')->constrained('items');
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('recipe_versions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('recipe_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('version_number');
            $table->decimal('reference_quantity', 18, 3);
            $table->foreignUuid('reference_unit_id')->constrained('units');
            $table->decimal('expected_yield_percent', 8, 3)->default(100);
            $table->date('valid_from')->nullable();
            $table->date('valid_to')->nullable();
            $table->string('status', 30)->default('DRAFT');
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->unique(['recipe_id', 'version_number']);
        });

        Schema::create('recipe_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('recipe_version_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('ingredient_item_id')->constrained('items');
            $table->decimal('quantity', 18, 6);
            $table->foreignUuid('unit_id')->constrained('units');
            $table->decimal('loss_percentage', 8, 3)->default(0);
            $table->boolean('optional')->default(false);
            $table->timestamps();

            $table->unique(['recipe_version_id', 'ingredient_item_id']);
        });

        Schema::create('process_templates', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->foreignUuid('finished_item_id')->nullable()->constrained('items')->nullOnDelete();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('process_steps', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('process_template_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('sequence_number');
            $table->string('code', 80);
            $table->string('name');
            $table->string('step_type', 40)->default('PRODUCTION');
            $table->foreignUuid('default_machine_id')->nullable()->constrained('machines')->nullOnDelete();
            $table->unsignedInteger('planned_duration_minutes')->nullable();
            $table->json('parameters')->nullable();
            $table->boolean('quality_gate')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['process_template_id', 'sequence_number']);
            $table->unique(['process_template_id', 'code']);
        });

        Schema::create('line_products', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_line_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->cascadeOnDelete();
            $table->decimal('production_rate_per_hour', 18, 3)->nullable();
            $table->foreignUuid('rate_unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->unsignedInteger('setup_time_minutes')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['production_line_id', 'item_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('line_products');
        Schema::dropIfExists('process_steps');
        Schema::dropIfExists('process_templates');
        Schema::dropIfExists('recipe_lines');
        Schema::dropIfExists('recipe_versions');
        Schema::dropIfExists('recipes');
    }
};
