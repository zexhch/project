<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('production_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('site_id')->constrained()->cascadeOnDelete();
            $table->string('code', 50);
            $table->string('name');
            $table->text('description')->nullable();
            $table->decimal('capacity_per_hour', 18, 3)->nullable();
            $table->foreignUuid('capacity_unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->string('status', 30)->default('AVAILABLE');
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['site_id', 'code']);
        });

        Schema::create('machines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('site_id')->constrained()->cascadeOnDelete();
            $table->string('code', 50);
            $table->string('name');
            $table->string('machine_type', 50);
            $table->string('manufacturer')->nullable();
            $table->string('model')->nullable();
            $table->string('serial_number')->nullable();
            $table->date('commissioned_at')->nullable();
            $table->string('status', 30)->default('AVAILABLE');
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['site_id', 'code']);
        });

        Schema::create('production_line_machines', function (Blueprint $table): void {
            $table->foreignUuid('production_line_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('machine_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('sequence_number');
            $table->boolean('critical')->default(false);
            $table->timestamps();

            $table->primary(['production_line_id', 'machine_id']);
            $table->unique(['production_line_id', 'sequence_number']);
        });

        Schema::create('work_shifts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('site_id')->constrained()->cascadeOnDelete();
            $table->string('code', 30);
            $table->string('name');
            $table->time('starts_at');
            $table->time('ends_at');
            $table->json('work_days')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['site_id', 'code']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('work_shifts');
        Schema::dropIfExists('production_line_machines');
        Schema::dropIfExists('machines');
        Schema::dropIfExists('production_lines');
    }
};
