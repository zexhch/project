<?php

use App\Http\Controllers\ProductionController;
use App\Http\Controllers\RecipeController;
use Illuminate\Support\Facades\Route;

Route::get('/production', [ProductionController::class, 'index'])->middleware('permission:production.view')->name('production.index');
Route::post('/production', [ProductionController::class, 'store'])->middleware('permission:production.create')->name('production.store');
Route::get('/production/{order}', [ProductionController::class, 'show'])->middleware('permission:production.view')->name('production.show');
Route::post('/production/{order}/start', [ProductionController::class, 'start'])->middleware('permission:production.update')->name('production.start');
Route::post('/production/{order}/complete', [ProductionController::class, 'complete'])->middleware('permission:production.update')->name('production.complete');

Route::prefix('recipes')->name('recipes.')->group(function (): void {
    Route::get('/', [RecipeController::class, 'index'])->middleware('permission:production.view')->name('index');
    Route::post('/', [RecipeController::class, 'store'])->middleware('permission:production.create')->name('store');
    Route::get('/{recipe}', [RecipeController::class, 'show'])->middleware('permission:production.view')->name('show');
    Route::put('/{recipe}', [RecipeController::class, 'update'])->middleware('permission:production.update')->name('update');
    Route::post('/{recipe}/versions', [RecipeController::class, 'storeVersion'])->middleware('permission:production.create')->name('versions.store');
    Route::put('/{recipe}/versions/{version}', [RecipeController::class, 'updateVersion'])->middleware('permission:production.update')->name('versions.update');
    Route::post('/{recipe}/versions/{version}/duplicate', [RecipeController::class, 'duplicateVersion'])->middleware('permission:production.create')->name('versions.duplicate');
    Route::post('/{recipe}/versions/{version}/approve', [RecipeController::class, 'approveVersion'])->middleware('permission:production.approve')->name('versions.approve');
    Route::post('/{recipe}/versions/{version}/archive', [RecipeController::class, 'archiveVersion'])->middleware('permission:production.approve')->name('versions.archive');
    Route::post('/{recipe}/versions/{version}/lines', [RecipeController::class, 'storeLine'])->middleware('permission:production.update')->name('lines.store');
    Route::put('/{recipe}/versions/{version}/lines/{line}', [RecipeController::class, 'updateLine'])->middleware('permission:production.update')->name('lines.update');
    Route::delete('/{recipe}/versions/{version}/lines/{line}', [RecipeController::class, 'destroyLine'])->middleware('permission:production.update')->name('lines.destroy');
    Route::post('/{recipe}/versions/{version}/cost-components', [RecipeController::class, 'storeCostComponent'])->middleware('permission:production.update')->name('cost-components.store');
    Route::delete('/{recipe}/versions/{version}/cost-components/{component}', [RecipeController::class, 'destroyCostComponent'])->middleware('permission:production.update')->name('cost-components.destroy');
});
