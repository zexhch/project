<?php

return [
    'code' => 'production',
    'name' => 'modules.production_name',
    'description' => 'modules.production_description',
    'version' => '0.17.6',
    'icon' => 'ti-settings-automation',
    'order' => 50,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['production'],
    'dependencies' => ['master-data', 'stocks'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
