<?php

namespace App\Modules\Administration\Database\Seeders;

use App\Services\Modules\ModuleRegistry;
use Illuminate\Database\Seeder;

class ApplicationModuleSeeder extends Seeder
{
    public function run(): void
    {
        app(ModuleRegistry::class)->sync();
    }
}
