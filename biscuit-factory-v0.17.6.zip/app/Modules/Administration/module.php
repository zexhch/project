<?php

return [
    'code' => 'administration',
    'name' => 'modules.administration_name',
    'description' => 'modules.administration_description',
    'version' => '0.17.6',
    'icon' => 'ti-shield-lock',
    'order' => 20,
    'core' => true,
    'default_enabled' => true,
    'permissions' => ['modules', 'users'],
    'dependencies' => ['core'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
