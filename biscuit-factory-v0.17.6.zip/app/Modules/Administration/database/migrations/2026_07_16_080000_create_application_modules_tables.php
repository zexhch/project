<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('application_modules', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 80)->unique();
            $table->string('name_key', 180);
            $table->string('description_key', 180);
            $table->string('version', 30);
            $table->string('icon', 80)->nullable();
            $table->boolean('core')->default(false)->index();
            $table->boolean('enabled')->default(true)->index();
            $table->unsignedInteger('sort_order')->default(0);
            $table->string('manifest_hash', 64);
            $table->timestamp('installed_at')->nullable();
            $table->timestamp('enabled_at')->nullable();
            $table->timestamp('disabled_at')->nullable();
            $table->foreignUuid('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('application_module_dependencies', function (Blueprint $table): void {
            $table->foreignUuid('module_id')->constrained('application_modules')->cascadeOnDelete();
            $table->foreignUuid('dependency_id')->constrained('application_modules')->cascadeOnDelete();
            $table->timestamps();

            $table->primary(['module_id', 'dependency_id'], 'application_module_dependency_pk');
            $table->index('dependency_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('application_module_dependencies');
        Schema::dropIfExists('application_modules');
    }
};
