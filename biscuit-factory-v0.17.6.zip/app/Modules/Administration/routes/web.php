<?php

use App\Http\Controllers\ModuleController;
use Illuminate\Support\Facades\Route;

Route::prefix('admin/modules')->name('admin.modules.')->group(function (): void {
    Route::get('/', [ModuleController::class, 'index'])->middleware('permission:modules.view')->name('index');
    Route::post('/sync', [ModuleController::class, 'sync'])->middleware('permission:modules.update')->name('sync');
    Route::put('/{module}', [ModuleController::class, 'update'])->middleware('permission:modules.update')->name('update');
});
