<?php

return [
    'code' => 'master-data',
    'name' => 'modules.master_data_name',
    'description' => 'modules.master_data_description',
    'version' => '0.17.6',
    'icon' => 'ti-adjustments',
    'order' => 30,
    'core' => true,
    'default_enabled' => true,
    'permissions' => ['settings', 'catalog'],
    'dependencies' => ['core', 'administration'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
