<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('companies', function (Blueprint $table): void {
            $table->string('business_activity')->nullable()->after('legal_name');
            $table->string('trade_register_number', 120)->nullable()->after('business_activity');
            $table->string('tax_identification_number', 120)->nullable()->after('trade_register_number');
            $table->string('statistical_identification_number', 120)->nullable()->after('tax_identification_number');
            $table->string('article_of_imposition_number', 120)->nullable()->after('statistical_identification_number');
            $table->string('bank_name')->nullable()->after('address');
            $table->string('bank_branch')->nullable()->after('bank_name');
            $table->string('bank_account_number', 160)->nullable()->after('bank_branch');
            $table->string('logo_path', 500)->nullable()->after('bank_account_number');
        });
    }

    public function down(): void
    {
        Schema::table('companies', function (Blueprint $table): void {
            $table->dropColumn([
                'business_activity',
                'trade_register_number',
                'tax_identification_number',
                'statistical_identification_number',
                'article_of_imposition_number',
                'bank_name',
                'bank_branch',
                'bank_account_number',
                'logo_path',
            ]);
        });
    }
};
