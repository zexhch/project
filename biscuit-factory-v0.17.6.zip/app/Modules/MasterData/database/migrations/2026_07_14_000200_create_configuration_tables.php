<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('languages', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 5)->unique();
            $table->string('name');
            $table->string('native_name');
            $table->string('direction', 3)->default('ltr');
            $table->boolean('active')->default(true);
            $table->boolean('is_default')->default(false);
            $table->timestamps();
        });

        Schema::create('currencies', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 3)->unique();
            $table->string('name');
            $table->string('symbol', 10);
            $table->unsignedTinyInteger('decimal_places')->default(2);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('companies', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 50)->unique();
            $table->string('name');
            $table->string('legal_name')->nullable();
            $table->string('country_code', 2)->default('DZ');
            $table->string('currency_code', 3)->default('DZD');
            $table->string('timezone')->default('Africa/Algiers');
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies');
        });

        Schema::create('tax_rates', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('code', 50);
            $table->string('name');
            $table->decimal('rate', 8, 4)->default(0);
            $table->date('valid_from')->nullable();
            $table->date('valid_to')->nullable();
            $table->boolean('active')->default(false);
            $table->boolean('is_default')->default(false);
            $table->timestamps();

            $table->unique(['company_id', 'code']);
        });

        Schema::create('system_settings', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('group', 80)->index();
            $table->string('key', 120);
            $table->json('value')->nullable();
            $table->string('value_type', 30)->default('string');
            $table->boolean('public')->default(false);
            $table->timestamps();

            $table->unique(['company_id', 'group', 'key']);
        });

        Schema::create('reference_values', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('domain', 100)->index();
            $table->string('code', 100);
            $table->json('labels');
            $table->unsignedInteger('sort_order')->default(0);
            $table->json('metadata')->nullable();
            $table->boolean('system')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['domain', 'code']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reference_values');
        Schema::dropIfExists('system_settings');
        Schema::dropIfExists('tax_rates');
        Schema::dropIfExists('companies');
        Schema::dropIfExists('currencies');
        Schema::dropIfExists('languages');
    }
};
