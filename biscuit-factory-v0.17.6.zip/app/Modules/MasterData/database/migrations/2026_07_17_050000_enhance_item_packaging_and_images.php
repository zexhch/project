<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('items', function (Blueprint $table): void {
            $table->string('main_image_path')->nullable()->after('barcode');
            $table->string('main_image_thumbnail_path')->nullable()->after('main_image_path');
        });

        Schema::table('item_unit_conversions', function (Blueprint $table): void {
            $table->foreignUuid('parent_unit_id')->nullable()->after('unit_id')->constrained('units')->nullOnDelete();
            $table->decimal('factor_to_parent', 20, 8)->default(1)->after('parent_unit_id');
            $table->string('barcode')->nullable()->after('factor_to_base');
            $table->decimal('net_weight_kg', 20, 6)->nullable()->after('barcode');
            $table->decimal('gross_weight_kg', 20, 6)->nullable()->after('net_weight_kg');
            $table->decimal('tare_weight_kg', 20, 6)->nullable()->after('gross_weight_kg');
            $table->decimal('length_cm', 12, 3)->nullable()->after('tare_weight_kg');
            $table->decimal('width_cm', 12, 3)->nullable()->after('length_cm');
            $table->decimal('height_cm', 12, 3)->nullable()->after('width_cm');
            $table->decimal('volume_m3', 20, 9)->nullable()->after('height_cm');
            $table->boolean('production_unit')->default(false)->after('sales_unit');
            $table->boolean('inventory_unit')->default(false)->after('production_unit');
            $table->boolean('fractional_allowed')->default(false)->after('inventory_unit');
            $table->string('rounding_mode', 20)->default('NONE')->after('fractional_allowed');
            $table->date('valid_from')->nullable()->after('rounding_mode');
            $table->date('valid_to')->nullable()->after('valid_from');
            $table->boolean('active')->default(true)->after('valid_to');
            $table->string('image_path')->nullable()->after('active');
            $table->index(['item_id', 'active']);
            $table->unique('barcode', 'item_unit_conversions_barcode_unique');
        });

        Schema::create('item_unit_conversion_histories', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('item_unit_conversion_id')->nullable()->constrained('item_unit_conversions')->nullOnDelete();
            $table->foreignUuid('item_id')->constrained('items')->cascadeOnDelete();
            $table->foreignUuid('unit_id')->constrained('units');
            $table->foreignUuid('changed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('event', 30);
            $table->json('snapshot');
            $table->timestamps();
            $table->index(['item_id', 'created_at']);
        });

        Schema::create('item_images', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('item_id')->constrained('items')->cascadeOnDelete();
            $table->string('path')->unique();
            $table->string('thumbnail_path')->nullable();
            $table->string('original_name')->nullable();
            $table->unsignedInteger('position')->default(1);
            $table->unsignedBigInteger('size_bytes')->nullable();
            $table->unsignedInteger('width_px')->nullable();
            $table->unsignedInteger('height_px')->nullable();
            $table->foreignUuid('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->unique(['item_id', 'position']);
        });

        // Existing conversions remain valid and become direct children of the base unit.
        DB::table('item_unit_conversions')->orderBy('id')->chunk(200, function ($rows): void {
            foreach ($rows as $row) {
                $item = DB::table('items')->where('id', $row->item_id)->first(['base_unit_id', 'barcode']);
                $baseUnitId = $item?->base_unit_id;
                $isBaseUnit = $row->unit_id === $baseUnitId;
                DB::table('item_unit_conversions')->where('id', $row->id)->update([
                    'parent_unit_id' => $isBaseUnit ? null : $baseUnitId,
                    'factor_to_parent' => $isBaseUnit ? 1 : $row->factor_to_base,
                    'factor_to_base' => $isBaseUnit ? 1 : $row->factor_to_base,
                    'barcode' => $isBaseUnit ? $item?->barcode : null,
                    'production_unit' => $isBaseUnit ? true : (bool) ($row->production_unit ?? false),
                    'inventory_unit' => $isBaseUnit ? true : (bool) ($row->inventory_unit ?? false),
                    'updated_at' => now(),
                ]);
            }
        });

        // Register a base conversion for every article so all downstream calculations use one graph.
        DB::table('items')->orderBy('id')->chunk(200, function ($items): void {
            foreach ($items as $item) {
                $exists = DB::table('item_unit_conversions')
                    ->where('item_id', $item->id)
                    ->where('unit_id', $item->base_unit_id)
                    ->exists();
                if (! $exists) {
                    DB::table('item_unit_conversions')->insert([
                        'id' => (string) Str::uuid(),
                        'item_id' => $item->id,
                        'unit_id' => $item->base_unit_id,
                        'parent_unit_id' => null,
                        'factor_to_parent' => 1,
                        'factor_to_base' => 1,
                        'barcode' => $item->barcode,
                        'purchasing_unit' => false,
                        'sales_unit' => false,
                        'production_unit' => true,
                        'inventory_unit' => true,
                        'fractional_allowed' => false,
                        'rounding_mode' => 'NONE',
                        'active' => true,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('item_images');
        Schema::dropIfExists('item_unit_conversion_histories');

        Schema::table('item_unit_conversions', function (Blueprint $table): void {
            $table->dropForeign(['parent_unit_id']);
            $table->dropIndex(['item_id', 'active']);
            $table->dropUnique('item_unit_conversions_barcode_unique');
            $table->dropColumn([
                'parent_unit_id', 'factor_to_parent', 'barcode', 'net_weight_kg', 'gross_weight_kg',
                'tare_weight_kg', 'length_cm', 'width_cm', 'height_cm', 'volume_m3', 'production_unit',
                'inventory_unit', 'fractional_allowed', 'rounding_mode', 'valid_from', 'valid_to', 'active', 'image_path',
            ]);
        });

        Schema::table('items', function (Blueprint $table): void {
            $table->dropColumn(['main_image_path', 'main_image_thumbnail_path']);
        });
    }
};
