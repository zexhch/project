<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('units', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('code', 20)->unique();
            $table->string('name');
            $table->string('symbol', 20);
            $table->string('dimension', 30)->default('COUNT');
            $table->unsignedTinyInteger('decimal_places')->default(3);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('unit_conversions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('from_unit_id')->constrained('units')->cascadeOnDelete();
            $table->foreignUuid('to_unit_id')->constrained('units')->cascadeOnDelete();
            $table->decimal('factor', 20, 8);
            $table->timestamps();

            $table->unique(['from_unit_id', 'to_unit_id']);
        });

        Schema::create('item_categories', function (Blueprint $table): void {
            $table->uuid('id');
            // PostgreSQL requires the primary key before the self-referencing FK.
            $table->primary('id');
            $table->foreignUuid('parent_id')->nullable()->constrained('item_categories')->nullOnDelete();
            $table->string('code', 50)->unique();
            $table->string('name');
            $table->string('category_type', 40)->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('items', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('category_id')->nullable()->constrained('item_categories')->nullOnDelete();
            $table->foreignUuid('base_unit_id')->constrained('units');
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('item_type', 40)->index();
            $table->string('barcode')->nullable()->unique();
            $table->boolean('lot_managed')->default(true);
            $table->boolean('expiry_managed')->default(false);
            $table->decimal('minimum_stock', 18, 3)->default(0);
            $table->unsignedInteger('shelf_life_days')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('item_unit_conversions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('item_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('unit_id')->constrained('units');
            $table->decimal('factor_to_base', 20, 8);
            $table->boolean('purchasing_unit')->default(false);
            $table->boolean('sales_unit')->default(false);
            $table->timestamps();

            $table->unique(['item_id', 'unit_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('item_unit_conversions');
        Schema::dropIfExists('items');
        Schema::dropIfExists('item_categories');
        Schema::dropIfExists('unit_conversions');
        Schema::dropIfExists('units');
    }
};
