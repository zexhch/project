<?php

use App\Http\Controllers\ItemPackagingController;
use App\Http\Controllers\MasterDataController;
use Illuminate\Support\Facades\Route;

Route::get('/admin/{resource}', MasterDataController::class)
    ->where('resource', '[a-z0-9-]+')
    ->middleware('resource.module')
    ->name('admin.master-data');

Route::prefix('/admin/items/{item}')->name('admin.items.')->group(function (): void {
    Route::get('/packaging', [ItemPackagingController::class, 'index'])->name('packaging');
    Route::post('/packaging', [ItemPackagingController::class, 'store'])->name('packaging.store');
    Route::put('/packaging/{conversion}', [ItemPackagingController::class, 'update'])->name('packaging.update');
    Route::delete('/packaging/{conversion}', [ItemPackagingController::class, 'destroy'])->name('packaging.destroy');
    Route::post('/main-image', [ItemPackagingController::class, 'uploadMain'])->name('main-image.store');
    Route::delete('/main-image', [ItemPackagingController::class, 'deleteMain'])->name('main-image.destroy');
    Route::post('/gallery', [ItemPackagingController::class, 'uploadGallery'])->name('gallery.store');
    Route::delete('/gallery/{image}', [ItemPackagingController::class, 'deleteGallery'])->name('gallery.destroy');
});

Route::post('/admin/items/images/import', [ItemPackagingController::class, 'importImages'])
    ->name('admin.items.images.import');
