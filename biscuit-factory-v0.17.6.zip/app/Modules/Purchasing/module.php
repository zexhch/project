<?php

return [
    'code' => 'purchasing',
    'name' => 'modules.purchasing_name',
    'description' => 'modules.purchasing_description',
    'version' => '0.17.6',
    'icon' => 'ti-building-store',
    'order' => 80,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['purchasing'],
    'dependencies' => ['master-data', 'stocks'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
