<?php

use App\Http\Controllers\FinancialDocumentController;
use App\Http\Controllers\PurchasingController;
use Illuminate\Support\Facades\Route;

Route::prefix('purchasing')->name('purchasing.')->group(function (): void {
    Route::get('/', [PurchasingController::class, 'index'])->middleware('permission:purchasing.view')->name('index');
    Route::post('/orders', [PurchasingController::class, 'storeOrder'])->middleware('permission:purchasing.create')->name('orders.store');
    Route::get('/orders/{order}', [PurchasingController::class, 'showOrder'])->middleware('permission:purchasing.view')->name('orders.show');
    Route::post('/orders/{order}/lines', [PurchasingController::class, 'addOrderLine'])->middleware('permission:purchasing.update')->name('orders.lines.store');
    Route::post('/orders/{order}/submit', [PurchasingController::class, 'submitOrder'])->middleware('permission:purchasing.update')->name('orders.submit');
    Route::post('/orders/{order}/approve', [PurchasingController::class, 'approveOrder'])->middleware('permission:purchasing.approve')->name('orders.approve');
    Route::post('/orders/{order}/receipts', [PurchasingController::class, 'storeReceipt'])->middleware('permission:purchasing.create')->name('orders.receipts.store');
    Route::get('/orders/{order}/print', [FinancialDocumentController::class, 'purchaseOrder'])->middleware('permission:purchasing.view')->name('orders.print');

    Route::get('/suppliers', [PurchasingController::class, 'suppliers'])->middleware('permission:purchasing.view')->name('suppliers.index');
    Route::post('/suppliers', [PurchasingController::class, 'storeSupplier'])->middleware('permission:purchasing.create')->name('suppliers.store');
    Route::get('/suppliers/{supplier}', [PurchasingController::class, 'showSupplier'])->middleware('permission:purchasing.view')->name('suppliers.show');
    Route::put('/suppliers/{supplier}', [PurchasingController::class, 'updateSupplier'])->middleware('permission:purchasing.update')->name('suppliers.update');
    Route::put('/suppliers/{supplier}/status', [PurchasingController::class, 'updateSupplierStatus'])->middleware('permission:purchasing.approve')->name('suppliers.status');
    Route::post('/suppliers/{supplier}/contacts', [PurchasingController::class, 'storeSupplierContact'])->middleware('permission:purchasing.update')->name('suppliers.contacts.store');
    Route::post('/suppliers/{supplier}/items', [PurchasingController::class, 'storeSupplierItem'])->middleware('permission:purchasing.update')->name('suppliers.items.store');
    Route::post('/suppliers/{supplier}/evaluations', [PurchasingController::class, 'storeEvaluation'])->middleware('permission:purchasing.update')->name('suppliers.evaluations.store');

    Route::get('/price-lists', [PurchasingController::class, 'priceLists'])->middleware('permission:purchasing.view')->name('price-lists.index');
    Route::post('/price-lists', [PurchasingController::class, 'storePriceList'])->middleware('permission:purchasing.create')->name('price-lists.store');
    Route::get('/price-lists/{priceList}', [PurchasingController::class, 'showPriceList'])->middleware('permission:purchasing.view')->name('price-lists.show');
    Route::post('/price-lists/{priceList}/lines', [PurchasingController::class, 'addPriceListLine'])->middleware('permission:purchasing.update')->name('price-lists.lines.store');
    Route::post('/price-lists/{priceList}/approve', [PurchasingController::class, 'approvePriceList'])->middleware('permission:purchasing.approve')->name('price-lists.approve');

    Route::get('/requisitions', [PurchasingController::class, 'requisitions'])->middleware('permission:purchasing.view')->name('requisitions.index');
    Route::post('/requisitions', [PurchasingController::class, 'storeRequisition'])->middleware('permission:purchasing.create')->name('requisitions.store');
    Route::get('/requisitions/{requisition}', [PurchasingController::class, 'showRequisition'])->middleware('permission:purchasing.view')->name('requisitions.show');
    Route::post('/requisitions/{requisition}/lines', [PurchasingController::class, 'addRequisitionLine'])->middleware('permission:purchasing.update')->name('requisitions.lines.store');
    Route::post('/requisitions/{requisition}/submit', [PurchasingController::class, 'submitRequisition'])->middleware('permission:purchasing.update')->name('requisitions.submit');
    Route::post('/requisitions/{requisition}/approve', [PurchasingController::class, 'approveRequisition'])->middleware('permission:purchasing.approve')->name('requisitions.approve');
    Route::post('/requisitions/{requisition}/quotations', [PurchasingController::class, 'storeQuotation'])->middleware('permission:purchasing.create')->name('requisitions.quotations.store');
    Route::get('/requisitions/{requisition}/print', [FinancialDocumentController::class, 'purchaseRequisition'])->middleware('permission:purchasing.view')->name('requisitions.print');
    Route::post('/quotations/{quotation}/lines', [PurchasingController::class, 'addQuotationLine'])->middleware('permission:purchasing.update')->name('quotations.lines.store');
    Route::post('/quotations/{quotation}/select', [PurchasingController::class, 'selectQuotation'])->middleware('permission:purchasing.approve')->name('quotations.select');

    Route::get('/receipts', [PurchasingController::class, 'receipts'])->middleware('permission:purchasing.view')->name('receipts.index');
    Route::get('/receipts/{receipt}', [PurchasingController::class, 'showReceipt'])->middleware('permission:purchasing.view')->name('receipts.show');
    Route::post('/receipts/{receipt}/post', [PurchasingController::class, 'postReceipt'])->middleware('permission:stocks.approve')->name('receipts.post');
    Route::post('/receipts/{receipt}/returns', [PurchasingController::class, 'storeReturn'])->middleware('permission:purchasing.create')->name('receipts.returns.store');
    Route::get('/receipts/{receipt}/print', [FinancialDocumentController::class, 'goodsReceipt'])->middleware('permission:purchasing.view')->name('receipts.print');
    Route::post('/returns/{supplierReturn}/post', [PurchasingController::class, 'postReturn'])->middleware('permission:stocks.approve')->name('returns.post');

    Route::get('/export/{type}', [PurchasingController::class, 'export'])
        ->whereIn('type', ['suppliers', 'orders'])
        ->middleware('permission:purchasing.export')
        ->name('export');
});
