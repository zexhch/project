<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('suppliers', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('legal_name')->nullable();
            $table->string('supplier_type', 40)->default('LOCAL');
            $table->string('tax_identifier', 120)->nullable();
            $table->string('registration_number', 120)->nullable();
            $table->string('country_code', 2)->default('DZ');
            $table->string('currency_code', 3)->default('DZD');
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->string('incoterm', 20)->nullable();
            $table->unsignedSmallInteger('lead_time_days')->default(0);
            $table->decimal('minimum_order_value', 20, 4)->default(0);
            $table->string('status', 30)->default('PROSPECT')->index();
            $table->boolean('preferred')->default(false);
            $table->string('email')->nullable();
            $table->string('phone', 80)->nullable();
            $table->text('address')->nullable();
            $table->text('notes')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'status', 'active']);
        });

        Schema::create('supplier_contacts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('job_title')->nullable();
            $table->string('email')->nullable();
            $table->string('phone', 80)->nullable();
            $table->string('mobile', 80)->nullable();
            $table->boolean('is_primary')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('supplier_items', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('purchasing_unit_id')->constrained('units')->restrictOnDelete();
            $table->string('supplier_reference', 120)->nullable();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('minimum_order_quantity', 18, 3)->default(0);
            $table->decimal('pack_quantity', 18, 3)->default(1);
            $table->unsignedSmallInteger('lead_time_days')->default(0);
            $table->boolean('preferred')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['supplier_id', 'item_id', 'purchasing_unit_id'], 'supplier_item_unit_unique');
        });

        Schema::create('purchase_price_lists', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('currency_code', 3);
            $table->boolean('tax_included')->default(false);
            $table->unsignedSmallInteger('priority')->default(100);
            $table->date('valid_from');
            $table->date('valid_to')->nullable();
            $table->string('status', 30)->default('DRAFT')->index();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
            $table->index(['supplier_id', 'status', 'valid_from', 'valid_to']);
        });

        Schema::create('purchase_price_list_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('purchase_price_list_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('supplier_item_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('minimum_quantity', 18, 3)->default(0);
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->unsignedSmallInteger('lead_time_days')->nullable();
            $table->timestamps();

            $table->unique(
                ['purchase_price_list_id', 'item_id', 'unit_id', 'minimum_quantity'],
                'purchase_price_tier_unique'
            );
        });

        Schema::create('purchase_requisitions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->string('requisition_number', 80)->unique();
            $table->date('request_date');
            $table->date('required_date')->nullable();
            $table->string('priority', 30)->default('NORMAL');
            $table->string('status', 30)->default('DRAFT')->index();
            $table->text('notes')->nullable();
            $table->text('rejection_reason')->nullable();
            $table->foreignUuid('requested_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('submitted_at')->nullable();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'request_date', 'status']);
        });

        Schema::create('purchase_requisition_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('purchase_requisition_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->string('description')->nullable();
            $table->decimal('quantity', 18, 3);
            $table->decimal('quantity_ordered', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->foreignUuid('suggested_supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $table->decimal('estimated_unit_price', 20, 6)->nullable();
            $table->string('currency_code', 3)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->nullOnDelete();
        });

        Schema::create('supplier_quotations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('purchase_requisition_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->string('quotation_number', 80)->unique();
            $table->string('supplier_reference', 120)->nullable();
            $table->date('quotation_date');
            $table->date('valid_until')->nullable();
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->boolean('tax_included')->default(false);
            $table->string('status', 30)->default('RECEIVED')->index();
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->unsignedSmallInteger('delivery_lead_time_days')->default(0);
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['purchase_requisition_id', 'status']);
        });

        Schema::create('supplier_quotation_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_quotation_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('purchase_requisition_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->string('description')->nullable();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('line_subtotal', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4)->default(0);
            $table->timestamps();
        });

        Schema::create('purchase_orders', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('purchase_requisition_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('supplier_quotation_id')->nullable()->constrained()->nullOnDelete();
            $table->string('order_number', 80)->unique();
            $table->date('order_date');
            $table->date('expected_date')->nullable();
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->boolean('tax_included')->default(false);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->string('incoterm', 20)->nullable();
            $table->string('supplier_reference', 120)->nullable();
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->text('notes')->nullable();
            $table->text('cancellation_reason')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('submitted_at')->nullable();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['company_id', 'order_date', 'status']);
            $table->index(['supplier_id', 'expected_date']);
        });

        Schema::create('purchase_order_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('purchase_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('purchase_requisition_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->string('description')->nullable();
            $table->decimal('ordered_quantity', 18, 3);
            $table->decimal('received_quantity', 18, 3)->default(0);
            $table->decimal('returned_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('net_unit_price', 20, 6);
            $table->decimal('line_subtotal', 20, 4);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4);
            $table->date('expected_date')->nullable();
            $table->string('status', 30)->default('OPEN');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['purchase_order_id', 'status']);
        });

        Schema::create('goods_receipts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('purchase_order_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('destination_location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->string('receipt_number', 80)->unique();
            $table->timestamp('received_at');
            $table->string('supplier_delivery_note', 120)->nullable();
            $table->string('status', 30)->default('DRAFT')->index();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->foreignUuid('stock_movement_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();

            $table->index(['purchase_order_id', 'received_at']);
        });

        Schema::create('goods_receipt_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('goods_receipt_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('purchase_order_line_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->string('lot_number', 120)->nullable();
            $table->date('manufacturing_date')->nullable();
            $table->date('expiry_date')->nullable();
            $table->decimal('accepted_quantity', 18, 3)->default(0);
            $table->decimal('rejected_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('base_quantity', 18, 3)->default(0);
            $table->decimal('unit_cost', 20, 6);
            $table->decimal('base_unit_cost', 20, 6);
            $table->text('rejection_reason')->nullable();
            $table->foreignUuid('stock_movement_line_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('supplier_returns', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('goods_receipt_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('source_location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->string('return_number', 80)->unique();
            $table->date('return_date');
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('reason_code', 80)->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->foreignUuid('stock_movement_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('supplier_return_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_return_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('goods_receipt_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('base_quantity', 18, 3);
            $table->decimal('unit_cost', 20, 6)->nullable();
            $table->text('reason')->nullable();
            $table->timestamps();
        });

        Schema::create('supplier_evaluations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->cascadeOnDelete();
            $table->string('evaluation_number', 80)->unique();
            $table->date('period_from');
            $table->date('period_to');
            $table->decimal('quality_score', 5, 2);
            $table->decimal('delivery_score', 5, 2);
            $table->decimal('commercial_score', 5, 2);
            $table->decimal('service_score', 5, 2);
            $table->decimal('total_score', 5, 2);
            $table->string('status', 30)->default('COMPLETED');
            $table->text('comments')->nullable();
            $table->foreignUuid('evaluated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->unique(['supplier_id', 'period_from', 'period_to'], 'supplier_evaluation_period_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('supplier_evaluations');
        Schema::dropIfExists('supplier_return_lines');
        Schema::dropIfExists('supplier_returns');
        Schema::dropIfExists('goods_receipt_lines');
        Schema::dropIfExists('goods_receipts');
        Schema::dropIfExists('purchase_order_lines');
        Schema::dropIfExists('purchase_orders');
        Schema::dropIfExists('supplier_quotation_lines');
        Schema::dropIfExists('supplier_quotations');
        Schema::dropIfExists('purchase_requisition_lines');
        Schema::dropIfExists('purchase_requisitions');
        Schema::dropIfExists('purchase_price_list_lines');
        Schema::dropIfExists('purchase_price_lists');
        Schema::dropIfExists('supplier_items');
        Schema::dropIfExists('supplier_contacts');
        Schema::dropIfExists('suppliers');
    }
};
