<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('suppliers', function (Blueprint $table): void {
            $table->string('statistical_identification_number', 120)->nullable()->after('registration_number');
            $table->string('article_of_imposition_number', 120)->nullable()->after('statistical_identification_number');
        });
    }

    public function down(): void
    {
        Schema::table('suppliers', function (Blueprint $table): void {
            $table->dropColumn(['statistical_identification_number', 'article_of_imposition_number']);
        });
    }
};
