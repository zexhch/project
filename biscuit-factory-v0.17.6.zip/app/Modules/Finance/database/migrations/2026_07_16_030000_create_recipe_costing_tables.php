<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('recipe_versions', function (Blueprint $table): void {
            $table->foreignUuid('process_template_id')->nullable()->constrained('process_templates')->nullOnDelete();
            $table->text('notes')->nullable();
        });

        Schema::create('recipe_cost_components', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('recipe_version_id')->constrained()->cascadeOnDelete();
            $table->string('cost_type', 40)->index();
            $table->string('label');
            $table->string('calculation_basis', 30)->default('QUANTITY');
            $table->decimal('quantity', 20, 6)->default(1);
            $table->foreignUuid('unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->decimal('unit_cost', 20, 6)->default(0);
            $table->decimal('percentage', 8, 3)->nullable();
            $table->string('currency_code', 3);
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });

        Schema::create('production_cost_entries', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_order_id')->constrained()->cascadeOnDelete();
            $table->string('cost_type', 40)->index();
            $table->string('label');
            $table->string('calculation_basis', 30)->default('QUANTITY');
            $table->decimal('quantity', 20, 6)->default(1);
            $table->foreignUuid('unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->decimal('unit_cost', 20, 6)->default(0);
            $table->decimal('percentage', 8, 3)->nullable();
            $table->string('currency_code', 3);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });

        Schema::create('cost_calculations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('calculation_type', 20)->index();
            $table->foreignUuid('recipe_version_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('production_order_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('currency_code', 3);
            $table->decimal('reference_quantity', 20, 6);
            $table->decimal('yield_percent', 8, 3)->default(100);
            $table->decimal('material_cost', 20, 6)->default(0);
            $table->decimal('packaging_cost', 20, 6)->default(0);
            $table->decimal('labor_cost', 20, 6)->default(0);
            $table->decimal('machine_cost', 20, 6)->default(0);
            $table->decimal('energy_cost', 20, 6)->default(0);
            $table->decimal('subcontracting_cost', 20, 6)->default(0);
            $table->decimal('overhead_cost', 20, 6)->default(0);
            $table->decimal('other_cost', 20, 6)->default(0);
            $table->decimal('total_cost', 20, 6);
            $table->decimal('unit_cost', 20, 6);
            $table->json('details')->nullable();
            $table->foreignUuid('calculated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('calculated_at');
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['recipe_version_id', 'calculation_type', 'calculated_at']);
            $table->index(['production_order_id', 'calculated_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cost_calculations');
        Schema::dropIfExists('production_cost_entries');
        Schema::dropIfExists('recipe_cost_components');

        Schema::table('recipe_versions', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('process_template_id');
            $table->dropColumn('notes');
        });
    }
};
