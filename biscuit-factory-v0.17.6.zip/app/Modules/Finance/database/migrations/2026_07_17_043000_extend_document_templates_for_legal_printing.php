<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('document_templates', function (Blueprint $table): void {
            $table->boolean('show_logo')->default(true)->after('terms');
            $table->boolean('show_legal_identifiers')->default(true)->after('show_company_details');
            $table->boolean('show_bank_details')->default(true)->after('show_legal_identifiers');
            $table->boolean('show_line_numbers')->default(true)->after('show_bank_details');
            $table->boolean('show_tax_rate')->default(true)->after('show_line_numbers');
            $table->boolean('show_amount_in_words')->default(true)->after('show_tax_rate');
            $table->boolean('show_internal_references')->default(true)->after('show_amount_in_words');
            $table->boolean('show_status')->default(true)->after('show_internal_references');
            $table->boolean('show_amounts')->nullable()->after('show_status');
        });
    }

    public function down(): void
    {
        Schema::table('document_templates', function (Blueprint $table): void {
            $table->dropColumn([
                'show_logo',
                'show_legal_identifiers',
                'show_bank_details',
                'show_line_numbers',
                'show_tax_rate',
                'show_amount_in_words',
                'show_internal_references',
                'show_status',
                'show_amounts',
            ]);
        });
    }
};
