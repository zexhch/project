<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('financial_accounts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('account_type', 30);
            $table->string('currency_code', 3);
            $table->string('bank_name')->nullable();
            $table->string('account_number', 120)->nullable();
            $table->string('iban', 80)->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'code']);
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });

        Schema::create('customer_invoices', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('sales_order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('delivery_note_id')->nullable()->unique()->constrained()->nullOnDelete();
            $table->string('invoice_number', 80)->unique();
            $table->date('invoice_date');
            $table->date('due_date');
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->decimal('credit_amount', 20, 4)->default(0);
            $table->decimal('paid_amount', 20, 4)->default(0);
            $table->decimal('balance_amount', 20, 4)->default(0);
            $table->string('customer_reference', 120)->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('issued_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('issued_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['company_id', 'invoice_date', 'status']);
            $table->index(['customer_id', 'due_date', 'status']);
        });

        Schema::create('customer_invoice_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_invoice_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('delivery_note_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('sales_order_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->nullable()->constrained()->nullOnDelete();
            $table->string('description');
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('line_subtotal', 20, 4);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4);
            $table->timestamps();
        });

        Schema::create('supplier_invoices', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('purchase_order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('goods_receipt_id')->nullable()->unique()->constrained()->nullOnDelete();
            $table->string('invoice_number', 80)->unique();
            $table->string('supplier_invoice_number', 120);
            $table->date('invoice_date');
            $table->date('due_date');
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('matching_status', 30)->default('PENDING')->index();
            $table->decimal('matching_variance_amount', 20, 4)->default(0);
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->decimal('credit_amount', 20, 4)->default(0);
            $table->decimal('paid_amount', 20, 4)->default(0);
            $table->decimal('balance_amount', 20, 4)->default(0);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['supplier_id', 'supplier_invoice_number']);
            $table->index(['company_id', 'invoice_date', 'status']);
            $table->index(['supplier_id', 'due_date', 'status']);
        });

        Schema::create('supplier_invoice_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_invoice_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('goods_receipt_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('purchase_order_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->nullable()->constrained()->nullOnDelete();
            $table->string('description');
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->nullable()->constrained('units')->nullOnDelete();
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('line_subtotal', 20, 4);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4);
            $table->timestamps();
        });

        Schema::create('customer_credit_notes', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_invoice_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->string('credit_note_number', 80)->unique();
            $table->date('credit_note_date');
            $table->string('currency_code', 3);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->decimal('total_amount', 20, 4);
            $table->decimal('applied_amount', 20, 4)->default(0);
            $table->string('reason_code', 80)->nullable();
            $table->text('reason');
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('issued_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('issued_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });

        Schema::create('supplier_credit_notes', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_invoice_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->string('credit_note_number', 80)->unique();
            $table->string('supplier_credit_note_number', 120)->nullable();
            $table->date('credit_note_date');
            $table->string('currency_code', 3);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->decimal('total_amount', 20, 4);
            $table->decimal('applied_amount', 20, 4)->default(0);
            $table->string('reason_code', 80)->nullable();
            $table->text('reason');
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });

        Schema::create('customer_payments', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('financial_account_id')->nullable()->constrained()->nullOnDelete();
            $table->string('payment_number', 80)->unique();
            $table->date('payment_date');
            $table->string('payment_method_code', 80);
            $table->string('currency_code', 3);
            $table->decimal('amount', 20, 4);
            $table->decimal('allocated_amount', 20, 4)->default(0);
            $table->decimal('unallocated_amount', 20, 4)->default(0);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('external_reference', 160)->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->text('reversal_reason')->nullable();
            $table->foreignUuid('reversed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reversed_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['customer_id', 'payment_date', 'status']);
        });

        Schema::create('customer_payment_allocations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_payment_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('customer_invoice_id')->constrained()->restrictOnDelete();
            $table->decimal('amount', 20, 4);
            $table->timestamps();
            $table->unique(['customer_payment_id', 'customer_invoice_id'], 'customer_payment_invoice_unique');
        });

        Schema::create('customer_payment_reminders', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_invoice_id')->constrained()->cascadeOnDelete();
            $table->string('reminder_number', 80)->unique();
            $table->date('reminder_date');
            $table->string('channel_code', 80);
            $table->string('status', 30)->default('SENT');
            $table->date('next_action_date')->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->index(['customer_invoice_id', 'reminder_date']);
        });

        Schema::create('supplier_payments', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('supplier_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('financial_account_id')->nullable()->constrained()->nullOnDelete();
            $table->string('payment_number', 80)->unique();
            $table->date('payment_date');
            $table->string('payment_method_code', 80);
            $table->string('currency_code', 3);
            $table->decimal('amount', 20, 4);
            $table->decimal('allocated_amount', 20, 4)->default(0);
            $table->decimal('unallocated_amount', 20, 4)->default(0);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('external_reference', 160)->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->text('reversal_reason')->nullable();
            $table->foreignUuid('reversed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reversed_at')->nullable();
            $table->timestamps();
            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['supplier_id', 'payment_date', 'status']);
        });

        Schema::create('supplier_payment_allocations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('supplier_payment_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('supplier_invoice_id')->constrained()->restrictOnDelete();
            $table->decimal('amount', 20, 4);
            $table->timestamps();
            $table->unique(['supplier_payment_id', 'supplier_invoice_id'], 'supplier_payment_invoice_unique');
        });

        if (DB::getDriverName() === 'pgsql') {
            DB::statement("ALTER TABLE customer_payments ADD CONSTRAINT customer_payment_amount_positive CHECK (amount > 0)");
            DB::statement("ALTER TABLE supplier_payments ADD CONSTRAINT supplier_payment_amount_positive CHECK (amount > 0)");
            DB::statement("ALTER TABLE customer_payment_allocations ADD CONSTRAINT customer_allocation_amount_positive CHECK (amount > 0)");
            DB::statement("ALTER TABLE supplier_payment_allocations ADD CONSTRAINT supplier_allocation_amount_positive CHECK (amount > 0)");
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('supplier_payment_allocations');
        Schema::dropIfExists('supplier_payments');
        Schema::dropIfExists('customer_payment_reminders');
        Schema::dropIfExists('customer_payment_allocations');
        Schema::dropIfExists('customer_payments');
        Schema::dropIfExists('supplier_credit_notes');
        Schema::dropIfExists('customer_credit_notes');
        Schema::dropIfExists('supplier_invoice_lines');
        Schema::dropIfExists('supplier_invoices');
        Schema::dropIfExists('customer_invoice_lines');
        Schema::dropIfExists('customer_invoices');
        Schema::dropIfExists('financial_accounts');
    }
};
