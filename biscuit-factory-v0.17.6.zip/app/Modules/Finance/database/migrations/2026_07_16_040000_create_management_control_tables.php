<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cost_centers', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('center_type', 50)->index();
            $table->string('allocation_method', 50)->default('DIRECT');
            $table->foreignUuid('responsible_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'active']);
        });

        Schema::create('cost_center_rates', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('cost_center_id')->constrained()->cascadeOnDelete();
            $table->string('rate_type', 50)->index();
            $table->decimal('hourly_rate', 20, 6);
            $table->string('currency_code', 3);
            $table->date('valid_from');
            $table->date('valid_to')->nullable();
            $table->text('notes')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['cost_center_id', 'rate_type', 'valid_from'], 'cost_center_rate_version_unique');
            $table->index(['cost_center_id', 'valid_from', 'valid_to'], 'cost_center_rate_validity_idx');
        });

        Schema::create('cost_scenarios', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('currency_code', 3);
            $table->date('valid_from')->nullable();
            $table->decimal('planned_revenue', 20, 4)->default(0);
            $table->decimal('planned_cost', 20, 4)->default(0);
            $table->decimal('planned_margin', 20, 4)->default(0);
            $table->decimal('planned_margin_percentage', 10, 4)->default(0);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('calculated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('calculated_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
        });

        Schema::create('cost_scenario_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('cost_scenario_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('recipe_version_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('planned_quantity', 20, 6);
            $table->decimal('sales_unit_price', 20, 6)->default(0);
            $table->decimal('material_adjustment_percentage', 10, 4)->default(0);
            $table->decimal('conversion_adjustment_percentage', 10, 4)->default(0);
            $table->decimal('overhead_adjustment_percentage', 10, 4)->default(0);
            $table->decimal('material_unit_cost', 20, 6)->default(0);
            $table->decimal('packaging_unit_cost', 20, 6)->default(0);
            $table->decimal('labor_unit_cost', 20, 6)->default(0);
            $table->decimal('machine_unit_cost', 20, 6)->default(0);
            $table->decimal('energy_unit_cost', 20, 6)->default(0);
            $table->decimal('overhead_unit_cost', 20, 6)->default(0);
            $table->decimal('other_unit_cost', 20, 6)->default(0);
            $table->decimal('total_unit_cost', 20, 6)->default(0);
            $table->decimal('planned_revenue', 20, 4)->default(0);
            $table->decimal('planned_cost', 20, 4)->default(0);
            $table->decimal('planned_margin', 20, 4)->default(0);
            $table->decimal('planned_margin_percentage', 10, 4)->default(0);
            $table->json('calculation_details')->nullable();
            $table->timestamps();

            $table->index(['cost_scenario_id', 'item_id']);
        });

        Schema::create('management_budgets', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('cost_center_id')->nullable()->constrained()->nullOnDelete();
            $table->unsignedSmallInteger('fiscal_year');
            $table->unsignedTinyInteger('period')->default(0);
            $table->string('category_code', 50)->index();
            $table->decimal('budget_amount', 20, 4);
            $table->decimal('actual_amount', 20, 4)->default(0);
            $table->decimal('variance_amount', 20, 4)->default(0);
            $table->decimal('variance_percentage', 10, 4)->default(0);
            $table->string('currency_code', 3);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('refreshed_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(
                ['company_id', 'cost_center_id', 'fiscal_year', 'period', 'category_code'],
                'management_budget_scope_unique'
            );
        });

        Schema::table('production_lines', function (Blueprint $table): void {
            $table->foreignUuid('cost_center_id')->nullable()->constrained()->nullOnDelete();
        });

        Schema::table('machines', function (Blueprint $table): void {
            $table->foreignUuid('cost_center_id')->nullable()->constrained()->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('machines', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('cost_center_id');
        });
        Schema::table('production_lines', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('cost_center_id');
        });

        Schema::dropIfExists('management_budgets');
        Schema::dropIfExists('cost_scenario_lines');
        Schema::dropIfExists('cost_scenarios');
        Schema::dropIfExists('cost_center_rates');
        Schema::dropIfExists('cost_centers');
    }
};
