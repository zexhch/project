<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('accounting_periods', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('fiscal_year');
            $table->unsignedTinyInteger('period');
            $table->date('starts_on');
            $table->date('ends_on');
            $table->string('status', 20)->default('OPEN')->index();
            $table->json('closing_snapshot')->nullable();
            $table->text('close_reason')->nullable();
            $table->foreignUuid('closed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('closed_at')->nullable();
            $table->text('reopen_reason')->nullable();
            $table->foreignUuid('reopened_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reopened_at')->nullable();
            $table->timestamps();

            $table->unique(['company_id', 'fiscal_year', 'period']);
            $table->index(['company_id', 'starts_on', 'ends_on']);
        });

        Schema::create('document_number_sequences', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('document_type', 80);
            $table->string('prefix', 20);
            $table->string('pattern', 120)->default('{PREFIX}-{YEAR}-{NUMBER}');
            $table->string('reset_policy', 20)->default('ANNUAL');
            $table->unsignedSmallInteger('fiscal_year')->default(0);
            $table->unsignedTinyInteger('period')->default(0);
            $table->unsignedBigInteger('next_number')->default(1);
            $table->unsignedTinyInteger('padding')->default(6);
            $table->timestamp('last_issued_at')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['company_id', 'document_type', 'fiscal_year', 'period'], 'document_sequence_scope_unique');
            $table->index(['company_id', 'active']);
        });

        Schema::create('approval_workflows', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('document_type', 80)->index();
            $table->decimal('minimum_amount', 20, 4)->default(0);
            $table->string('currency_code', 3)->nullable();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'document_type', 'active']);
        });

        Schema::create('approval_workflow_levels', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('approval_workflow_id')->constrained()->cascadeOnDelete();
            $table->unsignedTinyInteger('sequence');
            $table->string('name');
            $table->string('permission_code', 120)->default('finance.approve');
            $table->string('role_code', 80)->nullable();
            $table->unsignedTinyInteger('minimum_approvals')->default(1);
            $table->decimal('amount_from', 20, 4)->nullable();
            $table->decimal('amount_to', 20, 4)->nullable();
            $table->timestamps();

            $table->unique(['approval_workflow_id', 'sequence']);
        });

        Schema::create('approval_requests', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('approval_workflow_id')->constrained()->restrictOnDelete();
            $table->uuidMorphs('approvable');
            $table->string('document_type', 80)->index();
            $table->string('document_number', 120)->nullable();
            $table->decimal('amount', 20, 4)->default(0);
            $table->string('currency_code', 3)->nullable();
            $table->string('status', 20)->default('PENDING')->index();
            $table->unsignedTinyInteger('current_level')->default(1);
            $table->foreignUuid('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('submitted_at');
            $table->timestamp('completed_at')->nullable();
            $table->text('completion_comment')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['company_id', 'status', 'submitted_at']);
        });

        Schema::create('approval_request_steps', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('approval_request_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('approval_workflow_level_id')->nullable()->constrained()->nullOnDelete();
            $table->unsignedTinyInteger('sequence');
            $table->string('name');
            $table->string('permission_code', 120)->default('finance.approve');
            $table->string('role_code', 80)->nullable();
            $table->unsignedTinyInteger('required_approvals')->default(1);
            $table->unsignedTinyInteger('approved_count')->default(0);
            $table->string('status', 20)->default('WAITING')->index();
            $table->json('decisions')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->unique(['approval_request_id', 'sequence']);
        });

        Schema::create('document_templates', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('document_type', 80)->index();
            $table->string('locale', 10)->default('fr');
            $table->string('title')->nullable();
            $table->text('header_text')->nullable();
            $table->text('footer_text')->nullable();
            $table->text('terms')->nullable();
            $table->boolean('show_company_details')->default(true);
            $table->boolean('show_signature_blocks')->default(true);
            $table->boolean('is_default')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'document_type', 'locale', 'active'], 'document_templates_lookup_idx');
        });

        Schema::create('document_revisions', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->nullable()->constrained()->nullOnDelete();
            $table->string('document_type', 80)->index();
            $table->uuid('document_id')->index();
            $table->string('document_number', 120)->nullable();
            $table->unsignedInteger('version')->default(1);
            $table->string('action', 40)->index();
            $table->json('snapshot')->nullable();
            $table->text('reason')->nullable();
            $table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('created_at')->useCurrent();

            $table->unique(['document_type', 'document_id', 'version']);
            $table->index(['company_id', 'created_at']);
        });

        Schema::create('document_cancellations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('document_type', 80);
            $table->uuid('document_id');
            $table->string('document_number', 120)->nullable();
            $table->string('original_status', 40)->nullable();
            $table->string('cancellation_type', 40);
            $table->text('reason');
            $table->string('counter_document_type', 80)->nullable();
            $table->uuid('counter_document_id')->nullable();
            $table->string('counter_document_number', 120)->nullable();
            $table->foreignUuid('cancelled_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('cancelled_at');
            $table->timestamps();

            $table->unique(['document_type', 'document_id']);
            $table->index(['company_id', 'cancelled_at']);
        });

        if (DB::getDriverName() === 'pgsql') {
            DB::statement("ALTER TABLE accounting_periods ADD CONSTRAINT accounting_period_month_valid CHECK (period BETWEEN 1 AND 12)");
            DB::statement("ALTER TABLE accounting_periods ADD CONSTRAINT accounting_period_dates_valid CHECK (starts_on <= ends_on)");
            DB::statement("ALTER TABLE document_number_sequences ADD CONSTRAINT document_sequence_padding_valid CHECK (padding BETWEEN 1 AND 18)");
            DB::statement("ALTER TABLE approval_workflow_levels ADD CONSTRAINT approval_level_minimum_valid CHECK (minimum_approvals >= 1)");
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('document_cancellations');
        Schema::dropIfExists('document_revisions');
        Schema::dropIfExists('document_templates');
        Schema::dropIfExists('approval_request_steps');
        Schema::dropIfExists('approval_requests');
        Schema::dropIfExists('approval_workflow_levels');
        Schema::dropIfExists('approval_workflows');
        Schema::dropIfExists('document_number_sequences');
        Schema::dropIfExists('accounting_periods');
    }
};
