<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customer_payment_allocations', function (Blueprint $table): void {
            $table->index('customer_invoice_id', 'customer_allocations_invoice_idx');
        });
        Schema::table('supplier_payment_allocations', function (Blueprint $table): void {
            $table->index('supplier_invoice_id', 'supplier_allocations_invoice_idx');
        });
        Schema::table('customer_credit_notes', function (Blueprint $table): void {
            $table->index(['customer_invoice_id', 'status'], 'customer_credits_invoice_status_idx');
        });
        Schema::table('supplier_credit_notes', function (Blueprint $table): void {
            $table->index(['supplier_invoice_id', 'status'], 'supplier_credits_invoice_status_idx');
        });
        Schema::table('customer_payments', function (Blueprint $table): void {
            $table->index(['company_id', 'status', 'payment_date'], 'customer_payments_company_status_date_idx');
        });
        Schema::table('supplier_payments', function (Blueprint $table): void {
            $table->index(['company_id', 'status', 'payment_date'], 'supplier_payments_company_status_date_idx');
        });

        if (DB::getDriverName() === 'pgsql') {
            // NOT VALID avoids blocking an upgrade if historical data must first be repaired.
            // PostgreSQL still enforces these constraints for every new or modified row.
            DB::statement('ALTER TABLE customer_invoices ADD CONSTRAINT customer_invoice_derived_amounts_nonnegative CHECK (credit_amount >= 0 AND paid_amount >= 0 AND balance_amount >= 0) NOT VALID');
            DB::statement('ALTER TABLE supplier_invoices ADD CONSTRAINT supplier_invoice_derived_amounts_nonnegative CHECK (credit_amount >= 0 AND paid_amount >= 0 AND balance_amount >= 0) NOT VALID');
            DB::statement('ALTER TABLE customer_payments ADD CONSTRAINT customer_payment_derived_amounts_nonnegative CHECK (allocated_amount >= 0 AND unallocated_amount >= 0) NOT VALID');
            DB::statement('ALTER TABLE supplier_payments ADD CONSTRAINT supplier_payment_derived_amounts_nonnegative CHECK (allocated_amount >= 0 AND unallocated_amount >= 0) NOT VALID');
            DB::statement('ALTER TABLE customer_credit_notes ADD CONSTRAINT customer_credit_applied_amount_valid CHECK (total_amount > 0 AND applied_amount >= 0 AND applied_amount <= total_amount) NOT VALID');
            DB::statement('ALTER TABLE supplier_credit_notes ADD CONSTRAINT supplier_credit_applied_amount_valid CHECK (total_amount > 0 AND applied_amount >= 0 AND applied_amount <= total_amount) NOT VALID');
        }
    }

    public function down(): void
    {
        if (DB::getDriverName() === 'pgsql') {
            DB::statement('ALTER TABLE supplier_credit_notes DROP CONSTRAINT IF EXISTS supplier_credit_applied_amount_valid');
            DB::statement('ALTER TABLE customer_credit_notes DROP CONSTRAINT IF EXISTS customer_credit_applied_amount_valid');
            DB::statement('ALTER TABLE supplier_payments DROP CONSTRAINT IF EXISTS supplier_payment_derived_amounts_nonnegative');
            DB::statement('ALTER TABLE customer_payments DROP CONSTRAINT IF EXISTS customer_payment_derived_amounts_nonnegative');
            DB::statement('ALTER TABLE supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoice_derived_amounts_nonnegative');
            DB::statement('ALTER TABLE customer_invoices DROP CONSTRAINT IF EXISTS customer_invoice_derived_amounts_nonnegative');
        }

        Schema::table('supplier_payments', function (Blueprint $table): void {
            $table->dropIndex('supplier_payments_company_status_date_idx');
        });
        Schema::table('customer_payments', function (Blueprint $table): void {
            $table->dropIndex('customer_payments_company_status_date_idx');
        });
        Schema::table('supplier_credit_notes', function (Blueprint $table): void {
            $table->dropIndex('supplier_credits_invoice_status_idx');
        });
        Schema::table('customer_credit_notes', function (Blueprint $table): void {
            $table->dropIndex('customer_credits_invoice_status_idx');
        });
        Schema::table('supplier_payment_allocations', function (Blueprint $table): void {
            $table->dropIndex('supplier_allocations_invoice_idx');
        });
        Schema::table('customer_payment_allocations', function (Blueprint $table): void {
            $table->dropIndex('customer_allocations_invoice_idx');
        });
    }
};
