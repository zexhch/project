<?php

use App\Http\Controllers\BillingController;
use App\Http\Controllers\CostingController;
use App\Http\Controllers\FinancialDocumentController;
use App\Http\Controllers\FinancialGovernanceController;
use App\Http\Controllers\ManagementControlController;
use Illuminate\Support\Facades\Route;

Route::prefix('costing')->name('costing.')->group(function (): void {
    Route::get('/', [CostingController::class, 'index'])->middleware('permission:finance.view')->name('index');
    Route::post('/recipes/{version}/snapshot', [CostingController::class, 'snapshotTheoretical'])->middleware('permission:finance.create')->name('recipes.snapshot');
    Route::post('/orders/{order}/entries', [CostingController::class, 'storeEntry'])->middleware('permission:production.update')->name('orders.entries.store');
    Route::delete('/orders/{order}/entries/{entry}', [CostingController::class, 'destroyEntry'])->middleware('permission:production.update')->name('orders.entries.destroy');
    Route::post('/orders/{order}/snapshot', [CostingController::class, 'snapshotActual'])->middleware('permission:finance.create')->name('orders.snapshot');
});

Route::prefix('finance/control')->name('finance.control.')->group(function (): void {
    Route::get('/', [ManagementControlController::class, 'index'])->middleware('permission:finance.view')->name('index');
    Route::post('/cost-centers', [ManagementControlController::class, 'storeCenter'])->middleware('permission:finance.create')->name('centers.store');
    Route::put('/cost-centers/{center}', [ManagementControlController::class, 'updateCenter'])->middleware('permission:finance.update')->name('centers.update');
    Route::put('/cost-centers/{center}/resources', [ManagementControlController::class, 'assignCenterResources'])->middleware('permission:finance.update')->name('centers.resources');
    Route::post('/cost-centers/{center}/rates', [ManagementControlController::class, 'storeRate'])->middleware('permission:finance.create')->name('rates.store');
    Route::post('/scenarios', [ManagementControlController::class, 'storeScenario'])->middleware('permission:finance.create')->name('scenarios.store');
    Route::post('/scenarios/{scenario}/lines', [ManagementControlController::class, 'storeScenarioLine'])->middleware('permission:finance.update')->name('scenarios.lines.store');
    Route::delete('/scenarios/{scenario}/lines/{line}', [ManagementControlController::class, 'destroyScenarioLine'])->middleware('permission:finance.update')->name('scenarios.lines.destroy');
    Route::post('/scenarios/{scenario}/calculate', [ManagementControlController::class, 'calculateScenario'])->middleware('permission:finance.update')->name('scenarios.calculate');
    Route::post('/scenarios/{scenario}/approve', [ManagementControlController::class, 'approveScenario'])->middleware('permission:finance.approve')->name('scenarios.approve');
    Route::post('/budgets', [ManagementControlController::class, 'storeBudget'])->middleware('permission:finance.create')->name('budgets.store');
    Route::post('/budgets/{budget}/refresh', [ManagementControlController::class, 'refreshBudget'])->middleware('permission:finance.update')->name('budgets.refresh');
    Route::post('/budgets/{budget}/approve', [ManagementControlController::class, 'approveBudget'])->middleware('permission:finance.approve')->name('budgets.approve');
});

Route::prefix('finance/billing')->name('finance.billing.')->group(function (): void {
    Route::get('/', [BillingController::class, 'index'])->middleware('permission:finance.view')->name('index');
    Route::post('/customer-invoices', [BillingController::class, 'storeCustomerInvoice'])->middleware('permission:finance.create')->name('customer-invoices.store');
    Route::get('/customer-invoices/{invoice}', [BillingController::class, 'showCustomerInvoice'])->middleware('permission:finance.view')->name('customer-invoices.show');
    Route::post('/customer-invoices/{invoice}/issue', [BillingController::class, 'issueCustomerInvoice'])->middleware('permission:finance.approve')->name('customer-invoices.issue');
    Route::post('/customer-invoices/{invoice}/credit-notes', [BillingController::class, 'storeCustomerCredit'])->middleware('permission:finance.approve')->name('customer-invoices.credit-notes.store');
    Route::post('/customer-invoices/{invoice}/reminders', [BillingController::class, 'storeCustomerReminder'])->middleware('permission:finance.update')->name('customer-invoices.reminders.store');
    Route::post('/supplier-invoices', [BillingController::class, 'storeSupplierInvoice'])->middleware('permission:finance.create')->name('supplier-invoices.store');
    Route::get('/supplier-invoices/{invoice}', [BillingController::class, 'showSupplierInvoice'])->middleware('permission:finance.view')->name('supplier-invoices.show');
    Route::post('/supplier-invoices/{invoice}/approve', [BillingController::class, 'approveSupplierInvoice'])->middleware('permission:finance.approve')->name('supplier-invoices.approve');
    Route::post('/supplier-invoices/{invoice}/credit-notes', [BillingController::class, 'storeSupplierCredit'])->middleware('permission:finance.approve')->name('supplier-invoices.credit-notes.store');
    Route::post('/customer-payments', [BillingController::class, 'storeCustomerPayment'])->middleware('permission:finance.create')->name('customer-payments.store');
    Route::post('/customer-payments/{payment}/post', [BillingController::class, 'postCustomerPayment'])->middleware('permission:finance.approve')->name('customer-payments.post');
    Route::post('/customer-payments/{payment}/reverse', [BillingController::class, 'reverseCustomerPayment'])->middleware('permission:finance.approve')->name('customer-payments.reverse');
    Route::post('/supplier-payments', [BillingController::class, 'storeSupplierPayment'])->middleware('permission:finance.create')->name('supplier-payments.store');
    Route::post('/supplier-payments/{payment}/post', [BillingController::class, 'postSupplierPayment'])->middleware('permission:finance.approve')->name('supplier-payments.post');
    Route::post('/supplier-payments/{payment}/reverse', [BillingController::class, 'reverseSupplierPayment'])->middleware('permission:finance.approve')->name('supplier-payments.reverse');
});


Route::prefix('finance/governance')->name('finance.governance.')->group(function (): void {
    Route::get('/', [FinancialGovernanceController::class, 'index'])->middleware('permission:finance.view')->name('index');
    Route::post('/periods/generate', [FinancialGovernanceController::class, 'generatePeriods'])->middleware('permission:finance.create')->name('periods.generate');
    Route::post('/periods/{period}/close', [FinancialGovernanceController::class, 'closePeriod'])->middleware('permission:finance.approve')->name('periods.close');
    Route::post('/periods/{period}/reopen', [FinancialGovernanceController::class, 'reopenPeriod'])->middleware('permission:finance.approve')->name('periods.reopen');
    Route::post('/sequences', [FinancialGovernanceController::class, 'storeSequence'])->middleware('permission:finance.update')->name('sequences.store');
    Route::post('/workflows', [FinancialGovernanceController::class, 'storeWorkflow'])->middleware('permission:finance.update')->name('workflows.store');
    Route::post('/workflows/{workflow}/levels', [FinancialGovernanceController::class, 'storeWorkflowLevel'])->middleware('permission:finance.update')->name('workflows.levels.store');
    Route::post('/workflows/{workflow}/toggle', [FinancialGovernanceController::class, 'toggleWorkflow'])->middleware('permission:finance.update')->name('workflows.toggle');
    Route::post('/approvals/{approvalRequest}/approve', [FinancialGovernanceController::class, 'approveRequest'])->middleware('permission:finance.approve')->name('approvals.approve');
    Route::post('/approvals/{approvalRequest}/reject', [FinancialGovernanceController::class, 'rejectRequest'])->middleware('permission:finance.approve')->name('approvals.reject');
    Route::post('/templates', [FinancialGovernanceController::class, 'storeTemplate'])->middleware('permission:finance.update')->name('templates.store');
    Route::post('/templates/{template}/default', [FinancialGovernanceController::class, 'defaultTemplate'])->middleware('permission:finance.update')->name('templates.default');
    Route::post('/customer-invoices/{invoice}/cancel', [FinancialGovernanceController::class, 'cancelCustomerInvoice'])->middleware('permission:finance.approve')->name('customer-invoices.cancel');
    Route::post('/supplier-invoices/{invoice}/cancel', [FinancialGovernanceController::class, 'cancelSupplierInvoice'])->middleware('permission:finance.approve')->name('supplier-invoices.cancel');
});

Route::prefix('finance/documents')->name('finance.documents.')->middleware('permission:finance.view')->group(function (): void {
    Route::get('/customer-invoices/{invoice}/print', [FinancialDocumentController::class, 'customerInvoice'])->name('customer-invoices.print');
    Route::get('/supplier-invoices/{invoice}/print', [FinancialDocumentController::class, 'supplierInvoice'])->name('supplier-invoices.print');
    Route::get('/customer-credits/{credit}/print', [FinancialDocumentController::class, 'customerCredit'])->name('customer-credits.print');
    Route::get('/supplier-credits/{credit}/print', [FinancialDocumentController::class, 'supplierCredit'])->name('supplier-credits.print');
    Route::get('/customer-payments/{payment}/print', [FinancialDocumentController::class, 'customerPayment'])->name('customer-payments.print');
    Route::get('/supplier-payments/{payment}/print', [FinancialDocumentController::class, 'supplierPayment'])->name('supplier-payments.print');
});
