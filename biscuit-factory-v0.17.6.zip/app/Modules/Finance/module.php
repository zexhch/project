<?php

return [
    'code' => 'finance',
    'name' => 'modules.finance_name',
    'description' => 'modules.finance_description',
    'version' => '0.17.6',
    'icon' => 'ti-chart-histogram',
    'order' => 100,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['finance'],
    'dependencies' => ['master-data', 'production', 'purchasing', 'sales'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
