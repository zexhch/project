<?php

return [
    'code' => 'reports',
    'name' => 'modules.reports_name',
    'description' => 'modules.reports_description',
    'version' => '0.17.6',
    'icon' => 'ti-report-analytics',
    'order' => 110,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['reports'],
    'dependencies' => ['core', 'master-data'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
