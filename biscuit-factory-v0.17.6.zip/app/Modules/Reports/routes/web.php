<?php

use App\Http\Controllers\ReportController;
use Illuminate\Support\Facades\Route;

Route::prefix('reports')->name('reports.')->middleware('permission:reports.view')->group(function (): void {
    Route::get('/', [ReportController::class, 'index'])->name('index');
    Route::get('/schedules', [ReportController::class, 'schedules'])->name('schedules');
    Route::post('/schedules', [ReportController::class, 'storeSchedule'])->middleware('permission:reports.create')->name('schedules.store');
    Route::patch('/schedules/{reportSchedule}/toggle', [ReportController::class, 'toggleSchedule'])->middleware('permission:reports.update')->name('schedules.toggle');
    Route::delete('/schedules/{reportSchedule}', [ReportController::class, 'destroySchedule'])->middleware('permission:reports.delete')->name('schedules.destroy');
    Route::get('/runs/{reportRun}/download', [ReportController::class, 'downloadRun'])->middleware('permission:reports.export')->name('runs.download');
    Route::get('/{reportCode}', [ReportController::class, 'show'])->name('show');
    Route::get('/{reportCode}/export.csv', [ReportController::class, 'exportCsv'])->middleware('permission:reports.export')->name('export.csv');
    Route::get('/{reportCode}/print', [ReportController::class, 'print'])->middleware('permission:reports.export')->name('print');
});
