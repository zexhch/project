<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->unsignedSmallInteger('failed_login_attempts')->default(0);
            $table->timestamp('locked_until')->nullable()->index();
            $table->timestamp('password_changed_at')->nullable();
            $table->boolean('force_password_change')->default(false)->index();
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip', 45)->nullable();
        });

        DB::table('users')->whereNull('password_changed_at')->update(['password_changed_at' => now()]);

        Schema::table('audit_logs', function (Blueprint $table): void {
            $table->string('severity', 20)->default('info')->index();
            $table->uuid('correlation_id')->nullable()->index();
            $table->json('metadata')->nullable();
        });

        Schema::create('backup_schedules', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('frequency', 20)->default('DAILY');
            $table->unsignedTinyInteger('run_hour')->default(2);
            $table->unsignedTinyInteger('weekday')->nullable();
            $table->unsignedTinyInteger('month_day')->nullable();
            $table->boolean('include_files')->default(true);
            $table->unsignedSmallInteger('retention_days')->default(30);
            $table->boolean('active')->default(true)->index();
            $table->timestamp('next_run_at')->nullable()->index();
            $table->timestamp('last_run_at')->nullable();
            $table->foreignUuid('notification_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('backup_runs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('backup_schedule_id')->nullable()->constrained('backup_schedules')->nullOnDelete();
            $table->foreignUuid('initiated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('status', 20)->default('RUNNING')->index();
            $table->string('type', 30)->default('DATABASE_AND_FILES');
            $table->string('disk', 40)->default('local');
            $table->string('path')->nullable();
            $table->unsignedBigInteger('size_bytes')->nullable();
            $table->string('checksum_sha256', 64)->nullable();
            $table->text('error_message')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('system_health_snapshots', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('overall_status', 20)->index();
            $table->unsignedSmallInteger('failed_checks')->default(0);
            $table->unsignedSmallInteger('warnings')->default(0);
            $table->json('checks');
            $table->timestamp('captured_at')->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('system_health_snapshots');
        Schema::dropIfExists('backup_runs');
        Schema::dropIfExists('backup_schedules');

        Schema::table('audit_logs', function (Blueprint $table): void {
            $table->dropColumn(['severity', 'correlation_id', 'metadata']);
        });

        Schema::table('users', function (Blueprint $table): void {
            $table->dropColumn([
                'failed_login_attempts', 'locked_until', 'password_changed_at',
                'force_password_change', 'last_login_at', 'last_login_ip',
            ]);
        });
    }
};
