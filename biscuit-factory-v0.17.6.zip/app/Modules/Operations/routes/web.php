<?php

use App\Http\Controllers\OperationsController;
use Illuminate\Support\Facades\Route;

Route::prefix('admin/operations')->name('admin.operations.')->middleware('permission:operations.view')->group(function (): void {
    Route::get('/', [OperationsController::class, 'index'])->name('index');
    Route::put('/security-policy', [OperationsController::class, 'updatePolicy'])->middleware('permission:security.update')->name('policy.update');
    Route::post('/users/{user}/unlock', [OperationsController::class, 'unlockUser'])->middleware('permission:security.update')->name('users.unlock');
    Route::delete('/sessions/{sessionId}', [OperationsController::class, 'revokeSession'])->middleware('permission:security.update')->name('sessions.destroy');
    Route::post('/backup-schedules', [OperationsController::class, 'storeSchedule'])->middleware('permission:operations.create')->name('schedules.store');
    Route::patch('/backup-schedules/{backupSchedule}/toggle', [OperationsController::class, 'toggleSchedule'])->middleware('permission:operations.update')->name('schedules.toggle');
    Route::delete('/backup-schedules/{backupSchedule}', [OperationsController::class, 'destroySchedule'])->middleware('permission:operations.delete')->name('schedules.destroy');
    Route::post('/backups/run', [OperationsController::class, 'runBackup'])->middleware('permission:operations.create')->name('backups.run');
    Route::get('/backups/{backupRun}/download', [OperationsController::class, 'downloadBackup'])->middleware('permission:operations.export')->name('backups.download');
});
