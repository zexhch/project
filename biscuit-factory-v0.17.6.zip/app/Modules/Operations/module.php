<?php

return [
    'code' => 'operations',
    'name' => 'modules.operations_name',
    'description' => 'modules.operations_description',
    'version' => '0.17.6',
    'icon' => 'ti-activity-heartbeat',
    'order' => 110,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['operations', 'security'],
    'dependencies' => ['core', 'administration', 'master-data'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
