<?php

return [
    'code' => 'planning',
    'name' => 'modules.planning_name',
    'description' => 'modules.planning_description',
    'version' => '0.17.6',
    'icon' => 'ti-calendar-stats',
    'order' => 55,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['planning'],
    'dependencies' => ['master-data', 'stocks', 'production', 'sales', 'maintenance'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
