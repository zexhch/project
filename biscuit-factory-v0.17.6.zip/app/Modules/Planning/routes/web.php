<?php

use App\Http\Controllers\IndustrialPlanningController;
use Illuminate\Support\Facades\Route;

Route::prefix('planning')->name('planning.')->group(function (): void {
    Route::get('/', [IndustrialPlanningController::class, 'index'])->middleware('permission:planning.view')->name('index');
    Route::post('/', [IndustrialPlanningController::class, 'store'])->middleware('permission:planning.create')->name('store');
    Route::get('/capabilities', [IndustrialPlanningController::class, 'capabilities'])->middleware('permission:planning.view')->name('capabilities');
    Route::post('/capabilities', [IndustrialPlanningController::class, 'storeCapability'])->middleware('permission:planning.update')->name('capabilities.store');
    Route::delete('/capabilities/{capability}', [IndustrialPlanningController::class, 'destroyCapability'])->middleware('permission:planning.delete')->name('capabilities.destroy');
    Route::get('/oee', [IndustrialPlanningController::class, 'oee'])->middleware('permission:planning.view')->name('oee');
    Route::post('/oee/calculate', [IndustrialPlanningController::class, 'calculateOee'])->middleware('permission:planning.update')->name('oee.calculate');
    Route::get('/{plan}', [IndustrialPlanningController::class, 'show'])->middleware('permission:planning.view')->name('show');
    Route::post('/{plan}/calculate', [IndustrialPlanningController::class, 'calculate'])->middleware('permission:planning.update')->name('calculate');
    Route::post('/{plan}/approve', [IndustrialPlanningController::class, 'approve'])->middleware('permission:planning.approve')->name('approve');
    Route::post('/{plan}/generate-orders', [IndustrialPlanningController::class, 'generateOrders'])->middleware('permission:planning.create')->name('generate-orders');
    Route::post('/{plan}/scenarios', [IndustrialPlanningController::class, 'storeScenario'])->middleware('permission:planning.create')->name('scenarios.store');
});
