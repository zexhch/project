<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('production_plans', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->date('horizon_start');
            $table->date('horizon_end');
            $table->string('demand_source', 20)->default('SALES');
            $table->unsignedSmallInteger('safety_stock_days')->default(0);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->json('parameters')->nullable();
            $table->json('metrics')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('calculated_at')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'code']);
            $table->index(['site_id', 'horizon_start', 'horizon_end']);
        });

        Schema::create('production_plan_demands', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_plan_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->date('demand_date');
            $table->string('source_type', 80)->nullable();
            $table->uuid('source_id')->nullable();
            $table->decimal('gross_demand', 18, 3);
            $table->decimal('stock_on_hand', 18, 3)->default(0);
            $table->decimal('reserved_stock', 18, 3)->default(0);
            $table->decimal('planned_receipts', 18, 3)->default(0);
            $table->decimal('safety_stock', 18, 3)->default(0);
            $table->decimal('net_requirement', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->unsignedTinyInteger('priority')->default(5);
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->index(['production_plan_id', 'demand_date']);
            $table->index(['item_id', 'demand_date']);
        });

        Schema::create('material_requirements', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_plan_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('finished_item_id')->nullable()->constrained('items')->nullOnDelete();
            $table->foreignUuid('ingredient_item_id')->constrained('items')->restrictOnDelete();
            $table->foreignUuid('recipe_version_id')->nullable()->constrained()->nullOnDelete();
            $table->date('requirement_date');
            $table->decimal('gross_requirement', 18, 3);
            $table->decimal('stock_on_hand', 18, 3)->default(0);
            $table->decimal('planned_receipts', 18, 3)->default(0);
            $table->decimal('shortage_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->string('status', 30)->default('COVERED')->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->index(['production_plan_id', 'requirement_date']);
        });

        Schema::create('capacity_requirements', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_plan_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('production_plan_demand_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('production_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('work_shift_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('production_order_id')->nullable()->constrained()->nullOnDelete();
            $table->date('requirement_date');
            $table->decimal('planned_quantity', 18, 3);
            $table->unsignedInteger('required_minutes')->default(0);
            $table->unsignedInteger('available_minutes')->default(0);
            $table->decimal('load_percent', 8, 2)->default(0);
            $table->unsignedSmallInteger('sequence_number')->default(1);
            $table->timestamp('scheduled_start')->nullable();
            $table->timestamp('scheduled_end')->nullable();
            $table->string('status', 30)->default('AVAILABLE')->index();
            $table->json('conflict_codes')->nullable();
            $table->timestamps();
            $table->index(['production_plan_id', 'requirement_date']);
            $table->index(['production_line_id', 'scheduled_start', 'scheduled_end'], 'capacity_line_schedule_idx');
        });

        Schema::create('planning_conflicts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_plan_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('capacity_requirement_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('conflict_type', 50)->index();
            $table->string('severity', 20)->default('WARNING')->index();
            $table->date('conflict_date')->nullable();
            $table->string('subject_type', 80)->nullable();
            $table->uuid('subject_id')->nullable();
            $table->string('message_key');
            $table->json('context')->nullable();
            $table->string('status', 20)->default('OPEN')->index();
            $table->text('resolution')->nullable();
            $table->foreignUuid('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
        });

        Schema::create('planning_scenarios', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('production_plan_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->json('parameters');
            $table->json('metrics')->nullable();
            $table->string('status', 20)->default('CALCULATED');
            $table->boolean('is_baseline')->default(false);
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('calculated_at')->nullable();
            $table->timestamps();
            $table->unique(['production_plan_id', 'code']);
        });

        Schema::create('oee_snapshots', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('site_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('production_line_id')->constrained()->cascadeOnDelete();
            $table->date('period_start');
            $table->date('period_end');
            $table->unsignedInteger('scheduled_minutes')->default(0);
            $table->unsignedInteger('planned_downtime_minutes')->default(0);
            $table->unsignedInteger('unplanned_downtime_minutes')->default(0);
            $table->unsignedInteger('runtime_minutes')->default(0);
            $table->decimal('ideal_output', 18, 3)->default(0);
            $table->decimal('total_output', 18, 3)->default(0);
            $table->decimal('accepted_output', 18, 3)->default(0);
            $table->decimal('availability_percent', 8, 2)->default(0);
            $table->decimal('performance_percent', 8, 2)->default(0);
            $table->decimal('quality_percent', 8, 2)->default(0);
            $table->decimal('oee_percent', 8, 2)->default(0);
            $table->string('source_hash', 64)->nullable();
            $table->timestamp('calculated_at');
            $table->timestamps();
            $table->unique(['production_line_id', 'period_start', 'period_end'], 'oee_line_period_unique');
        });

        Schema::table('production_orders', function (Blueprint $table): void {
            $table->foreignUuid('production_plan_id')->nullable()->after('id')->constrained()->nullOnDelete();
            $table->foreignUuid('capacity_requirement_id')->nullable()->after('production_plan_id')->constrained()->nullOnDelete();
            $table->unique('capacity_requirement_id');
        });
    }

    public function down(): void
    {
        Schema::table('production_orders', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('capacity_requirement_id');
            $table->dropConstrainedForeignId('production_plan_id');
        });
        Schema::dropIfExists('oee_snapshots');
        Schema::dropIfExists('planning_scenarios');
        Schema::dropIfExists('planning_conflicts');
        Schema::dropIfExists('capacity_requirements');
        Schema::dropIfExists('material_requirements');
        Schema::dropIfExists('production_plan_demands');
        Schema::dropIfExists('production_plans');
    }
};
