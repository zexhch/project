<?php

use App\Http\Controllers\FinancialDocumentController;
use App\Http\Controllers\SalesController;
use Illuminate\Support\Facades\Route;

Route::prefix('sales')->name('sales.')->group(function (): void {
    Route::get('/', [SalesController::class, 'index'])->middleware('permission:sales.view')->name('index');
    Route::post('/orders', [SalesController::class, 'storeOrder'])->middleware('permission:sales.create')->name('orders.store');
    Route::get('/orders/{order}', [SalesController::class, 'showOrder'])->middleware('permission:sales.view')->name('orders.show');
    Route::post('/orders/{order}/lines', [SalesController::class, 'addOrderLine'])->middleware('permission:sales.update')->name('orders.lines.store');
    Route::delete('/orders/{order}/lines/{line}', [SalesController::class, 'removeOrderLine'])->middleware('permission:sales.update')->name('orders.lines.destroy');
    Route::post('/orders/{order}/submit', [SalesController::class, 'submitOrder'])->middleware('permission:sales.update')->name('orders.submit');
    Route::post('/orders/{order}/confirm', [SalesController::class, 'confirmOrder'])->middleware('permission:sales.approve')->name('orders.confirm');
    Route::post('/orders/{order}/reserve', [SalesController::class, 'reserveOrder'])->middleware('permission:sales.update')->name('orders.reserve');
    Route::post('/orders/{order}/cancel', [SalesController::class, 'cancelOrder'])->middleware('permission:sales.approve')->name('orders.cancel');
    Route::post('/orders/{order}/deliveries', [SalesController::class, 'storeDelivery'])->middleware('permission:sales.update')->name('orders.deliveries.store');
    Route::get('/orders/{order}/print', [FinancialDocumentController::class, 'salesOrder'])->middleware('permission:sales.view')->name('orders.print');

    Route::get('/quotations', [SalesController::class, 'quotations'])->middleware('permission:sales.view')->name('quotations.index');
    Route::post('/quotations', [SalesController::class, 'storeQuotation'])->middleware('permission:sales.create')->name('quotations.store');
    Route::get('/quotations/{quotation}', [SalesController::class, 'showQuotation'])->middleware('permission:sales.view')->name('quotations.show');
    Route::post('/quotations/{quotation}/lines', [SalesController::class, 'addQuotationLine'])->middleware('permission:sales.update')->name('quotations.lines.store');
    Route::delete('/quotations/{quotation}/lines/{line}', [SalesController::class, 'removeQuotationLine'])->middleware('permission:sales.update')->name('quotations.lines.destroy');
    Route::post('/quotations/{quotation}/send', [SalesController::class, 'sendQuotation'])->middleware('permission:sales.update')->name('quotations.send');
    Route::post('/quotations/{quotation}/accept', [SalesController::class, 'acceptQuotation'])->middleware('permission:sales.approve')->name('quotations.accept');
    Route::post('/quotations/{quotation}/convert', [SalesController::class, 'convertQuotation'])->middleware('permission:sales.create')->name('quotations.convert');
    Route::get('/quotations/{quotation}/print', [FinancialDocumentController::class, 'salesQuotation'])->middleware('permission:sales.view')->name('quotations.print');

    Route::get('/customers', [SalesController::class, 'customers'])->middleware('permission:sales.view')->name('customers.index');
    Route::post('/customers', [SalesController::class, 'storeCustomer'])->middleware('permission:sales.create')->name('customers.store');
    Route::get('/customers/{customer}', [SalesController::class, 'showCustomer'])->middleware('permission:sales.view')->name('customers.show');
    Route::put('/customers/{customer}', [SalesController::class, 'updateCustomer'])->middleware('permission:sales.update')->name('customers.update');
    Route::put('/customers/{customer}/status', [SalesController::class, 'updateCustomerStatus'])->middleware('permission:sales.approve')->name('customers.status');
    Route::post('/customers/{customer}/contacts', [SalesController::class, 'storeCustomerContact'])->middleware('permission:sales.update')->name('customers.contacts.store');

    Route::get('/price-lists', [SalesController::class, 'priceLists'])->middleware('permission:sales.view')->name('price-lists.index');
    Route::post('/price-lists', [SalesController::class, 'storePriceList'])->middleware('permission:sales.create')->name('price-lists.store');
    Route::get('/price-lists/{priceList}', [SalesController::class, 'showPriceList'])->middleware('permission:sales.view')->name('price-lists.show');
    Route::post('/price-lists/{priceList}/lines', [SalesController::class, 'addPriceListLine'])->middleware('permission:sales.update')->name('price-lists.lines.store');
    Route::delete('/price-lists/{priceList}/lines/{line}', [SalesController::class, 'removePriceListLine'])->middleware('permission:sales.update')->name('price-lists.lines.destroy');
    Route::post('/price-lists/{priceList}/approve', [SalesController::class, 'approvePriceList'])->middleware('permission:sales.approve')->name('price-lists.approve');

    Route::get('/deliveries', [SalesController::class, 'deliveries'])->middleware('permission:sales.view')->name('deliveries.index');
    Route::get('/deliveries/{delivery}', [SalesController::class, 'showDelivery'])->middleware('permission:sales.view')->name('deliveries.show');
    Route::post('/deliveries/{delivery}/post', [SalesController::class, 'postDelivery'])->middleware('permission:stocks.approve')->name('deliveries.post');
    Route::post('/deliveries/{delivery}/returns', [SalesController::class, 'storeReturn'])->middleware('permission:sales.create')->name('deliveries.returns.store');
    Route::get('/deliveries/{delivery}/print', [FinancialDocumentController::class, 'deliveryNote'])->middleware('permission:sales.view')->name('deliveries.print');
    Route::post('/returns/{customerReturn}/post', [SalesController::class, 'postReturn'])->middleware('permission:stocks.approve')->name('returns.post');

    Route::get('/export/{type}', [SalesController::class, 'export'])
        ->whereIn('type', ['customers', 'orders'])
        ->middleware('permission:sales.export')
        ->name('export');
});
