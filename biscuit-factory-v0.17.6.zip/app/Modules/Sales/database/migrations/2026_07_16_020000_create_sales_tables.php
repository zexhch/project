<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->string('code', 80);
            $table->string('name');
            $table->string('legal_name')->nullable();
            $table->string('customer_group_code', 50)->nullable()->index();
            $table->string('sales_channel_code', 50)->nullable()->index();
            $table->string('tax_identifier', 120)->nullable();
            $table->string('registration_number', 120)->nullable();
            $table->string('country_code', 2)->default('DZ');
            $table->string('currency_code', 3)->default('DZD');
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->decimal('credit_limit', 20, 4)->default(0);
            $table->boolean('tax_exempt')->default(false);
            $table->string('status', 30)->default('PROSPECT')->index();
            $table->string('email')->nullable();
            $table->string('phone', 80)->nullable();
            $table->text('billing_address')->nullable();
            $table->text('shipping_address')->nullable();
            $table->text('notes')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'status', 'active']);
        });

        Schema::create('customer_contacts', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('job_title')->nullable();
            $table->string('email')->nullable();
            $table->string('phone', 80)->nullable();
            $table->string('mobile', 80)->nullable();
            $table->boolean('is_primary')->default(false);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('sales_price_lists', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('customer_id')->nullable()->constrained()->nullOnDelete();
            $table->string('customer_group_code', 50)->nullable();
            $table->string('sales_channel_code', 50)->nullable();
            $table->string('code', 80);
            $table->string('name');
            $table->string('price_type', 40)->default('STANDARD');
            $table->string('currency_code', 3);
            $table->boolean('tax_included')->default(false);
            $table->unsignedSmallInteger('priority')->default(100);
            $table->date('valid_from');
            $table->date('valid_to')->nullable();
            $table->string('status', 30)->default('DRAFT')->index();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->unique(['company_id', 'code']);
            $table->index(['company_id', 'status', 'valid_from', 'valid_to'], 'sales_price_list_validity_idx');
        });

        Schema::create('sales_price_list_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_price_list_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('minimum_quantity', 18, 3)->default(0);
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('target_margin_percentage', 8, 4)->nullable();
            $table->timestamps();

            $table->unique(
                ['sales_price_list_id', 'item_id', 'unit_id', 'minimum_quantity'],
                'sales_price_tier_unique'
            );
        });

        Schema::create('sales_quotations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->string('quotation_number', 80)->unique();
            $table->date('quotation_date');
            $table->date('valid_until')->nullable();
            $table->date('requested_delivery_date')->nullable();
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->boolean('tax_included')->default(false);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->text('delivery_address')->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('sent_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('sent_at')->nullable();
            $table->foreignUuid('accepted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('accepted_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['company_id', 'quotation_date', 'status']);
        });

        Schema::create('sales_quotation_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_quotation_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->string('description')->nullable();
            $table->decimal('quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('net_unit_price', 20, 6);
            $table->decimal('line_subtotal', 20, 4);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4);
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('sales_orders', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('company_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('site_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('sales_quotation_id')->nullable()->constrained()->nullOnDelete();
            $table->string('order_number', 80)->unique();
            $table->string('customer_reference', 120)->nullable();
            $table->date('order_date');
            $table->date('requested_delivery_date')->nullable();
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate', 20, 8)->default(1);
            $table->boolean('tax_included')->default(false);
            $table->string('status', 30)->default('DRAFT')->index();
            $table->unsignedSmallInteger('payment_terms_days')->default(30);
            $table->decimal('subtotal', 20, 4)->default(0);
            $table->decimal('discount_amount', 20, 4)->default(0);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('total_amount', 20, 4)->default(0);
            $table->text('delivery_address')->nullable();
            $table->text('notes')->nullable();
            $table->text('cancellation_reason')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('submitted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('submitted_at')->nullable();
            $table->foreignUuid('confirmed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamps();

            $table->foreign('currency_code')->references('code')->on('currencies')->restrictOnDelete();
            $table->index(['company_id', 'order_date', 'status']);
            $table->index(['customer_id', 'requested_delivery_date']);
        });

        Schema::create('sales_order_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('sales_quotation_line_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->string('description')->nullable();
            $table->decimal('ordered_quantity', 18, 3);
            $table->decimal('reserved_quantity', 18, 3)->default(0);
            $table->decimal('delivered_quantity', 18, 3)->default(0);
            $table->decimal('returned_quantity', 18, 3)->default(0);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('unit_price', 20, 6);
            $table->decimal('discount_percentage', 8, 4)->default(0);
            $table->foreignUuid('tax_rate_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('net_unit_price', 20, 6);
            $table->decimal('line_subtotal', 20, 4);
            $table->decimal('tax_amount', 20, 4)->default(0);
            $table->decimal('line_total', 20, 4);
            $table->string('status', 30)->default('OPEN');
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('stock_reservations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_order_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('sales_order_line_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('stock_balance_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignUuid('location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->decimal('allocated_quantity', 18, 3)->default(0);
            $table->decimal('consumed_quantity', 18, 3)->default(0);
            $table->string('status', 30)->default('ACTIVE')->index();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('released_at')->nullable();
            $table->timestamps();

            $table->unique(['sales_order_line_id', 'stock_balance_id'], 'sales_line_balance_reservation_unique');
            $table->index(['stock_balance_id', 'status']);
        });

        Schema::create('delivery_notes', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('sales_order_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->string('delivery_number', 80)->unique();
            $table->timestamp('delivered_at');
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('carrier')->nullable();
            $table->string('vehicle_registration', 80)->nullable();
            $table->string('driver_name')->nullable();
            $table->string('customer_reference', 120)->nullable();
            $table->text('delivery_address')->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->foreignUuid('stock_movement_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();

            $table->index(['sales_order_id', 'delivered_at']);
        });

        Schema::create('delivery_note_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('delivery_note_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('sales_order_line_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->decimal('base_quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->timestamps();
        });

        Schema::create('delivery_allocations', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('delivery_note_line_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('stock_reservation_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->restrictOnDelete();
            $table->foreignUuid('source_location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->decimal('unit_cost', 20, 6)->nullable();
            $table->foreignUuid('stock_movement_line_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('customer_returns', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('delivery_note_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('sales_order_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('customer_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('warehouse_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('destination_location_id')->constrained('warehouse_locations')->restrictOnDelete();
            $table->string('return_number', 80)->unique();
            $table->date('return_date');
            $table->string('status', 30)->default('DRAFT')->index();
            $table->string('reason_code', 80);
            $table->text('notes')->nullable();
            $table->foreignUuid('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignUuid('posted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('posted_at')->nullable();
            $table->foreignUuid('stock_movement_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('customer_return_lines', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->foreignUuid('customer_return_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('delivery_note_line_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('delivery_allocation_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignUuid('item_id')->constrained()->restrictOnDelete();
            $table->foreignUuid('lot_id')->nullable()->constrained()->restrictOnDelete();
            $table->decimal('quantity', 18, 3);
            $table->decimal('base_quantity', 18, 3);
            $table->foreignUuid('unit_id')->constrained('units')->restrictOnDelete();
            $table->decimal('factor_to_base', 20, 8)->default(1);
            $table->decimal('unit_cost', 20, 6)->nullable();
            $table->string('condition_code', 50)->default('UNOPENED');
            $table->text('reason')->nullable();
            $table->foreignUuid('stock_movement_line_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_return_lines');
        Schema::dropIfExists('customer_returns');
        Schema::dropIfExists('delivery_allocations');
        Schema::dropIfExists('delivery_note_lines');
        Schema::dropIfExists('delivery_notes');
        Schema::dropIfExists('stock_reservations');
        Schema::dropIfExists('sales_order_lines');
        Schema::dropIfExists('sales_orders');
        Schema::dropIfExists('sales_quotation_lines');
        Schema::dropIfExists('sales_quotations');
        Schema::dropIfExists('sales_price_list_lines');
        Schema::dropIfExists('sales_price_lists');
        Schema::dropIfExists('customer_contacts');
        Schema::dropIfExists('customers');
    }
};
