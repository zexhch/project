<?php

return [
    'code' => 'sales',
    'name' => 'modules.sales_name',
    'description' => 'modules.sales_description',
    'version' => '0.17.6',
    'icon' => 'ti-shopping-bag',
    'order' => 90,
    'core' => false,
    'default_enabled' => true,
    'permissions' => ['sales'],
    'dependencies' => ['master-data', 'stocks'],
    'routes' => ['routes/web.php'],
    'migrations' => ['database/migrations'],
];
