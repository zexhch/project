<?php

namespace App\View\Components;

use App\Services\Workflow\WorkflowNextStepService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\View\Component;
use Illuminate\View\View;

class WorkflowNextStep extends Component
{
    public function __construct(public Model $subject)
    {
    }

    public function render(): View
    {
        return view('components.workflow-next-step', [
            'nextStep' => app(WorkflowNextStepService::class)->resolve($this->subject, auth()->user()),
        ]);
    }
}
