<?php

namespace App\View\Components;

use App\Services\Workflow\WorkflowTimelineService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\View\Component;
use Illuminate\View\View;

class WorkflowTimeline extends Component
{
    public function __construct(public Model $subject, public int $limit = 12)
    {
    }

    public function render(): View
    {
        return view('components.workflow-timeline', [
            'entries' => app(WorkflowTimelineService::class)->entries($this->subject, $this->limit),
        ]);
    }
}
