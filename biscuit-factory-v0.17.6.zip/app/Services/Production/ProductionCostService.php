<?php

namespace App\Services\Production;

use App\Models\Company;
use App\Models\CostCalculation;
use App\Models\ProductionOrder;
use App\Models\RecipeVersion;
use App\Models\StockBalance;
use App\Models\StockMovementLine;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class ProductionCostService
{
    public function theoretical(RecipeVersion $version): array
    {
        $version->loadMissing([
            'recipe.finishedItem.baseUnit',
            'lines.ingredient.baseUnit',
            'lines.unit',
            'costComponents.unit',
        ]);

        $currency = $this->currencyCode();
        $costs = $this->emptyCosts();
        $details = ['ingredients' => [], 'components' => []];
        $warnings = [];

        foreach ($version->lines as $line) {
            $factor = $this->factorToBase($line->ingredient_item_id, $line->unit_id, $line->ingredient->base_unit_id);
            $unitCost = $this->currentUnitCost($line->ingredient_item_id);
            $quantityWithLoss = (float) $line->quantity * (1 + ((float) $line->loss_percentage / 100));
            $baseQuantity = $factor === null ? 0 : $quantityWithLoss * $factor;
            $amount = $unitCost === null ? 0 : $baseQuantity * $unitCost;
            $bucket = $line->ingredient->item_type === 'PACKAGING' ? 'packaging_cost' : 'material_cost';

            $costs[$bucket] += $amount;
            if ($factor === null) {
                $warnings[] = __('production.missing_conversion', ['item' => $line->ingredient->code]);
            }
            if ($unitCost === null) {
                $warnings[] = __('production.missing_stock_cost', ['item' => $line->ingredient->code]);
            }

            $details['ingredients'][] = [
                'item_id' => $line->ingredient_item_id,
                'code' => $line->ingredient->code,
                'name' => $line->ingredient->name,
                'type' => $line->ingredient->item_type,
                'quantity' => (float) $line->quantity,
                'loss_percentage' => (float) $line->loss_percentage,
                'base_quantity' => $baseQuantity,
                'unit_cost' => $unitCost,
                'amount' => $amount,
            ];
        }

        $this->applyComponents($version->costComponents, $costs, $details['components'], $warnings, $currency);

        $yield = max(0.001, (float) $version->expected_yield_percent);
        $referenceOutput = (float) $version->reference_quantity * ($yield / 100);

        return $this->result(
            type: 'THEORETICAL',
            version: $version,
            order: null,
            currency: $currency,
            referenceQuantity: $referenceOutput,
            yieldPercent: $yield,
            costs: $costs,
            details: $details,
            warnings: $warnings,
        );
    }

    public function actual(ProductionOrder $order): array
    {
        $order->loadMissing([
            'recipeVersion.recipe.finishedItem.baseUnit',
            'outputs',
            'costEntries.unit',
        ]);

        $currency = $this->currencyCode();
        $costs = $this->emptyCosts();
        $details = ['ingredients' => [], 'components' => []];
        $warnings = [];

        $movementLines = StockMovementLine::query()
            ->with(['item.baseUnit', 'lot'])
            ->whereHas('movement', fn ($query) => $query
                ->where('source_type', ProductionOrder::class)
                ->where('source_id', $order->id)
                ->where('movement_type', 'ISSUE')
                ->where('status', 'POSTED'))
            ->get();

        foreach ($movementLines as $line) {
            $unitCost = $line->unit_cost === null ? $this->currentUnitCost($line->item_id) : (float) $line->unit_cost;
            $amount = (float) $line->quantity * (float) ($unitCost ?? 0);
            $bucket = $line->item->item_type === 'PACKAGING' ? 'packaging_cost' : 'material_cost';

            $costs[$bucket] += $amount;
            if ($unitCost === null) {
                $warnings[] = __('production.missing_stock_cost', ['item' => $line->item->code]);
            }
            $details['ingredients'][] = [
                'item_id' => $line->item_id,
                'code' => $line->item->code,
                'name' => $line->item->name,
                'lot' => $line->lot?->lot_number,
                'type' => $line->item->item_type,
                'base_quantity' => (float) $line->quantity,
                'unit_cost' => $unitCost,
                'amount' => $amount,
            ];
        }

        $this->applyComponents($order->costEntries, $costs, $details['components'], $warnings, $currency);

        $accepted = (float) $order->outputs->sum('accepted_quantity');
        $planned = max(0.001, (float) $order->planned_quantity);
        $yield = $accepted > 0 ? ($accepted / $planned) * 100 : 0;
        if ($accepted <= 0) {
            $warnings[] = __('production.missing_accepted_output');
        }

        return $this->result(
            type: 'ACTUAL',
            version: $order->recipeVersion,
            order: $order,
            currency: $currency,
            referenceQuantity: $accepted,
            yieldPercent: $yield,
            costs: $costs,
            details: $details,
            warnings: $warnings,
        );
    }

    public function storeTheoretical(RecipeVersion $version, ?string $userId): CostCalculation
    {
        return $this->store($this->theoretical($version), $userId);
    }

    public function storeActual(ProductionOrder $order, ?string $userId): CostCalculation
    {
        return $this->store($this->actual($order), $userId);
    }

    private function store(array $result, ?string $userId): CostCalculation
    {
        return CostCalculation::create([
            'calculation_type' => $result['type'],
            'recipe_version_id' => $result['recipe_version_id'],
            'production_order_id' => $result['production_order_id'],
            'currency_code' => $result['currency_code'],
            'reference_quantity' => $result['reference_quantity'],
            'yield_percent' => $result['yield_percent'],
            ...$result['costs'],
            'total_cost' => $result['total_cost'],
            'unit_cost' => $result['unit_cost'],
            'details' => [
                ...$result['details'],
                'warnings' => $result['warnings'],
            ],
            'calculated_by' => $userId,
            'calculated_at' => now(),
        ]);
    }

    private function applyComponents(
        Collection $components,
        array &$costs,
        array &$details,
        array &$warnings,
        string $currency,
    ): void {
        $fixed = $components->where('calculation_basis', '!=', 'PERCENTAGE');
        $percentages = $components->where('calculation_basis', 'PERCENTAGE');

        foreach ($fixed as $component) {
            if ($component->currency_code !== $currency) {
                $warnings[] = __('production.currency_mismatch', ['label' => $component->label]);
                continue;
            }
            $amount = $component->calculation_basis === 'FIXED'
                ? (float) $component->unit_cost
                : (float) $component->quantity * (float) $component->unit_cost;
            $bucket = $this->componentBucket($component->cost_type);
            $costs[$bucket] += $amount;
            $details[] = $this->componentDetails($component, $amount);
        }

        $percentageBase = array_sum($costs);
        foreach ($percentages as $component) {
            if ($component->currency_code !== $currency) {
                $warnings[] = __('production.currency_mismatch', ['label' => $component->label]);
                continue;
            }
            $amount = $percentageBase * ((float) $component->percentage / 100);
            $bucket = $this->componentBucket($component->cost_type);
            $costs[$bucket] += $amount;
            $details[] = $this->componentDetails($component, $amount);
        }
    }

    private function componentDetails(object $component, float $amount): array
    {
        return [
            'type' => $component->cost_type,
            'label' => $component->label,
            'calculation_basis' => $component->calculation_basis,
            'quantity' => (float) $component->quantity,
            'unit_cost' => (float) $component->unit_cost,
            'percentage' => $component->percentage === null ? null : (float) $component->percentage,
            'currency_code' => $component->currency_code,
            'amount' => $amount,
        ];
    }

    private function factorToBase(string $itemId, string $unitId, string $baseUnitId): ?float
    {
        if ($unitId === $baseUnitId) {
            return 1.0;
        }

        $factor = DB::table('item_unit_conversions')
            ->where('item_id', $itemId)
            ->where('unit_id', $unitId)
            ->value('factor_to_base');

        return $factor === null ? null : (float) $factor;
    }

    private function currentUnitCost(string $itemId): ?float
    {
        $totals = StockBalance::query()
            ->where('item_id', $itemId)
            ->where('quantity', '>', 0)
            ->whereNotNull('average_unit_cost')
            ->selectRaw('SUM(quantity * average_unit_cost) AS total_value, SUM(quantity) AS total_quantity')
            ->first();

        $quantity = (float) ($totals?->total_quantity ?? 0);

        return $quantity > 0 ? (float) $totals->total_value / $quantity : null;
    }

    private function result(
        string $type,
        RecipeVersion $version,
        ?ProductionOrder $order,
        string $currency,
        float $referenceQuantity,
        float $yieldPercent,
        array $costs,
        array $details,
        array $warnings,
    ): array {
        $total = array_sum($costs);

        return [
            'type' => $type,
            'recipe_version_id' => $version->id,
            'production_order_id' => $order?->id,
            'currency_code' => $currency,
            'reference_quantity' => $referenceQuantity,
            'yield_percent' => $yieldPercent,
            'costs' => $costs,
            'total_cost' => $total,
            'unit_cost' => $referenceQuantity > 0 ? $total / $referenceQuantity : 0,
            'details' => $details,
            'warnings' => array_values(array_unique($warnings)),
        ];
    }

    private function emptyCosts(): array
    {
        return [
            'material_cost' => 0.0,
            'packaging_cost' => 0.0,
            'labor_cost' => 0.0,
            'machine_cost' => 0.0,
            'energy_cost' => 0.0,
            'subcontracting_cost' => 0.0,
            'overhead_cost' => 0.0,
            'other_cost' => 0.0,
        ];
    }

    private function componentBucket(string $type): string
    {
        return match ($type) {
            'LABOR' => 'labor_cost',
            'MACHINE' => 'machine_cost',
            'ENERGY' => 'energy_cost',
            'SUBCONTRACTING' => 'subcontracting_cost',
            'OVERHEAD' => 'overhead_cost',
            default => 'other_cost',
        };
    }

    private function currencyCode(): string
    {
        return Company::query()->where('active', true)->orderBy('created_at')->value('currency_code') ?? 'DZD';
    }
}
