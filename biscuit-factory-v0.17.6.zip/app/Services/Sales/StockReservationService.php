<?php

namespace App\Services\Sales;

use App\Models\SalesOrder;
use App\Models\SalesOrderLine;
use App\Models\StockBalance;
use App\Models\StockReservation;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class StockReservationService
{
    public function reserveOrder(SalesOrder $order, string $userId): SalesOrder
    {
        return DB::transaction(function () use ($order, $userId): SalesOrder {
            $order = SalesOrder::query()->with(['lines.item'])->lockForUpdate()->findOrFail($order->id);
            if (! in_array($order->status, ['CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED', 'PARTIALLY_DELIVERED'], true)) {
                throw ValidationException::withMessages(['status' => __('sales.order_not_reservable')]);
            }

            foreach ($order->lines as $line) {
                $this->reserveLine($order, $line, $userId);
            }
            $this->refreshOrderReservationStatus($order);

            return $order->fresh(['lines.reservations.lot', 'lines.reservations.location']);
        }, 3);
    }

    public function releaseOutstanding(SalesOrder $order): void
    {
        $reservations = StockReservation::query()
            ->where('sales_order_id', $order->id)
            ->where('status', 'ACTIVE')
            ->lockForUpdate()
            ->get();

        foreach ($reservations as $reservation) {
            if ((float) $reservation->allocated_quantity > 0) {
                throw ValidationException::withMessages(['delivery' => __('sales.allocated_delivery_must_be_posted')]);
            }
            $remaining = max(0, (float) $reservation->quantity - (float) $reservation->consumed_quantity);
            if ($remaining > 0) {
                $balance = StockBalance::query()->lockForUpdate()->findOrFail($reservation->stock_balance_id);
                $balance->update(['reserved_quantity' => max(0, (float) $balance->reserved_quantity - $remaining)]);
            }
            $reservation->update(['status' => 'RELEASED', 'released_at' => now()]);
        }

        $order->lines()->update(['reserved_quantity' => 0]);
    }

    public function refreshLine(SalesOrderLine $line): void
    {
        $remainingReservedBase = $this->remainingReservedBase($line);
        $reservedInOrderUnit = (float) $line->factor_to_base > 0
            ? round($remainingReservedBase / (float) $line->factor_to_base, 3)
            : 0;
        $remainingToDeliver = max(0, (float) $line->ordered_quantity - (float) $line->delivered_quantity);
        $status = (float) $line->delivered_quantity >= (float) $line->ordered_quantity - 0.0005
            ? 'DELIVERED'
            : ($reservedInOrderUnit >= $remainingToDeliver - 0.0005
                ? 'RESERVED'
                : ($reservedInOrderUnit > 0 ? 'PARTIALLY_RESERVED' : 'OPEN'));
        $line->update(['reserved_quantity' => $reservedInOrderUnit, 'status' => $status]);
    }

    public function refreshOrderReservationStatus(SalesOrder $order): void
    {
        $order->load('lines');
        $allDelivered = $order->lines->isNotEmpty() && $order->lines->every(
            fn (SalesOrderLine $line): bool => (float) $line->delivered_quantity >= (float) $line->ordered_quantity - 0.0005
        );
        if ($allDelivered) {
            $order->update(['status' => 'DELIVERED']);

            return;
        }
        if ($order->lines->contains(fn (SalesOrderLine $line): bool => (float) $line->delivered_quantity > 0)) {
            $order->update(['status' => 'PARTIALLY_DELIVERED']);

            return;
        }
        $allReserved = $order->lines->isNotEmpty() && $order->lines->every(
            fn (SalesOrderLine $line): bool => $line->status === 'RESERVED'
        );
        $hasReservation = $order->lines->contains(
            fn (SalesOrderLine $line): bool => (float) $line->reserved_quantity > 0
        );
        $order->update(['status' => $allReserved ? 'RESERVED' : ($hasReservation ? 'PARTIALLY_RESERVED' : 'CONFIRMED')]);
    }

    private function reserveLine(SalesOrder $order, SalesOrderLine $line, string $userId): void
    {
        $factor = (float) $line->factor_to_base;
        if ($factor <= 0) {
            throw ValidationException::withMessages(['factor_to_base' => __('sales.invalid_conversion_factor')]);
        }
        $targetBase = max(0, ((float) $line->ordered_quantity - (float) $line->delivered_quantity) * $factor);
        $alreadyReservedBase = $this->remainingReservedBase($line);
        $remaining = max(0, $targetBase - $alreadyReservedBase);

        if ($remaining > 0.0005) {
            $balances = StockBalance::query()
                ->with(['lot', 'location'])
                ->where('item_id', $line->item_id)
                ->whereHas('location', fn ($location) => $location
                    ->where('warehouse_id', $order->warehouse_id)
                    ->where('active', true)
                    ->where('quarantine', false))
                ->whereRaw('quantity > reserved_quantity')
                ->where(fn ($query) => $query
                    ->whereNull('lot_id')
                    ->orWhereHas('lot', fn ($lot) => $lot
                        ->where('status', 'RELEASED')
                        ->where(fn ($expiry) => $expiry
                            ->whereNull('expiry_date')
                            ->orWhereDate('expiry_date', '>=', today()))))
                ->lockForUpdate()
                ->get()
                ->sortBy(fn (StockBalance $balance) => $balance->lot?->expiry_date?->format('Y-m-d') ?? '9999-12-31');

            foreach ($balances as $balance) {
                $available = max(0, (float) $balance->quantity - (float) $balance->reserved_quantity);
                $taken = min($remaining, $available);
                if ($taken <= 0) {
                    continue;
                }
                $reservation = StockReservation::query()->firstOrNew([
                    'sales_order_line_id' => $line->id,
                    'stock_balance_id' => $balance->id,
                ]);
                if (! $reservation->exists) {
                    $reservation->fill([
                        'sales_order_id' => $order->id,
                        'item_id' => $line->item_id,
                        'lot_id' => $balance->lot_id,
                        'location_id' => $balance->location_id,
                        'quantity' => 0,
                        'allocated_quantity' => 0,
                        'consumed_quantity' => 0,
                        'created_by' => $userId,
                    ]);
                }
                $reservation->fill([
                    'quantity' => (float) $reservation->quantity + $taken,
                    'status' => 'ACTIVE',
                    'released_at' => null,
                ])->save();
                $balance->update(['reserved_quantity' => (float) $balance->reserved_quantity + $taken]);
                $remaining -= $taken;
                if ($remaining <= 0.0005) {
                    break;
                }
            }
        }

        $this->refreshLine($line->fresh());
    }

    private function remainingReservedBase(SalesOrderLine $line): float
    {
        $summary = $line->reservations()
            ->where('status', 'ACTIVE')
            ->selectRaw('COALESCE(SUM(quantity - consumed_quantity), 0) AS remaining')
            ->first();

        return (float) ($summary?->remaining ?? 0);
    }
}
