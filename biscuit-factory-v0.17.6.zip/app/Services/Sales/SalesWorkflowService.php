<?php

namespace App\Services\Sales;

use App\Events\DashboardUpdated;
use App\Models\CustomerReturn;
use App\Models\DeliveryAllocation;
use App\Models\DeliveryNote;
use App\Models\DeliveryNoteLine;
use App\Models\Lot;
use App\Models\SalesOrder;
use App\Models\SalesOrderLine;
use App\Models\SalesPriceList;
use App\Models\SalesQuotation;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Models\StockReservation;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use App\Services\Modules\ModuleRegistry;
use App\Services\Stock\StockPostingService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class SalesWorkflowService
{
    public function __construct(
        private readonly StockReservationService $reservations,
        private readonly StockPostingService $stockPosting,
        private readonly ModuleRegistry $modules,
        private readonly DocumentNumberService $numbers,
    ) {}

    public function approvePriceList(SalesPriceList $priceList, string $userId): SalesPriceList
    {
        return DB::transaction(function () use ($priceList, $userId): SalesPriceList {
            $priceList = SalesPriceList::query()->with('lines')->lockForUpdate()->findOrFail($priceList->id);
            $this->requireStatus($priceList->status, ['DRAFT'], 'sales.price_list_not_draft');
            if ($priceList->lines->isEmpty()) {
                throw ValidationException::withMessages(['price_list' => __('sales.line_required')]);
            }
            $priceList->update(['status' => 'APPROVED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->audit('sales.price_list.approved', $priceList, $userId, ['status' => 'DRAFT'], ['status' => 'APPROVED']);

            return $priceList->fresh('lines');
        }, 3);
    }

    public function sendQuotation(SalesQuotation $quotation, string $userId): SalesQuotation
    {
        return DB::transaction(function () use ($quotation, $userId): SalesQuotation {
            $quotation = SalesQuotation::query()->with(['lines', 'customer'])->lockForUpdate()->findOrFail($quotation->id);
            $this->requireStatus($quotation->status, ['DRAFT'], 'sales.quotation_not_draft');
            if ($quotation->lines->isEmpty()) {
                throw ValidationException::withMessages(['quotation' => __('sales.line_required')]);
            }
            if (! $quotation->customer->active || ! in_array($quotation->customer->status, ['APPROVED', 'ACTIVE'], true)) {
                throw ValidationException::withMessages(['customer_id' => __('sales.customer_not_approved')]);
            }
            $quotation->update(['status' => 'SENT', 'sent_by' => $userId, 'sent_at' => now()]);
            $this->audit('sales.quotation.sent', $quotation, $userId, ['status' => 'DRAFT'], ['status' => 'SENT']);

            return $quotation->fresh('lines');
        }, 3);
    }

    public function acceptQuotation(SalesQuotation $quotation, string $userId): SalesQuotation
    {
        return DB::transaction(function () use ($quotation, $userId): SalesQuotation {
            $quotation = SalesQuotation::query()->lockForUpdate()->findOrFail($quotation->id);
            $this->requireStatus($quotation->status, ['SENT'], 'sales.quotation_not_sent');
            if ($quotation->valid_until && $quotation->valid_until->isPast()) {
                throw ValidationException::withMessages(['valid_until' => __('sales.quotation_expired')]);
            }
            $quotation->update(['status' => 'ACCEPTED', 'accepted_by' => $userId, 'accepted_at' => now()]);
            $this->audit('sales.quotation.accepted', $quotation, $userId, ['status' => 'SENT'], ['status' => 'ACCEPTED']);

            return $quotation->fresh();
        }, 3);
    }

    public function convertQuotation(SalesQuotation $quotation, string $userId): SalesOrder
    {
        return DB::transaction(function () use ($quotation, $userId): SalesOrder {
            $quotation = SalesQuotation::query()->with('lines')->lockForUpdate()->findOrFail($quotation->id);
            $this->requireStatus($quotation->status, ['ACCEPTED'], 'sales.quotation_not_accepted');
            if ($quotation->salesOrder()->exists()) {
                throw ValidationException::withMessages(['quotation' => __('sales.quotation_already_converted')]);
            }
            $order = SalesOrder::create([
                'company_id' => $quotation->company_id,
                'site_id' => $quotation->site_id,
                'warehouse_id' => $quotation->warehouse_id,
                'customer_id' => $quotation->customer_id,
                'sales_quotation_id' => $quotation->id,
                'order_number' => $this->numbers->next($quotation->company_id, FinancialDocumentCatalog::SALES_ORDER, today()),
                'order_date' => today(),
                'requested_delivery_date' => $quotation->requested_delivery_date,
                'currency_code' => $quotation->currency_code,
                'exchange_rate' => $quotation->exchange_rate,
                'tax_included' => $quotation->tax_included,
                'status' => 'DRAFT',
                'subtotal' => $quotation->subtotal,
                'discount_amount' => $quotation->discount_amount,
                'tax_amount' => $quotation->tax_amount,
                'total_amount' => $quotation->total_amount,
                'delivery_address' => $quotation->delivery_address,
                'notes' => $quotation->notes,
                'created_by' => $userId,
            ]);
            foreach ($quotation->lines as $line) {
                $order->lines()->create([
                    'sales_quotation_line_id' => $line->id,
                    'item_id' => $line->item_id,
                    'description' => $line->description,
                    'ordered_quantity' => $line->quantity,
                    'unit_id' => $line->unit_id,
                    'factor_to_base' => $line->factor_to_base,
                    'unit_price' => $line->unit_price,
                    'discount_percentage' => $line->discount_percentage,
                    'tax_rate_id' => $line->tax_rate_id,
                    'net_unit_price' => $line->net_unit_price,
                    'line_subtotal' => $line->line_subtotal,
                    'tax_amount' => $line->tax_amount,
                    'line_total' => $line->line_total,
                    'status' => 'OPEN',
                    'notes' => $line->notes,
                ]);
            }
            $quotation->update(['status' => 'CONVERTED']);
            $this->audit('sales.quotation.converted', $quotation, $userId, ['status' => 'ACCEPTED'], ['status' => 'CONVERTED']);
            $this->audit('sales.order.created_from_quotation', $order, $userId, null, ['quotation_id' => $quotation->id]);

            return $order->fresh('lines');
        }, 3);
    }

    public function submitOrder(SalesOrder $order, string $userId): SalesOrder
    {
        return DB::transaction(function () use ($order, $userId): SalesOrder {
            $order = SalesOrder::query()->with(['lines', 'customer'])->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus($order->status, ['DRAFT'], 'sales.order_not_draft');
            if ($order->lines->isEmpty()) {
                throw ValidationException::withMessages(['order' => __('sales.line_required')]);
            }
            if (! $order->customer->active || ! in_array($order->customer->status, ['APPROVED', 'ACTIVE'], true)) {
                throw ValidationException::withMessages(['customer_id' => __('sales.customer_not_approved')]);
            }
            $order->update(['status' => 'SUBMITTED', 'submitted_by' => $userId, 'submitted_at' => now()]);
            $this->audit('sales.order.submitted', $order, $userId, ['status' => 'DRAFT'], ['status' => 'SUBMITTED']);

            return $order->fresh('lines');
        }, 3);
    }

    public function confirmOrder(SalesOrder $order, string $userId): SalesOrder
    {
        return DB::transaction(function () use ($order, $userId): SalesOrder {
            $locked = SalesOrder::query()->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus($locked->status, ['SUBMITTED'], 'sales.order_not_submitted');
            $locked->update(['status' => 'CONFIRMED', 'confirmed_by' => $userId, 'confirmed_at' => now()]);
            $this->audit('sales.order.confirmed', $locked, $userId, ['status' => 'SUBMITTED'], ['status' => 'CONFIRMED']);
            $reserved = $this->reservations->reserveOrder($locked->fresh(), $userId);
            DB::afterCommit(fn () => event(new DashboardUpdated(['sales_order_id' => $order->id])));

            return $reserved;
        }, 3);
    }

    public function cancelOrder(SalesOrder $order, string $userId, string $reason): SalesOrder
    {
        return DB::transaction(function () use ($order, $userId, $reason): SalesOrder {
            $order = SalesOrder::query()->with('lines')->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus(
                $order->status,
                ['DRAFT', 'SUBMITTED', 'CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED'],
                'sales.order_not_cancellable',
            );
            $this->reservations->releaseOutstanding($order);
            $old = $order->status;
            $order->update(['status' => 'CANCELLED', 'cancellation_reason' => $reason]);
            $this->audit('sales.order.cancelled', $order, $userId, ['status' => $old], ['status' => 'CANCELLED']);

            return $order->fresh('lines');
        }, 3);
    }

    public function createDelivery(SalesOrder $order, array $lineQuantities, array $metadata, string $userId): DeliveryNote
    {
        $this->reservations->reserveOrder($order, $userId);

        return DB::transaction(function () use ($order, $lineQuantities, $metadata, $userId): DeliveryNote {
            $order = SalesOrder::query()->with(['lines.item'])->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus(
                $order->status,
                ['RESERVED', 'PARTIALLY_RESERVED', 'PARTIALLY_DELIVERED'],
                'sales.order_not_deliverable',
            );
            $delivery = DeliveryNote::create([
                'sales_order_id' => $order->id,
                'customer_id' => $order->customer_id,
                'warehouse_id' => $order->warehouse_id,
                'delivery_number' => $this->numbers->next($order->company_id, FinancialDocumentCatalog::DELIVERY_NOTE, $metadata['delivered_at']),
                'delivered_at' => $metadata['delivered_at'],
                'status' => 'PICKED',
                'carrier' => $metadata['carrier'] ?? null,
                'vehicle_registration' => $metadata['vehicle_registration'] ?? null,
                'driver_name' => $metadata['driver_name'] ?? null,
                'customer_reference' => $metadata['customer_reference'] ?? null,
                'delivery_address' => $metadata['delivery_address'] ?? $order->delivery_address,
                'notes' => $metadata['notes'] ?? null,
                'created_by' => $userId,
            ]);

            foreach ($order->lines as $line) {
                $quantity = (float) ($lineQuantities[$line->id] ?? 0);
                if ($quantity <= 0) {
                    continue;
                }
                $remainingOrderQuantity = (float) $line->ordered_quantity - (float) $line->delivered_quantity;
                if ($quantity > $remainingOrderQuantity + 0.0005) {
                    throw ValidationException::withMessages(['quantity' => __('sales.delivery_exceeds_remaining')]);
                }
                $baseQuantity = round($quantity * (float) $line->factor_to_base, 3);
                $deliveryLine = $delivery->lines()->create([
                    'sales_order_line_id' => $line->id,
                    'item_id' => $line->item_id,
                    'quantity' => $quantity,
                    'base_quantity' => $baseQuantity,
                    'unit_id' => $line->unit_id,
                    'factor_to_base' => $line->factor_to_base,
                ]);
                $this->allocateDeliveryLine($deliveryLine, $baseQuantity);
            }
            if (! $delivery->lines()->exists()) {
                throw ValidationException::withMessages(['quantity' => __('sales.delivery_line_required')]);
            }
            $this->audit('sales.delivery.picked', $delivery, $userId, null, ['status' => 'PICKED']);

            return $delivery->fresh(['lines.allocations.lot', 'lines.item']);
        }, 3);
    }

    public function postDelivery(DeliveryNote $delivery, string $userId): DeliveryNote
    {
        return DB::transaction(function () use ($delivery, $userId): DeliveryNote {
            $delivery = DeliveryNote::query()
                ->with(['lines.allocations.reservation.stockBalance', 'lines.salesOrderLine.item', 'salesOrder.lines'])
                ->lockForUpdate()
                ->findOrFail($delivery->id);
            $this->requireStatus($delivery->status, ['PICKED'], 'sales.delivery_not_picked');
            if ($delivery->lines->isEmpty()) {
                throw ValidationException::withMessages(['delivery' => __('sales.delivery_line_required')]);
            }
            $movement = StockMovement::create([
                'movement_number' => $this->number('EXP'),
                'movement_type' => 'ISSUE',
                'movement_at' => $delivery->delivered_at,
                'source_type' => DeliveryNote::class,
                'source_id' => $delivery->id,
                'status' => 'DRAFT',
                'notes' => __('sales.stock_movement_delivery', ['number' => $delivery->delivery_number]),
                'created_by' => $userId,
            ]);

            foreach ($delivery->lines as $deliveryLine) {
                if ($deliveryLine->allocations->isEmpty()) {
                    throw ValidationException::withMessages(['delivery' => __('sales.delivery_allocation_required')]);
                }
                foreach ($deliveryLine->allocations as $allocation) {
                    $reservation = StockReservation::query()->lockForUpdate()->findOrFail($allocation->stock_reservation_id);
                    $balance = StockBalance::query()->lockForUpdate()->findOrFail($reservation->stock_balance_id);
                    $quantity = (float) $allocation->quantity;
                    if ($quantity > (float) $reservation->allocated_quantity + 0.0005) {
                        throw ValidationException::withMessages(['delivery' => __('sales.reservation_allocation_mismatch')]);
                    }
                    if ($quantity > (float) $balance->reserved_quantity + 0.0005) {
                        throw ValidationException::withMessages(['delivery' => __('sales.reservation_allocation_mismatch')]);
                    }
                    $movementLine = $movement->lines()->create([
                        'reference' => $delivery->delivery_number,
                        'item_id' => $allocation->item_id,
                        'lot_id' => $allocation->lot_id,
                        'source_location_id' => $allocation->source_location_id,
                        'quantity' => $quantity,
                        'unit_id' => $deliveryLine->salesOrderLine->item->base_unit_id,
                        'unit_cost' => $balance->average_unit_cost,
                        'notes' => $delivery->customer_reference,
                    ]);
                    $allocation->update([
                        'unit_cost' => $balance->average_unit_cost,
                        'stock_movement_line_id' => $movementLine->id,
                    ]);
                    $reservation->update([
                        'allocated_quantity' => max(0, (float) $reservation->allocated_quantity - $quantity),
                        'consumed_quantity' => (float) $reservation->consumed_quantity + $quantity,
                        'status' => (float) $reservation->consumed_quantity + $quantity >= (float) $reservation->quantity - 0.0005
                            ? 'CONSUMED'
                            : 'ACTIVE',
                    ]);
                    $balance->update([
                        'reserved_quantity' => max(0, (float) $balance->reserved_quantity - $quantity),
                    ]);
                }
                $orderLine = SalesOrderLine::query()->lockForUpdate()->findOrFail($deliveryLine->sales_order_line_id);
                $orderLine->update([
                    'delivered_quantity' => (float) $orderLine->delivered_quantity + (float) $deliveryLine->quantity,
                ]);
            }

            $this->stockPosting->post($movement, $userId);
            $delivery->update([
                'status' => 'POSTED', 'posted_by' => $userId, 'posted_at' => now(),
                'stock_movement_id' => $movement->id,
            ]);
            foreach ($delivery->lines as $deliveryLine) {
                $this->reservations->refreshLine($deliveryLine->salesOrderLine->fresh());
            }
            $this->reservations->refreshOrderReservationStatus($delivery->salesOrder->fresh('lines'));
            $this->audit('sales.delivery.posted', $delivery, $userId, ['status' => 'PICKED'], ['status' => 'POSTED']);
            DB::afterCommit(fn () => event(new DashboardUpdated(['delivery_note_id' => $delivery->id])));

            return $delivery->fresh(['lines.allocations.lot', 'stockMovement', 'salesOrder']);
        }, 3);
    }

    public function postCustomerReturn(CustomerReturn $customerReturn, string $userId): CustomerReturn
    {
        return DB::transaction(function () use ($customerReturn, $userId): CustomerReturn {
            $customerReturn = CustomerReturn::query()
                ->with(['lines.deliveryAllocation', 'lines.deliveryNoteLine.salesOrderLine.item', 'deliveryNote', 'destinationLocation'])
                ->lockForUpdate()
                ->findOrFail($customerReturn->id);
            $this->requireStatus($customerReturn->status, ['DRAFT'], 'sales.return_not_draft');
            if ($customerReturn->deliveryNote->status !== 'POSTED') {
                throw ValidationException::withMessages(['delivery' => __('sales.delivery_not_posted')]);
            }
            if ($customerReturn->destinationLocation->warehouse_id !== $customerReturn->warehouse_id
                || ! $customerReturn->destinationLocation->quarantine) {
                throw ValidationException::withMessages(['destination_location_id' => __('sales.return_requires_quarantine')]);
            }
            if ($customerReturn->lines->isEmpty()) {
                throw ValidationException::withMessages(['return' => __('sales.return_line_required')]);
            }
            $movement = StockMovement::create([
                'movement_number' => $this->number('RET-CLI'),
                'movement_type' => 'RECEIPT',
                'movement_at' => $customerReturn->return_date->endOfDay(),
                'source_type' => CustomerReturn::class,
                'source_id' => $customerReturn->id,
                'status' => 'DRAFT',
                'notes' => __('sales.stock_movement_return', ['number' => $customerReturn->return_number]),
                'created_by' => $userId,
            ]);

            foreach ($customerReturn->lines as $returnLine) {
                $allocation = $returnLine->deliveryAllocation;
                if ((float) $returnLine->base_quantity <= 0
                    || ! $allocation
                    || $allocation->delivery_note_line_id !== $returnLine->delivery_note_line_id
                    || $returnLine->deliveryNoteLine->delivery_note_id !== $customerReturn->delivery_note_id) {
                    throw ValidationException::withMessages(['return' => __('sales.return_allocation_mismatch')]);
                }
                $alreadyReturned = DB::table('customer_return_lines')
                    ->join('customer_returns', 'customer_returns.id', '=', 'customer_return_lines.customer_return_id')
                    ->where('customer_return_lines.delivery_allocation_id', $allocation->id)
                    ->where('customer_returns.status', 'POSTED')
                    ->sum('customer_return_lines.base_quantity');
                if ((float) $returnLine->base_quantity > (float) $allocation->quantity - (float) $alreadyReturned + 0.0005) {
                    throw ValidationException::withMessages(['quantity' => __('sales.return_exceeds_delivery')]);
                }
                $item = $returnLine->deliveryNoteLine->salesOrderLine->item;
                $returnLot = null;
                if ($item->lot_managed) {
                    $returnLot = Lot::firstOrCreate(
                        ['item_id' => $item->id, 'lot_number' => $this->returnLotNumber($customerReturn, $allocation)],
                        [
                            'manufacturing_date' => $allocation->lot?->manufacturing_date,
                            'expiry_date' => $allocation->lot?->expiry_date,
                            'status' => $this->modules->enabled('quality') ? 'QUARANTINE' : 'RELEASED',
                            'attributes' => [
                                'quality_module_enabled' => $this->modules->enabled('quality'),
                                'origin' => 'CUSTOMER_RETURN',
                                'source_lot_id' => $allocation->lot_id,
                                'delivery_allocation_id' => $allocation->id,
                            ],
                        ],
                    );
                }
                $movementLine = $movement->lines()->create([
                    'reference' => $customerReturn->return_number,
                    'item_id' => $item->id,
                    'lot_id' => $returnLot?->id,
                    'destination_location_id' => $customerReturn->destination_location_id,
                    'quantity' => $returnLine->base_quantity,
                    'unit_id' => $item->base_unit_id,
                    'unit_cost' => $returnLine->unit_cost,
                    'notes' => $returnLine->reason,
                ]);
                $returnLine->update(['lot_id' => $returnLot?->id, 'stock_movement_line_id' => $movementLine->id]);
                $orderLine = $returnLine->deliveryNoteLine->salesOrderLine;
                $orderLine->increment(
                    'returned_quantity',
                    round((float) $returnLine->base_quantity / (float) $orderLine->factor_to_base, 3),
                );
            }

            $this->stockPosting->post($movement, $userId);
            $customerReturn->update([
                'status' => 'POSTED', 'posted_by' => $userId, 'posted_at' => now(),
                'stock_movement_id' => $movement->id,
            ]);
            $this->audit('sales.return.posted', $customerReturn, $userId, ['status' => 'DRAFT'], ['status' => 'POSTED']);
            DB::afterCommit(fn () => event(new DashboardUpdated(['customer_return_id' => $customerReturn->id])));

            return $customerReturn->fresh(['lines.lot', 'stockMovement']);
        }, 3);
    }

    public function recalculateQuotation(SalesQuotation $quotation): void
    {
        $lines = $quotation->lines()->get();
        $quotation->update([
            'subtotal' => $lines->sum('line_subtotal'),
            'discount_amount' => $lines->sum(fn ($line) => (float) $line->quantity
                * (float) $line->unit_price * ((float) $line->discount_percentage / 100)),
            'tax_amount' => $lines->sum('tax_amount'),
            'total_amount' => $lines->sum('line_total'),
        ]);
    }

    public function recalculateOrder(SalesOrder $order): void
    {
        $lines = $order->lines()->get();
        $order->update([
            'subtotal' => $lines->sum('line_subtotal'),
            'discount_amount' => $lines->sum(fn ($line) => (float) $line->ordered_quantity
                * (float) $line->unit_price * ((float) $line->discount_percentage / 100)),
            'tax_amount' => $lines->sum('tax_amount'),
            'total_amount' => $lines->sum('line_total'),
        ]);
    }

    private function allocateDeliveryLine(DeliveryNoteLine $deliveryLine, float $baseQuantity): void
    {
        $remaining = $baseQuantity;
        $reservations = StockReservation::query()
            ->with('lot')
            ->where('sales_order_line_id', $deliveryLine->sales_order_line_id)
            ->where('status', 'ACTIVE')
            ->lockForUpdate()
            ->get()
            ->sortBy(fn (StockReservation $reservation) => $reservation->lot?->expiry_date?->format('Y-m-d') ?? '9999-12-31');

        foreach ($reservations as $reservation) {
            $available = max(
                0,
                (float) $reservation->quantity
                    - (float) $reservation->consumed_quantity
                    - (float) $reservation->allocated_quantity,
            );
            $taken = min($remaining, $available);
            if ($taken <= 0) {
                continue;
            }
            DeliveryAllocation::create([
                'delivery_note_line_id' => $deliveryLine->id,
                'stock_reservation_id' => $reservation->id,
                'item_id' => $reservation->item_id,
                'lot_id' => $reservation->lot_id,
                'source_location_id' => $reservation->location_id,
                'quantity' => $taken,
                'unit_cost' => $reservation->stockBalance()->value('average_unit_cost'),
            ]);
            $reservation->update(['allocated_quantity' => (float) $reservation->allocated_quantity + $taken]);
            $remaining -= $taken;
            if ($remaining <= 0.0005) {
                break;
            }
        }
        if ($remaining > 0.0005) {
            throw ValidationException::withMessages(['quantity' => __('sales.insufficient_reserved_stock')]);
        }
    }

    private function returnLotNumber(CustomerReturn $return, DeliveryAllocation $allocation): string
    {
        return Str::limit('RET-'.$return->return_number.'-'.Str::upper(substr($allocation->id, 0, 8)), 120, '');
    }

    private function requireStatus(string $actual, array $allowed, string $message): void
    {
        if (! in_array($actual, $allowed, true)) {
            throw ValidationException::withMessages(['status' => __($message)]);
        }
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

    private function audit(
        string $event,
        object $model,
        string $userId,
        ?array $oldValues,
        ?array $newValues,
    ): void {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(), 'user_id' => $userId, 'event' => $event,
            'auditable_type' => $model::class, 'auditable_id' => $model->id,
            'old_values' => $oldValues ? json_encode($oldValues, JSON_THROW_ON_ERROR) : null,
            'new_values' => $newValues ? json_encode($newValues, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()?->ip(), 'user_agent' => request()?->userAgent(), 'created_at' => now(),
        ]);
    }
}
