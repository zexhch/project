<?php

namespace App\Services\Sales;

use App\Models\Customer;
use App\Models\Item;
use App\Models\SalesPriceListLine;
use Carbon\CarbonInterface;

class SalesPricingService
{
    public function resolve(
        Customer $customer,
        Item $item,
        float $quantity,
        string $unitId,
        CarbonInterface $date,
    ): ?array {
        $line = SalesPriceListLine::query()
            ->with(['priceList', 'taxRate'])
            ->where('item_id', $item->id)
            ->where('unit_id', $unitId)
            ->where('minimum_quantity', '<=', $quantity)
            ->whereHas('priceList', fn ($query) => $query
                ->where('company_id', $customer->company_id)
                ->activeOn($date)
                ->where(fn ($scope) => $scope
                    ->where('customer_id', $customer->id)
                    ->when($customer->customer_group_code, fn ($groupScope) => $groupScope
                        ->orWhere(fn ($group) => $group
                            ->whereNull('customer_id')
                            ->where('customer_group_code', $customer->customer_group_code)))
                    ->when($customer->sales_channel_code, fn ($channelScope) => $channelScope
                        ->orWhere(fn ($channel) => $channel
                            ->whereNull('customer_id')
                            ->whereNull('customer_group_code')
                            ->where('sales_channel_code', $customer->sales_channel_code)))
                    ->orWhere(fn ($general) => $general
                        ->whereNull('customer_id')
                        ->whereNull('customer_group_code')
                        ->whereNull('sales_channel_code'))))
            ->get()
            ->sort(function (SalesPriceListLine $left, SalesPriceListLine $right) use ($customer): int {
                $leftSpecificity = $this->specificity($left, $customer);
                $rightSpecificity = $this->specificity($right, $customer);
                if ($leftSpecificity !== $rightSpecificity) {
                    return $rightSpecificity <=> $leftSpecificity;
                }
                $priority = $left->priceList->priority <=> $right->priceList->priority;

                return $priority !== 0
                    ? $priority
                    : (float) $right->minimum_quantity <=> (float) $left->minimum_quantity;
            })
            ->first();

        if (! $line) {
            return null;
        }

        return [
            'price_list_id' => $line->sales_price_list_id,
            'price_list_code' => $line->priceList->code,
            'currency_code' => $line->priceList->currency_code,
            'tax_included' => $line->priceList->tax_included,
            'factor_to_base' => (float) $line->factor_to_base,
            'unit_price' => (float) $line->unit_price,
            'discount_percentage' => (float) $line->discount_percentage,
            'tax_rate_id' => $line->tax_rate_id,
            'tax_rate' => (float) ($line->taxRate?->rate ?? 0),
            'target_margin_percentage' => $line->target_margin_percentage !== null
                ? (float) $line->target_margin_percentage
                : null,
        ];
    }

    public function calculate(
        float $quantity,
        float $unitPrice,
        float $discountPercentage,
        float $taxRate,
        bool $taxIncluded,
    ): array {
        $grossBeforeDiscount = $quantity * $unitPrice;
        $discountAmount = $grossBeforeDiscount * ($discountPercentage / 100);
        $discountedAmount = $grossBeforeDiscount - $discountAmount;

        if ($taxIncluded && $taxRate > 0) {
            $lineSubtotal = $discountedAmount / (1 + ($taxRate / 100));
            $taxAmount = $discountedAmount - $lineSubtotal;
            $lineTotal = $discountedAmount;
        } else {
            $lineSubtotal = $discountedAmount;
            $taxAmount = $lineSubtotal * ($taxRate / 100);
            $lineTotal = $lineSubtotal + $taxAmount;
        }

        return [
            'net_unit_price' => $quantity > 0 ? round($lineSubtotal / $quantity, 6) : 0,
            'line_subtotal' => round($lineSubtotal, 4),
            'discount_amount' => round($discountAmount, 4),
            'tax_amount' => round($taxAmount, 4),
            'line_total' => round($lineTotal, 4),
        ];
    }

    private function specificity(SalesPriceListLine $line, Customer $customer): int
    {
        if ($line->priceList->customer_id === $customer->id) {
            return 4;
        }
        if ($line->priceList->customer_group_code === $customer->customer_group_code
            && $customer->customer_group_code !== null) {
            return 3;
        }
        if ($line->priceList->sales_channel_code === $customer->sales_channel_code
            && $customer->sales_channel_code !== null) {
            return 2;
        }

        return 1;
    }
}
