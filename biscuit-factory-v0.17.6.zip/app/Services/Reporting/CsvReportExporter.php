<?php

namespace App\Services\Reporting;

use RuntimeException;
use Illuminate\Support\Facades\Storage;

final class CsvReportExporter
{
    public function stream(array $report, string $filename)
    {
        return response()->streamDownload(function () use ($report): void {
            $handle = fopen('php://output', 'wb');
            throw_unless(is_resource($handle), new RuntimeException('Unable to open CSV output stream.'));
            $this->write($handle, $report);
            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function store(array $report, string $path, string $disk = 'local'): array
    {
        $handle = fopen('php://temp', 'w+b');
        throw_unless(is_resource($handle), new RuntimeException('Unable to create CSV temporary stream.'));
        $rows = $this->write($handle, $report);
        rewind($handle);
        $contents = stream_get_contents($handle);
        fclose($handle);
        throw_unless(is_string($contents), new RuntimeException('Unable to read generated CSV content.'));
        throw_unless(Storage::disk($disk)->put($path, $contents), new RuntimeException('Unable to store generated CSV report.'));

        return ['disk' => $disk, 'path' => $path, 'size' => strlen($contents), 'rows' => $rows];
    }

    /** @param resource $handle */
    private function write($handle, array $report): int
    {
        fwrite($handle, "\xEF\xBB\xBF");
        $this->row($handle, [__($report['title'])]);
        $this->row($handle, [__('reports.period'), $report['filter']->from->toDateString().' — '.$report['filter']->to->toDateString()]);
        $this->row($handle, []);

        $this->row($handle, [__('reports.indicator'), __('reports.value')]);
        foreach ($report['metrics'] as $metric) {
            $this->row($handle, [__($metric['label']), $metric['value']]);
        }

        $rowCount = 0;
        foreach ($report['tables'] as $table) {
            $this->row($handle, []);
            $this->row($handle, [__($table['title'])]);
            $this->row($handle, array_map(fn (array $column): string => __($column['label']), $table['columns']));
            foreach ($table['rows'] as $row) {
                $this->row($handle, array_map(fn (array $column): mixed => data_get($row, $column['key']), $table['columns']));
                $rowCount++;
            }
        }

        return $rowCount;
    }

    /** @param resource $handle */
    private function row($handle, array $values): void
    {
        fputcsv($handle, array_map($this->safeCell(...), $values), ';');
    }

    private function safeCell(mixed $value): mixed
    {
        if (! is_string($value)) {
            return $value;
        }

        $trimmed = ltrim($value);
        if ($trimmed !== '' && in_array($trimmed[0], ['=', '+', '-', '@'], true)) {
            return "'".$value;
        }

        return $value;
    }
}
