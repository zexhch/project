<?php

namespace App\Services\Reporting;

use App\Models\Company;
use App\Models\User;
use App\Services\Modules\ModuleRegistry;
use Illuminate\Support\Facades\Cache;

final class RoleDashboardService
{
    public function __construct(
        private readonly ReportCatalog $catalog,
        private readonly ReportingService $reports,
        private readonly ModuleRegistry $modules,
    ) {
    }

    public function for(User $user): ?array
    {
        if (! $this->modules->enabled('reports') || ! $user->hasPermission('reports.view')) {
            return null;
        }

        $code = $this->catalog->defaultFor($user);
        $filter = new ReportFilter(
            today()->subMonths(5)->startOfMonth()->toImmutable()->startOfDay(),
            today()->toImmutable()->endOfDay(),
        );

        return Cache::remember(
            'role-dashboard:'.$user->id.':'.$code.':'.today()->toDateString(),
            now()->addSeconds(30),
            fn (): array => $this->reports->dashboard($code, $filter) + [
                'url' => route('reports.show', ['reportCode' => $code] + $filter->query()),
                'currency' => Company::query()->where('active', true)->value('currency_code') ?: 'DZD',
            ],
        );
    }
}
