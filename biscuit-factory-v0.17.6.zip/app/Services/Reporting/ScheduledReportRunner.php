<?php

namespace App\Services\Reporting;

use App\Models\ReportRun;
use App\Models\ReportSchedule;
use App\Notifications\SystemAlertNotification;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Log;

final class ScheduledReportRunner
{
    public function __construct(
        private readonly ReportingService $reports,
        private readonly CsvReportExporter $exporter,
        private readonly ReportScheduleCalculator $calculator,
        private readonly ReportCatalog $catalog,
    ) {
    }

    public function run(ReportSchedule $schedule): ReportRun
    {
        $schedule->loadMissing('user.roles.permissions');
        $filter = $this->filter($schedule);
        $run = ReportRun::create([
            'report_schedule_id' => $schedule->id,
            'user_id' => $schedule->user_id,
            'report_code' => $schedule->report_code,
            'format' => 'CSV',
            'status' => 'RUNNING',
            'period_from' => $filter->from,
            'period_to' => $filter->to,
            'filters' => $filter->toArray(),
            'started_at' => now(),
        ]);

        try {
            if (! $schedule->user || ! $schedule->user->active || ! $this->catalog->availableFor($schedule->user)->has($schedule->report_code)) {
                throw new \DomainException('Scheduled report owner is inactive or no longer authorized.');
            }

            $report = $this->reports->build($schedule->report_code, $filter);
            $path = sprintf('reports/%s/%s/%s.csv', $schedule->user_id, now()->format('Y/m'), $run->id);
            $stored = $this->exporter->store($report, $path);

            $run->update([
                'status' => 'COMPLETED',
                'file_disk' => $stored['disk'],
                'file_path' => $stored['path'],
                'file_size' => $stored['size'],
                'row_count' => $stored['rows'],
                'completed_at' => now(),
            ]);

            $schedule->update([
                'last_run_at' => now(),
                'next_run_at' => $this->calculator->next($schedule, CarbonImmutable::now()),
            ]);

            $schedule->user?->notify(new SystemAlertNotification(
                __('reports.scheduled_report_ready'),
                __('reports.scheduled_report_ready_message', ['name' => $schedule->name]),
                'success',
                route('reports.runs.download', $run),
                'report-run:'.$run->id,
            ));
        } catch (\Throwable $exception) {
            $run->update([
                'status' => 'FAILED',
                'error_message' => mb_substr($exception->getMessage(), 0, 4000),
                'completed_at' => now(),
            ]);
            $schedule->update([
                'last_run_at' => now(),
                'next_run_at' => $this->calculator->next($schedule, CarbonImmutable::now()),
            ]);
            if ($schedule->user?->active) {
                $schedule->user->notify(new SystemAlertNotification(
                    __('reports.scheduled_report_failed'),
                    __('reports.scheduled_report_failed_message', ['name' => $schedule->name]),
                    'danger',
                    route('reports.schedules'),
                    'report-run-failed:'.$run->id,
                ));
            }
            Log::error('Scheduled report failed', ['schedule_id' => $schedule->id, 'exception' => $exception]);
        }

        return $run->refresh();
    }

    private function filter(ReportSchedule $schedule): ReportFilter
    {
        $period = strtoupper((string) data_get($schedule->filters, 'relative_period', 'LAST_30_DAYS'));
        $today = CarbonImmutable::today();
        [$from, $to] = match ($period) {
            'TODAY' => [$today, $today],
            'LAST_7_DAYS' => [$today->subDays(6), $today],
            'THIS_MONTH' => [$today->startOfMonth(), $today],
            'LAST_MONTH' => [$today->subMonthNoOverflow()->startOfMonth(), $today->subMonthNoOverflow()->endOfMonth()],
            'YEAR_TO_DATE' => [$today->startOfYear(), $today],
            default => [$today->subDays(29), $today],
        };

        return new ReportFilter($from->startOfDay(), $to->endOfDay(), $schedule->company_id, $schedule->site_id);
    }
}
