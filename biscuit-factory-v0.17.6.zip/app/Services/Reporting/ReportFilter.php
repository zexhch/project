<?php

namespace App\Services\Reporting;

use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final readonly class ReportFilter
{
    public function __construct(
        public CarbonImmutable $from,
        public CarbonImmutable $to,
        public ?string $companyId = null,
        public ?string $siteId = null,
    ) {
    }

    public static function fromRequest(Request $request): self
    {
        $validated = $request->validate([
            'from' => ['nullable', 'date'],
            'to' => ['nullable', 'date', 'after_or_equal:from'],
            'company_id' => ['nullable', 'uuid', 'exists:companies,id'],
            'site_id' => ['nullable', 'uuid', 'exists:sites,id'],
        ]);

        if (! empty($validated['company_id']) && ! empty($validated['site_id'])) {
            abort_unless(
                DB::table('sites')->where('id', $validated['site_id'])->where('company_id', $validated['company_id'])->exists(),
                422,
                __('reports.site_company_mismatch'),
            );
        }

        $from = CarbonImmutable::parse($validated['from'] ?? today()->subMonths(5)->startOfMonth()->toDateString())->startOfDay();
        $to = CarbonImmutable::parse($validated['to'] ?? today()->toDateString())->endOfDay();

        abort_if($from->diffInMonths($to) > 36, 422, __('reports.period_too_large'));

        return new self($from, $to, $validated['company_id'] ?? null, $validated['site_id'] ?? null);
    }

    public static function fromArray(array $filters): self
    {
        return new self(
            CarbonImmutable::parse($filters['from'] ?? today()->subMonth()->startOfMonth())->startOfDay(),
            CarbonImmutable::parse($filters['to'] ?? today())->endOfDay(),
            $filters['company_id'] ?? null,
            $filters['site_id'] ?? null,
        );
    }

    public function toArray(): array
    {
        return [
            'from' => $this->from->toDateString(),
            'to' => $this->to->toDateString(),
            'company_id' => $this->companyId,
            'site_id' => $this->siteId,
        ];
    }

    public function query(): array
    {
        return array_filter($this->toArray(), fn ($value): bool => $value !== null && $value !== '');
    }
}
