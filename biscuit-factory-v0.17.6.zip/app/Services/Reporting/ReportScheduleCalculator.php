<?php

namespace App\Services\Reporting;

use App\Models\ReportSchedule;
use Carbon\CarbonImmutable;

final class ReportScheduleCalculator
{
    public function next(ReportSchedule|array $schedule, ?CarbonImmutable $after = null): CarbonImmutable
    {
        $after ??= CarbonImmutable::now();
        $frequency = strtoupper((string) data_get($schedule, 'frequency', 'WEEKLY'));
        $time = (string) data_get($schedule, 'run_time', '07:00');
        [$hour, $minute] = array_map('intval', explode(':', $time));
        $candidate = $after->setTime($hour, $minute);

        if ($frequency === 'DAILY') {
            return $candidate->isAfter($after) ? $candidate : $candidate->addDay();
        }

        if ($frequency === 'MONTHLY') {
            $day = max(1, min(28, (int) data_get($schedule, 'month_day', 1)));
            $candidate = $candidate->day($day);

            return $candidate->isAfter($after) ? $candidate : $candidate->addMonthNoOverflow()->day($day);
        }

        $weekday = max(1, min(7, (int) data_get($schedule, 'weekday', 1)));
        $daysToAdd = ($weekday - $candidate->isoWeekday() + 7) % 7;
        $candidate = $candidate->addDays($daysToAdd);

        return $candidate->isAfter($after) ? $candidate : $candidate->addWeek();
    }
}
