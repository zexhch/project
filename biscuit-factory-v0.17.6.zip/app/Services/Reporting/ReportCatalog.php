<?php

namespace App\Services\Reporting;

use App\Models\User;
use App\Services\Modules\ModuleRegistry;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;

final class ReportCatalog
{
    public function __construct(private readonly ModuleRegistry $modules)
    {
    }

    /** @return array<string, array<string, mixed>> */
    public function definitions(): array
    {
        return [
            'executive' => ['title' => 'reports.executive', 'description' => 'reports.executive_description', 'icon' => 'ti-chart-pie', 'module' => null, 'permission' => 'dashboard.view'],
            'sales' => ['title' => 'reports.sales', 'description' => 'reports.sales_description', 'icon' => 'ti-shopping-bag', 'module' => 'sales', 'permission' => 'sales.view'],
            'purchasing' => ['title' => 'reports.purchasing', 'description' => 'reports.purchasing_description', 'icon' => 'ti-building-store', 'module' => 'purchasing', 'permission' => 'purchasing.view'],
            'production' => ['title' => 'reports.production', 'description' => 'reports.production_description', 'icon' => 'ti-settings-automation', 'module' => 'production', 'permission' => 'production.view'],
            'stocks' => ['title' => 'reports.stocks', 'description' => 'reports.stocks_description', 'icon' => 'ti-packages', 'module' => 'stocks', 'permission' => 'stocks.view'],
            'quality' => ['title' => 'reports.quality', 'description' => 'reports.quality_description', 'icon' => 'ti-shield-check', 'module' => 'quality', 'permission' => 'quality.view'],
            'maintenance' => ['title' => 'reports.maintenance', 'description' => 'reports.maintenance_description', 'icon' => 'ti-tool', 'module' => 'maintenance', 'permission' => 'maintenance.view'],
            'finance' => ['title' => 'reports.finance', 'description' => 'reports.finance_description', 'icon' => 'ti-cash-banknote', 'module' => 'finance', 'permission' => 'finance.view'],
        ];
    }

    public function availableFor(User $user): Collection
    {
        $permissions = $user->permissions()->pluck('code')->flip();

        return collect($this->definitions())
            ->filter(function (array $definition) use ($permissions): bool {
                $module = $definition['module'];

                return $permissions->has($definition['permission'])
                    && ($module === null || $this->modules->enabled($module));
            });
    }

    public function definitionFor(User $user, string $code): array
    {
        $definition = $this->availableFor($user)->get($code);
        abort_unless($definition, 404);

        return $definition;
    }

    public function defaultFor(User $user): string
    {
        $roles = $user->roles()->pluck('code');
        $preferred = match (true) {
            $roles->contains(fn (string $code): bool => in_array($code, ['ADMINISTRATOR', 'MANAGEMENT'], true)) => 'executive',
            $roles->contains(fn (string $code): bool => in_array($code, ['SALES_MANAGER', 'SALES', 'DELIVERY_DRIVER'], true)) => 'sales',
            $roles->contains(fn (string $code): bool => in_array($code, ['PURCHASING_MANAGER', 'BUYER'], true)) => 'purchasing',
            $roles->contains(fn (string $code): bool => in_array($code, ['PRODUCTION_MANAGER', 'PRODUCTION_OPERATOR'], true)) => 'production',
            $roles->contains('WAREHOUSE_KEEPER') => 'stocks',
            $roles->contains('QUALITY_MANAGER') => 'quality',
            $roles->contains(fn (string $code): bool => in_array($code, ['MAINTENANCE_MANAGER', 'MAINTENANCE_TECHNICIAN'], true)) => 'maintenance',
            $roles->contains('FINANCE') => 'finance',
            default => 'executive',
        };

        $available = $this->availableFor($user);

        return $available->has($preferred) ? $preferred : (string) ($available->keys()->first() ?? 'executive');
    }
}
