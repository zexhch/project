<?php

namespace App\Services\Reporting;

use App\Services\Finance\ManagementControlService;
use App\Services\Modules\ModuleRegistry;
use Carbon\CarbonImmutable;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class ReportingService
{
    public function __construct(
        private readonly ModuleRegistry $modules,
        private readonly ManagementControlService $managementControl,
    ) {
    }

    public function build(string $code, ReportFilter $filter): array
    {
        return match ($code) {
            'executive' => $this->executive($filter),
            'sales' => $this->sales($filter),
            'purchasing' => $this->purchasing($filter),
            'production' => $this->production($filter),
            'stocks' => $this->stocks($filter),
            'quality' => $this->quality($filter),
            'maintenance' => $this->maintenance($filter),
            'finance' => $this->finance($filter),
            default => abort(404),
        };
    }

    public function dashboard(string $code, ReportFilter $filter): array
    {
        $report = $this->build($code, $filter);

        return [
            'code' => $code,
            'title' => $report['title'],
            'metrics' => array_slice($report['metrics'], 0, 6),
            'trend' => $report['trend'] ?? [],
        ];
    }

    private function executive(ReportFilter $filter): array
    {
        $revenue = $this->invoiceTotal('customer_invoices', $filter);
        $purchases = $this->invoiceTotal('supplier_invoices', $filter);
        $collections = $this->paymentTotal('customer_payments', $filter);
        $supplierPayments = $this->paymentTotal('supplier_payments', $filter);
        $receivables = $this->openBalance('customer_invoices', $filter);
        $payables = $this->openBalance('supplier_invoices', $filter);
        $margin = 0.0;
        if ($this->modules->enabled('finance') && $this->modules->enabled('sales') && Schema::hasTable('sales_order_lines')) {
            $margin = (float) data_get($this->managementControl->marginReport(
                $filter->from->toDateString(),
                $filter->to->toDateString(),
                $filter->companyId,
                $filter->siteId,
            ), 'totals.margin', 0);
        }
        $accepted = $this->productionQuantity($filter, 'accepted_quantity');
        $losses = $this->productionLosses($filter);
        $yield = ($accepted + $losses) > 0 ? ($accepted / ($accepted + $losses)) * 100 : 0;

        $trendRows = $this->monthlyFinanceTrend($filter);

        return $this->report('reports.executive', 'reports.executive_description', $filter, [
            $this->metric('reports.revenue', $revenue, 'currency', 'ti-cash'),
            $this->metric('reports.purchases_amount', $purchases, 'currency', 'ti-shopping-cart'),
            $this->metric('reports.operating_margin', $margin, 'currency', 'ti-chart-line'),
            $this->metric('reports.collections', $collections, 'currency', 'ti-arrow-down-left'),
            $this->metric('reports.receivables', $receivables, 'currency', 'ti-receipt'),
            $this->metric('reports.payables', $payables, 'currency', 'ti-file-invoice'),
            $this->metric('reports.production_output', $accepted, 'decimal', 'ti-packages'),
            $this->metric('reports.production_yield', $yield, 'percent', 'ti-gauge'),
        ], $this->trendFromRows($trendRows, 'revenue'), [
            $this->table('reports.monthly_evolution', [
                $this->column('period', 'reports.period'),
                $this->column('revenue', 'reports.revenue', 'currency'),
                $this->column('purchases', 'reports.purchases_amount', 'currency'),
                $this->column('collections', 'reports.collections', 'currency'),
                $this->column('payments', 'reports.supplier_payments', 'currency'),
                $this->column('net_cash', 'reports.net_cash', 'currency'),
            ], $trendRows),
        ]);
    }

    private function sales(ReportFilter $filter): array
    {
        if (! $this->available('sales', 'sales_orders')) {
            return $this->emptyReport('reports.sales', 'reports.sales_description', $filter);
        }

        $orders = $this->scoped(DB::table('sales_orders'), $filter, 'sales_orders.order_date', 'sales_orders')
            ->whereNotIn('status', ['DRAFT', 'CANCELLED']);
        $orderCount = (clone $orders)->count();
        $orderValue = (float) (clone $orders)->sum('total_amount');
        $invoiced = $this->invoiceTotal('customer_invoices', $filter);
        $collected = $this->paymentTotal('customer_payments', $filter);
        $openOrders = (clone $orders)->whereNotIn('status', ['DELIVERED', 'CLOSED', 'CANCELLED'])->count();
        $avgOrder = $orderCount > 0 ? $orderValue / $orderCount : 0;

        $topCustomersQuery = DB::table('customer_invoices as ci')
            ->join('customers as c', 'c.id', '=', 'ci.customer_id')
            ->selectRaw('c.code, c.name, COUNT(ci.id) as invoice_count, SUM(ci.total_amount) as revenue, SUM(ci.paid_amount) as paid, SUM(ci.balance_amount) as balance')
            ->whereNotIn('ci.status', ['DRAFT', 'CANCELLED']);
        $this->scopeAliased($topCustomersQuery, $filter, 'ci.invoice_date', 'ci');
        $topCustomers = $topCustomersQuery->groupBy('c.id', 'c.code', 'c.name')->orderByDesc('revenue')->limit(20)->get()->map(fn ($row): array => (array) $row)->all();

        $topItemsQuery = DB::table('customer_invoice_lines as cil')
            ->join('customer_invoices as ci', 'ci.id', '=', 'cil.customer_invoice_id')
            ->leftJoin('items as i', 'i.id', '=', 'cil.item_id')
            ->selectRaw("COALESCE(i.code, '-') as code, COALESCE(i.name, cil.description) as name, SUM(cil.quantity) as quantity, SUM(cil.line_total) as revenue")
            ->whereNotIn('ci.status', ['DRAFT', 'CANCELLED']);
        $this->scopeAliased($topItemsQuery, $filter, 'ci.invoice_date', 'ci');
        $topItems = $topItemsQuery->groupBy('i.id', 'i.code', 'i.name', 'cil.description')->orderByDesc('revenue')->limit(20)->get()->map(fn ($row): array => (array) $row)->all();

        $trend = $this->monthlyRows('customer_invoices', 'invoice_date', 'total_amount', $filter, ['DRAFT', 'CANCELLED']);

        return $this->report('reports.sales', 'reports.sales_description', $filter, [
            $this->metric('reports.order_count', $orderCount, 'integer', 'ti-shopping-cart'),
            $this->metric('reports.order_value', $orderValue, 'currency', 'ti-cash'),
            $this->metric('reports.invoiced', $invoiced, 'currency', 'ti-file-invoice'),
            $this->metric('reports.collections', $collected, 'currency', 'ti-arrow-down-left'),
            $this->metric('reports.open_orders', $openOrders, 'integer', 'ti-clock'),
            $this->metric('reports.average_order', $avgOrder, 'currency', 'ti-calculator'),
        ], $this->trendFromRows($trend, 'value'), [
            $this->table('reports.top_customers', [
                $this->column('code', 'reports.code'), $this->column('name', 'reports.customer'),
                $this->column('invoice_count', 'reports.invoice_count', 'integer'), $this->column('revenue', 'reports.revenue', 'currency'),
                $this->column('paid', 'reports.paid', 'currency'), $this->column('balance', 'reports.balance', 'currency'),
            ], $topCustomers),
            $this->table('reports.top_products', [
                $this->column('code', 'reports.code'), $this->column('name', 'reports.product'),
                $this->column('quantity', 'reports.quantity', 'decimal'), $this->column('revenue', 'reports.revenue', 'currency'),
            ], $topItems),
        ]);
    }

    private function purchasing(ReportFilter $filter): array
    {
        if (! $this->available('purchasing', 'purchase_orders')) {
            return $this->emptyReport('reports.purchasing', 'reports.purchasing_description', $filter);
        }

        $orders = $this->scoped(DB::table('purchase_orders'), $filter, 'purchase_orders.order_date', 'purchase_orders')->whereNotIn('status', ['DRAFT', 'CANCELLED']);
        $count = (clone $orders)->count();
        $value = (float) (clone $orders)->sum('total_amount');
        $receiptsQuery = DB::table('goods_receipts as gr')->join('purchase_orders as po', 'po.id', '=', 'gr.purchase_order_id')->whereBetween('gr.received_at', [$filter->from, $filter->to])->where('gr.status', 'POSTED');
        if ($filter->companyId) $receiptsQuery->where('po.company_id', $filter->companyId);
        if ($filter->siteId) $receiptsQuery->where('po.site_id', $filter->siteId);
        $receipts = $receiptsQuery->count('gr.id');
        $invoiced = $this->invoiceTotal('supplier_invoices', $filter);
        $paid = $this->paymentTotal('supplier_payments', $filter);

        $onTimeQuery = DB::table('goods_receipts as gr')->join('purchase_orders as po', 'po.id', '=', 'gr.purchase_order_id')->where('gr.status', 'POSTED')->whereNotNull('po.expected_date');
        $this->scopeAliased($onTimeQuery, $filter, 'gr.received_at', 'po');
        $receiptTotal = (clone $onTimeQuery)->count();
        $onTime = (clone $onTimeQuery)->whereColumn('gr.received_at', '<=', 'po.expected_date')->count();
        $onTimeRate = $receiptTotal > 0 ? $onTime / $receiptTotal * 100 : 0;

        $suppliersQuery = DB::table('purchase_orders as po')->join('suppliers as s', 's.id', '=', 'po.supplier_id')
            ->selectRaw('s.code, s.name, COUNT(po.id) as order_count, SUM(po.total_amount) as ordered_amount')
            ->whereNotIn('po.status', ['DRAFT', 'CANCELLED']);
        $this->scopeAliased($suppliersQuery, $filter, 'po.order_date', 'po');
        $suppliers = $suppliersQuery->groupBy('s.id', 's.code', 's.name')->orderByDesc('ordered_amount')->limit(20)->get()->map(fn ($row): array => (array) $row)->all();

        $trend = $this->monthlyRows('purchase_orders', 'order_date', 'total_amount', $filter, ['DRAFT', 'CANCELLED']);

        return $this->report('reports.purchasing', 'reports.purchasing_description', $filter, [
            $this->metric('reports.purchase_orders', $count, 'integer', 'ti-shopping-cart'),
            $this->metric('reports.purchases_amount', $value, 'currency', 'ti-cash'),
            $this->metric('reports.receipts', $receipts, 'integer', 'ti-package-import'),
            $this->metric('reports.supplier_invoiced', $invoiced, 'currency', 'ti-file-invoice'),
            $this->metric('reports.supplier_payments', $paid, 'currency', 'ti-arrow-up-right'),
            $this->metric('reports.on_time_delivery', $onTimeRate, 'percent', 'ti-clock-check'),
        ], $this->trendFromRows($trend, 'value'), [
            $this->table('reports.top_suppliers', [
                $this->column('code', 'reports.code'), $this->column('name', 'reports.supplier'),
                $this->column('order_count', 'reports.order_count', 'integer'), $this->column('ordered_amount', 'reports.purchases_amount', 'currency'),
            ], $suppliers),
        ]);
    }

    private function production(ReportFilter $filter): array
    {
        if (! $this->available('production', 'production_orders')) {
            return $this->emptyReport('reports.production', 'reports.production_description', $filter);
        }

        $orders = $this->productionOrders($filter)->get();
        $ids = $orders->pluck('id');
        $outputs = $ids->isEmpty() ? collect() : DB::table('production_outputs')->whereIn('production_order_id', $ids)->get()->groupBy('production_order_id');
        $losses = $ids->isEmpty() ? collect() : DB::table('production_losses')->whereIn('production_order_id', $ids)->get()->groupBy('production_order_id');
        $planned = (float) $orders->sum('planned_quantity');
        $accepted = (float) $outputs->flatten()->sum('accepted_quantity');
        $rejected = (float) $outputs->flatten()->sum('rejected_quantity');
        $lossQuantity = (float) $losses->flatten()->sum('quantity');
        $completed = $orders->where('status', 'COMPLETED')->count();
        $yield = ($accepted + $rejected + $lossQuantity) > 0 ? $accepted / ($accepted + $rejected + $lossQuantity) * 100 : 0;

        $lineRows = $orders->groupBy(fn ($order): string => $order->production_line_id ?: 'unassigned')->map(function (Collection $lineOrders, string $lineId) use ($outputs, $losses): array {
            $orderIds = $lineOrders->pluck('id');
            $lineOutputs = $orderIds->flatMap(fn ($id) => $outputs->get($id, collect()));
            $lineLosses = $orderIds->flatMap(fn ($id) => $losses->get($id, collect()));
            $accepted = (float) $lineOutputs->sum('accepted_quantity');
            $waste = (float) $lineOutputs->sum('rejected_quantity') + (float) $lineLosses->sum('quantity');

            return [
                'line' => $lineOrders->first()->line_name ?: __('reports.unassigned'),
                'orders' => $lineOrders->count(),
                'completed' => $lineOrders->where('status', 'COMPLETED')->count(),
                'planned' => (float) $lineOrders->sum('planned_quantity'),
                'accepted' => $accepted,
                'losses' => $waste,
                'yield' => ($accepted + $waste) > 0 ? $accepted / ($accepted + $waste) * 100 : 0,
            ];
        })->sortByDesc('accepted')->values()->all();

        $trend = $orders->groupBy(fn ($order): string => CarbonImmutable::parse($order->planned_date)->format('Y-m'))->map(fn (Collection $group, string $month): array => [
            'period' => CarbonImmutable::createFromFormat('Y-m-d', $month.'-01')->translatedFormat('M Y'),
            'value' => (float) $group->sum(fn ($order) => (float) $outputs->get($order->id, collect())->sum('accepted_quantity')),
            'sort' => $month,
        ])->sortBy('sort')->values()->map(fn (array $row): array => collect($row)->except('sort')->all())->all();

        return $this->report('reports.production', 'reports.production_description', $filter, [
            $this->metric('reports.production_orders', $orders->count(), 'integer', 'ti-settings-automation'),
            $this->metric('reports.completed_orders', $completed, 'integer', 'ti-circle-check'),
            $this->metric('reports.planned_quantity', $planned, 'decimal', 'ti-calendar'),
            $this->metric('reports.accepted_quantity', $accepted, 'decimal', 'ti-package'),
            $this->metric('reports.loss_quantity', $lossQuantity + $rejected, 'decimal', 'ti-trash'),
            $this->metric('reports.production_yield', $yield, 'percent', 'ti-gauge'),
        ], $this->trendFromRows($trend, 'value'), [
            $this->table('reports.line_performance', [
                $this->column('line', 'reports.production_line'), $this->column('orders', 'reports.order_count', 'integer'),
                $this->column('completed', 'reports.completed', 'integer'), $this->column('planned', 'reports.planned_quantity', 'decimal'),
                $this->column('accepted', 'reports.accepted_quantity', 'decimal'), $this->column('losses', 'reports.loss_quantity', 'decimal'),
                $this->column('yield', 'reports.production_yield', 'percent'),
            ], $lineRows),
        ]);
    }

    private function stocks(ReportFilter $filter): array
    {
        if (! $this->available('stocks', 'stock_balances')) {
            return $this->emptyReport('reports.stocks', 'reports.stocks_description', $filter);
        }

        $query = DB::table('stock_balances as sb')
            ->join('items as i', 'i.id', '=', 'sb.item_id')
            ->join('warehouse_locations as wl', 'wl.id', '=', 'sb.location_id')
            ->join('warehouses as w', 'w.id', '=', 'wl.warehouse_id')
            ->join('sites as s', 's.id', '=', 'w.site_id');
        $this->companySite($query, $filter, 's');

        $rows = (clone $query)->selectRaw('i.code, i.name, i.minimum_stock, SUM(sb.quantity) as quantity, SUM(sb.reserved_quantity) as reserved_quantity, SUM(sb.quantity - sb.reserved_quantity) as available_quantity, SUM(sb.quantity * COALESCE(sb.average_unit_cost, 0)) as stock_value')
            ->groupBy('i.id', 'i.code', 'i.name', 'i.minimum_stock')->orderByDesc('stock_value')->get()->map(function ($row): array {
                $data = (array) $row;
                $data['below_minimum'] = (float) $data['available_quantity'] < (float) $data['minimum_stock'] ? __('reports.yes') : __('reports.no');
                return $data;
            })->all();

        $totalQty = (float) collect($rows)->sum('quantity');
        $reserved = (float) collect($rows)->sum('reserved_quantity');
        $value = (float) collect($rows)->sum('stock_value');
        $lowStock = collect($rows)->where('below_minimum', __('reports.yes'))->count();
        $expiringQuery = DB::table('stock_balances as sb')->join('lots as l', 'l.id', '=', 'sb.lot_id')->join('warehouse_locations as wl', 'wl.id', '=', 'sb.location_id')->join('warehouses as w', 'w.id', '=', 'wl.warehouse_id')->join('sites as s', 's.id', '=', 'w.site_id')->where('sb.quantity', '>', 0)->whereBetween('l.expiry_date', [today(), today()->addDays(30)]);
        $this->companySite($expiringQuery, $filter, 's');
        $expiring = $expiringQuery->distinct('l.id')->count('l.id');

        return $this->report('reports.stocks', 'reports.stocks_description', $filter, [
            $this->metric('reports.stock_quantity', $totalQty, 'decimal', 'ti-packages'),
            $this->metric('reports.available_quantity', $totalQty - $reserved, 'decimal', 'ti-package'),
            $this->metric('reports.reserved_quantity', $reserved, 'decimal', 'ti-lock'),
            $this->metric('reports.stock_value', $value, 'currency', 'ti-cash'),
            $this->metric('reports.low_stock_items', $lowStock, 'integer', 'ti-alert-triangle'),
            $this->metric('reports.expiring_lots_30', $expiring, 'integer', 'ti-calendar-alert'),
        ], [], [
            $this->table('reports.stock_by_item', [
                $this->column('code', 'reports.code'), $this->column('name', 'reports.product'),
                $this->column('quantity', 'reports.stock_quantity', 'decimal'), $this->column('reserved_quantity', 'reports.reserved_quantity', 'decimal'),
                $this->column('available_quantity', 'reports.available_quantity', 'decimal'), $this->column('minimum_stock', 'reports.minimum_stock', 'decimal'),
                $this->column('stock_value', 'reports.stock_value', 'currency'), $this->column('below_minimum', 'reports.below_minimum'),
            ], $rows),
        ]);
    }

    private function quality(ReportFilter $filter): array
    {
        if (! $this->available('quality', 'quality_inspections')) {
            return $this->emptyReport('reports.quality', 'reports.quality_description', $filter);
        }

        $inspections = DB::table('quality_inspections as qi')->leftJoin('production_lines as pl', 'pl.id', '=', 'qi.production_line_id')->leftJoin('sites as s', 's.id', '=', 'pl.site_id')->whereBetween('qi.created_at', [$filter->from, $filter->to]);
        $this->companySite($inspections, $filter, 's');
        $total = (clone $inspections)->count('qi.id');
        $conforming = (clone $inspections)->where('qi.status', 'CONFORMING')->count('qi.id');
        $nonConforming = (clone $inspections)->where('qi.status', 'NONCONFORMING')->count('qi.id');
        $pending = (clone $inspections)->whereIn('qi.status', ['DRAFT', 'IN_PROGRESS'])->count('qi.id');
        $compliance = ($conforming + $nonConforming) > 0 ? $conforming / ($conforming + $nonConforming) * 100 : 0;

        $ncQuery = DB::table('quality_non_conformities as qn')->leftJoin('production_orders as po', 'po.id', '=', 'qn.production_order_id')->leftJoin('production_lines as pl', 'pl.id', '=', 'po.production_line_id')->leftJoin('sites as s', 's.id', '=', 'pl.site_id')->whereBetween('qn.detected_at', [$filter->from, $filter->to]);
        $this->companySite($ncQuery, $filter, 's');
        $openNc = (clone $ncQuery)->whereNotIn('qn.status', ['CLOSED', 'CANCELLED'])->count('qn.id');
        $critical = (clone $ncQuery)->whereIn('qn.severity', ['CRITICAL', 'MAJOR'])->count('qn.id');

        $statusRows = (clone $inspections)->selectRaw('qi.status, COUNT(qi.id) as total')->groupBy('qi.status')->orderByDesc('total')->get()->map(fn ($row): array => ['status' => __('reports.status_'.strtolower($row->status)), 'total' => $row->total])->all();
        $severityRows = (clone $ncQuery)->selectRaw('qn.severity, COUNT(qn.id) as total')->groupBy('qn.severity')->orderByDesc('total')->get()->map(fn ($row): array => ['severity' => $row->severity, 'total' => $row->total])->all();

        return $this->report('reports.quality', 'reports.quality_description', $filter, [
            $this->metric('reports.inspections', $total, 'integer', 'ti-clipboard-check'),
            $this->metric('reports.conforming', $conforming, 'integer', 'ti-circle-check'),
            $this->metric('reports.nonconforming', $nonConforming, 'integer', 'ti-alert-triangle'),
            $this->metric('reports.pending_inspections', $pending, 'integer', 'ti-clock'),
            $this->metric('reports.compliance_rate', $compliance, 'percent', 'ti-shield-check'),
            $this->metric('reports.open_nonconformities', $openNc, 'integer', 'ti-bug'),
            $this->metric('reports.major_critical_nc', $critical, 'integer', 'ti-alert-octagon'),
        ], [], [
            $this->table('reports.inspection_statuses', [$this->column('status', 'reports.status'), $this->column('total', 'reports.total', 'integer')], $statusRows),
            $this->table('reports.nonconformities_by_severity', [$this->column('severity', 'reports.severity'), $this->column('total', 'reports.total', 'integer')], $severityRows),
        ]);
    }

    private function maintenance(ReportFilter $filter): array
    {
        if (! $this->available('maintenance', 'maintenance_work_orders')) {
            return $this->emptyReport('reports.maintenance', 'reports.maintenance_description', $filter);
        }

        $workOrders = DB::table('maintenance_work_orders as mw')->leftJoin('production_lines as pl', 'pl.id', '=', 'mw.production_line_id')->leftJoin('sites as s', 's.id', '=', 'pl.site_id')->whereBetween('mw.created_at', [$filter->from, $filter->to]);
        $this->companySite($workOrders, $filter, 's');
        $count = (clone $workOrders)->count('mw.id');
        $completed = (clone $workOrders)->where('mw.status', 'COMPLETED')->count('mw.id');
        $open = (clone $workOrders)->whereNotIn('mw.status', ['COMPLETED', 'CANCELLED'])->count('mw.id');
        $cost = (float) (clone $workOrders)->sum(DB::raw('mw.labor_cost + mw.parts_cost'));
        $completedRows = (clone $workOrders)->where('mw.status', 'COMPLETED')->whereNotNull('mw.actual_start')->whereNotNull('mw.actual_end')->select('mw.actual_start', 'mw.actual_end')->get();
        $mttr = $completedRows->isNotEmpty() ? $completedRows->avg(fn ($row): int => CarbonImmutable::parse($row->actual_start)->diffInSeconds(CarbonImmutable::parse($row->actual_end))) : 0;

        $downtimes = DB::table('production_downtimes as pd')->join('production_lines as pl', 'pl.id', '=', 'pd.production_line_id')->join('sites as s', 's.id', '=', 'pl.site_id')->whereBetween('pd.started_at', [$filter->from, $filter->to]);
        $this->companySite($downtimes, $filter, 's');
        $downtimeSeconds = (int) (clone $downtimes)->sum('pd.duration_seconds');
        $unplannedSeconds = (int) (clone $downtimes)->where('pd.planned', false)->sum('pd.duration_seconds');

        $lineRows = (clone $downtimes)->selectRaw('pl.code, pl.name, COUNT(pd.id) as events, SUM(COALESCE(pd.duration_seconds, 0)) as duration_seconds, SUM(CASE WHEN pd.planned = false THEN COALESCE(pd.duration_seconds, 0) ELSE 0 END) as unplanned_seconds')->groupBy('pl.id', 'pl.code', 'pl.name')->orderByDesc('duration_seconds')->get()->map(fn ($row): array => (array) $row)->all();

        return $this->report('reports.maintenance', 'reports.maintenance_description', $filter, [
            $this->metric('reports.work_orders', $count, 'integer', 'ti-tool'),
            $this->metric('reports.completed_orders', $completed, 'integer', 'ti-circle-check'),
            $this->metric('reports.open_work_orders', $open, 'integer', 'ti-clock'),
            $this->metric('reports.maintenance_cost', $cost, 'currency', 'ti-cash'),
            $this->metric('reports.total_downtime', $downtimeSeconds, 'duration', 'ti-player-pause'),
            $this->metric('reports.unplanned_downtime', $unplannedSeconds, 'duration', 'ti-alert-triangle'),
            $this->metric('reports.mttr', $mttr, 'duration', 'ti-clock-cog'),
        ], [], [
            $this->table('reports.downtime_by_line', [
                $this->column('code', 'reports.code'), $this->column('name', 'reports.production_line'),
                $this->column('events', 'reports.events', 'integer'), $this->column('duration_seconds', 'reports.total_downtime', 'duration'),
                $this->column('unplanned_seconds', 'reports.unplanned_downtime', 'duration'),
            ], $lineRows),
        ]);
    }

    private function finance(ReportFilter $filter): array
    {
        if (! $this->available('finance', 'customer_invoices')) {
            return $this->emptyReport('reports.finance', 'reports.finance_description', $filter);
        }

        $revenue = $this->invoiceTotal('customer_invoices', $filter);
        $purchases = $this->invoiceTotal('supplier_invoices', $filter);
        $collections = $this->paymentTotal('customer_payments', $filter);
        $payments = $this->paymentTotal('supplier_payments', $filter);
        $receivables = $this->openBalance('customer_invoices', $filter);
        $payables = $this->openBalance('supplier_invoices', $filter);
        $overdueReceivables = $this->overdueBalance('customer_invoices', $filter);
        $overduePayables = $this->overdueBalance('supplier_invoices', $filter);

        $aging = [
            ['bucket' => __('reports.not_due'), 'customer' => $this->agingBalance('customer_invoices', $filter, null, 0), 'supplier' => $this->agingBalance('supplier_invoices', $filter, null, 0)],
            ['bucket' => '1–30', 'customer' => $this->agingBalance('customer_invoices', $filter, 1, 30), 'supplier' => $this->agingBalance('supplier_invoices', $filter, 1, 30)],
            ['bucket' => '31–60', 'customer' => $this->agingBalance('customer_invoices', $filter, 31, 60), 'supplier' => $this->agingBalance('supplier_invoices', $filter, 31, 60)],
            ['bucket' => '61–90', 'customer' => $this->agingBalance('customer_invoices', $filter, 61, 90), 'supplier' => $this->agingBalance('supplier_invoices', $filter, 61, 90)],
            ['bucket' => '90+', 'customer' => $this->agingBalance('customer_invoices', $filter, 91, null), 'supplier' => $this->agingBalance('supplier_invoices', $filter, 91, null)],
        ];
        $trendRows = $this->monthlyFinanceTrend($filter);

        return $this->report('reports.finance', 'reports.finance_description', $filter, [
            $this->metric('reports.revenue', $revenue, 'currency', 'ti-cash'),
            $this->metric('reports.purchases_amount', $purchases, 'currency', 'ti-shopping-cart'),
            $this->metric('reports.collections', $collections, 'currency', 'ti-arrow-down-left'),
            $this->metric('reports.supplier_payments', $payments, 'currency', 'ti-arrow-up-right'),
            $this->metric('reports.receivables', $receivables, 'currency', 'ti-receipt'),
            $this->metric('reports.payables', $payables, 'currency', 'ti-file-invoice'),
            $this->metric('reports.overdue_receivables', $overdueReceivables, 'currency', 'ti-alert-triangle'),
            $this->metric('reports.overdue_payables', $overduePayables, 'currency', 'ti-alert-octagon'),
        ], $this->trendFromRows($trendRows, 'net_cash'), [
            $this->table('reports.aging_balance', [
                $this->column('bucket', 'reports.aging_bucket'), $this->column('customer', 'reports.receivables', 'currency'), $this->column('supplier', 'reports.payables', 'currency'),
            ], $aging),
            $this->table('reports.monthly_cashflow', [
                $this->column('period', 'reports.period'), $this->column('collections', 'reports.collections', 'currency'),
                $this->column('payments', 'reports.supplier_payments', 'currency'), $this->column('net_cash', 'reports.net_cash', 'currency'),
            ], $trendRows),
        ]);
    }

    private function report(string $title, string $description, ReportFilter $filter, array $metrics, array $trend, array $tables): array
    {
        return compact('title', 'description', 'filter', 'metrics', 'trend', 'tables') + ['generated_at' => now()];
    }

    private function emptyReport(string $title, string $description, ReportFilter $filter): array
    {
        return $this->report($title, $description, $filter, [], [], []);
    }

    private function metric(string $label, float|int $value, string $format, string $icon): array
    {
        return compact('label', 'value', 'format', 'icon');
    }

    private function table(string $title, array $columns, array $rows): array
    {
        return compact('title', 'columns', 'rows');
    }

    private function column(string $key, string $label, string $format = 'text'): array
    {
        return compact('key', 'label', 'format');
    }

    private function available(string $module, string $table): bool
    {
        return $this->modules->enabled($module) && Schema::hasTable($table);
    }

    private function scoped(Builder $query, ReportFilter $filter, string $dateColumn, string $table): Builder
    {
        $query->whereBetween($dateColumn, [$filter->from, $filter->to]);
        if ($filter->companyId && Schema::hasColumn($table, 'company_id')) $query->where("{$table}.company_id", $filter->companyId);
        if ($filter->siteId && Schema::hasColumn($table, 'site_id')) $query->where("{$table}.site_id", $filter->siteId);
        return $query;
    }

    private function scopeAliased(Builder $query, ReportFilter $filter, string $dateColumn, string $alias): void
    {
        $query->whereBetween($dateColumn, [$filter->from, $filter->to]);
        if ($filter->companyId) $query->where("{$alias}.company_id", $filter->companyId);
        if ($filter->siteId) $query->where("{$alias}.site_id", $filter->siteId);
    }

    private function dateScoped(Builder $query, ReportFilter $filter, string $dateColumn): Builder
    {
        return $query->whereBetween($dateColumn, [$filter->from, $filter->to]);
    }

    private function companySite(Builder $query, ReportFilter $filter, string $siteAlias): void
    {
        if ($filter->companyId) $query->where("{$siteAlias}.company_id", $filter->companyId);
        if ($filter->siteId) $query->where("{$siteAlias}.id", $filter->siteId);
    }

    private function invoiceTotal(string $table, ReportFilter $filter): float
    {
        if (! Schema::hasTable($table) || ! $this->modules->enabled('finance')) return 0;
        return (float) $this->scoped(DB::table($table), $filter, "{$table}.invoice_date", $table)->whereNotIn('status', ['DRAFT', 'CANCELLED'])->sum('total_amount');
    }

    private function paymentTotal(string $table, ReportFilter $filter): float
    {
        if (! Schema::hasTable($table) || ! $this->modules->enabled('finance')) return 0;
        $query = DB::table($table)->whereBetween('payment_date', [$filter->from, $filter->to])->where('status', 'POSTED');
        if ($filter->companyId) $query->where('company_id', $filter->companyId);
        return (float) $query->sum('amount');
    }

    private function openBalance(string $table, ReportFilter $filter): float
    {
        if (! Schema::hasTable($table) || ! $this->modules->enabled('finance')) return 0;
        $query = DB::table($table)->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])->where('balance_amount', '>', 0);
        if ($filter->companyId) $query->where('company_id', $filter->companyId);
        if ($filter->siteId) $query->where('site_id', $filter->siteId);
        return (float) $query->sum('balance_amount');
    }

    private function overdueBalance(string $table, ReportFilter $filter): float
    {
        if (! Schema::hasTable($table) || ! $this->modules->enabled('finance')) return 0;
        $query = DB::table($table)->where('due_date', '<', today())->where('balance_amount', '>', 0)->whereNotIn('status', ['DRAFT', 'CANCELLED', 'PAID']);
        if ($filter->companyId) $query->where('company_id', $filter->companyId);
        if ($filter->siteId) $query->where('site_id', $filter->siteId);
        return (float) $query->sum('balance_amount');
    }

    private function agingBalance(string $table, ReportFilter $filter, ?int $minDays, ?int $maxDays): float
    {
        if (! Schema::hasTable($table) || ! $this->modules->enabled('finance')) return 0;
        $query = DB::table($table)->where('balance_amount', '>', 0)->whereNotIn('status', ['DRAFT', 'CANCELLED', 'PAID']);
        if ($minDays === null) $query->where('due_date', '>=', today());
        else {
            $query->where('due_date', '<=', today()->subDays($minDays));
            if ($maxDays !== null) $query->where('due_date', '>=', today()->subDays($maxDays));
        }
        if ($filter->companyId) $query->where('company_id', $filter->companyId);
        if ($filter->siteId) $query->where('site_id', $filter->siteId);
        return (float) $query->sum('balance_amount');
    }

    private function productionOrders(ReportFilter $filter): Builder
    {
        $query = DB::table('production_orders as po')->leftJoin('production_lines as pl', 'pl.id', '=', 'po.production_line_id')->leftJoin('sites as s', 's.id', '=', 'pl.site_id')
            ->whereBetween('po.planned_date', [$filter->from->toDateString(), $filter->to->toDateString()])
            ->where('po.status', '!=', 'CANCELLED')
            ->select('po.*', 'pl.name as line_name');
        $this->companySite($query, $filter, 's');
        return $query;
    }

    private function productionQuantity(ReportFilter $filter, string $column): float
    {
        if (! $this->available('production', 'production_orders') || ! Schema::hasTable('production_outputs')) return 0;
        $ids = $this->productionOrders($filter)->pluck('po.id');
        return $ids->isEmpty() ? 0 : (float) DB::table('production_outputs')->whereIn('production_order_id', $ids)->sum($column);
    }

    private function productionLosses(ReportFilter $filter): float
    {
        if (! $this->available('production', 'production_orders') || ! Schema::hasTable('production_losses')) return 0;
        $ids = $this->productionOrders($filter)->pluck('po.id');
        return $ids->isEmpty() ? 0 : (float) DB::table('production_losses')->whereIn('production_order_id', $ids)->sum('quantity');
    }

    private function monthlyRows(string $table, string $dateColumn, string $valueColumn, ReportFilter $filter, array $excludedStatuses = []): array
    {
        if (! Schema::hasTable($table)) return [];
        $query = $this->scoped(DB::table($table), $filter, "{$table}.{$dateColumn}", $table)->select($dateColumn, $valueColumn);
        if ($excludedStatuses !== [] && Schema::hasColumn($table, 'status')) $query->whereNotIn('status', $excludedStatuses);
        return $query->get()->groupBy(fn ($row): string => CarbonImmutable::parse($row->{$dateColumn})->format('Y-m'))->map(fn (Collection $rows, string $month): array => [
            'period' => CarbonImmutable::createFromFormat('Y-m-d', $month.'-01')->translatedFormat('M Y'),
            'value' => (float) $rows->sum($valueColumn),
            'sort' => $month,
        ])->sortBy('sort')->values()->map(fn (array $row): array => collect($row)->except('sort')->all())->all();
    }

    private function monthlyFinanceTrend(ReportFilter $filter): array
    {
        $sources = $this->modules->enabled('finance') ? [
            'revenue' => ['customer_invoices', 'invoice_date', 'total_amount', ['DRAFT', 'CANCELLED']],
            'purchases' => ['supplier_invoices', 'invoice_date', 'total_amount', ['DRAFT', 'CANCELLED']],
            'collections' => ['customer_payments', 'payment_date', 'amount', ['DRAFT', 'REVERSED']],
            'payments' => ['supplier_payments', 'payment_date', 'amount', ['DRAFT', 'REVERSED']],
        ] : [];
        $months = collect();
        for ($cursor = $filter->from->startOfMonth(); $cursor <= $filter->to->startOfMonth(); $cursor = $cursor->addMonth()) {
            $months->put($cursor->format('Y-m'), ['period' => $cursor->translatedFormat('M Y'), 'revenue' => 0, 'purchases' => 0, 'collections' => 0, 'payments' => 0]);
        }
        foreach ($sources as $key => [$table, $date, $amount, $excluded]) {
            if (! Schema::hasTable($table)) continue;
            $query = DB::table($table)->whereBetween($date, [$filter->from, $filter->to])->select($date, $amount);
            if ($filter->companyId && Schema::hasColumn($table, 'company_id')) $query->where('company_id', $filter->companyId);
            if ($filter->siteId && Schema::hasColumn($table, 'site_id')) $query->where('site_id', $filter->siteId);
            if (Schema::hasColumn($table, 'status')) $query->whereNotIn('status', $excluded);
            foreach ($query->get() as $row) {
                $month = CarbonImmutable::parse($row->{$date})->format('Y-m');
                if ($months->has($month)) {
                    $item = $months->get($month);
                    $item[$key] += (float) $row->{$amount};
                    $months->put($month, $item);
                }
            }
        }
        return $months->map(function (array $row): array {
            $row['net_cash'] = $row['collections'] - $row['payments'];
            return $row;
        })->values()->all();
    }

    private function trendFromRows(array $rows, string $key): array
    {
        return collect($rows)->map(fn (array $row): array => ['label' => $row['period'], 'value' => (float) ($row[$key] ?? 0)])->all();
    }
}
