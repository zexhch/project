<?php

namespace App\Services\Purchasing;

use App\Models\Item;
use App\Models\PurchasePriceListLine;
use App\Models\Supplier;
use Carbon\CarbonInterface;

class PurchasePricingService
{
    public function resolve(
        Supplier $supplier,
        Item $item,
        float $quantity,
        string $unitId,
        CarbonInterface $date,
    ): ?array {
        $line = PurchasePriceListLine::query()
            ->with(['priceList', 'taxRate'])
            ->where('item_id', $item->id)
            ->where('unit_id', $unitId)
            ->where('minimum_quantity', '<=', $quantity)
            ->whereHas('priceList', fn ($query) => $query
                ->where('supplier_id', $supplier->id)
                ->activeOn($date))
            ->get()
            ->sort(function (PurchasePriceListLine $left, PurchasePriceListLine $right): int {
                $priority = $left->priceList->priority <=> $right->priceList->priority;

                return $priority !== 0
                    ? $priority
                    : (float) $right->minimum_quantity <=> (float) $left->minimum_quantity;
            })
            ->first();

        if (! $line) {
            return null;
        }

        return [
            'price_list_id' => $line->purchase_price_list_id,
            'price_list_code' => $line->priceList->code,
            'currency_code' => $line->priceList->currency_code,
            'tax_included' => $line->priceList->tax_included,
            'unit_price' => (float) $line->unit_price,
            'discount_percentage' => (float) $line->discount_percentage,
            'tax_rate_id' => $line->tax_rate_id,
            'tax_rate' => (float) ($line->taxRate?->rate ?? 0),
            'lead_time_days' => $line->lead_time_days,
        ];
    }

    public function calculate(
        float $quantity,
        float $unitPrice,
        float $discountPercentage,
        float $taxRate,
        bool $taxIncluded,
    ): array {
        $grossBeforeDiscount = $quantity * $unitPrice;
        $discountAmount = $grossBeforeDiscount * ($discountPercentage / 100);
        $discountedAmount = $grossBeforeDiscount - $discountAmount;

        if ($taxIncluded && $taxRate > 0) {
            $lineSubtotal = $discountedAmount / (1 + ($taxRate / 100));
            $taxAmount = $discountedAmount - $lineSubtotal;
            $lineTotal = $discountedAmount;
        } else {
            $lineSubtotal = $discountedAmount;
            $taxAmount = $lineSubtotal * ($taxRate / 100);
            $lineTotal = $lineSubtotal + $taxAmount;
        }

        return [
            'net_unit_price' => $quantity > 0 ? round($lineSubtotal / $quantity, 6) : 0,
            'line_subtotal' => round($lineSubtotal, 4),
            'discount_amount' => round($discountAmount, 4),
            'tax_amount' => round($taxAmount, 4),
            'line_total' => round($lineTotal, 4),
        ];
    }
}
