<?php

namespace App\Services\Purchasing;

use App\Events\DashboardUpdated;
use App\Models\GoodsReceipt;
use App\Models\GoodsReceiptLine;
use App\Models\Lot;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLine;
use App\Models\PurchasePriceList;
use App\Models\PurchaseRequisition;
use App\Models\StockMovement;
use App\Models\SupplierQuotation;
use App\Models\SupplierReturn;
use App\Models\User;
use App\Notifications\SystemAlertNotification;
use App\Services\Modules\ModuleRegistry;
use App\Services\Stock\StockPostingService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class PurchasingWorkflowService
{
    public function __construct(
        private readonly StockPostingService $stockPosting,
        private readonly ModuleRegistry $modules,
    ) {
    }

    public function submitRequisition(PurchaseRequisition $requisition, string $userId): PurchaseRequisition
    {
        return DB::transaction(function () use ($requisition, $userId): PurchaseRequisition {
            $requisition = PurchaseRequisition::query()->with('lines')->lockForUpdate()->findOrFail($requisition->id);
            $this->requireStatus($requisition->status, ['DRAFT'], 'purchasing.requisition_not_draft');
            if ($requisition->lines->isEmpty()) {
                throw ValidationException::withMessages(['requisition' => __('purchasing.line_required')]);
            }

            $requisition->update([
                'status' => 'SUBMITTED',
                'submitted_by' => $userId,
                'submitted_at' => now(),
            ]);
            $this->audit('purchasing.requisition.submitted', $requisition, $userId, ['status' => 'DRAFT'], ['status' => 'SUBMITTED']);
            $this->notifyAfterCommit(
                ['purchasing.approve'],
                __('purchasing.notification_requisition_title'),
                __('purchasing.notification_requisition_message', ['number' => $requisition->requisition_number]),
                route('purchasing.requisitions.show', $requisition),
            );

            return $requisition->fresh('lines');
        }, 3);
    }

    public function approveRequisition(PurchaseRequisition $requisition, string $userId): PurchaseRequisition
    {
        return DB::transaction(function () use ($requisition, $userId): PurchaseRequisition {
            $requisition = PurchaseRequisition::query()->lockForUpdate()->findOrFail($requisition->id);
            $this->requireStatus($requisition->status, ['SUBMITTED'], 'purchasing.requisition_not_submitted');
            $requisition->update(['status' => 'APPROVED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->audit('purchasing.requisition.approved', $requisition, $userId, ['status' => 'SUBMITTED'], ['status' => 'APPROVED']);

            return $requisition->fresh();
        }, 3);
    }

    public function approvePriceList(PurchasePriceList $priceList, string $userId): PurchasePriceList
    {
        return DB::transaction(function () use ($priceList, $userId): PurchasePriceList {
            $priceList = PurchasePriceList::query()->with('lines')->lockForUpdate()->findOrFail($priceList->id);
            $this->requireStatus($priceList->status, ['DRAFT'], 'purchasing.price_list_not_draft');
            if ($priceList->lines->isEmpty()) {
                throw ValidationException::withMessages(['price_list' => __('purchasing.line_required')]);
            }
            $priceList->update(['status' => 'APPROVED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->audit('purchasing.price_list.approved', $priceList, $userId, ['status' => 'DRAFT'], ['status' => 'APPROVED']);

            return $priceList->fresh('lines');
        }, 3);
    }

    public function submitOrder(PurchaseOrder $order, string $userId): PurchaseOrder
    {
        return DB::transaction(function () use ($order, $userId): PurchaseOrder {
            $order = PurchaseOrder::query()->with(['lines', 'supplier'])->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus($order->status, ['DRAFT'], 'purchasing.order_not_draft');
            if ($order->lines->isEmpty()) {
                throw ValidationException::withMessages(['order' => __('purchasing.line_required')]);
            }
            if (! $order->supplier->active || $order->supplier->status !== 'APPROVED') {
                throw ValidationException::withMessages(['supplier_id' => __('purchasing.supplier_not_approved')]);
            }
            if ((float) $order->total_amount < (float) $order->supplier->minimum_order_value) {
                throw ValidationException::withMessages(['total_amount' => __('purchasing.minimum_order_not_reached')]);
            }

            $order->update(['status' => 'SUBMITTED', 'submitted_by' => $userId, 'submitted_at' => now()]);
            $this->audit('purchasing.order.submitted', $order, $userId, ['status' => 'DRAFT'], ['status' => 'SUBMITTED']);
            $this->notifyAfterCommit(
                ['purchasing.approve'],
                __('purchasing.notification_order_title'),
                __('purchasing.notification_order_message', ['number' => $order->order_number]),
                route('purchasing.orders.show', $order),
            );

            return $order->fresh('lines');
        }, 3);
    }

    public function approveOrder(PurchaseOrder $order, string $userId): PurchaseOrder
    {
        return DB::transaction(function () use ($order, $userId): PurchaseOrder {
            $order = PurchaseOrder::query()->lockForUpdate()->findOrFail($order->id);
            $this->requireStatus($order->status, ['SUBMITTED'], 'purchasing.order_not_submitted');
            $order->update(['status' => 'APPROVED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->audit('purchasing.order.approved', $order, $userId, ['status' => 'SUBMITTED'], ['status' => 'APPROVED']);
            DB::afterCommit(fn () => event(new DashboardUpdated(['purchase_order_id' => $order->id])));

            return $order->fresh('lines');
        }, 3);
    }

    public function postReceipt(GoodsReceipt $receipt, string $userId): GoodsReceipt
    {
        return DB::transaction(function () use ($receipt, $userId): GoodsReceipt {
            $receipt = GoodsReceipt::query()
                ->with(['lines.purchaseOrderLine.item', 'purchaseOrder.lines', 'destinationLocation'])
                ->lockForUpdate()
                ->findOrFail($receipt->id);
            $this->requireStatus($receipt->status, ['DRAFT'], 'purchasing.receipt_not_draft');
            $this->requireStatus($receipt->purchaseOrder->status, ['APPROVED', 'PARTIALLY_RECEIVED'], 'purchasing.order_not_receivable');
            if ($receipt->lines->isEmpty()) {
                throw ValidationException::withMessages(['receipt' => __('purchasing.line_required')]);
            }
            if ($receipt->supplier_id !== $receipt->purchaseOrder->supplier_id
                || $receipt->warehouse_id !== $receipt->purchaseOrder->warehouse_id) {
                throw ValidationException::withMessages(['receipt' => __('purchasing.receipt_order_mismatch')]);
            }
            if ($receipt->destinationLocation->warehouse_id !== $receipt->warehouse_id) {
                throw ValidationException::withMessages(['destination_location_id' => __('purchasing.location_warehouse_mismatch')]);
            }

            $movement = StockMovement::create([
                'movement_number' => $this->number('REC-ACH'),
                'movement_type' => 'RECEIPT',
                'movement_at' => $receipt->received_at,
                'source_type' => GoodsReceipt::class,
                'source_id' => $receipt->id,
                'status' => 'DRAFT',
                'notes' => __('purchasing.stock_movement_receipt', ['number' => $receipt->receipt_number]),
                'created_by' => $userId,
            ]);

            foreach ($receipt->lines as $receiptLine) {
                $orderLine = PurchaseOrderLine::query()
                    ->with('item')
                    ->lockForUpdate()
                    ->findOrFail($receiptLine->purchase_order_line_id);
                if ($orderLine->purchase_order_id !== $receipt->purchase_order_id || $receiptLine->item_id !== $orderLine->item_id) {
                    throw ValidationException::withMessages(['receipt' => __('purchasing.receipt_line_mismatch')]);
                }
                $accepted = (float) $receiptLine->accepted_quantity;
                $rejected = (float) $receiptLine->rejected_quantity;
                if ($accepted <= 0 && $rejected <= 0) {
                    throw ValidationException::withMessages(['quantity' => __('purchasing.received_quantity_required')]);
                }
                $remaining = (float) $orderLine->ordered_quantity - (float) $orderLine->received_quantity;
                if (($accepted + $rejected) > $remaining + 0.0005) {
                    throw ValidationException::withMessages(['quantity' => __('purchasing.delivery_quantity_exceeds_remaining')]);
                }
                if ($rejected > 0 && blank($receiptLine->rejection_reason)) {
                    throw ValidationException::withMessages(['rejection_reason' => __('purchasing.rejection_reason_required')]);
                }

                $factor = (float) $receiptLine->factor_to_base;
                if ($factor <= 0) {
                    throw ValidationException::withMessages(['factor_to_base' => __('purchasing.invalid_conversion_factor')]);
                }
                $baseQuantity = round($accepted * $factor, 3);
                $baseUnitCost = round(((float) $orderLine->net_unit_price * (float) $receipt->purchaseOrder->exchange_rate) / $factor, 6);
                $lot = $accepted > 0 ? $this->resolveReceiptLot($receiptLine) : null;

                $movementLine = null;
                if ($accepted > 0) {
                    $movementLine = $movement->lines()->create([
                        'reference' => $receipt->receipt_number,
                        'item_id' => $receiptLine->item_id,
                        'lot_id' => $lot?->id,
                        'destination_location_id' => $receipt->destination_location_id,
                        'quantity' => $baseQuantity,
                        'unit_id' => $orderLine->item->base_unit_id,
                        'unit_cost' => $baseUnitCost,
                        'notes' => $receipt->supplier_delivery_note,
                    ]);
                }

                $receiptLine->update([
                    'lot_id' => $lot?->id,
                    'base_quantity' => $baseQuantity,
                    'unit_cost' => $orderLine->net_unit_price,
                    'base_unit_cost' => $baseUnitCost,
                    'stock_movement_line_id' => $movementLine?->id,
                ]);
                $newReceived = (float) $orderLine->received_quantity + $accepted;
                $orderLine->update([
                    'received_quantity' => $newReceived,
                    'status' => $newReceived + 0.0005 >= (float) $orderLine->ordered_quantity ? 'RECEIVED' : 'PARTIALLY_RECEIVED',
                ]);
            }

            if ($movement->lines()->exists()) {
                $this->stockPosting->post($movement, $userId);
            } else {
                $movement->delete();
                $movement = null;
            }

            $allReceived = $receipt->purchaseOrder->lines()->whereColumn('received_quantity', '<', 'ordered_quantity')->doesntExist();
            $hasReceived = (float) $receipt->purchaseOrder->lines()->sum('received_quantity') > 0;
            $receipt->purchaseOrder->update([
                'status' => $allReceived ? 'RECEIVED' : ($hasReceived ? 'PARTIALLY_RECEIVED' : 'APPROVED'),
            ]);
            $receipt->update([
                'status' => 'POSTED',
                'posted_by' => $userId,
                'posted_at' => now(),
                'stock_movement_id' => $movement?->id,
            ]);
            $this->audit('purchasing.receipt.posted', $receipt, $userId, ['status' => 'DRAFT'], ['status' => 'POSTED']);
            DB::afterCommit(fn () => event(new DashboardUpdated(['goods_receipt_id' => $receipt->id])));

            return $receipt->fresh(['lines.lot', 'stockMovement']);
        }, 3);
    }

    public function postReturn(SupplierReturn $supplierReturn, string $userId): SupplierReturn
    {
        return DB::transaction(function () use ($supplierReturn, $userId): SupplierReturn {
            $supplierReturn = SupplierReturn::query()
                ->with(['goodsReceipt', 'lines.item', 'lines.goodsReceiptLine.purchaseOrderLine.item', 'sourceLocation'])
                ->lockForUpdate()
                ->findOrFail($supplierReturn->id);
            $this->requireStatus($supplierReturn->status, ['DRAFT'], 'purchasing.return_not_draft');
            if ($supplierReturn->lines->isEmpty()) {
                throw ValidationException::withMessages(['return' => __('purchasing.line_required')]);
            }
            if ($supplierReturn->goodsReceipt
                && ($supplierReturn->goodsReceipt->supplier_id !== $supplierReturn->supplier_id
                    || $supplierReturn->goodsReceipt->warehouse_id !== $supplierReturn->warehouse_id)) {
                throw ValidationException::withMessages(['return' => __('purchasing.return_receipt_mismatch')]);
            }
            if ($supplierReturn->sourceLocation->warehouse_id !== $supplierReturn->warehouse_id) {
                throw ValidationException::withMessages(['source_location_id' => __('purchasing.location_warehouse_mismatch')]);
            }

            $movement = StockMovement::create([
                'movement_number' => $this->number('RET-FOU'),
                'movement_type' => 'ISSUE',
                'movement_at' => $supplierReturn->return_date->endOfDay(),
                'source_type' => SupplierReturn::class,
                'source_id' => $supplierReturn->id,
                'status' => 'DRAFT',
                'notes' => __('purchasing.stock_movement_return', ['number' => $supplierReturn->return_number]),
                'created_by' => $userId,
            ]);

            foreach ($supplierReturn->lines as $returnLine) {
                $factor = (float) $returnLine->factor_to_base;
                if ($factor <= 0 || (float) $returnLine->quantity <= 0) {
                    throw ValidationException::withMessages(['quantity' => __('purchasing.invalid_return_quantity')]);
                }
                if ($returnLine->goodsReceiptLine) {
                    if ($returnLine->goodsReceiptLine->goods_receipt_id !== $supplierReturn->goods_receipt_id
                        || $returnLine->goodsReceiptLine->item_id !== $returnLine->item_id
                        || $returnLine->goodsReceiptLine->lot_id !== $returnLine->lot_id) {
                        throw ValidationException::withMessages(['return' => __('purchasing.return_line_mismatch')]);
                    }
                    $alreadyReturned = DB::table('supplier_return_lines')
                        ->join('supplier_returns', 'supplier_returns.id', '=', 'supplier_return_lines.supplier_return_id')
                        ->where('supplier_return_lines.goods_receipt_line_id', $returnLine->goods_receipt_line_id)
                        ->where('supplier_returns.status', 'POSTED')
                        ->sum('supplier_return_lines.quantity');
                    $availableToReturn = (float) $returnLine->goodsReceiptLine->accepted_quantity - (float) $alreadyReturned;
                    if ((float) $returnLine->quantity > $availableToReturn + 0.0005) {
                        throw ValidationException::withMessages(['quantity' => __('purchasing.return_exceeds_receipt')]);
                    }
                }
                $baseQuantity = round((float) $returnLine->quantity * $factor, 3);
                $returnLine->update(['base_quantity' => $baseQuantity]);
                $movement->lines()->create([
                    'reference' => $supplierReturn->return_number,
                    'item_id' => $returnLine->item_id,
                    'lot_id' => $returnLine->lot_id,
                    'source_location_id' => $supplierReturn->source_location_id,
                    'quantity' => $baseQuantity,
                    'unit_id' => $returnLine->item->base_unit_id,
                    'unit_cost' => $returnLine->unit_cost,
                    'notes' => $returnLine->reason,
                ]);
                $orderLine = $returnLine->goodsReceiptLine?->purchaseOrderLine;
                if ($orderLine) {
                    $orderLine->increment('returned_quantity', (float) $returnLine->quantity);
                }
            }

            $this->stockPosting->post($movement, $userId);
            $supplierReturn->update([
                'status' => 'POSTED',
                'approved_by' => $userId,
                'approved_at' => now(),
                'stock_movement_id' => $movement->id,
            ]);
            $this->audit('purchasing.return.posted', $supplierReturn, $userId, ['status' => 'DRAFT'], ['status' => 'POSTED']);
            DB::afterCommit(fn () => event(new DashboardUpdated(['supplier_return_id' => $supplierReturn->id])));

            return $supplierReturn->fresh(['lines', 'stockMovement']);
        }, 3);
    }

    public function recalculateQuotation(SupplierQuotation $quotation): void
    {
        $lines = $quotation->lines()->get();
        $quotation->update([
            'subtotal' => $lines->sum('line_subtotal'),
            'discount_amount' => $lines->sum(fn ($line) => (float) $line->quantity
                * (float) $line->unit_price
                * ((float) $line->discount_percentage / 100)),
            'tax_amount' => $lines->sum('tax_amount'),
            'total_amount' => $lines->sum('line_total'),
        ]);
    }

    public function recalculateOrder(PurchaseOrder $order): void
    {
        $lines = $order->lines()->get();
        $order->update([
            'subtotal' => $lines->sum('line_subtotal'),
            'discount_amount' => $lines->sum(fn ($line) => (float) $line->ordered_quantity
                * (float) $line->unit_price
                * ((float) $line->discount_percentage / 100)),
            'tax_amount' => $lines->sum('tax_amount'),
            'total_amount' => $lines->sum('line_total'),
        ]);
    }

    private function resolveReceiptLot(GoodsReceiptLine $line): ?Lot
    {
        $line->loadMissing('item');
        if (! $line->item->lot_managed) {
            return null;
        }
        if (blank($line->lot_number)) {
            throw ValidationException::withMessages(['lot_number' => __('purchasing.lot_number_required')]);
        }
        if ($line->item->expiry_managed && ! $line->expiry_date) {
            throw ValidationException::withMessages(['expiry_date' => __('purchasing.expiry_date_required')]);
        }
        if ($line->manufacturing_date && $line->expiry_date && $line->expiry_date->lt($line->manufacturing_date)) {
            throw ValidationException::withMessages(['expiry_date' => __('purchasing.expiry_before_manufacturing')]);
        }

        $lot = Lot::firstOrCreate(
            ['item_id' => $line->item_id, 'lot_number' => $line->lot_number],
            [
                'manufacturing_date' => $line->manufacturing_date,
                'expiry_date' => $line->expiry_date,
                'status' => $this->modules->enabled('quality') ? 'QUARANTINE' : 'RELEASED',
                'attributes' => ['origin' => 'PURCHASE_RECEIPT', 'quality_module_enabled' => $this->modules->enabled('quality')],
            ],
        );
        if (! $lot->wasRecentlyCreated
            && (($line->expiry_date && ! $lot->expiry_date?->equalTo($line->expiry_date))
                || ($line->manufacturing_date && ! $lot->manufacturing_date?->equalTo($line->manufacturing_date)))) {
            throw ValidationException::withMessages(['lot_number' => __('purchasing.lot_dates_mismatch')]);
        }

        return $lot;
    }

    private function requireStatus(string $actual, array $allowed, string $message): void
    {
        if (! in_array($actual, $allowed, true)) {
            throw ValidationException::withMessages(['status' => __($message)]);
        }
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4));
    }

    private function audit(string $event, object $model, string $userId, ?array $oldValues, ?array $newValues): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => $userId,
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->id,
            'old_values' => $oldValues ? json_encode($oldValues, JSON_THROW_ON_ERROR) : null,
            'new_values' => $newValues ? json_encode($newValues, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()?->ip(),
            'user_agent' => request()?->userAgent(),
            'created_at' => now(),
        ]);
    }

    private function notifyAfterCommit(array $permissions, string $title, string $message, string $url): void
    {
        DB::afterCommit(function () use ($permissions, $title, $message, $url): void {
            $users = User::query()
                ->where('active', true)
                ->whereHas('roles.permissions', fn ($query) => $query->whereIn('code', $permissions))
                ->get()
                ->unique('id');
            Notification::send($users, new SystemAlertNotification($title, $message, 'info', $url));
        });
    }
}
