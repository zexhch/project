<?php

namespace App\Services\System;

use App\Services\Modules\ModuleRegistry;
use App\Services\Modules\ModuleRouteLoader;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

class SystemHealthService
{
    public function __construct(
        private readonly ModuleRegistry $modules,
        private readonly ModuleRouteLoader $moduleRoutes,
    ) {
    }

    /** @return array<string, mixed> */
    public function liveness(): array
    {
        return [
            'status' => 'ok',
            'version' => $this->version(),
            'timestamp' => now()->toIso8601String(),
        ];
    }

    /** @return array<string, mixed> */
    public function readiness(bool $includeDetails = false): array
    {
        $checks = [
            'configuration' => $this->checkConfiguration(),
            'database' => $this->checkDatabase(),
            'migrations' => $this->checkMigrations(),
            'cache' => $this->checkCache(),
            'storage' => $this->checkStorage(),
            'modules' => $this->checkModules(),
        ];

        if ($this->redisIsRequired()) {
            $checks['redis'] = $this->checkRedis();
        }

        $failed = collect($checks)->where('status', 'failed')->count();
        $warnings = collect($checks)->where('status', 'warning')->count();
        $ready = $failed === 0;

        if (! $includeDetails) {
            $checks = collect($checks)->map(fn (array $check): array => [
                'status' => $check['status'],
                'code' => $check['code'],
            ])->all();
        }

        return [
            'status' => $ready ? 'ready' : 'not_ready',
            'ready' => $ready,
            'version' => $this->version(),
            'environment' => app()->environment(),
            'failed_checks' => $failed,
            'warnings' => $warnings,
            'checks' => $checks,
            'timestamp' => now()->toIso8601String(),
        ];
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkConfiguration(): array
    {
        $issues = [];

        if (! is_string(config('app.key')) || config('app.key') === '') {
            $issues[] = 'APP_KEY is missing.';
        }

        if (app()->environment('production') && (bool) config('app.debug')) {
            $issues[] = 'APP_DEBUG must be disabled in production.';
        }

        if (! is_string(config('app.url')) || config('app.url') === '') {
            $issues[] = 'APP_URL is missing.';
        }

        if ($issues !== []) {
            return $this->failed('configuration_invalid', implode(' ', $issues));
        }

        $warnings = [];
        if (! app()->environment('production') && (bool) config('app.debug')) {
            $warnings[] = 'Debug mode is enabled.';
        }

        return $warnings === []
            ? $this->ok('configuration_valid', 'Application configuration is valid.')
            : $this->warning('configuration_warning', implode(' ', $warnings));
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkDatabase(): array
    {
        try {
            DB::select('select 1');

            return $this->ok('database_available', 'Database connection is available.');
        } catch (Throwable $exception) {
            return $this->failed('database_unavailable', $exception->getMessage());
        }
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkMigrations(): array
    {
        try {
            $migrator = app('migrator');
            $paths = array_values(array_unique([
                database_path('migrations'),
                ...$this->moduleRoutes->migrationPaths(),
            ]));
            $files = $migrator->getMigrationFiles($paths);
            $ran = $migrator->getRepository()->getRan();
            $pending = array_values(array_diff(array_keys($files), $ran));

            if ($pending !== []) {
                return $this->failed(
                    'migrations_pending',
                    count($pending).' migration(s) are pending.',
                    ['pending' => $pending],
                );
            }

            return $this->ok('migrations_current', 'All migrations are applied.');
        } catch (Throwable $exception) {
            return $this->failed('migrations_unavailable', $exception->getMessage());
        }
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkCache(): array
    {
        $key = 'health:'.bin2hex(random_bytes(8));
        $value = bin2hex(random_bytes(8));

        try {
            Cache::put($key, $value, 10);
            $read = Cache::get($key);
            Cache::forget($key);

            if (! hash_equals($value, (string) $read)) {
                return $this->failed('cache_roundtrip_failed', 'Cache write/read verification failed.');
            }

            return $this->ok('cache_available', 'Cache write/read verification succeeded.');
        } catch (Throwable $exception) {
            return $this->failed('cache_unavailable', $exception->getMessage());
        }
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkStorage(): array
    {
        $disk = (string) config('filesystems.default', 'local');
        $path = 'health/.probe-'.bin2hex(random_bytes(8));
        $value = bin2hex(random_bytes(16));

        try {
            Storage::disk($disk)->put($path, $value);
            $read = Storage::disk($disk)->get($path);
            Storage::disk($disk)->delete($path);

            if (! hash_equals($value, $read)) {
                return $this->failed('storage_roundtrip_failed', "Storage disk [{$disk}] returned invalid content.");
            }

            return $this->ok('storage_available', "Storage disk [{$disk}] is writable.");
        } catch (Throwable $exception) {
            try {
                Storage::disk($disk)->delete($path);
            } catch (Throwable) {
                // Best-effort cleanup only.
            }

            return $this->failed('storage_unavailable', $exception->getMessage(), ['disk' => $disk]);
        }
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkModules(): array
    {
        try {
            $diagnostics = $this->modules->diagnostics();

            if ($diagnostics['issue_count'] > 0) {
                return $this->failed(
                    'modules_inconsistent',
                    $diagnostics['issue_count'].' module issue(s) detected.',
                    ['issues' => $diagnostics['issues']],
                );
            }

            return $this->ok(
                'modules_consistent',
                $diagnostics['enabled_count'].'/'.$diagnostics['module_count'].' modules enabled.',
            );
        } catch (Throwable $exception) {
            return $this->failed('modules_unavailable', $exception->getMessage());
        }
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function checkRedis(): array
    {
        try {
            $response = app('redis')->connection()->ping();
            $valid = $response === true || strtoupper((string) $response) === 'PONG';

            return $valid
                ? $this->ok('redis_available', 'Redis connection is available.')
                : $this->failed('redis_invalid_response', 'Redis returned an invalid PING response.');
        } catch (Throwable $exception) {
            return $this->failed('redis_unavailable', $exception->getMessage());
        }
    }

    private function redisIsRequired(): bool
    {
        return config('cache.default') === 'redis'
            || config('queue.default') === 'redis'
            || (bool) config('reverb.servers.reverb.scaling.enabled', false);
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function ok(string $code, string $message, mixed $details = null): array
    {
        return array_filter([
            'status' => 'ok',
            'code' => $code,
            'message' => $message,
            'details' => $details,
        ], fn (mixed $value): bool => $value !== null);
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function warning(string $code, string $message, mixed $details = null): array
    {
        return array_filter([
            'status' => 'warning',
            'code' => $code,
            'message' => $message,
            'details' => $details,
        ], fn (mixed $value): bool => $value !== null);
    }

    /** @return array{status:string,code:string,message:string,details?:mixed} */
    private function failed(string $code, string $message, mixed $details = null): array
    {
        return array_filter([
            'status' => 'failed',
            'code' => $code,
            'message' => $message,
            'details' => $details,
        ], fn (mixed $value): bool => $value !== null);
    }

    private function version(): string
    {
        $path = base_path('VERSION');

        return is_file($path) ? trim((string) file_get_contents($path)) : 'unknown';
    }
}
