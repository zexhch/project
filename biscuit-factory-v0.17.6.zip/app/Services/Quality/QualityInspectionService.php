<?php

namespace App\Services\Quality;

use App\Events\DashboardUpdated;
use App\Models\Lot;
use App\Models\QualityControlPlanParameter;
use App\Models\QualityDecision;
use App\Models\QualityInspection;
use App\Models\QualityInspectionResult;
use App\Models\QualityNonConformity;
use App\Models\User;
use App\Notifications\SystemAlertNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class QualityInspectionService
{
    public function recordResult(
        QualityInspection $inspection,
        QualityControlPlanParameter $parameter,
        array $values,
        string $userId,
    ): QualityInspectionResult {
        if (! in_array($inspection->status, ['DRAFT', 'IN_PROGRESS'], true)) {
            throw ValidationException::withMessages(['inspection' => __('quality.inspection_not_editable')]);
        }

        if ($parameter->quality_control_plan_id !== $inspection->quality_control_plan_id) {
            throw ValidationException::withMessages(['parameter' => __('quality.parameter_plan_mismatch')]);
        }

        [$status, $deviation] = $this->evaluate($parameter, $values);

        $result = QualityInspectionResult::updateOrCreate(
            [
                'quality_inspection_id' => $inspection->id,
                'quality_control_plan_parameter_id' => $parameter->id,
            ],
            [
                'value_numeric' => $values['value_numeric'] ?? null,
                'value_text' => $values['value_text'] ?? null,
                'value_boolean' => $values['value_boolean'] ?? null,
                'result_status' => $status,
                'deviation' => $deviation,
                'notes' => $values['notes'] ?? null,
                'measured_by' => $userId,
                'measured_at' => now(),
            ]
        );

        if ($inspection->status === 'DRAFT') {
            $inspection->update([
                'status' => 'IN_PROGRESS',
                'inspector_id' => $inspection->inspector_id ?: $userId,
                'inspected_at' => $inspection->inspected_at ?: now(),
            ]);
        }

        return $result;
    }

    public function submit(QualityInspection $inspection, string $userId): QualityInspection
    {
        if (! in_array($inspection->status, ['DRAFT', 'IN_PROGRESS'], true)) {
            throw ValidationException::withMessages(['inspection' => __('quality.inspection_not_editable')]);
        }

        $inspection->loadMissing('plan');
        $requiredIds = $inspection->plan->parameters()->where('required', true)->pluck('id');
        $measuredIds = $inspection->results()->whereIn('result_status', ['PASS', 'FAIL'])->pluck('quality_control_plan_parameter_id');
        $missing = $requiredIds->diff($measuredIds);

        if ($missing->isNotEmpty()) {
            throw ValidationException::withMessages(['results' => __('quality.required_results_missing')]);
        }

        $inspection->update([
            'status' => 'PENDING_DECISION',
            'inspector_id' => $inspection->inspector_id ?: $userId,
            'inspected_at' => $inspection->inspected_at ?: now(),
        ]);

        event(new DashboardUpdated(['quality_inspection_id' => $inspection->id]));

        return $inspection;
    }

    public function decide(QualityInspection $inspection, string $decision, string $reason, string $userId): QualityInspection
    {
        if ($inspection->status !== 'PENDING_DECISION') {
            throw ValidationException::withMessages(['inspection' => __('quality.inspection_not_pending')]);
        }

        $criticalFailure = $inspection->results()
            ->where('result_status', 'FAIL')
            ->whereHas('parameter', fn ($query) => $query->where('critical', true))
            ->exists();

        if ($decision === 'RELEASE' && $criticalFailure) {
            throw ValidationException::withMessages(['decision' => __('quality.critical_failure_release_forbidden')]);
        }

        $inspection = DB::transaction(function () use ($inspection, $decision, $reason, $userId, $criticalFailure): QualityInspection {
            $locked = QualityInspection::query()->lockForUpdate()->findOrFail($inspection->id);
            if ($locked->status !== 'PENDING_DECISION') {
                throw ValidationException::withMessages(['inspection' => __('quality.inspection_not_pending')]);
            }
            $lot = $locked->lot_id ? Lot::query()->lockForUpdate()->find($locked->lot_id) : null;
            $lotStatus = match ($decision) {
                'RELEASE' => 'RELEASED',
                'BLOCK' => 'BLOCKED',
                'REJECT' => 'REJECTED',
                default => null,
            };
            $inspectionStatus = $decision === 'RELEASE' ? 'CONFORMING' : 'NONCONFORMING';

            $locked->update([
                'status' => $inspectionStatus,
                'decision' => $decision,
                'decision_reason' => $reason,
                'decided_by' => $userId,
                'decided_at' => now(),
            ]);

            QualityDecision::create([
                'quality_inspection_id' => $locked->id,
                'lot_id' => $lot?->id,
                'decision' => $decision,
                'previous_lot_status' => $lot?->status,
                'new_lot_status' => $lotStatus,
                'reason' => $reason,
                'decided_by' => $userId,
                'decided_at' => now(),
            ]);

            if ($lot && $lotStatus) {
                $oldStatus = $lot->status;
                $lot->update(['status' => $lotStatus]);
                $this->audit('quality.lot.decision', Lot::class, $lot->id, ['status' => $oldStatus], ['status' => $lotStatus], $userId);
            }

            if (in_array($decision, ['BLOCK', 'REJECT'], true) && ! $locked->nonConformities()->exists()) {
                QualityNonConformity::create([
                    'non_conformity_number' => $this->number('NC'),
                    'quality_inspection_id' => $locked->id,
                    'lot_id' => $locked->lot_id,
                    'item_id' => $locked->item_id,
                    'production_order_id' => $locked->production_order_id,
                    'severity' => $criticalFailure ? 'CRITICAL' : 'MAJOR',
                    'title' => __('quality.automatic_non_conformity_title', ['number' => $locked->inspection_number]),
                    'description' => $reason,
                    'immediate_action' => $decision === 'BLOCK' ? __('quality.lot_blocked') : __('quality.lot_rejected'),
                    'status' => 'OPEN',
                    'detected_by' => $userId,
                    'detected_at' => now(),
                    'owner_id' => $userId,
                    'due_date' => today()->addDays(7),
                ]);
            }

            $this->audit(
                'quality.inspection.decided',
                QualityInspection::class,
                $locked->id,
                ['status' => 'PENDING_DECISION'],
                ['status' => $inspectionStatus, 'decision' => $decision],
                $userId,
            );

            return $locked->fresh();
        });

        event(new DashboardUpdated(['quality_inspection_id' => $inspection->id, 'decision' => $decision]));
        $this->notifyQualityManagers($inspection, $decision);

        return $inspection;
    }

    private function evaluate(QualityControlPlanParameter $parameter, array $values): array
    {
        if ($parameter->data_type === 'NUMERIC') {
            if (! array_key_exists('value_numeric', $values) || $values['value_numeric'] === null) {
                throw ValidationException::withMessages(['value_numeric' => __('quality.numeric_value_required')]);
            }

            $value = (float) $values['value_numeric'];
            $passed = ($parameter->minimum_value === null || $value >= (float) $parameter->minimum_value)
                && ($parameter->maximum_value === null || $value <= (float) $parameter->maximum_value);
            $deviation = $parameter->target_value === null ? null : $value - (float) $parameter->target_value;

            return [$passed ? 'PASS' : 'FAIL', $deviation];
        }

        if ($parameter->data_type === 'BOOLEAN') {
            if (! array_key_exists('value_boolean', $values) || $values['value_boolean'] === null) {
                throw ValidationException::withMessages(['value_boolean' => __('quality.boolean_value_required')]);
            }

            $actual = filter_var($values['value_boolean'], FILTER_VALIDATE_BOOL);
            $expected = filter_var($parameter->expected_value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);

            return [($expected === null || $actual === $expected) ? 'PASS' : 'FAIL', null];
        }

        $value = trim((string) ($values['value_text'] ?? ''));
        if ($value === '') {
            throw ValidationException::withMessages(['value_text' => __('quality.text_value_required')]);
        }
        if ($parameter->data_type === 'SELECT' && ! in_array($value, $parameter->options ?? [], true)) {
            throw ValidationException::withMessages(['value_text' => __('quality.invalid_selection')]);
        }

        $passed = $parameter->expected_value === null
            || mb_strtolower($value) === mb_strtolower(trim($parameter->expected_value));

        return [$passed ? 'PASS' : 'FAIL', null];
    }

    private function notifyQualityManagers(QualityInspection $inspection, string $decision): void
    {
        User::query()->where('active', true)
            ->whereHas('roles.permissions', fn ($query) => $query->where('code', 'quality.approve'))
            ->each(fn (User $user) => $user->notify(new SystemAlertNotification(
                __('quality.decision_notification_title'),
                __('quality.decision_notification_message', ['number' => $inspection->inspection_number, 'decision' => $decision]),
                $decision === 'RELEASE' ? 'success' : 'warning',
                route('quality.inspections.show', $inspection),
            )));
    }

    private function audit(string $event, string $type, string $id, ?array $old, ?array $new, string $userId): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => $userId,
            'event' => $event,
            'auditable_type' => $type,
            'auditable_id' => $id,
            'old_values' => $old ? json_encode($old, JSON_THROW_ON_ERROR) : null,
            'new_values' => $new ? json_encode($new, JSON_THROW_ON_ERROR) : null,
            'ip_address' => request()?->ip(),
            'user_agent' => request()?->userAgent(),
            'created_at' => now(),
        ]);
    }

    private function number(string $prefix): string
    {
        return $prefix.'-'.now()->format('YmdHis').'-'.strtoupper(Str::random(4));
    }
}
