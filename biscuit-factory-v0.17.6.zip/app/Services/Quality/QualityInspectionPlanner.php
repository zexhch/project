<?php

namespace App\Services\Quality;

use App\Models\Lot;
use App\Models\QualityControlPlan;
use App\Models\QualityInspection;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class QualityInspectionPlanner
{
    public function createForLot(
        Lot $lot,
        string $stage,
        ?string $productionOrderId = null,
        ?string $stockMovementId = null,
        ?string $productionLineId = null,
        ?string $inspectorId = null,
    ): Collection {
        $lot->loadMissing('item');
        $plans = QualityControlPlan::approvedAndActive()
            ->where('control_stage', $stage)
            ->where(function (Builder $query) use ($lot): void {
                $query->where('item_id', $lot->item_id);
                if ($lot->item->category_id) {
                    $query->orWhere('item_category_id', $lot->item->category_id);
                }
                $query->orWhere(fn (Builder $generic) => $generic->whereNull('item_id')->whereNull('item_category_id'));
            })
            ->where(function (Builder $query) use ($productionLineId): void {
                $query->whereNull('production_line_id');
                if ($productionLineId) {
                    $query->orWhere('production_line_id', $productionLineId);
                }
            })
            ->get();

        return $plans->map(function (QualityControlPlan $plan) use (
            $lot,
            $stage,
            $productionOrderId,
            $stockMovementId,
            $productionLineId,
            $inspectorId,
        ): QualityInspection {
            $inspection = QualityInspection::firstOrCreate(
                array_filter([
                    'quality_control_plan_id' => $plan->id,
                    'lot_id' => $lot->id,
                    'production_order_id' => $productionOrderId,
                    'stock_movement_id' => $stockMovementId,
                ], fn ($value) => $value !== null),
                [
                    'inspection_number' => 'CQ-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4)),
                    'control_stage' => $stage,
                    'item_id' => $lot->item_id,
                    'production_line_id' => $productionLineId,
                    'sample_size' => $plan->sample_size,
                    'status' => 'DRAFT',
                    'inspector_id' => $inspectorId,
                    'overall_notes' => __('quality.automatically_planned'),
                ],
            );
            if ($inspection->wasRecentlyCreated) {
                DB::table('audit_logs')->insert([
                    'id' => (string) Str::uuid(),
                    'user_id' => $inspectorId,
                    'event' => 'quality.inspection.automatically_planned',
                    'auditable_type' => QualityInspection::class,
                    'auditable_id' => $inspection->id,
                    'old_values' => null,
                    'new_values' => json_encode(['status' => 'DRAFT', 'control_stage' => $stage], JSON_THROW_ON_ERROR),
                    'ip_address' => request()?->ip(),
                    'user_agent' => request()?->userAgent(),
                    'created_at' => now(),
                ]);
            }

            return $inspection;
        });
    }
}
