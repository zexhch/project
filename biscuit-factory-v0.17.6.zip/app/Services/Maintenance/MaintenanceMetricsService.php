<?php
namespace App\Services\Maintenance;
use App\Models\ProductionDowntime;
class MaintenanceMetricsService {
 public function calculate(int $days=30):array{$start=now()->subDays($days);$q=ProductionDowntime::where('started_at','>=',$start)->where('planned',false);$count=(clone $q)->count();$down=(int)(clone $q)->sum('duration_seconds');$period=$days*86400;$mttr=$count?$down/$count:0;$mtbf=$count?max(0,$period-$down)/$count:$period;return ['failures'=>$count,'downtime_seconds'=>$down,'mttr_hours'=>round($mttr/3600,2),'mtbf_hours'=>round($mtbf/3600,2),'availability_percent'=>round(max(0,($period-$down)/$period*100),2)];}
}
