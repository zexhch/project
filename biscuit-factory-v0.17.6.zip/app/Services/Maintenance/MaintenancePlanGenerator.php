<?php
namespace App\Services\Maintenance;
use App\Models\MaintenancePlan; use App\Models\MaintenanceWorkOrder; use Illuminate\Support\Facades\DB;
class MaintenancePlanGenerator {
 public function generate():int{return DB::transaction(function(){ $count=0; foreach(MaintenancePlan::where('active',true)->where('next_due_at','<=',now())->lockForUpdate()->get() as $p){$open=$p->workOrders()->whereNotIn('status',['COMPLETED','CANCELLED'])->exists();if(!$open){MaintenanceWorkOrder::create(['work_order_number'=>'OT-'.now()->format('YmdHis').'-'.strtoupper(substr($p->id,0,4)),'maintenance_plan_id'=>$p->id,'production_line_id'=>$p->production_line_id,'machine_id'=>$p->machine_id,'maintenance_type'=>$p->maintenance_type,'priority'=>'NORMAL','description'=>$p->name,'planned_start'=>$p->next_due_at,'planned_end'=>$p->estimated_duration_minutes?$p->next_due_at->copy()->addMinutes($p->estimated_duration_minutes):null,'status'=>'PLANNED']);$count++;}$p->update(['next_due_at'=>$this->next($p)]);} return $count;});}
 private function next(MaintenancePlan $p){return match($p->frequency_type){'DAYS'=>$p->next_due_at->copy()->addDays($p->frequency_value),'WEEKS'=>$p->next_due_at->copy()->addWeeks($p->frequency_value),'MONTHS'=>$p->next_due_at->copy()->addMonthsNoOverflow($p->frequency_value),default=>$p->next_due_at->copy()->addHours($p->frequency_value)};}
}
