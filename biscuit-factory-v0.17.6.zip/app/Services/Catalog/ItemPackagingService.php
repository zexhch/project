<?php

namespace App\Services\Catalog;

use App\Models\Item;
use App\Models\ItemUnitConversion;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ItemPackagingService
{

    public function ensureBaseConversion(Item $item, ?User $actor = null): ItemUnitConversion
    {
        return DB::transaction(function () use ($item, $actor): ItemUnitConversion {
            $conversion = ItemUnitConversion::query()->firstOrNew([
                'item_id' => $item->id,
                'unit_id' => $item->base_unit_id,
            ]);
            $otherProductionUnitExists = ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('unit_id', '!=', $item->base_unit_id)
                ->where('active', true)
                ->where('production_unit', true)
                ->exists();
            $otherInventoryUnitExists = ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('unit_id', '!=', $item->base_unit_id)
                ->where('active', true)
                ->where('inventory_unit', true)
                ->exists();
            $conversion->fill([
                'parent_unit_id' => null,
                'factor_to_parent' => 1,
                'factor_to_base' => 1,
                'barcode' => $item->barcode,
                'production_unit' => ! $otherProductionUnitExists,
                'inventory_unit' => ! $otherInventoryUnitExists,
                'fractional_allowed' => $conversion->exists ? (bool) $conversion->fractional_allowed : false,
                'rounding_mode' => $conversion->exists ? $conversion->rounding_mode : 'NONE',
                'active' => true,
            ]);
            $conversion->save();
            return $conversion;
        });
    }

    /** @return ItemUnitConversion */
    public function save(Item $item, array $data, ?ItemUnitConversion $conversion, User $actor): ItemUnitConversion
    {
        return DB::transaction(function () use ($item, $data, $conversion, $actor): ItemUnitConversion {
            $item = Item::query()->lockForUpdate()->findOrFail($item->id);
            $conversion = $conversion
                ? ItemUnitConversion::query()->lockForUpdate()->where('item_id', $item->id)->findOrFail($conversion->id)
                : new ItemUnitConversion(['item_id' => $item->id]);

            $unitId = (string) $data['unit_id'];
            if ($conversion->exists && $conversion->unit_id !== $unitId) {
                throw new DomainException(__('packaging.unit_change_blocked'));
            }
            $parentUnitId = $data['parent_unit_id'] ?: null;
            $isBase = $unitId === $item->base_unit_id;

            if ($isBase) {
                $parentUnitId = null;
                $factorToParent = 1.0;
                $factorToBase = 1.0;
            } else {
                if (! $parentUnitId || $parentUnitId === $unitId) {
                    throw new DomainException(__('packaging.invalid_parent_unit'));
                }
                $factorToParent = (float) $data['factor_to_parent'];
                if ($factorToParent <= 0) {
                    throw new DomainException(__('packaging.invalid_factor'));
                }
                $factorToBase = $this->parentFactorToBase($item, $parentUnitId, $conversion->exists ? $conversion->id : null)
                    * $factorToParent;
            }

            $this->assertNoCycle($item, $unitId, $parentUnitId, $conversion->exists ? $conversion->id : null);
            $this->assertBarcodeAvailable($item, $unitId, $data['barcode'] ?? null, $conversion->exists ? $conversion->id : null);

            $before = $conversion->exists ? $conversion->getAttributes() : [];
            $values = [
                ...$data,
                'parent_unit_id' => $parentUnitId,
                'factor_to_parent' => $factorToParent,
                'factor_to_base' => $factorToBase,
                'volume_m3' => $this->volume($data),
                'active' => (bool) ($data['active'] ?? true),
            ];

            foreach (['purchasing_unit', 'sales_unit', 'production_unit', 'inventory_unit'] as $role) {
                if (! empty($values[$role])) {
                    ItemUnitConversion::query()
                        ->where('item_id', $item->id)
                        ->when($conversion->exists, fn ($query) => $query->where('id', '!=', $conversion->id))
                        ->update([$role => false]);
                }
            }

            if ($isBase) {
                $values['barcode'] = $item->barcode;
                $values['fractional_allowed'] = (bool) ($data['fractional_allowed'] ?? false);
            }

            if (! ($values['active'] ?? true) && ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('parent_unit_id', $unitId)
                ->where('active', true)
                ->exists()) {
                throw new DomainException(__('packaging.active_children_require_parent'));
            }

            $conversion->fill($values);
            $conversion->save();
            $this->ensureRequiredRoles($item);
            $this->recalculateDescendants($item, $conversion, $actor);

            DB::table('item_unit_conversion_histories')->insert([
                'id' => (string) Str::uuid(),
                'item_unit_conversion_id' => $conversion->id,
                'item_id' => $item->id,
                'unit_id' => $conversion->unit_id,
                'changed_by' => $actor->id,
                'event' => $before === [] ? 'CREATED' : 'UPDATED',
                'snapshot' => json_encode($conversion->fresh()->getAttributes(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $this->writeAudit($before === [] ? 'item.packaging.created' : 'item.packaging.updated', $conversion, $before, $conversion->getAttributes(), $actor);

            return $conversion->fresh(['unit', 'parentUnit']);
        });
    }

    public function delete(Item $item, ItemUnitConversion $conversion, User $actor): void
    {
        DB::transaction(function () use ($item, $conversion, $actor): void {
            $item = Item::query()->lockForUpdate()->findOrFail($item->id);
            $conversion = ItemUnitConversion::query()->lockForUpdate()->where('item_id', $item->id)->findOrFail($conversion->id);

            if ($conversion->unit_id === $item->base_unit_id) {
                throw new DomainException(__('packaging.base_unit_cannot_delete'));
            }

            $children = ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('parent_unit_id', $conversion->unit_id)
                ->exists();
            if ($children) {
                throw new DomainException(__('packaging.packaging_has_children'));
            }

            $used = $this->isUsed($item->id, $conversion->unit_id);
            $before = $conversion->getAttributes();
            if ($used) {
                $conversion->update(['active' => false]);
                $event = 'item.packaging.deactivated';
            } else {
                $conversion->delete();
                $event = 'item.packaging.deleted';
            }
            $this->ensureRequiredRoles($item);

            DB::table('item_unit_conversion_histories')->insert([
                'id' => (string) Str::uuid(),
                'item_unit_conversion_id' => $used ? $conversion->id : null,
                'item_id' => $item->id,
                'unit_id' => $conversion->unit_id,
                'changed_by' => $actor->id,
                'event' => $used ? 'DEACTIVATED' : 'DELETED',
                'snapshot' => json_encode($before, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->writeAudit($event, $conversion, $before, $used ? $conversion->fresh()->getAttributes() : [], $actor);
        });
    }

    public function normalizeQuantity(Item $item, string $unitId, float $quantity): float
    {
        if ($quantity < 0) {
            throw new DomainException(__('packaging.invalid_quantity'));
        }

        $conversion = $this->currentConversion($item, $unitId);
        if ($conversion->fractional_allowed) {
            return round($quantity, 6);
        }

        $integer = round($quantity);
        if (abs($quantity - $integer) < 0.0000005) {
            return (float) $integer;
        }

        return match ($conversion->rounding_mode) {
            'UP' => (float) ceil($quantity),
            'DOWN' => (float) floor($quantity),
            'NEAREST' => (float) round($quantity),
            default => throw new DomainException(__('packaging.fractional_quantity_not_allowed')),
        };
    }

    public function convertToBase(Item $item, string $unitId, float $quantity): float
    {
        $conversion = $this->currentConversion($item, $unitId);
        $normalized = $this->normalizeQuantity($item, $unitId, $quantity);

        return $normalized * (float) $conversion->factor_to_base;
    }

    /** @return array<int, array{unit: string, quantity: int|float}> */
    public function decompose(Item $item, float $baseQuantity): array
    {
        $remaining = $baseQuantity;
        $result = [];
        $conversions = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('active', true)
            ->where(fn ($query) => $query->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
            ->where(fn ($query) => $query->whereNull('valid_to')->orWhereDate('valid_to', '>=', today()))
            ->with('unit')
            ->orderByDesc('factor_to_base')
            ->get();

        foreach ($conversions as $conversion) {
            $factor = (float) $conversion->factor_to_base;
            if ($factor <= 0) {
                continue;
            }
            $quantity = $conversion->fractional_allowed
                ? round($remaining / $factor, 3)
                : (int) floor(($remaining + 1e-9) / $factor);
            if ($quantity <= 0) {
                continue;
            }
            $result[] = ['unit' => $conversion->unit?->symbol ?? $conversion->unit?->code ?? '', 'quantity' => $quantity];
            $remaining -= $quantity * $factor;
            if ($conversion->fractional_allowed) {
                break;
            }
        }

        return $result;
    }


    private function currentConversion(Item $item, string $unitId): ItemUnitConversion
    {
        $conversion = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('unit_id', $unitId)
            ->where('active', true)
            ->where(fn ($query) => $query->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
            ->where(fn ($query) => $query->whereNull('valid_to')->orWhereDate('valid_to', '>=', today()))
            ->first();

        if (! $conversion || (float) $conversion->factor_to_base <= 0) {
            throw new DomainException(__('packaging.conversion_missing'));
        }

        return $conversion;
    }

    private function ensureRequiredRoles(Item $item): void
    {
        $base = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('unit_id', $item->base_unit_id)
            ->lockForUpdate()
            ->first();

        if (! $base) {
            return;
        }

        $updates = [];
        if (! ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('active', true)
            ->where('production_unit', true)
            ->exists()) {
            $updates['production_unit'] = true;
        }
        if (! ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('active', true)
            ->where('inventory_unit', true)
            ->exists()) {
            $updates['inventory_unit'] = true;
        }
        if ($updates !== []) {
            $base->update($updates);
        }
    }

    private function recalculateDescendants(Item $item, ItemUnitConversion $parent, User $actor): void
    {
        $children = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('parent_unit_id', $parent->unit_id)
            ->lockForUpdate()
            ->get();

        foreach ($children as $child) {
            $before = $child->getAttributes();
            $child->factor_to_base = (float) $parent->factor_to_base * (float) $child->factor_to_parent;
            $child->save();

            DB::table('item_unit_conversion_histories')->insert([
                'id' => (string) Str::uuid(),
                'item_unit_conversion_id' => $child->id,
                'item_id' => $item->id,
                'unit_id' => $child->unit_id,
                'changed_by' => $actor->id,
                'event' => 'RECALCULATED',
                'snapshot' => json_encode($child->fresh()->getAttributes(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->writeAudit('item.packaging.recalculated', $child, $before, $child->getAttributes(), $actor);
            $this->recalculateDescendants($item, $child, $actor);
        }
    }

    private function parentFactorToBase(Item $item, string $parentUnitId, ?string $ignoreId): float
    {
        if ($parentUnitId === $item->base_unit_id) {
            return 1.0;
        }

        $query = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('unit_id', $parentUnitId)
            ->where('active', true);
        if ($ignoreId) {
            $query->where('id', '!=', $ignoreId);
        }
        $factor = (float) $query->value('factor_to_base');
        if ($factor <= 0) {
            throw new DomainException(__('packaging.parent_conversion_missing'));
        }

        return $factor;
    }

    private function assertNoCycle(Item $item, string $unitId, ?string $parentUnitId, ?string $ignoreId): void
    {
        $visited = [$unitId => true];
        $current = $parentUnitId;
        while ($current) {
            if (isset($visited[$current])) {
                throw new DomainException(__('packaging.conversion_cycle'));
            }
            $visited[$current] = true;
            if ($current === $item->base_unit_id) {
                return;
            }
            $query = ItemUnitConversion::query()
                ->where('item_id', $item->id)
                ->where('unit_id', $current);
            if ($ignoreId) {
                $query->where('id', '!=', $ignoreId);
            }
            $current = $query->value('parent_unit_id');
            if (! $current) {
                throw new DomainException(__('packaging.parent_conversion_missing'));
            }
        }
    }

    private function assertBarcodeAvailable(Item $item, string $unitId, mixed $barcode, ?string $ignoreId): void
    {
        $barcode = trim((string) $barcode);
        if ($barcode === '') {
            return;
        }
        $onItems = Item::query()
            ->where('barcode', $barcode)
            ->when($unitId === $item->base_unit_id, fn ($query) => $query->where('id', '!=', $item->id))
            ->exists();
        $onPackaging = ItemUnitConversion::query()->where('barcode', $barcode)
            ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->exists();
        if ($onItems || $onPackaging) {
            throw new DomainException(__('packaging.barcode_already_used'));
        }
    }

    private function volume(array $data): ?float
    {
        $length = (float) ($data['length_cm'] ?? 0);
        $width = (float) ($data['width_cm'] ?? 0);
        $height = (float) ($data['height_cm'] ?? 0);
        return $length > 0 && $width > 0 && $height > 0
            ? ($length * $width * $height) / 1_000_000
            : null;
    }

    private function isUsed(string $itemId, string $unitId): bool
    {
        $usages = [
            ['purchase_order_lines', 'unit_id', 'item_id'],
            ['goods_receipt_lines', 'unit_id', 'item_id'],
            ['purchase_price_list_lines', 'unit_id', 'item_id'],
            ['purchase_requisition_lines', 'unit_id', 'item_id'],
            ['supplier_quotation_lines', 'unit_id', 'item_id'],
            ['supplier_return_lines', 'unit_id', 'item_id'],
            ['supplier_items', 'purchasing_unit_id', 'item_id'],
            ['sales_order_lines', 'unit_id', 'item_id'],
            ['delivery_note_lines', 'unit_id', 'item_id'],
            ['sales_price_list_lines', 'unit_id', 'item_id'],
            ['sales_quotation_lines', 'unit_id', 'item_id'],
            ['customer_return_lines', 'unit_id', 'item_id'],
            ['recipe_lines', 'unit_id', 'ingredient_item_id'],
            ['production_consumptions', 'unit_id', 'item_id'],
            ['production_outputs', 'unit_id', 'item_id'],
            ['production_losses', 'unit_id', 'item_id'],
        ];

        $schema = DB::getSchemaBuilder();
        foreach ($usages as [$table, $unitColumn, $itemColumn]) {
            if (! $schema->hasTable($table)
                || ! $schema->hasColumn($table, $unitColumn)
                || ! $schema->hasColumn($table, $itemColumn)) {
                continue;
            }

            if (DB::table($table)
                ->where($unitColumn, $unitId)
                ->where($itemColumn, $itemId)
                ->exists()) {
                return true;
            }
        }

        return false;
    }

    private function writeAudit(string $event, ItemUnitConversion $conversion, array $old, array $new, User $actor): void
    {
        if (! DB::getSchemaBuilder()->hasTable('audit_logs')) {
            return;
        }
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => $actor->id,
            'event' => $event,
            'auditable_type' => ItemUnitConversion::class,
            'auditable_id' => $conversion->id,
            'old_values' => $old === [] ? null : json_encode($old, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'new_values' => $new === [] ? null : json_encode($new, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'ip_address' => app()->runningInConsole() ? null : request()->ip(),
            'user_agent' => app()->runningInConsole() ? null : Str::limit((string) request()->userAgent(), 1000, ''),
            'created_at' => now(),
        ]);
    }
}
