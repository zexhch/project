<?php

namespace App\Services\Catalog;

use App\Models\Item;
use App\Models\ItemImage;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

class ItemImageService
{

    public function storeMain(Item $item, UploadedFile $file, User $actor): Item
    {
        $code = $this->safeCode($item->code);
        $path = "item-images/{$code}.png";
        $thumbnail = "item-images/thumbnails/{$code}.png";

        $meta = $this->convertToPng($file->getRealPath(), $path, $this->maxDimension());
        $this->convertToPng($file->getRealPath(), $thumbnail, $this->thumbnailDimension());

        if ($item->main_image_path && $item->main_image_path !== $path) {
            Storage::disk($this->disk())->delete([$item->main_image_path, $item->main_image_thumbnail_path]);
        }

        $before = $item->only(['main_image_path', 'main_image_thumbnail_path']);
        $item->forceFill(['main_image_path' => $path, 'main_image_thumbnail_path' => $thumbnail])->save();
        $this->audit('item.image.main.updated', $item, $before, [
            'main_image_path' => $path,
            'main_image_thumbnail_path' => $thumbnail,
            'width_px' => $meta['width'],
            'height_px' => $meta['height'],
        ], $actor);

        return $item->fresh();
    }

    public function deleteMain(Item $item, User $actor): Item
    {
        $before = $item->only(['main_image_path', 'main_image_thumbnail_path']);
        if ($item->main_image_path || $item->main_image_thumbnail_path) {
            Storage::disk($this->disk())->delete(array_values(array_filter([
                $item->main_image_path,
                $item->main_image_thumbnail_path,
            ])));
        }
        $item->forceFill(['main_image_path' => null, 'main_image_thumbnail_path' => null])->save();
        $this->audit('item.image.main.deleted', $item, $before, [], $actor);

        return $item->fresh();
    }

    public function addGallery(Item $item, UploadedFile $file, User $actor): ItemImage
    {
        $createdPaths = [];
        try {
            return DB::transaction(function () use ($item, $file, $actor, &$createdPaths): ItemImage {
                $images = $item->images()->lockForUpdate();
                $maximum = max(1, (int) config('catalog.item_images.gallery_max_files', 10));
                if ($images->count() >= $maximum) {
                    throw new RuntimeException(__('packaging.gallery_limit_reached', ['max' => $maximum]));
                }

                $position = ((int) $images->max('position')) + 1;
                $code = $this->safeCode($item->code);
                $suffix = str_pad((string) $position, 2, '0', STR_PAD_LEFT);
                $path = "item-images/gallery/{$code}-{$suffix}.png";
                $thumbnail = "item-images/gallery/thumbnails/{$code}-{$suffix}.png";
                $createdPaths = [$path, $thumbnail];
                $meta = $this->convertToPng($file->getRealPath(), $path, $this->maxDimension());
                $this->convertToPng($file->getRealPath(), $thumbnail, $this->thumbnailDimension());

                $image = ItemImage::query()->create([
                    'item_id' => $item->id,
                    'path' => $path,
                    'thumbnail_path' => $thumbnail,
                    'original_name' => $file->getClientOriginalName(),
                    'position' => $position,
                    'size_bytes' => Storage::disk($this->disk())->size($path),
                    'width_px' => $meta['width'],
                    'height_px' => $meta['height'],
                    'uploaded_by' => $actor->id,
                ]);
                $this->audit('item.image.gallery.added', $image, [], $image->getAttributes(), $actor);
                return $image;
            });
        } catch (\Throwable $exception) {
            if ($createdPaths !== []) {
                Storage::disk($this->disk())->delete($createdPaths);
            }
            throw $exception;
        }
    }

    public function deleteGallery(ItemImage $image, User $actor): void
    {
        $before = $image->getAttributes();
        Storage::disk($this->disk())->delete([$image->path, $image->thumbnail_path]);
        $image->delete();
        $this->audit('item.image.gallery.deleted', $image, $before, [], $actor);
    }

    public function renameForCodeChange(Item $item, string $oldCode, User $actor): void
    {
        $oldSafe = $this->safeCode($oldCode);
        $newSafe = $this->safeCode($item->code);
        if ($oldSafe === $newSafe) {
            return;
        }

        DB::transaction(function () use ($item, $oldSafe, $newSafe, $actor): void {
            $before = $item->only(['main_image_path', 'main_image_thumbnail_path']);
            $updates = [];
            if ($item->main_image_path) {
                $newPath = "item-images/{$newSafe}.png";
                $this->move($item->main_image_path, $newPath);
                $updates['main_image_path'] = $newPath;
            }
            if ($item->main_image_thumbnail_path) {
                $newThumb = "item-images/thumbnails/{$newSafe}.png";
                $this->move($item->main_image_thumbnail_path, $newThumb);
                $updates['main_image_thumbnail_path'] = $newThumb;
            }
            if ($updates !== []) {
                $item->forceFill($updates)->save();
            }

            foreach ($item->images()->orderBy('position')->get() as $image) {
                $suffix = str_pad((string) $image->position, 2, '0', STR_PAD_LEFT);
                $newPath = "item-images/gallery/{$newSafe}-{$suffix}.png";
                $newThumb = "item-images/gallery/thumbnails/{$newSafe}-{$suffix}.png";
                $this->move($image->path, $newPath);
                $this->move($image->thumbnail_path, $newThumb);
                $image->update(['path' => $newPath, 'thumbnail_path' => $newThumb]);
            }

            $this->audit('item.images.renamed', $item, $before, $item->fresh()->only(['main_image_path', 'main_image_thumbnail_path']), $actor);
        });
    }

    public function importZip(UploadedFile $zipFile, User $actor): array
    {
        $zip = new \ZipArchive();
        if ($zip->open($zipFile->getRealPath()) !== true) {
            throw new RuntimeException(__('packaging.invalid_image_archive'));
        }

        $maximumFiles = max(1, (int) config('catalog.item_images.archive_max_files', 1000));
        if ($zip->numFiles > $maximumFiles) {
            $zip->close();
            throw new RuntimeException(__('packaging.archive_file_limit_exceeded', ['max' => $maximumFiles]));
        }

        $result = ['imported' => 0, 'unknown' => [], 'invalid' => []];
        $seenItems = [];
        $temporaryDirectory = storage_path('framework/testing/item-image-import-'.Str::uuid());
        if (! is_dir($temporaryDirectory)) {
            mkdir($temporaryDirectory, 0775, true);
        }

        try {
            for ($index = 0; $index < $zip->numFiles; $index++) {
                $name = $zip->getNameIndex($index);
                if (! $name || str_ends_with($name, '/') || str_contains($name, '..')) {
                    continue;
                }
                $base = pathinfo(basename($name), PATHINFO_FILENAME);
                $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                if (! in_array($extension, ['png', 'jpg', 'jpeg'], true)) {
                    $result['invalid'][] = $name;
                    continue;
                }
                try {
                    $code = $this->safeCode($base);
                } catch (RuntimeException) {
                    $result['invalid'][] = $name;
                    continue;
                }
                if (isset($seenItems[$code])) {
                    $result['invalid'][] = $name;
                    continue;
                }
                $item = Item::query()->where('code', $code)->first();
                if (! $item) {
                    $result['unknown'][] = $name;
                    continue;
                }
                $seenItems[$code] = true;
                $content = $zip->getFromIndex($index);
                if ($content === false || strlen($content) > ((int) config('catalog.item_images.max_file_kb', 8192) * 1024)) {
                    $result['invalid'][] = $name;
                    continue;
                }
                $tempPath = $temporaryDirectory.'/'.Str::uuid().'.'.$extension;
                file_put_contents($tempPath, $content);
                $uploaded = new UploadedFile($tempPath, basename($name), null, null, true);
                $this->storeMain($item, $uploaded, $actor);
                $result['imported']++;
            }
        } finally {
            $zip->close();
            foreach (glob($temporaryDirectory.'/*') ?: [] as $file) {
                @unlink($file);
            }
            @rmdir($temporaryDirectory);
        }

        return $result;
    }

    public function safeCode(string $code): string
    {
        $code = trim($code);
        if ($code === '' || in_array($code, ['.', '..'], true)
            || preg_match('/^[A-Za-z0-9._-]+$/', $code) !== 1) {
            throw new RuntimeException(__('packaging.invalid_item_code_for_image'));
        }
        return $code;
    }

    private function convertToPng(string $sourcePath, string $targetPath, int $maxDimension): array
    {
        $dimensions = @getimagesize($sourcePath);
        if (! is_array($dimensions) || ($dimensions[0] * $dimensions[1]) > (int) config('catalog.item_images.max_pixels', 25000000)) {
            throw new RuntimeException(__('packaging.image_dimensions_invalid'));
        }

        $binary = file_get_contents($sourcePath);
        $source = $binary === false ? false : @imagecreatefromstring($binary);
        if (! $source) {
            throw new RuntimeException(__('packaging.invalid_image'));
        }

        $width = imagesx($source);
        $height = imagesy($source);
        $ratio = min(1, $maxDimension / max($width, $height));
        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));
        $target = imagecreatetruecolor($targetWidth, $targetHeight);
        imagealphablending($target, false);
        imagesavealpha($target, true);
        $transparent = imagecolorallocatealpha($target, 0, 0, 0, 127);
        imagefilledrectangle($target, 0, 0, $targetWidth, $targetHeight, $transparent);
        imagecopyresampled($target, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);

        ob_start();
        imagepng($target, null, 7);
        $png = ob_get_clean();
        imagedestroy($source);
        imagedestroy($target);
        if ($png === false) {
            throw new RuntimeException(__('packaging.image_conversion_failed'));
        }

        if (! Storage::disk($this->disk())->put($targetPath, $png)) {
            throw new RuntimeException(__('packaging.image_conversion_failed'));
        }
        return ['width' => $targetWidth, 'height' => $targetHeight];
    }

    private function move(?string $from, string $to): void
    {
        if (! $from || $from === $to || ! Storage::disk($this->disk())->exists($from)) {
            return;
        }
        Storage::disk($this->disk())->delete($to);
        Storage::disk($this->disk())->move($from, $to);
    }

    private function disk(): string
    {
        return (string) config('catalog.item_images.disk', 'public');
    }

    private function maxDimension(): int
    {
        return max(320, (int) config('catalog.item_images.max_dimension', 1600));
    }

    private function thumbnailDimension(): int
    {
        return max(64, (int) config('catalog.item_images.thumbnail_dimension', 320));
    }

    private function audit(string $event, object $model, array $old, array $new, User $actor): void
    {
        if (! DB::getSchemaBuilder()->hasTable('audit_logs')) {
            return;
        }
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(),
            'user_id' => $actor->id,
            'event' => $event,
            'auditable_type' => $model::class,
            'auditable_id' => $model->getKey(),
            'old_values' => $old === [] ? null : json_encode($old, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'new_values' => $new === [] ? null : json_encode($new, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
            'ip_address' => app()->runningInConsole() ? null : request()->ip(),
            'user_agent' => app()->runningInConsole() ? null : Str::limit((string) request()->userAgent(), 1000, ''),
            'created_at' => now(),
        ]);
    }
}
