<?php

namespace App\Services\Productivity;

use App\Models\DataExportRun;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Throwable;

class DataExportService
{
    public function __construct(
        private readonly SpreadsheetFileService $spreadsheets,
        private readonly DataExchangeCatalog $catalog,
    ) {
    }

    public function generate(DataExportRun $run): DataExportRun
    {
        $run->loadMissing('user');
        abort_unless($run->user, 422);
        $this->catalog->assertAuthorized($run->user, $run->export_type, 'read');
        $run->update(['status' => 'RUNNING', 'error_message' => null]);
        $format = strtolower($run->format);
        $directory = 'exports/productivity/'.now()->format('Y/m');
        $filename = sprintf('%s-%s-%s.%s', $run->export_type, now()->format('Ymd-His'), Str::lower(Str::random(6)), $format);
        $path = $directory.'/'.$filename;
        $absolutePath = Storage::disk('local')->path($path);
        if (! is_dir(dirname($absolutePath))) {
            mkdir(dirname($absolutePath), 0775, true);
        }

        try {
            $query = $this->catalog->exportQuery($run->export_type, $run->company_id);
            $definition = $this->catalog->definition($run->export_type);
            $rows = (function () use ($query, $run): \Generator {
                foreach ($query->lazy(500) as $model) {
                    yield $this->catalog->exportRow($run->export_type, $model);
                }
            })();
            $count = $this->spreadsheets->write($absolutePath, array_keys($definition['columns']), $rows, $format, __($definition['label']));
            $run->update([
                'status' => 'COMPLETED', 'row_count' => $count, 'file_disk' => 'local',
                'file_path' => $path, 'file_name' => $filename, 'completed_at' => now(),
            ]);
        } catch (Throwable $exception) {
            $run->update(['status' => 'FAILED', 'error_message' => Str::limit($exception->getMessage(), 5000), 'completed_at' => now()]);
            throw $exception;
        }

        return $run->refresh();
    }
}
