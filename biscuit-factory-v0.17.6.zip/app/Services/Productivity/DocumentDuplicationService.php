<?php

namespace App\Services\Productivity;

use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\User;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DocumentDuplicationService
{
    public function __construct(private readonly DocumentNumberService $numbers)
    {
    }

    /** @return array<string, array<string, string>> */
    public function types(): array
    {
        return [
            'sales-quotation' => ['model' => SalesQuotation::class, 'permission' => 'sales.create', 'route' => 'sales.quotations.show', 'document_type' => FinancialDocumentCatalog::SALES_QUOTATION, 'line_foreign_key' => 'sales_quotation_id'],
            'sales-order' => ['model' => SalesOrder::class, 'permission' => 'sales.create', 'route' => 'sales.orders.show', 'document_type' => FinancialDocumentCatalog::SALES_ORDER, 'line_foreign_key' => 'sales_order_id'],
            'purchase-requisition' => ['model' => PurchaseRequisition::class, 'permission' => 'purchasing.create', 'route' => 'purchasing.requisitions.show', 'document_type' => FinancialDocumentCatalog::PURCHASE_REQUISITION, 'line_foreign_key' => 'purchase_requisition_id'],
            'purchase-order' => ['model' => PurchaseOrder::class, 'permission' => 'purchasing.create', 'route' => 'purchasing.orders.show', 'document_type' => FinancialDocumentCatalog::PURCHASE_ORDER, 'line_foreign_key' => 'purchase_order_id'],
        ];
    }

    /** @return array{model: Model, route: string} */
    public function duplicate(User $user, string $type, string $id): array
    {
        $definition = $this->types()[$type] ?? abort(404);
        abort_unless($user->hasPermission($definition['permission']), 403);

        return DB::transaction(function () use ($definition, $id, $user): array {
            /** @var Model $source */
            $source = $definition['model']::query()->with('lines')->lockForUpdate()->findOrFail($id);
            $copy = $source->replicate();
            $copy->setAttribute($this->numberAttribute($definition['document_type']), $this->numbers->next($source->company_id, $definition['document_type'], now()));
            $copy->fill($this->resetAttributes($source, $user));
            $copy->save();

            foreach ($source->lines as $line) {
                $lineCopy = $line->replicate();
                $lineCopy->setAttribute($definition['line_foreign_key'], $copy->getKey());
                foreach (['reserved_quantity', 'delivered_quantity', 'returned_quantity', 'received_quantity', 'quantity_ordered'] as $field) {
                    if (array_key_exists($field, $lineCopy->getAttributes())) {
                        $lineCopy->setAttribute($field, 0);
                    }
                }
                if (array_key_exists('status', $lineCopy->getAttributes())) {
                    $lineCopy->setAttribute('status', 'OPEN');
                }
                $lineCopy->save();
            }

            DB::table('audit_logs')->insert([
                'id' => (string) Str::uuid(), 'user_id' => $user->id, 'event' => 'productivity.document.duplicated',
                'auditable_type' => $copy::class, 'auditable_id' => $copy->getKey(),
                'old_values' => json_encode(['source_id' => $source->getKey()], JSON_THROW_ON_ERROR),
                'new_values' => json_encode(['copy_id' => $copy->getKey(), 'document_type' => $definition['document_type']], JSON_THROW_ON_ERROR),
                'ip_address' => request()->ip(), 'user_agent' => request()->userAgent(), 'created_at' => now(),
            ]);

            return ['model' => $copy, 'route' => $definition['route']];
        });
    }

    /** @return array<string, mixed> */
    private function resetAttributes(Model $source, User $user): array
    {
        $attributes = [
            'status' => 'DRAFT', 'created_by' => $user->id, 'submitted_by' => null,
            'submitted_at' => null, 'approved_by' => null, 'approved_at' => null,
            'sent_by' => null, 'sent_at' => null, 'accepted_by' => null, 'accepted_at' => null,
            'cancellation_reason' => null,
        ];
        if ($source instanceof SalesQuotation) {
            $attributes += ['quotation_date' => now()->toDateString(), 'valid_until' => now()->addDays(30)->toDateString()];
        } elseif ($source instanceof SalesOrder || $source instanceof PurchaseOrder) {
            $attributes += ['order_date' => now()->toDateString()];
            if ($source instanceof SalesOrder) {
                $attributes['sales_quotation_id'] = null;
            } else {
                $attributes['purchase_requisition_id'] = null;
                $attributes['supplier_quotation_id'] = null;
            }
        } elseif ($source instanceof PurchaseRequisition) {
            $attributes += ['request_date' => now()->toDateString(), 'requested_by' => $user->id, 'rejection_reason' => null];
        }

        return array_filter($attributes, fn ($value, $key) => array_key_exists($key, $source->getAttributes()), ARRAY_FILTER_USE_BOTH);
    }

    private function numberAttribute(string $documentType): string
    {
        return FinancialDocumentCatalog::definition($documentType)['number_attribute'];
    }
}
