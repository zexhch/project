<?php

namespace App\Services\Productivity;

use Generator;
use RuntimeException;
use XMLReader;
use ZipArchive;

class SpreadsheetFileService
{
    /** @return Generator<int, array<int, string|int|float|null>> */
    public function rows(string $path, string $format): Generator
    {
        $format = strtolower($format);

        if ($format === 'csv') {
            yield from $this->csvRows($path);
            return;
        }

        if ($format === 'xlsx') {
            yield from $this->xlsxRows($path);
            return;
        }

        throw new RuntimeException("Unsupported spreadsheet format [{$format}].");
    }

    /** @param iterable<int, array<int, scalar|null>> $rows */
    public function write(string $path, array $headers, iterable $rows, string $format, string $sheetName = 'Data'): int
    {
        return strtolower($format) === 'csv'
            ? $this->writeCsv($path, $headers, $rows)
            : $this->writeXlsx($path, $headers, $rows, $sheetName);
    }

    /** @return Generator<int, array<int, string|null>> */
    private function csvRows(string $path): Generator
    {
        $handle = fopen($path, 'rb');
        if ($handle === false) {
            throw new RuntimeException('Unable to open CSV file.');
        }

        try {
            $sample = fgets($handle) ?: '';
            rewind($handle);
            $delimiter = $this->detectDelimiter($sample);

            while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
                if (isset($row[0])) {
                    $row[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $row[0]);
                }
                yield array_map(fn ($value) => $value === null ? null : trim((string) $value), $row);
            }
        } finally {
            fclose($handle);
        }
    }

    /** @return Generator<int, array<int, string|int|float|null>> */
    private function xlsxRows(string $path): Generator
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('Unable to open XLSX archive.');
        }

        try {
            $sharedStrings = $this->sharedStrings($zip);
            $sheetPath = $this->firstWorksheetPath($zip);
            $xml = $this->safeZipContents($zip, $sheetPath, 50 * 1024 * 1024);
            if ($xml === false) {
                throw new RuntimeException('The first XLSX worksheet is missing.');
            }

            $reader = new XMLReader();
            $reader->XML($xml, null, LIBXML_NONET | LIBXML_COMPACT);
            $currentRow = [];

            while ($reader->read()) {
                if ($reader->nodeType === XMLReader::ELEMENT && $reader->localName === 'row') {
                    $currentRow = [];
                }

                if ($reader->nodeType === XMLReader::ELEMENT && $reader->localName === 'c') {
                    $cellRef = $reader->getAttribute('r') ?: 'A1';
                    $cellType = $reader->getAttribute('t') ?: 'n';
                    $columnIndex = $this->columnIndex($cellRef);
                    $cellXml = $reader->readOuterXml();
                    $cell = simplexml_load_string($cellXml);
                    $value = null;

                    if ($cell !== false) {
                        $cellChildren = $this->defaultNamespaceChildren($cell);
                        if ($cellType === 'inlineStr') {
                            $inline = isset($cellChildren->is)
                                ? $this->defaultNamespaceChildren($cellChildren->is)
                                : null;
                            $value = $inline && isset($inline->t) ? (string) $inline->t : '';
                        } else {
                            $raw = isset($cellChildren->v) ? (string) $cellChildren->v : '';
                            $value = match ($cellType) {
                                's' => $sharedStrings[(int) $raw] ?? '',
                                'b' => $raw === '1' ? '1' : '0',
                                'str' => $raw,
                                default => $raw === '' ? null : (is_numeric($raw) ? $raw + 0 : $raw),
                            };
                        }
                    }

                    $currentRow[$columnIndex] = $value;
                }

                if ($reader->nodeType === XMLReader::END_ELEMENT && $reader->localName === 'row') {
                    if ($currentRow === []) {
                        yield [];
                        continue;
                    }
                    $max = max(array_keys($currentRow));
                    $normalized = [];
                    for ($index = 0; $index <= $max; $index++) {
                        $normalized[] = $currentRow[$index] ?? null;
                    }
                    yield $normalized;
                }
            }

            $reader->close();
        } finally {
            $zip->close();
        }
    }

    /** @return array<int, string> */
    private function sharedStrings(ZipArchive $zip): array
    {
        $xml = $this->safeZipContents($zip, 'xl/sharedStrings.xml', 50 * 1024 * 1024);
        if ($xml === false) {
            return [];
        }

        $document = simplexml_load_string($xml);
        if ($document === false) {
            return [];
        }

        $strings = [];
        $documentChildren = $this->defaultNamespaceChildren($document);
        foreach ($documentChildren->si as $item) {
            $itemChildren = $this->defaultNamespaceChildren($item);
            if (isset($itemChildren->t)) {
                $strings[] = (string) $itemChildren->t;
                continue;
            }
            $value = '';
            foreach ($itemChildren->r as $run) {
                $runChildren = $this->defaultNamespaceChildren($run);
                $value .= isset($runChildren->t) ? (string) $runChildren->t : '';
            }
            $strings[] = $value;
        }

        return $strings;
    }

    private function firstWorksheetPath(ZipArchive $zip): string
    {
        $workbook = $this->safeZipContents($zip, 'xl/workbook.xml', 5 * 1024 * 1024);
        $relations = $this->safeZipContents($zip, 'xl/_rels/workbook.xml.rels', 5 * 1024 * 1024);
        if ($workbook === false || $relations === false) {
            return 'xl/worksheets/sheet1.xml';
        }

        $workbookXml = simplexml_load_string($workbook);
        $relationsXml = simplexml_load_string($relations);
        if ($workbookXml === false || $relationsXml === false) {
            return 'xl/worksheets/sheet1.xml';
        }

        $workbookXml->registerXPathNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');
        $sheets = $workbookXml->xpath('//*[local-name()="sheet"]');
        $relationshipId = $sheets ? (string) $sheets[0]->attributes('r', true)['id'] : '';

        $relationshipChildren = $this->defaultNamespaceChildren($relationsXml);
        foreach ($relationshipChildren->Relationship as $relation) {
            if ((string) $relation['Id'] === $relationshipId) {
                $target = ltrim((string) $relation['Target'], '/');
                return str_starts_with($target, 'xl/') ? $target : 'xl/'.$target;
            }
        }

        return 'xl/worksheets/sheet1.xml';
    }

    private function safeZipContents(ZipArchive $zip, string $entry, int $maximumBytes): string|false
    {
        $statistics = $zip->statName($entry);
        if ($statistics === false) {
            return false;
        }

        $size = (int) ($statistics['size'] ?? 0);
        if ($size > $maximumBytes) {
            throw new RuntimeException("XLSX entry [{$entry}] exceeds the allowed uncompressed size.");
        }

        return $zip->getFromName($entry);
    }

    private function defaultNamespaceChildren(\SimpleXMLElement $element): \SimpleXMLElement
    {
        $namespaces = $element->getNamespaces(true);
        $defaultNamespace = $namespaces[''] ?? null;

        return $defaultNamespace ? $element->children($defaultNamespace) : $element;
    }

    /** @param iterable<int, array<int, scalar|null>> $rows */
    private function writeCsv(string $path, array $headers, iterable $rows): int
    {
        $handle = fopen($path, 'wb');
        if ($handle === false) {
            throw new RuntimeException('Unable to create CSV file.');
        }

        $count = 0;
        try {
            fwrite($handle, "\xEF\xBB\xBF");
            fputcsv($handle, $headers, ';');
            foreach ($rows as $row) {
                fputcsv($handle, array_map([$this, 'safeCsvValue'], $row), ';');
                $count++;
            }
        } finally {
            fclose($handle);
        }

        return $count;
    }

    /** @param iterable<int, array<int, scalar|null>> $rows */
    private function writeXlsx(string $path, array $headers, iterable $rows, string $sheetName): int
    {
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Unable to create XLSX archive.');
        }

        $count = 0;
        $sheet = fopen('php://temp', 'w+b');
        if ($sheet === false) {
            throw new RuntimeException('Unable to allocate XLSX worksheet.');
        }

        fwrite($sheet, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        fwrite($sheet, '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><sheetData>');
        $this->writeXlsxRow($sheet, 1, $headers, true);
        $rowNumber = 2;
        foreach ($rows as $row) {
            $this->writeXlsxRow($sheet, $rowNumber++, $row, false);
            $count++;
        }
        fwrite($sheet, '</sheetData><autoFilter ref="A1:'.$this->columnLetters(max(1, count($headers))).'1"/><pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/></worksheet>');
        rewind($sheet);

        try {
            $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
            $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
            $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'.htmlspecialchars(mb_substr($sheetName, 0, 31), ENT_XML1).'" sheetId="1" r:id="rId1"/></sheets></workbook>');
            $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
            $zip->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>');
            $zip->addFromString('xl/worksheets/sheet1.xml', stream_get_contents($sheet));
        } finally {
            fclose($sheet);
            $zip->close();
        }

        return $count;
    }

    /** @param resource $handle */
    private function writeXlsxRow($handle, int $rowNumber, iterable $values, bool $header): void
    {
        fwrite($handle, '<row r="'.$rowNumber.'">');
        foreach (array_values(is_array($values) ? $values : iterator_to_array($values)) as $index => $value) {
            $reference = $this->columnLetters($index + 1).$rowNumber;
            if (is_int($value) || is_float($value)) {
                fwrite($handle, '<c r="'.$reference.'"'.($header ? ' s="1"' : '').'><v>'.$value.'</v></c>');
            } else {
                $safe = htmlspecialchars((string) ($value ?? ''), ENT_XML1 | ENT_QUOTES, 'UTF-8');
                fwrite($handle, '<c r="'.$reference.'" t="inlineStr"'.($header ? ' s="1"' : '').'><is><t xml:space="preserve">'.$safe.'</t></is></c>');
            }
        }
        fwrite($handle, '</row>');
    }

    private function detectDelimiter(string $sample): string
    {
        $counts = [';' => substr_count($sample, ';'), ',' => substr_count($sample, ','), "\t" => substr_count($sample, "\t")];
        arsort($counts);
        return (string) array_key_first($counts);
    }

    private function safeCsvValue(mixed $value): string
    {
        $string = (string) ($value ?? '');
        return preg_match('/^[=+\-@]/', ltrim($string)) ? "'".$string : $string;
    }

    private function columnIndex(string $reference): int
    {
        preg_match('/^([A-Z]+)/i', $reference, $matches);
        $letters = strtoupper($matches[1] ?? 'A');
        $index = 0;
        foreach (str_split($letters) as $letter) {
            $index = ($index * 26) + (ord($letter) - 64);
        }
        return max(0, $index - 1);
    }

    private function columnLetters(int $index): string
    {
        $letters = '';
        while ($index > 0) {
            $index--;
            $letters = chr(65 + ($index % 26)).$letters;
            $index = intdiv($index, 26);
        }
        return $letters ?: 'A';
    }
}
