<?php

namespace App\Services\Productivity;

use App\Models\Customer;
use App\Models\Item;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\Supplier;
use App\Models\User;
use App\Services\Modules\ModuleRegistry;
use Illuminate\Support\Collection;

class GlobalSearchService
{
    public function __construct(private readonly ModuleRegistry $modules)
    {
    }

    /** @return Collection<int, array<string, string>> */
    public function search(User $user, string $term, int $limitPerType = 5): Collection
    {
        $term = trim($term);
        if (mb_strlen($term) < 2) {
            return collect();
        }

        $results = collect();

        if ($this->allowed($user, 'catalog.view', 'master-data')) {
            Item::query()->where(fn ($query) => $query->whereLike('code', "%{$term}%")->orWhereLike('name', "%{$term}%")->orWhereLike('barcode', "%{$term}%"))
                ->orderBy('code')->limit($limitPerType)->get()->each(function (Item $item) use ($results): void {
                    $results->push($this->result(
                        'productivity.items',
                        'ti-package',
                        $item->code,
                        $item->name,
                        route('admin.items.packaging', $item),
                        $item->main_image_thumbnail_path ? asset('storage/'.$item->main_image_thumbnail_path) : null,
                    ));
                });
        }

        if ($this->allowed($user, 'sales.view', 'sales')) {
            Customer::query()->where(fn ($query) => $query
                ->whereLike('code', "%{$term}%")
                ->orWhereLike('name', "%{$term}%")
                ->orWhereLike('legal_name', "%{$term}%")
                ->orWhereLike('email', "%{$term}%")
                ->orWhereLike('registration_number', "%{$term}%")
                ->orWhereLike('tax_identifier', "%{$term}%")
                ->orWhereLike('statistical_identification_number', "%{$term}%")
                ->orWhereLike('article_of_imposition_number', "%{$term}%"))
                ->orderBy('code')->limit($limitPerType)->get()->each(function (Customer $customer) use ($results): void {
                    $results->push($this->result('productivity.customers', 'ti-users', $customer->code, $customer->name, route('sales.customers.show', $customer)));
                });
            SalesQuotation::query()->where(fn ($query) => $query->whereLike('quotation_number', "%{$term}%")->orWhereHas('customer', fn ($customer) => $customer->whereLike('name', "%{$term}%")))
                ->with('customer:id,name')->latest('quotation_date')->limit($limitPerType)->get()->each(function (SalesQuotation $quotation) use ($results): void {
                    $results->push($this->result('sales.quotations', 'ti-file-invoice', $quotation->quotation_number, $quotation->customer?->name, route('sales.quotations.show', $quotation)));
                });
            SalesOrder::query()->where(fn ($query) => $query->whereLike('order_number', "%{$term}%")->orWhereLike('customer_reference', "%{$term}%")->orWhereHas('customer', fn ($customer) => $customer->whereLike('name', "%{$term}%")))
                ->with('customer:id,name')->latest('order_date')->limit($limitPerType)->get()->each(function (SalesOrder $order) use ($results): void {
                    $results->push($this->result('sales.sales_orders', 'ti-shopping-cart', $order->order_number, $order->customer?->name, route('sales.orders.show', $order)));
                });
        }

        if ($this->allowed($user, 'purchasing.view', 'purchasing')) {
            Supplier::query()->where(fn ($query) => $query
                ->whereLike('code', "%{$term}%")
                ->orWhereLike('name', "%{$term}%")
                ->orWhereLike('legal_name', "%{$term}%")
                ->orWhereLike('email', "%{$term}%")
                ->orWhereLike('registration_number', "%{$term}%")
                ->orWhereLike('tax_identifier', "%{$term}%")
                ->orWhereLike('statistical_identification_number', "%{$term}%")
                ->orWhereLike('article_of_imposition_number', "%{$term}%"))
                ->orderBy('code')->limit($limitPerType)->get()->each(function (Supplier $supplier) use ($results): void {
                    $results->push($this->result('productivity.suppliers', 'ti-building-factory-2', $supplier->code, $supplier->name, route('purchasing.suppliers.show', $supplier)));
                });
            PurchaseRequisition::query()->whereLike('requisition_number', "%{$term}%")
                ->latest('request_date')->limit($limitPerType)->get()->each(function (PurchaseRequisition $requisition) use ($results): void {
                    $results->push($this->result('purchasing.requisitions', 'ti-file-description', $requisition->requisition_number, (string) $requisition->status, route('purchasing.requisitions.show', $requisition)));
                });
            PurchaseOrder::query()->where(fn ($query) => $query->whereLike('order_number', "%{$term}%")->orWhereLike('supplier_reference', "%{$term}%")->orWhereHas('supplier', fn ($supplier) => $supplier->whereLike('name', "%{$term}%")))
                ->with('supplier:id,name')->latest('order_date')->limit($limitPerType)->get()->each(function (PurchaseOrder $order) use ($results): void {
                    $results->push($this->result('purchasing.purchase_orders', 'ti-shopping-cart', $order->order_number, $order->supplier?->name, route('purchasing.orders.show', $order)));
                });
        }

        return $results->take(30)->values();
    }

    private function allowed(User $user, string $permission, string $module): bool
    {
        return $this->modules->enabled($module) && $user->hasPermission($permission);
    }

    /** @return array<string, string|null> */
    private function result(
        string $group,
        string $icon,
        string $title,
        ?string $subtitle,
        string $url,
        ?string $imageUrl = null,
    ): array {
        return [
            'group' => __($group),
            'icon' => $icon,
            'title' => $title,
            'subtitle' => (string) $subtitle,
            'url' => $url,
            'image_url' => $imageUrl,
        ];
    }
}
