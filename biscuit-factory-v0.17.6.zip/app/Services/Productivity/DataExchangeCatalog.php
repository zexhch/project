<?php

namespace App\Services\Productivity;

use App\Models\Company;
use App\Models\Customer;
use App\Models\Item;
use App\Models\ItemCategory;
use App\Models\ItemUnitConversion;
use App\Models\Supplier;
use App\Models\Unit;
use App\Models\User;
use App\Services\Modules\ModuleRegistry;
use App\Services\Catalog\ItemPackagingService;
use DomainException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class DataExchangeCatalog
{
    public function __construct(
        private readonly ModuleRegistry $modules,
        private readonly ItemPackagingService $packaging,
    ) {
    }

    /** @return array<string, array<string, mixed>> */
    public function available(?User $user = null, ?string $operation = null): array
    {
        return collect($this->definitions())
            ->filter(fn (array $definition): bool => $this->modules->enabled($definition['application_module']))
            ->filter(function (array $definition) use ($user, $operation): bool {
                if (! $user) {
                    return true;
                }

                if ($operation === 'write') {
                    return $user->hasPermission($definition['write_permission']);
                }

                if ($operation === 'read') {
                    return $user->hasPermission($definition['view_permission']);
                }

                return $user->hasPermission($definition['view_permission'])
                    || $user->hasPermission($definition['write_permission']);
            })
            ->all();
    }

    public function assertAuthorized(User $user, string $type, string $operation): void
    {
        $definition = $this->definition($type);
        $permission = $operation === 'write'
            ? $definition['write_permission']
            : $definition['view_permission'];

        abort_unless($user->hasPermission($permission), 403);
    }

    /** @return array<string, mixed> */
    public function definition(string $type): array
    {
        $definition = $this->definitions()[$type] ?? throw new DomainException(__('productivity.unknown_exchange_type'));
        if (! $this->modules->enabled($definition['application_module'])) {
            throw new DomainException(__('modules.module_disabled'));
        }
        return $definition;
    }

    /** @return array<int, string> */
    public function headers(string $type): array
    {
        return array_keys($this->definition($type)['columns']);
    }

    /** @return array<int, array<int, scalar|null>> */
    public function exampleRows(string $type): array
    {
        return [$this->definition($type)['example']];
    }

    /** @param array<string, mixed> $row @return array{normalized: array<string, mixed>, errors: array<string, array<int, string>>} */
    public function validateRow(string $type, array $row, ?string $companyId): array
    {
        $definition = $this->definition($type);
        $normalized = $this->normalize($type, $row, $companyId);
        $validator = Validator::make($normalized, $this->rules($type, $companyId), [], $definition['attributes']);
        $errors = $validator->errors()->toArray();

        if ($definition['company_scoped'] && $companyId && ! empty($normalized['company_code'])) {
            $selectedCode = Company::query()->whereKey($companyId)->value('code');
            if ($selectedCode && Str::upper((string) $normalized['company_code']) !== Str::upper((string) $selectedCode)) {
                $errors['company_code'][] = __('productivity.company_code_mismatch', ['code' => $selectedCode]);
            }
        }

        return ['normalized' => $normalized, 'errors' => $errors];
    }

    /** @return array{action: string, model_id: string} */
    public function persist(string $type, array $data, ?string $companyId, string $existingMode, ?User $actor = null): array
    {
        return match ($type) {
            'items' => $this->persistItem($data, $existingMode),
            'item-packagings' => $this->persistItemPackaging($data, $existingMode, $actor),
            'customers' => $this->persistCustomer($data, $companyId, $existingMode),
            'suppliers' => $this->persistSupplier($data, $companyId, $existingMode),
            default => throw new DomainException(__('productivity.unknown_exchange_type')),
        };
    }

    public function rowKey(string $type, array $data, ?string $companyId): string
    {
        if ($type === 'item-packagings') {
            return $type.'|'.Str::upper((string) ($data['article_code'] ?? '')).'|'.Str::upper((string) ($data['unit_code'] ?? ''));
        }

        $scope = in_array($type, ['customers', 'suppliers'], true)
            ? (string) ($data['company_id'] ?? $companyId ?? '')
            : 'global';

        return $type.'|'.$scope.'|'.Str::upper((string) ($data['code'] ?? ''));
    }

    public function previewAction(string $type, array $data, ?string $companyId, string $existingMode): string
    {
        $exists = match ($type) {
            'items' => Item::withTrashed()->where('code', $data['code'] ?? null)->exists(),
            'item-packagings' => ItemUnitConversion::query()->where('item_id', $data['item_id'] ?? null)->where('unit_id', $data['unit_id'] ?? null)->exists(),
            'customers' => Customer::withTrashed()->where('company_id', $data['company_id'] ?? $companyId)->where('code', $data['code'] ?? null)->exists(),
            'suppliers' => Supplier::withTrashed()->where('company_id', $data['company_id'] ?? $companyId)->where('code', $data['code'] ?? null)->exists(),
            default => false,
        };

        return $this->actionFor($exists, $existingMode);
    }

    public function exportQuery(string $type, ?string $companyId): Builder
    {
        return match ($type) {
            'items' => Item::query()->with(['category:id,code', 'baseUnit:id,code'])->orderBy('code'),
            'item-packagings' => ItemUnitConversion::query()->with(['item:id,code', 'unit:id,code', 'parentUnit:id,code'])->orderBy('item_id')->orderBy('factor_to_base'),
            'customers' => Customer::query()->when($companyId, fn (Builder $query) => $query->where('company_id', $companyId))->with('company:id,code')->orderBy('code'),
            'suppliers' => Supplier::query()->when($companyId, fn (Builder $query) => $query->where('company_id', $companyId))->with('company:id,code')->orderBy('code'),
            default => throw new DomainException(__('productivity.unknown_exchange_type')),
        };
    }

    /** @return array<int, scalar|null> */
    public function exportRow(string $type, object $model): array
    {
        return match ($type) {
            'items' => [
                $model->code, $model->name, $model->baseUnit?->code, $model->category?->code,
                $model->item_type, $model->barcode, $model->lot_managed ? 1 : 0,
                $model->expiry_managed ? 1 : 0, $model->minimum_stock, $model->shelf_life_days,
                $model->active ? 1 : 0,
            ],
            'item-packagings' => [
                $model->item?->code, $model->unit?->code, $model->parentUnit?->code,
                $model->factor_to_parent, $model->barcode, $model->net_weight_kg, $model->gross_weight_kg,
                $model->tare_weight_kg, $model->length_cm, $model->width_cm, $model->height_cm,
                $model->purchasing_unit ? 1 : 0, $model->sales_unit ? 1 : 0,
                $model->production_unit ? 1 : 0, $model->inventory_unit ? 1 : 0,
                $model->fractional_allowed ? 1 : 0, $model->rounding_mode,
                $model->valid_from?->format('Y-m-d'), $model->valid_to?->format('Y-m-d'), $model->active ? 1 : 0,
            ],
            'customers' => [
                $model->company?->code, $model->code, $model->name, $model->legal_name,
                $model->customer_group_code, $model->sales_channel_code, $model->tax_identifier,
                $model->registration_number, $model->statistical_identification_number,
                $model->article_of_imposition_number, $model->country_code, $model->currency_code,
                $model->payment_terms_days, $model->credit_limit, $model->tax_exempt ? 1 : 0,
                $model->status, $model->email, $model->phone, $model->billing_address,
                $model->shipping_address, $model->notes, $model->active ? 1 : 0,
            ],
            'suppliers' => [
                $model->company?->code, $model->code, $model->name, $model->legal_name,
                $model->supplier_type, $model->tax_identifier, $model->registration_number,
                $model->statistical_identification_number, $model->article_of_imposition_number,
                $model->country_code, $model->currency_code, $model->payment_terms_days,
                $model->incoterm, $model->lead_time_days, $model->minimum_order_value,
                $model->status, $model->preferred ? 1 : 0, $model->email, $model->phone,
                $model->address, $model->notes, $model->active ? 1 : 0,
            ],
            default => [],
        };
    }

    /** @return array<string, array<string, mixed>> */
    private function definitions(): array
    {
        return [
            'items' => [
                'label' => 'productivity.items', 'application_module' => 'master-data', 'company_scoped' => false,
                'view_permission' => 'catalog.view', 'write_permission' => 'catalog.update',
                'columns' => [
                    'code' => true, 'name' => true, 'base_unit_code' => true, 'category_code' => false,
                    'item_type' => true, 'barcode' => false, 'lot_managed' => false,
                    'expiry_managed' => false, 'minimum_stock' => false, 'shelf_life_days' => false, 'active' => false,
                ],
                'attributes' => [],
                'example' => ['PF-BIS-VAN', 'Biscuit vanille', 'KG', 'PROD-FINI', 'FINISHED_GOOD', '6130000000012', 1, 1, 100, 180, 1],
            ],
            'item-packagings' => [
                'label' => 'packaging.item_packagings', 'application_module' => 'master-data', 'company_scoped' => false,
                'view_permission' => 'catalog.view', 'write_permission' => 'catalog.update',
                'columns' => [
                    'article_code' => true, 'unit_code' => true, 'parent_unit_code' => false,
                    'factor_to_parent' => true, 'barcode' => false, 'net_weight_kg' => false,
                    'gross_weight_kg' => false, 'tare_weight_kg' => false, 'length_cm' => false,
                    'width_cm' => false, 'height_cm' => false, 'purchasing_unit' => false,
                    'sales_unit' => false, 'production_unit' => false, 'inventory_unit' => false,
                    'fractional_allowed' => false, 'rounding_mode' => false, 'valid_from' => false,
                    'valid_to' => false, 'active' => false,
                ],
                'attributes' => [],
                'example' => ['PF-BIS-180', 'CT', 'PAQ', 24, '6130000000029', 4.32, 4.60, 0.28, 40, 30, 25, 0, 1, 0, 0, 0, 'NONE', '', '', 1],
            ],
            'customers' => [
                'label' => 'productivity.customers', 'application_module' => 'sales', 'company_scoped' => true,
                'view_permission' => 'sales.view', 'write_permission' => 'sales.update',
                'columns' => [
                    'company_code' => false, 'code' => true, 'name' => true, 'legal_name' => false,
                    'customer_group_code' => false, 'sales_channel_code' => false, 'tax_identifier' => false,
                    'registration_number' => false, 'statistical_identification_number' => false,
                    'article_of_imposition_number' => false, 'country_code' => false, 'currency_code' => false,
                    'payment_terms_days' => false, 'credit_limit' => false, 'tax_exempt' => false,
                    'status' => false, 'email' => false, 'phone' => false, 'billing_address' => false,
                    'shipping_address' => false, 'notes' => false, 'active' => false,
                ],
                'attributes' => [],
                'example' => ['COMP-DEMO', 'CLI-100', 'Distributeur Centre', 'Distributeur Centre SARL', 'DISTRIBUTEUR', 'B2B', 'NIF001', 'RC001', 'NIS001', 'AI001', 'DZ', 'DZD', 30, 500000, 0, 'APPROVED', 'contact@example.dz', '0550000000', 'Alger', 'Alger', '', 1],
            ],
            'suppliers' => [
                'label' => 'productivity.suppliers', 'application_module' => 'purchasing', 'company_scoped' => true,
                'view_permission' => 'purchasing.view', 'write_permission' => 'purchasing.update',
                'columns' => [
                    'company_code' => false, 'code' => true, 'name' => true, 'legal_name' => false,
                    'supplier_type' => false, 'tax_identifier' => false, 'registration_number' => false,
                    'statistical_identification_number' => false, 'article_of_imposition_number' => false,
                    'country_code' => false, 'currency_code' => false, 'payment_terms_days' => false,
                    'incoterm' => false, 'lead_time_days' => false, 'minimum_order_value' => false,
                    'status' => false, 'preferred' => false, 'email' => false, 'phone' => false,
                    'address' => false, 'notes' => false, 'active' => false,
                ],
                'attributes' => [],
                'example' => ['COMP-DEMO', 'FOU-100', 'Farines du Centre', 'Farines du Centre SPA', 'LOCAL', 'NIF100', 'RC100', 'NIS100', 'AI100', 'DZ', 'DZD', 30, 'DAP', 5, 50000, 'APPROVED', 1, 'vente@example.dz', '0550000001', 'Blida', '', 1],
            ],
        ];
    }

    /** @return array<string, mixed> */
    private function normalize(string $type, array $row, ?string $companyId): array
    {
        $clean = [];
        foreach ($this->headers($type) as $header) {
            $value = $row[$header] ?? null;
            $clean[$header] = is_string($value) ? trim($value) : $value;
        }

        foreach (['code', 'company_code', 'base_unit_code', 'category_code', 'item_type', 'country_code', 'currency_code', 'status', 'supplier_type', 'incoterm', 'article_code', 'unit_code', 'parent_unit_code', 'rounding_mode'] as $field) {
            if (isset($clean[$field]) && $clean[$field] !== '') {
                $clean[$field] = Str::upper((string) $clean[$field]);
            }
        }

        $booleanDefaults = [
            'active' => true,
            'lot_managed' => true,
            'expiry_managed' => false,
            'tax_exempt' => false,
            'preferred' => false,
            'purchasing_unit' => false,
            'sales_unit' => false,
            'production_unit' => false,
            'inventory_unit' => false,
            'fractional_allowed' => false,
        ];
        foreach ($booleanDefaults as $field => $default) {
            if (array_key_exists($field, $clean)) {
                $clean[$field] = $this->booleanValue($clean[$field], $default);
            }
        }

        if ($companyId && in_array($type, ['customers', 'suppliers'], true)) {
            $clean['company_id'] = $companyId;
        } elseif (! empty($clean['company_code'])) {
            $clean['company_id'] = Company::query()->where('code', $clean['company_code'])->value('id');
        }

        if ($type === 'items') {
            $clean['base_unit_id'] = Unit::query()->where('code', $clean['base_unit_code'] ?? null)->value('id');
            $clean['category_id'] = empty($clean['category_code']) ? null : ItemCategory::query()->where('code', $clean['category_code'])->value('id');
        }

        if ($type === 'item-packagings') {
            $clean['item_id'] = Item::query()->where('code', $clean['article_code'] ?? null)->value('id');
            $clean['unit_id'] = Unit::query()->where('code', $clean['unit_code'] ?? null)->value('id');
            $clean['parent_unit_id'] = empty($clean['parent_unit_code']) ? null : Unit::query()->where('code', $clean['parent_unit_code'])->value('id');
            $clean['factor_to_parent'] = $clean['factor_to_parent'] === '' ? 1 : $clean['factor_to_parent'];
            $clean['rounding_mode'] = $clean['rounding_mode'] ?: 'NONE';
        }

        return $clean;
    }

    /** @return array<string, mixed> */
    private function rules(string $type, ?string $companyId): array
    {
        $common = ['code' => ['required', 'string', 'max:80'], 'name' => ['required', 'string', 'max:255'], 'active' => ['boolean']];

        return match ($type) {
            'items' => [
                ...$common,
                'base_unit_code' => ['required', 'string', 'exists:units,code'],
                'base_unit_id' => ['required', 'uuid'],
                'category_code' => ['nullable', 'string', 'exists:item_categories,code'],
                'item_type' => ['required', Rule::in(['RAW_MATERIAL', 'PACKAGING', 'SEMI_FINISHED', 'FINISHED_GOOD', 'SPARE_PART'])],
                'barcode' => ['nullable', 'string', 'max:255'],
                'lot_managed' => ['boolean'], 'expiry_managed' => ['boolean'],
                'minimum_stock' => ['nullable', 'numeric', 'min:0'], 'shelf_life_days' => ['nullable', 'integer', 'min:0'],
            ],
            'item-packagings' => [
                'article_code' => ['required', 'string', 'max:80', 'exists:items,code'],
                'item_id' => ['required', 'uuid', 'exists:items,id'],
                'unit_code' => ['required', 'string', 'max:20', 'exists:units,code'],
                'unit_id' => ['required', 'uuid', 'exists:units,id'],
                'parent_unit_code' => ['nullable', 'string', 'max:20', 'exists:units,code', 'different:unit_code'],
                'parent_unit_id' => ['nullable', 'uuid', 'exists:units,id', 'different:unit_id'],
                'factor_to_parent' => ['required', 'numeric', 'gt:0', 'max:1000000000'],
                'barcode' => ['nullable', 'string', 'max:120'],
                'net_weight_kg' => ['nullable', 'numeric', 'min:0'],
                'gross_weight_kg' => ['nullable', 'numeric', 'min:0', 'gte:net_weight_kg'],
                'tare_weight_kg' => ['nullable', 'numeric', 'min:0'],
                'length_cm' => ['nullable', 'numeric', 'min:0'],
                'width_cm' => ['nullable', 'numeric', 'min:0'],
                'height_cm' => ['nullable', 'numeric', 'min:0'],
                'purchasing_unit' => ['boolean'], 'sales_unit' => ['boolean'],
                'production_unit' => ['boolean'], 'inventory_unit' => ['boolean'],
                'fractional_allowed' => ['boolean'],
                'rounding_mode' => ['required', Rule::in(['NONE', 'UP', 'DOWN', 'NEAREST'])],
                'valid_from' => ['nullable', 'date_format:Y-m-d'],
                'valid_to' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:valid_from'],
                'active' => ['boolean'],
            ],
            'customers' => [
                ...$common, 'company_id' => ['required', 'uuid', 'exists:companies,id'],
                'country_code' => ['nullable', 'string', 'size:2'], 'currency_code' => ['nullable', 'string', 'size:3', 'exists:currencies,code'],
                'payment_terms_days' => ['nullable', 'integer', 'between:0,3650'], 'credit_limit' => ['nullable', 'numeric', 'min:0'],
                'tax_exempt' => ['boolean'], 'status' => ['nullable', Rule::in(['PROSPECT', 'APPROVED', 'SUSPENDED', 'BLOCKED'])],
                'legal_name' => ['nullable', 'string', 'max:255'],
                'tax_identifier' => ['nullable', 'string', 'max:120'],
                'registration_number' => ['nullable', 'string', 'max:120'],
                'email' => ['nullable', 'email'],
                'statistical_identification_number' => ['nullable', 'string', 'max:120'],
                'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            ],
            'suppliers' => [
                ...$common, 'company_id' => ['required', 'uuid', 'exists:companies,id'],
                'supplier_type' => ['nullable', Rule::in(['LOCAL', 'IMPORT', 'SERVICE'])],
                'country_code' => ['nullable', 'string', 'size:2'], 'currency_code' => ['nullable', 'string', 'size:3', 'exists:currencies,code'],
                'payment_terms_days' => ['nullable', 'integer', 'between:0,3650'], 'lead_time_days' => ['nullable', 'integer', 'between:0,3650'],
                'minimum_order_value' => ['nullable', 'numeric', 'min:0'], 'preferred' => ['boolean'],
                'status' => ['nullable', Rule::in(['PROSPECT', 'APPROVED', 'SUSPENDED', 'BLOCKED'])],
                'legal_name' => ['nullable', 'string', 'max:255'],
                'tax_identifier' => ['nullable', 'string', 'max:120'],
                'registration_number' => ['nullable', 'string', 'max:120'],
                'email' => ['nullable', 'email'],
                'statistical_identification_number' => ['nullable', 'string', 'max:120'],
                'article_of_imposition_number' => ['nullable', 'string', 'max:120'],
            ],
            default => [],
        };
    }

    private function persistItem(array $data, string $mode): array
    {
        $existing = Item::withTrashed()->where('code', $data['code'])->first();
        $action = $this->actionFor($existing !== null, $mode);
        if ($action === 'SKIPPED') {
            return ['action' => $action, 'model_id' => $existing->id];
        }
        $values = collect($data)->only([
            'code', 'name', 'base_unit_id', 'category_id', 'item_type', 'barcode', 'lot_managed',
            'expiry_managed', 'minimum_stock', 'shelf_life_days', 'active',
        ])->all();
        $values = $this->withoutBlankValues($values);
        $values = $this->applyCreateDefaults($values, $existing, [
            'lot_managed' => true, 'expiry_managed' => false, 'minimum_stock' => 0, 'active' => true,
        ]);
        if (! empty($values['barcode']) && ItemUnitConversion::query()
            ->where('barcode', $values['barcode'])
            ->when($existing, fn ($query) => $query->where(fn ($scope) => $scope
                ->where('item_id', '!=', $existing->id)
                ->orWhere('unit_id', '!=', $existing->base_unit_id)))
            ->exists()) {
            throw new DomainException(__('packaging.barcode_already_used'));
        }
        $model = $existing ?: new Item();
        if ($existing?->trashed()) {
            $existing->restore();
        }
        $model->fill($values)->save();
        return ['action' => $existing ? 'UPDATED' : 'CREATED', 'model_id' => $model->id];
    }

    private function persistItemPackaging(array $data, string $mode, ?User $actor): array
    {
        if (! $actor) {
            throw new DomainException(__('messages.forbidden'));
        }

        $item = Item::query()->findOrFail($data['item_id']);
        $existing = ItemUnitConversion::query()
            ->where('item_id', $item->id)
            ->where('unit_id', $data['unit_id'])
            ->first();
        $action = $this->actionFor($existing !== null, $mode);
        if ($action === 'SKIPPED') {
            return ['action' => $action, 'model_id' => $existing->id];
        }

        $values = collect($data)->only([
            'unit_id', 'parent_unit_id', 'factor_to_parent', 'barcode', 'net_weight_kg', 'gross_weight_kg',
            'tare_weight_kg', 'length_cm', 'width_cm', 'height_cm', 'purchasing_unit', 'sales_unit',
            'production_unit', 'inventory_unit', 'fractional_allowed', 'rounding_mode', 'valid_from', 'valid_to', 'active',
        ])->all();
        $values = $this->withoutBlankValues($values);
        $values = $this->applyCreateDefaults($values, $existing, [
            'factor_to_parent' => 1, 'purchasing_unit' => false, 'sales_unit' => false,
            'production_unit' => false, 'inventory_unit' => false, 'fractional_allowed' => false,
            'rounding_mode' => 'NONE', 'active' => true,
        ]);

        $model = $this->packaging->save($item, $values, $existing, $actor);
        return ['action' => $existing ? 'UPDATED' : 'CREATED', 'model_id' => $model->id];
    }

    private function persistCustomer(array $data, ?string $companyId, string $mode): array
    {
        $companyId = $data['company_id'] ?? $companyId;
        $existing = Customer::withTrashed()->where('company_id', $companyId)->where('code', $data['code'])->first();
        $action = $this->actionFor($existing !== null, $mode);
        if ($action === 'SKIPPED') {
            return ['action' => $action, 'model_id' => $existing->id];
        }
        $values = collect($data)->only([
            'code', 'name', 'legal_name', 'customer_group_code', 'sales_channel_code', 'tax_identifier',
            'registration_number', 'statistical_identification_number', 'article_of_imposition_number',
            'country_code', 'currency_code', 'payment_terms_days', 'credit_limit',
            'tax_exempt', 'status', 'email', 'phone', 'billing_address', 'shipping_address', 'notes', 'active',
        ])->all();
        $values = $this->withoutBlankValues($values);
        $values = $this->applyCreateDefaults($values, $existing, [
            'country_code' => 'DZ', 'currency_code' => 'DZD', 'payment_terms_days' => 30,
            'credit_limit' => 0, 'tax_exempt' => false, 'status' => 'PROSPECT', 'active' => true,
        ]);
        $model = $existing ?: new Customer(['company_id' => $companyId]);
        if ($existing?->trashed()) {
            $existing->restore();
        }
        $model->fill($values)->save();
        return ['action' => $existing ? 'UPDATED' : 'CREATED', 'model_id' => $model->id];
    }

    private function persistSupplier(array $data, ?string $companyId, string $mode): array
    {
        $companyId = $data['company_id'] ?? $companyId;
        $existing = Supplier::withTrashed()->where('company_id', $companyId)->where('code', $data['code'])->first();
        $action = $this->actionFor($existing !== null, $mode);
        if ($action === 'SKIPPED') {
            return ['action' => $action, 'model_id' => $existing->id];
        }
        $values = collect($data)->only([
            'code', 'name', 'legal_name', 'supplier_type', 'tax_identifier', 'registration_number',
            'statistical_identification_number', 'article_of_imposition_number', 'country_code', 'currency_code', 'payment_terms_days', 'incoterm', 'lead_time_days',
            'minimum_order_value', 'status', 'preferred', 'email', 'phone', 'address', 'notes', 'active',
        ])->all();
        $values = $this->withoutBlankValues($values);
        $values = $this->applyCreateDefaults($values, $existing, [
            'supplier_type' => 'LOCAL', 'country_code' => 'DZ', 'currency_code' => 'DZD',
            'payment_terms_days' => 30, 'lead_time_days' => 0, 'minimum_order_value' => 0,
            'status' => 'PROSPECT', 'preferred' => false, 'active' => true,
        ]);
        $model = $existing ?: new Supplier(['company_id' => $companyId]);
        if ($existing?->trashed()) {
            $existing->restore();
        }
        $model->fill($values)->save();
        return ['action' => $existing ? 'UPDATED' : 'CREATED', 'model_id' => $model->id];
    }

    private function actionFor(bool $exists, string $mode): string
    {
        if (! $exists) {
            return 'CREATED';
        }
        return match ($mode) {
            'SKIP' => 'SKIPPED',
            'FAIL' => throw new DomainException(__('productivity.existing_record_error')),
            default => 'UPDATED',
        };
    }

    private function withoutBlankValues(array $values): array
    {
        return array_filter(
            $values,
            static fn (mixed $value): bool => $value !== null && $value !== '',
        );
    }

    private function applyCreateDefaults(array $values, ?object $existing, array $defaults): array
    {
        if ($existing) {
            return $values;
        }

        foreach ($defaults as $key => $default) {
            if (! array_key_exists($key, $values) || $values[$key] === null || $values[$key] === '') {
                $values[$key] = $default;
            }
        }

        return $values;
    }

    private function booleanValue(mixed $value, bool $default): bool
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (is_bool($value)) {
            return $value;
        }
        return in_array(Str::lower(trim((string) $value)), ['1', 'true', 'yes', 'oui', 'on', 'active'], true);
    }
}
