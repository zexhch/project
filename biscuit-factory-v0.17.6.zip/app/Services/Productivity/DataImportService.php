<?php

namespace App\Services\Productivity;

use App\Models\DataImportJob;
use App\Models\DataImportRow;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class DataImportService
{
    public function __construct(
        private readonly SpreadsheetFileService $spreadsheets,
        private readonly DataExchangeCatalog $catalog,
    ) {
    }

    public function preview(DataImportJob $job, int $maxRows = 10000): DataImportJob
    {
        $job->loadMissing('user');
        abort_unless($job->user, 422);
        $this->catalog->assertAuthorized($job->user, $job->import_type, 'write');

        $path = Storage::disk($job->file_disk)->path($job->file_path);
        $headers = [];
        $expected = $this->catalog->headers($job->import_type);
        $seen = 0;
        $valid = 0;
        $invalid = 0;
        $seenKeys = [];

        DB::transaction(function () use ($job, $path, $maxRows, $expected, &$headers, &$seen, &$valid, &$invalid, &$seenKeys): void {
            $job->rows()->delete();

            foreach ($this->spreadsheets->rows($path, $job->source_format) as $index => $values) {
                if ($index === 0) {
                    $headers = array_map([$this, 'normalizeHeader'], $values);
                    $missing = array_values(array_diff(array_keys(array_filter($this->catalog->definition($job->import_type)['columns'])), $headers));
                    if ($missing !== []) {
                        throw new RuntimeException(__('productivity.missing_columns', ['columns' => implode(', ', $missing)]));
                    }
                    continue;
                }

                if ($this->emptyRow($values)) {
                    continue;
                }
                if ($seen >= $maxRows) {
                    throw new RuntimeException(__('productivity.import_row_limit', ['count' => $maxRows]));
                }

                $seen++;
                $payload = [];
                foreach ($headers as $column => $header) {
                    if ($header !== '') {
                        $payload[$header] = $values[$column] ?? null;
                    }
                }
                $validation = $this->catalog->validateRow($job->import_type, $payload, $job->company_id);
                $action = null;
                if ($validation['errors'] === []) {
                    $rowKey = $this->catalog->rowKey($job->import_type, $validation['normalized'], $job->company_id);
                    if (isset($seenKeys[$rowKey])) {
                        $validation['errors']['code'] = [__('productivity.duplicate_import_key', ['row' => $seenKeys[$rowKey]])];
                    } else {
                        $seenKeys[$rowKey] = $index + 1;
                        try {
                            $action = $this->catalog->previewAction($job->import_type, $validation['normalized'], $job->company_id, $job->existing_mode);
                        } catch (\Throwable $exception) {
                            $validation['errors']['record'] = [$exception->getMessage()];
                        }
                    }
                }
                $rowValid = $validation['errors'] === [];
                $rowValid ? $valid++ : $invalid++;

                DataImportRow::create([
                    'data_import_job_id' => $job->id,
                    'row_number' => $index + 1,
                    'status' => $rowValid ? 'VALID' : 'INVALID',
                    'action' => $action,
                    'payload' => $payload,
                    'normalized_payload' => $validation['normalized'],
                    'errors' => $validation['errors'] ?: null,
                ]);
            }

            $job->update([
                'status' => 'PREVIEW',
                'total_rows' => $seen,
                'valid_rows' => $valid,
                'invalid_rows' => $invalid,
                'error_message' => null,
            ]);
        });

        return $job->refresh();
    }

    public function process(DataImportJob $job): DataImportJob
    {
        $job->loadMissing('user');
        abort_unless($job->user, 422);
        $this->catalog->assertAuthorized($job->user, $job->import_type, 'write');
        $job->update(['status' => 'PROCESSING', 'started_at' => now(), 'error_message' => null]);
        $counters = ['processed_rows' => 0, 'created_rows' => 0, 'updated_rows' => 0, 'skipped_rows' => 0, 'failed_rows' => 0];
        $abortOnError = (bool) data_get($job->options, 'abort_on_error', false);

        try {
            $rowIds = $job->rows()
                ->where('status', 'VALID')
                ->orderBy('row_number')
                ->pluck('id');

            foreach ($rowIds->chunk(250) as $chunkIds) {
                $rows = $job->rows()
                    ->whereIn('id', $chunkIds->all())
                    ->orderBy('row_number')
                    ->get();

                foreach ($rows as $row) {
                    try {
                        $result = DB::transaction(fn (): array => $this->catalog->persist(
                            $job->import_type,
                            $row->normalized_payload ?? [],
                            $job->company_id,
                            $job->existing_mode,
                            $job->user,
                        ));
                        $row->update(['status' => 'PROCESSED', 'action' => $result['action'], 'errors' => null]);
                        $counters['processed_rows']++;
                        $counter = strtolower($result['action']).'_rows';
                        if (array_key_exists($counter, $counters)) {
                            $counters[$counter]++;
                        }
                    } catch (Throwable $exception) {
                        $row->update(['status' => 'FAILED', 'errors' => ['processing' => [$exception->getMessage()]]]);
                        $counters['processed_rows']++;
                        $counters['failed_rows']++;
                        if ($abortOnError) {
                            throw $exception;
                        }
                    }
                }

                $job->update($counters);
            }

            $job->update([...$counters, 'status' => $counters['failed_rows'] > 0 ? 'COMPLETED_WITH_ERRORS' : 'COMPLETED', 'completed_at' => now()]);
        } catch (Throwable $exception) {
            $job->update([...$counters, 'status' => 'FAILED', 'error_message' => Str::limit($exception->getMessage(), 5000), 'completed_at' => now()]);
            throw $exception;
        }

        return $job->refresh();
    }

    private function normalizeHeader(mixed $value): string
    {
        return Str::of((string) $value)->trim()->lower()->ascii()->replaceMatches('/[^a-z0-9]+/', '_')->trim('_')->toString();
    }

    private function emptyRow(array $values): bool
    {
        return collect($values)->every(fn ($value): bool => $value === null || trim((string) $value) === '');
    }
}
