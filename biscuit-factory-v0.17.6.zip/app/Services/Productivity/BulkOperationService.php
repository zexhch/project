<?php

namespace App\Services\Productivity;

use App\Models\BulkOperationRun;
use App\Models\Customer;
use App\Models\Item;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

class BulkOperationService
{
    /** @return array<string, array<string, string>> */
    public function resources(): array
    {
        return [
            'items' => ['label' => 'productivity.items', 'model' => Item::class, 'permission' => 'catalog.update'],
            'customers' => ['label' => 'productivity.customers', 'model' => Customer::class, 'permission' => 'sales.update'],
            'suppliers' => ['label' => 'productivity.suppliers', 'model' => Supplier::class, 'permission' => 'purchasing.update'],
        ];
    }

    /** @return array<string, array<string, string>> */
    public function availableResources(User $user): array
    {
        return collect($this->resources())
            ->filter(fn (array $definition): bool => $user->hasPermission($definition['permission']))
            ->all();
    }

    public function execute(User $user, string $resource, string $action, array $codes): BulkOperationRun
    {
        $definition = $this->resources()[$resource] ?? abort(422);
        abort_unless($user->hasPermission($definition['permission']), 403);
        $codes = collect($codes)->map(fn ($code) => Str::upper(trim((string) $code)))->filter()->unique()->take(1000)->values();
        $run = BulkOperationRun::create([
            'user_id' => $user->id, 'resource_type' => $resource, 'action' => $action,
            'requested_count' => $codes->count(), 'processed_count' => 0, 'failed_count' => 0,
        ]);
        $errors = [];
        $processed = 0;

        foreach ($codes as $code) {
            try {
                DB::transaction(function () use ($definition, $code, $action, $user, $resource): void {
                    /** @var Model|null $model */
                    $model = $definition['model']::withTrashed()->where('code', $code)->lockForUpdate()->first();
                    if (! $model) {
                        throw new \DomainException(__('productivity.record_not_found', ['code' => $code]));
                    }
                    $old = ['active' => (bool) $model->active, 'deleted_at' => $model->deleted_at?->toISOString()];
                    match ($action) {
                        'ACTIVATE' => $model->update(['active' => true]),
                        'DEACTIVATE' => $model->update(['active' => false]),
                        'RESTORE' => $model->trashed() ? $model->restore() : null,
                        default => throw new \DomainException(__('productivity.invalid_bulk_action')),
                    };
                    DB::table('audit_logs')->insert([
                        'id' => (string) Str::uuid(), 'user_id' => $user->id, 'event' => 'productivity.bulk.'.strtolower($action),
                        'auditable_type' => $model::class, 'auditable_id' => $model->getKey(),
                        'old_values' => json_encode($old, JSON_THROW_ON_ERROR),
                        'new_values' => json_encode(['resource' => $resource, 'code' => $code, 'active' => (bool) $model->fresh()->active], JSON_THROW_ON_ERROR),
                        'ip_address' => request()->ip(), 'user_agent' => request()->userAgent(), 'created_at' => now(),
                    ]);
                });
                $processed++;
            } catch (Throwable $exception) {
                $errors[$code] = $exception->getMessage();
            }
        }

        $run->update(['processed_count' => $processed, 'failed_count' => count($errors), 'errors' => $errors ?: null]);
        return $run->refresh();
    }
}
