<?php

namespace App\Services\Operations;

use App\Models\BackupRun;
use App\Models\SystemHealthSnapshot;
use App\Models\User;
use App\Services\System\SystemHealthService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class OperationsStatusService
{
    public function __construct(private readonly SystemHealthService $health)
    {
    }

    public function dashboard(): array
    {
        $readiness = $this->health->readiness(true);

        return [
            'readiness' => $readiness,
            'active_sessions' => Schema::hasTable('sessions') ? DB::table('sessions')->whereNotNull('user_id')->count() : 0,
            'locked_users' => User::query()->whereNotNull('locked_until')->where('locked_until', '>', now())->count(),
            'failed_jobs' => Schema::hasTable('failed_jobs') ? DB::table('failed_jobs')->count() : 0,
            'queued_jobs' => Schema::hasTable('jobs') ? DB::table('jobs')->count() : 0,
            'last_backup' => BackupRun::query()->latest('started_at')->first(),
            'recent_snapshots' => SystemHealthSnapshot::query()->latest('captured_at')->limit(24)->get(),
        ];
    }

    public function capture(): SystemHealthSnapshot
    {
        $result = $this->health->readiness(true);

        return SystemHealthSnapshot::query()->create([
            'overall_status' => $result['status'],
            'failed_checks' => $result['failed_checks'],
            'warnings' => $result['warnings'],
            'checks' => $result['checks'],
            'captured_at' => now(),
        ]);
    }
}
