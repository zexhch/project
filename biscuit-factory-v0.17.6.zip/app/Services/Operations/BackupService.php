<?php

namespace App\Services\Operations;

use App\Models\BackupRun;
use App\Models\BackupSchedule;
use App\Notifications\SystemAlertNotification;
use App\Services\Security\SecurityAuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use Symfony\Component\Process\Process;
use Throwable;
use ZipArchive;

class BackupService
{
    public function __construct(
        private readonly BackupScheduleService $schedules,
        private readonly SecurityAuditService $audit,
    ) {
    }

    public function run(?BackupSchedule $schedule = null, ?string $initiatedBy = null): BackupRun
    {
        $run = BackupRun::query()->create([
            'backup_schedule_id' => $schedule?->id,
            'initiated_by' => $initiatedBy,
            'status' => 'RUNNING',
            'type' => $schedule?->include_files === false ? 'DATABASE' : 'DATABASE_AND_FILES',
            'disk' => 'local',
            'started_at' => now(),
        ]);

        $workDirectory = storage_path('app/private/backups/.work-'.$run->id);
        $backupDirectory = storage_path('app/private/backups');
        @mkdir($workDirectory, 0770, true);
        @mkdir($backupDirectory, 0770, true);

        $absolutePath = null;

        try {
            $databasePath = $workDirectory.'/database.dump';
            $this->dumpDatabase($databasePath);

            $timestamp = now()->format('Ymd-His');
            if ($schedule?->include_files === false) {
                $relativePath = "backups/biscuit-factory-{$timestamp}-{$run->id}.dump";
                $absolutePath = Storage::disk('local')->path($relativePath);
                rename($databasePath, $absolutePath);
            } else {
                $relativePath = "backups/biscuit-factory-{$timestamp}-{$run->id}.zip";
                $absolutePath = Storage::disk('local')->path($relativePath);
                $this->buildArchive($absolutePath, $databasePath);
            }

            $run->update([
                'status' => 'COMPLETED',
                'path' => $relativePath,
                'size_bytes' => filesize($absolutePath) ?: null,
                'checksum_sha256' => hash_file('sha256', $absolutePath),
                'completed_at' => now(),
            ]);

            $this->audit->record('operations.backup.completed', null, 'notice', [
                'backup_run_id' => $run->id,
                'backup_schedule_id' => $schedule?->id,
                'type' => $run->type,
                'size_bytes' => $run->size_bytes,
                'checksum_sha256' => $run->checksum_sha256,
            ], $run);
            $this->notify($schedule, $run, true);
        } catch (Throwable $exception) {
            if ($absolutePath && is_file($absolutePath)) {
                @unlink($absolutePath);
            }
            report($exception);
            $run->update([
                'status' => 'FAILED',
                'error_message' => Str::limit($exception->getMessage(), 4000),
                'completed_at' => now(),
            ]);
            $this->audit->record('operations.backup.failed', null, 'error', [
                'backup_run_id' => $run->id,
                'backup_schedule_id' => $schedule?->id,
                'type' => $run->type,
                'error' => Str::limit($exception->getMessage(), 1000),
            ], $run);
            $this->notify($schedule, $run, false);
        } finally {
            $this->deleteDirectory($workDirectory);
            if ($schedule) {
                $schedule->update([
                    'last_run_at' => now(),
                    'next_run_at' => $this->schedules->nextRun($schedule),
                ]);
            }
        }

        return $run->fresh();
    }

    public function prune(int $defaultDays = 30): int
    {
        $count = 0;

        BackupRun::query()->with('schedule')->orderBy('created_at')->chunkById(100, function ($runs) use (&$count, $defaultDays): void {
            foreach ($runs as $run) {
                $retentionDays = max(1, (int) ($run->schedule?->retention_days ?? $defaultDays));
                if ($run->created_at->gte(now()->subDays($retentionDays))) {
                    continue;
                }
                if ($run->path) {
                    Storage::disk($run->disk ?: 'local')->delete($run->path);
                }
                $run->delete();
                $count++;
            }
        });

        return $count;
    }

    public function reconcile(): array
    {
        $interrupted = BackupRun::query()
            ->where('status', 'RUNNING')
            ->update([
                'status' => 'FAILED',
                'error_message' => 'Exécution interrompue ou restaurée avant finalisation.',
                'completed_at' => now(),
                'updated_at' => now(),
            ]);

        $missing = 0;
        BackupRun::query()
            ->where('status', 'COMPLETED')
            ->whereNotNull('path')
            ->orderBy('created_at')
            ->chunkById(100, function ($runs) use (&$missing): void {
                foreach ($runs as $run) {
                    if (Storage::disk($run->disk ?: 'local')->exists($run->path)) {
                        continue;
                    }

                    $run->update([
                        'status' => 'EXPIRED',
                        'error_message' => 'Fichier de sauvegarde absent après restauration ou rétention.',
                    ]);
                    $missing++;
                }
            });

        return ['interrupted' => $interrupted, 'missing' => $missing];
    }

    private function dumpDatabase(string $path): void
    {
        if ((string) config('database.default') !== 'pgsql') {
            throw new \RuntimeException('Les sauvegardes applicatives nécessitent PostgreSQL.');
        }

        $this->assertCompatiblePgDump();
        $connection = config('database.connections.pgsql');
        $process = new Process([
            'pg_dump', '--format=custom', '--no-owner', '--no-acl',
            '--exclude-table-data=sessions',
            '--exclude-table-data=cache',
            '--exclude-table-data=cache_locks',
            '--exclude-table-data=jobs',
            '--exclude-table-data=job_batches',
            '--exclude-table-data=failed_jobs',
            '--exclude-table-data=backup_runs',
            '--host='.(string) $connection['host'],
            '--port='.(string) $connection['port'],
            '--username='.(string) $connection['username'],
            '--file='.$path,
            (string) $connection['database'],
        ], base_path(), ['PGPASSWORD' => (string) $connection['password']]);
        $process->setTimeout(1800);
        $process->mustRun();
    }

    private function assertCompatiblePgDump(): void
    {
        $versionProcess = new Process(['pg_dump', '--version']);
        $versionProcess->setTimeout(30);
        $versionProcess->mustRun();

        if (! preg_match('/(?:PostgreSQL\)?\s*)(\d+)(?:\.\d+)?/i', trim($versionProcess->getOutput()), $matches)) {
            throw new \RuntimeException('Version de pg_dump impossible à déterminer.');
        }

        $clientMajor = (int) $matches[1];
        $serverVersion = (int) (DB::selectOne('show server_version_num')->server_version_num ?? 0);
        $serverMajor = intdiv($serverVersion, 10000);

        if ($serverMajor > 0 && $clientMajor < $serverMajor) {
            throw new \RuntimeException("pg_dump {$clientMajor} est incompatible avec PostgreSQL {$serverMajor}. Reconstruire l’image applicative.");
        }
    }

    private function buildArchive(string $archivePath, string $databasePath): void
    {
        $zip = new ZipArchive();
        if ($zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Impossible de créer l’archive de sauvegarde.');
        }

        $zip->addFile($databasePath, 'database.dump');
        $root = storage_path('app/private');
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY,
        );

        foreach ($iterator as $file) {
            $realPath = $file->getRealPath();
            if (! $realPath || ! $file->isFile() || str_starts_with($realPath, storage_path('app/private/backups'))) {
                continue;
            }
            $relative = ltrim(str_replace($root, '', $realPath), DIRECTORY_SEPARATOR);
            $zip->addFile($realPath, 'files/'.str_replace(DIRECTORY_SEPARATOR, '/', $relative));
        }

        if (! $zip->close()) {
            throw new \RuntimeException('Impossible de finaliser l’archive de sauvegarde.');
        }
    }

    private function notify(?BackupSchedule $schedule, BackupRun $run, bool $success): void
    {
        $user = $schedule?->notificationUser;
        if (! $user) {
            return;
        }

        $user->notify(new SystemAlertNotification(
            $success ? __('operations.backup_completed') : __('operations.backup_failed'),
            $success ? __('operations.backup_completed_message') : __('operations.backup_failed_message'),
            $success ? 'success' : 'danger',
            route('admin.operations.index'),
            'backup:'.$run->id,
        ));
    }

    private function deleteDirectory(string $directory): void
    {
        if (! is_dir($directory)) {
            return;
        }

        $items = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($items as $item) {
            $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
        }
        rmdir($directory);
    }
}
