<?php

namespace App\Services\Operations;

use App\Models\BackupSchedule;
use Carbon\CarbonImmutable;

class BackupScheduleService
{
    public function nextRun(BackupSchedule|array $schedule, ?CarbonImmutable $from = null): CarbonImmutable
    {
        $from ??= CarbonImmutable::now();
        $frequency = strtoupper((string) data_get($schedule, 'frequency', 'DAILY'));
        $hour = max(0, min(23, (int) data_get($schedule, 'run_hour', 2)));
        $candidate = $from->startOfDay()->setHour($hour);

        if ($frequency === 'WEEKLY') {
            $weekday = max(0, min(6, (int) data_get($schedule, 'weekday', 1)));
            $delta = ($weekday - $candidate->dayOfWeek + 7) % 7;
            $candidate = $candidate->addDays($delta);
            if ($candidate->lte($from)) {
                $candidate = $candidate->addWeek();
            }

            return $candidate;
        }

        if ($frequency === 'MONTHLY') {
            $day = max(1, min(28, (int) data_get($schedule, 'month_day', 1)));
            $candidate = $candidate->day($day);
            if ($candidate->lte($from)) {
                $candidate = $candidate->addMonthNoOverflow()->day($day);
            }

            return $candidate;
        }

        if ($candidate->lte($from)) {
            $candidate = $candidate->addDay();
        }

        return $candidate;
    }
}
