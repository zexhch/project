<?php

namespace App\Services\Finance;

use App\Models\CustomerCreditNote;
use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\DeliveryNote;
use App\Models\FinancialAccount;
use App\Models\GoodsReceipt;
use App\Models\SupplierCreditNote;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use App\Models\SystemSetting;
use App\Services\Finance\Governance\AccountingPeriodService;
use App\Services\Finance\Governance\ApprovalService;
use App\Services\Finance\Governance\DocumentNumberService;
use App\Services\Finance\Governance\DocumentRevisionService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class BillingService
{
    public function __construct(
        private readonly AccountingPeriodService $periods,
        private readonly DocumentNumberService $numbers,
        private readonly ApprovalService $approvals,
        private readonly DocumentRevisionService $revisions,
    ) {
    }

    public function createCustomerInvoice(DeliveryNote $delivery, Carbon $invoiceDate, ?string $notes, string $userId): CustomerInvoice
    {
        return DB::transaction(function () use ($delivery, $invoiceDate, $notes, $userId): CustomerInvoice {
            $delivery = DeliveryNote::query()->with([
                'salesOrder.company', 'salesOrder.site', 'salesOrder.customer',
                'lines.salesOrderLine.taxRate', 'lines.salesOrderLine.item', 'lines.salesOrderLine.unit',
            ])->lockForUpdate()->findOrFail($delivery->id);

            if ($delivery->status !== 'POSTED') {
                throw ValidationException::withMessages(['delivery_note_id' => __('billing.delivery_must_be_posted')]);
            }
            if (CustomerInvoice::query()->where('delivery_note_id', $delivery->id)->exists()) {
                throw ValidationException::withMessages(['delivery_note_id' => __('billing.delivery_already_invoiced')]);
            }

            $order = $delivery->salesOrder;
            $this->periods->assertOpen($order->company_id, $invoiceDate, __('governance.operation_create_invoice'));
            $terms = (int) ($order->payment_terms_days ?: $order->customer->payment_terms_days ?: 30);
            $invoice = CustomerInvoice::create([
                'company_id' => $order->company_id,
                'site_id' => $order->site_id,
                'customer_id' => $order->customer_id,
                'sales_order_id' => $order->id,
                'delivery_note_id' => $delivery->id,
                'invoice_number' => $this->numbers->next($order->company_id, FinancialDocumentCatalog::CUSTOMER_INVOICE, $invoiceDate),
                'invoice_date' => $invoiceDate->toDateString(),
                'due_date' => $invoiceDate->copy()->addDays($terms)->toDateString(),
                'currency_code' => $order->currency_code,
                'exchange_rate' => $order->exchange_rate,
                'status' => 'DRAFT',
                'payment_terms_days' => $terms,
                'customer_reference' => $order->customer_reference,
                'notes' => $notes,
                'created_by' => $userId,
            ]);

            foreach ($delivery->lines as $deliveryLine) {
                $source = $deliveryLine->salesOrderLine;
                $quantity = (float) $deliveryLine->quantity;
                $subtotal = round($quantity * (float) $source->net_unit_price, 4);
                $rate = (float) ($source->taxRate?->rate ?? 0);
                $tax = round($subtotal * $rate / 100, 4);
                $invoice->lines()->create([
                    'delivery_note_line_id' => $deliveryLine->id,
                    'sales_order_line_id' => $source->id,
                    'item_id' => $source->item_id,
                    'description' => $source->description ?: $source->item?->name ?: __('billing.delivery_line'),
                    'quantity' => $quantity,
                    'unit_id' => $source->unit_id,
                    'unit_price' => $source->unit_price,
                    'discount_percentage' => $source->discount_percentage,
                    'tax_rate_id' => $source->tax_rate_id,
                    'line_subtotal' => $subtotal,
                    'tax_amount' => $tax,
                    'line_total' => round($subtotal + $tax, 4),
                ]);
            }

            $this->recalculateCustomerInvoice($invoice);
            $this->audit('finance.customer_invoice.created', $invoice, $userId);
            $this->revisions->record($invoice, 'CREATED', $userId);

            return $invoice->fresh(['customer', 'lines.item']);
        });
    }

    public function issueCustomerInvoice(CustomerInvoice $invoice, string $userId): CustomerInvoice
    {
        return DB::transaction(function () use ($invoice, $userId): CustomerInvoice {
            $invoice = CustomerInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            if (! in_array($invoice->status, ['DRAFT', 'REJECTED'], true) || ! $invoice->lines()->exists()) {
                throw ValidationException::withMessages(['invoice' => __('billing.invoice_not_issuable')]);
            }
            $this->periods->assertOpen($invoice->company_id, $invoice->invoice_date, __('governance.operation_issue_invoice'));

            $request = $this->approvals->submit(
                $invoice,
                FinancialDocumentCatalog::CUSTOMER_INVOICE,
                $invoice->company_id,
                (float) $invoice->total_amount,
                $invoice->currency_code,
                $userId,
            );

            if ($request && $request->status === 'PENDING') {
                $invoice->update(['status' => 'PENDING_APPROVAL']);
                $this->audit('finance.customer_invoice.submitted_for_approval', $invoice, $userId);
                $this->revisions->record($invoice, 'SUBMITTED_FOR_APPROVAL', $userId);
                return $invoice->fresh();
            }

            $invoice->update(['status' => 'ISSUED', 'issued_by' => $userId, 'issued_at' => now()]);
            $this->recalculateCustomerInvoice($invoice);
            $this->audit('finance.customer_invoice.issued', $invoice, $userId);
            $this->revisions->record($invoice, 'ISSUED', $userId);
            return $invoice->fresh();
        });
    }

    public function createSupplierInvoice(GoodsReceipt $receipt, Carbon $invoiceDate, string $supplierNumber, float $declaredTotal, ?string $notes, string $userId): SupplierInvoice
    {
        return DB::transaction(function () use ($receipt, $invoiceDate, $supplierNumber, $declaredTotal, $notes, $userId): SupplierInvoice {
            $receipt = GoodsReceipt::query()->with([
                'purchaseOrder.company', 'purchaseOrder.site', 'purchaseOrder.supplier',
                'lines.purchaseOrderLine.taxRate', 'lines.purchaseOrderLine.item', 'lines.purchaseOrderLine.unit',
            ])->lockForUpdate()->findOrFail($receipt->id);

            if ($receipt->status !== 'POSTED') {
                throw ValidationException::withMessages(['goods_receipt_id' => __('billing.receipt_must_be_posted')]);
            }
            if (SupplierInvoice::query()->where('goods_receipt_id', $receipt->id)->exists()) {
                throw ValidationException::withMessages(['goods_receipt_id' => __('billing.receipt_already_invoiced')]);
            }

            $order = $receipt->purchaseOrder;
            $this->periods->assertOpen($order->company_id, $invoiceDate, __('governance.operation_create_invoice'));
            $terms = (int) ($order->payment_terms_days ?: $order->supplier->payment_terms_days ?: 30);
            $invoice = SupplierInvoice::create([
                'company_id' => $order->company_id,
                'site_id' => $order->site_id,
                'supplier_id' => $order->supplier_id,
                'purchase_order_id' => $order->id,
                'goods_receipt_id' => $receipt->id,
                'invoice_number' => $this->numbers->next($order->company_id, FinancialDocumentCatalog::SUPPLIER_INVOICE, $invoiceDate),
                'supplier_invoice_number' => $supplierNumber,
                'invoice_date' => $invoiceDate->toDateString(),
                'due_date' => $invoiceDate->copy()->addDays($terms)->toDateString(),
                'currency_code' => $order->currency_code,
                'exchange_rate' => $order->exchange_rate,
                'status' => 'DRAFT',
                'matching_status' => 'PENDING',
                'payment_terms_days' => $terms,
                'notes' => $notes,
                'created_by' => $userId,
            ]);

            $expectedTotal = 0.0;
            foreach ($receipt->lines as $receiptLine) {
                $source = $receiptLine->purchaseOrderLine;
                $quantity = (float) $receiptLine->accepted_quantity;
                if ($quantity <= 0) {
                    continue;
                }
                $subtotal = round($quantity * (float) $source->net_unit_price, 4);
                $rate = (float) ($source->taxRate?->rate ?? 0);
                $tax = round($subtotal * $rate / 100, 4);
                $total = round($subtotal + $tax, 4);
                $expectedTotal += $total;
                $invoice->lines()->create([
                    'goods_receipt_line_id' => $receiptLine->id,
                    'purchase_order_line_id' => $source->id,
                    'item_id' => $source->item_id,
                    'description' => $source->description ?: $source->item?->name ?: __('billing.receipt_line'),
                    'quantity' => $quantity,
                    'unit_id' => $source->unit_id,
                    'unit_price' => $source->unit_price,
                    'discount_percentage' => $source->discount_percentage,
                    'tax_rate_id' => $source->tax_rate_id,
                    'line_subtotal' => $subtotal,
                    'tax_amount' => $tax,
                    'line_total' => $total,
                ]);
            }

            $variance = round($declaredTotal - $expectedTotal, 4);
            if (abs($variance) > 0.0001) {
                $invoice->lines()->create([
                    'description' => __('billing.supplier_invoice_adjustment'),
                    'quantity' => 1,
                    'unit_price' => $variance,
                    'line_subtotal' => $variance,
                    'tax_amount' => 0,
                    'line_total' => $variance,
                ]);
            }

            $this->recalculateSupplierInvoice($invoice);
            $tolerance = $this->matchingTolerance($invoice->company_id);
            $invoice->update([
                'matching_variance_amount' => $variance,
                'matching_status' => abs($variance) <= $tolerance ? 'MATCHED' : 'VARIANCE',
            ]);
            $this->audit('finance.supplier_invoice.created', $invoice, $userId);
            $this->revisions->record($invoice, 'CREATED', $userId);

            return $invoice->fresh(['supplier', 'lines.item']);
        });
    }

    public function approveSupplierInvoice(SupplierInvoice $invoice, string $userId, bool $acceptVariance = false): SupplierInvoice
    {
        return DB::transaction(function () use ($invoice, $userId, $acceptVariance): SupplierInvoice {
            $invoice = SupplierInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            if (! in_array($invoice->status, ['DRAFT', 'REJECTED'], true) || ! $invoice->lines()->exists()) {
                throw ValidationException::withMessages(['invoice' => __('billing.invoice_not_issuable')]);
            }
            if ($invoice->matching_status === 'VARIANCE' && ! $acceptVariance) {
                throw ValidationException::withMessages(['accept_variance' => __('billing.variance_requires_approval')]);
            }
            $this->periods->assertOpen($invoice->company_id, $invoice->invoice_date, __('governance.operation_approve_invoice'));

            $request = $this->approvals->submit(
                $invoice,
                FinancialDocumentCatalog::SUPPLIER_INVOICE,
                $invoice->company_id,
                (float) $invoice->total_amount,
                $invoice->currency_code,
                $userId,
            );

            if ($request && $request->status === 'PENDING') {
                $invoice->update(['status' => 'PENDING_APPROVAL']);
                $this->audit('finance.supplier_invoice.submitted_for_approval', $invoice, $userId);
                $this->revisions->record($invoice, 'SUBMITTED_FOR_APPROVAL', $userId);
                return $invoice->fresh();
            }

            $invoice->update(['status' => 'ISSUED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->recalculateSupplierInvoice($invoice);
            $this->audit('finance.supplier_invoice.approved', $invoice, $userId);
            $this->revisions->record($invoice, 'APPROVED', $userId);
            return $invoice->fresh();
        });
    }

    public function issueCustomerCredit(CustomerInvoice $invoice, float $amount, string $reason, ?string $reasonCode, string $userId): CustomerCreditNote
    {
        return DB::transaction(function () use ($invoice, $amount, $reason, $reasonCode, $userId): CustomerCreditNote {
            $invoice = CustomerInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            $this->ensureOpenInvoice($invoice);
            $this->periods->assertOpen($invoice->company_id, today(), __('governance.operation_issue_credit'));
            if ($amount > (float) $invoice->balance_amount + 0.0001) {
                throw ValidationException::withMessages(['total_amount' => __('billing.credit_exceeds_balance')]);
            }
            $credit = CustomerCreditNote::create([
                'customer_invoice_id' => $invoice->id,
                'customer_id' => $invoice->customer_id,
                'credit_note_number' => $this->numbers->next($invoice->company_id, FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE, today()),
                'credit_note_date' => today(),
                'currency_code' => $invoice->currency_code,
                'status' => 'ISSUED',
                'total_amount' => $amount,
                'applied_amount' => $amount,
                'reason_code' => $reasonCode,
                'reason' => $reason,
                'created_by' => $userId,
                'issued_by' => $userId,
                'issued_at' => now(),
            ]);
            $this->recalculateCustomerInvoice($invoice);
            $this->audit('finance.customer_credit_note.issued', $credit, $userId);
            $this->revisions->record($credit, 'ISSUED', $userId);
            return $credit;
        });
    }

    public function approveSupplierCredit(SupplierInvoice $invoice, float $amount, string $reason, ?string $reasonCode, ?string $supplierNumber, string $userId): SupplierCreditNote
    {
        return DB::transaction(function () use ($invoice, $amount, $reason, $reasonCode, $supplierNumber, $userId): SupplierCreditNote {
            $invoice = SupplierInvoice::query()->lockForUpdate()->findOrFail($invoice->id);
            $this->ensureOpenInvoice($invoice);
            $this->periods->assertOpen($invoice->company_id, today(), __('governance.operation_issue_credit'));
            if ($amount > (float) $invoice->balance_amount + 0.0001) {
                throw ValidationException::withMessages(['total_amount' => __('billing.credit_exceeds_balance')]);
            }
            $credit = SupplierCreditNote::create([
                'supplier_invoice_id' => $invoice->id,
                'supplier_id' => $invoice->supplier_id,
                'credit_note_number' => $this->numbers->next($invoice->company_id, FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE, today()),
                'supplier_credit_note_number' => $supplierNumber,
                'credit_note_date' => today(),
                'currency_code' => $invoice->currency_code,
                'status' => 'APPROVED',
                'total_amount' => $amount,
                'applied_amount' => $amount,
                'reason_code' => $reasonCode,
                'reason' => $reason,
                'created_by' => $userId,
                'approved_by' => $userId,
                'approved_at' => now(),
            ]);
            $this->recalculateSupplierInvoice($invoice);
            $this->audit('finance.supplier_credit_note.approved', $credit, $userId);
            $this->revisions->record($credit, 'APPROVED', $userId);
            return $credit;
        });
    }

    public function postCustomerPayment(CustomerPayment $payment, string $userId): CustomerPayment
    {
        return DB::transaction(function () use ($payment, $userId): CustomerPayment {
            $payment = CustomerPayment::query()
                ->with(['allocations' => fn ($query) => $query->orderBy('customer_invoice_id')])
                ->lockForUpdate()
                ->findOrFail($payment->id);

            if ($payment->status !== 'DRAFT') {
                throw ValidationException::withMessages(['payment' => __('billing.payment_not_postable')]);
            }

            $this->assertCustomerPaymentContext($payment);
            $this->periods->assertOpen($payment->company_id, $payment->payment_date, __('governance.operation_post_payment'));
            $allocated = round((float) $payment->allocations->sum('amount'), 4);
            if ($allocated > (float) $payment->amount + 0.0001) {
                throw ValidationException::withMessages(['allocations' => __('billing.allocations_exceed_payment')]);
            }
            if (! $this->allowsUnallocatedPayments($payment->company_id) && $allocated + 0.0001 < (float) $payment->amount) {
                throw ValidationException::withMessages(['allocations' => __('billing.unallocated_payment_not_allowed')]);
            }

            $invoiceIds = $payment->allocations->pluck('customer_invoice_id')->unique()->sort()->values();
            $invoices = CustomerInvoice::query()
                ->whereKey($invoiceIds)
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            if ($invoices->count() !== $invoiceIds->count()) {
                throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
            }

            foreach ($payment->allocations as $allocation) {
                $invoice = $this->recalculateCustomerInvoice($invoices->get($allocation->customer_invoice_id));
                if (
                    $invoice->company_id !== $payment->company_id
                    || $invoice->customer_id !== $payment->customer_id
                    || $invoice->currency_code !== $payment->currency_code
                ) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
                }
                $this->ensureOpenInvoice($invoice);
                if ((float) $allocation->amount > (float) $invoice->balance_amount + 0.0001) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_exceeds_balance')]);
                }
            }

            $payment->update([
                'status' => 'POSTED',
                'allocated_amount' => $allocated,
                'unallocated_amount' => round((float) $payment->amount - $allocated, 4),
                'posted_by' => $userId,
                'posted_at' => now(),
            ]);

            foreach ($invoices as $invoice) {
                $this->recalculateCustomerInvoice($invoice);
            }

            $this->audit('finance.customer_payment.posted', $payment, $userId);
            $this->revisions->record($payment, 'POSTED', $userId);

            return $payment->fresh();
        });
    }

    public function postSupplierPayment(SupplierPayment $payment, string $userId): SupplierPayment
    {
        return DB::transaction(function () use ($payment, $userId): SupplierPayment {
            $payment = SupplierPayment::query()
                ->with(['allocations' => fn ($query) => $query->orderBy('supplier_invoice_id')])
                ->lockForUpdate()
                ->findOrFail($payment->id);

            if ($payment->status !== 'DRAFT') {
                throw ValidationException::withMessages(['payment' => __('billing.payment_not_postable')]);
            }

            $this->assertSupplierPaymentContext($payment);
            $this->periods->assertOpen($payment->company_id, $payment->payment_date, __('governance.operation_post_payment'));
            $allocated = round((float) $payment->allocations->sum('amount'), 4);
            if ($allocated > (float) $payment->amount + 0.0001) {
                throw ValidationException::withMessages(['allocations' => __('billing.allocations_exceed_payment')]);
            }
            if (! $this->allowsUnallocatedPayments($payment->company_id) && $allocated + 0.0001 < (float) $payment->amount) {
                throw ValidationException::withMessages(['allocations' => __('billing.unallocated_payment_not_allowed')]);
            }

            $invoiceIds = $payment->allocations->pluck('supplier_invoice_id')->unique()->sort()->values();
            $invoices = SupplierInvoice::query()
                ->whereKey($invoiceIds)
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            if ($invoices->count() !== $invoiceIds->count()) {
                throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
            }

            foreach ($payment->allocations as $allocation) {
                $invoice = $this->recalculateSupplierInvoice($invoices->get($allocation->supplier_invoice_id));
                if (
                    $invoice->company_id !== $payment->company_id
                    || $invoice->supplier_id !== $payment->supplier_id
                    || $invoice->currency_code !== $payment->currency_code
                ) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_party_mismatch')]);
                }
                $this->ensureOpenInvoice($invoice);
                if ((float) $allocation->amount > (float) $invoice->balance_amount + 0.0001) {
                    throw ValidationException::withMessages(['allocations' => __('billing.allocation_exceeds_balance')]);
                }
            }

            $payment->update([
                'status' => 'POSTED',
                'allocated_amount' => $allocated,
                'unallocated_amount' => round((float) $payment->amount - $allocated, 4),
                'posted_by' => $userId,
                'posted_at' => now(),
            ]);

            foreach ($invoices as $invoice) {
                $this->recalculateSupplierInvoice($invoice);
            }

            $this->audit('finance.supplier_payment.posted', $payment, $userId);
            $this->revisions->record($payment, 'POSTED', $userId);

            return $payment->fresh();
        });
    }

    public function reverseCustomerPayment(CustomerPayment $payment, string $reason, string $userId): CustomerPayment
    {
        return DB::transaction(function () use ($payment, $reason, $userId): CustomerPayment {
            $payment = CustomerPayment::query()
                ->with(['allocations' => fn ($query) => $query->orderBy('customer_invoice_id')])
                ->lockForUpdate()
                ->findOrFail($payment->id);

            if ($payment->status !== 'POSTED') {
                throw ValidationException::withMessages(['payment' => __('billing.payment_not_reversible')]);
            }
            $this->periods->assertOpen($payment->company_id, today(), __('governance.operation_reverse_payment'));

            $invoices = CustomerInvoice::query()
                ->whereKey($payment->allocations->pluck('customer_invoice_id')->unique())
                ->orderBy('id')
                ->lockForUpdate()
                ->get();

            $payment->update([
                'status' => 'CANCELLED',
                'reversal_reason' => $reason,
                'reversed_by' => $userId,
                'reversed_at' => now(),
            ]);

            foreach ($invoices as $invoice) {
                $this->recalculateCustomerInvoice($invoice);
            }

            $this->audit('finance.customer_payment.reversed', $payment, $userId);
            $this->revisions->record($payment, 'REVERSED', $userId, $reason);

            return $payment->fresh();
        });
    }

    public function reverseSupplierPayment(SupplierPayment $payment, string $reason, string $userId): SupplierPayment
    {
        return DB::transaction(function () use ($payment, $reason, $userId): SupplierPayment {
            $payment = SupplierPayment::query()
                ->with(['allocations' => fn ($query) => $query->orderBy('supplier_invoice_id')])
                ->lockForUpdate()
                ->findOrFail($payment->id);

            if ($payment->status !== 'POSTED') {
                throw ValidationException::withMessages(['payment' => __('billing.payment_not_reversible')]);
            }
            $this->periods->assertOpen($payment->company_id, today(), __('governance.operation_reverse_payment'));

            $invoices = SupplierInvoice::query()
                ->whereKey($payment->allocations->pluck('supplier_invoice_id')->unique())
                ->orderBy('id')
                ->lockForUpdate()
                ->get();

            $payment->update([
                'status' => 'CANCELLED',
                'reversal_reason' => $reason,
                'reversed_by' => $userId,
                'reversed_at' => now(),
            ]);

            foreach ($invoices as $invoice) {
                $this->recalculateSupplierInvoice($invoice);
            }

            $this->audit('finance.supplier_payment.reversed', $payment, $userId);
            $this->revisions->record($payment, 'REVERSED', $userId, $reason);

            return $payment->fresh();
        });
    }

    public function recalculateCustomerInvoice(CustomerInvoice $invoice): CustomerInvoice
    {
        $invoice->refresh()->load('lines', 'creditNotes', 'allocations.payment');
        $subtotal = round((float) $invoice->lines->sum('line_subtotal'), 4);
        $tax = round((float) $invoice->lines->sum('tax_amount'), 4);
        $total = round((float) $invoice->lines->sum('line_total'), 4);
        $credits = round((float) $invoice->creditNotes->where('status', 'ISSUED')->sum('applied_amount'), 4);
        $payments = round((float) $invoice->allocations
            ->filter(fn ($allocation) => $allocation->payment?->status === 'POSTED')
            ->sum('amount'), 4);
        $balance = max(0, round($total - $credits - $payments, 4));
        $status = $this->paymentStatus($invoice->status, $balance, $credits + $payments, $invoice->due_date);

        $invoice->update([
            'subtotal' => $subtotal,
            'tax_amount' => $tax,
            'total_amount' => $total,
            'credit_amount' => $credits,
            'paid_amount' => $payments,
            'balance_amount' => $balance,
            'status' => $status,
        ]);

        return $invoice->fresh();
    }

    public function recalculateSupplierInvoice(SupplierInvoice $invoice): SupplierInvoice
    {
        $invoice->refresh()->load('lines', 'creditNotes', 'allocations.payment');
        $subtotal = round((float) $invoice->lines->sum('line_subtotal'), 4);
        $tax = round((float) $invoice->lines->sum('tax_amount'), 4);
        $total = round((float) $invoice->lines->sum('line_total'), 4);
        $credits = round((float) $invoice->creditNotes->where('status', 'APPROVED')->sum('applied_amount'), 4);
        $payments = round((float) $invoice->allocations
            ->filter(fn ($allocation) => $allocation->payment?->status === 'POSTED')
            ->sum('amount'), 4);
        $balance = max(0, round($total - $credits - $payments, 4));
        $status = $this->paymentStatus($invoice->status, $balance, $credits + $payments, $invoice->due_date);

        $invoice->update([
            'subtotal' => $subtotal,
            'tax_amount' => $tax,
            'total_amount' => $total,
            'credit_amount' => $credits,
            'paid_amount' => $payments,
            'balance_amount' => $balance,
            'status' => $status,
        ]);

        return $invoice->fresh();
    }

    /**
     * @return array{customer: int, supplier: int}
     */
    public function refreshOverdueStatuses(?string $companyId = null): array
    {
        $counts = ['customer' => 0, 'supplier' => 0];

        $customerQuery = CustomerInvoice::query()
            ->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE']);
        $supplierQuery = SupplierInvoice::query()
            ->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE']);

        if ($companyId) {
            $customerQuery->where('company_id', $companyId);
            $supplierQuery->where('company_id', $companyId);
        }

        $customerQuery->chunkById(200, function ($invoices) use (&$counts): void {
            foreach ($invoices as $invoice) {
                $this->recalculateCustomerInvoice($invoice);
                $counts['customer']++;
            }
        });

        $supplierQuery->chunkById(200, function ($invoices) use (&$counts): void {
            foreach ($invoices as $invoice) {
                $this->recalculateSupplierInvoice($invoice);
                $counts['supplier']++;
            }
        });

        return $counts;
    }

    public function agingSummary(string $type, ?string $companyId = null): array
    {
        $thresholds = $this->agingThresholds($companyId);
        $query = $type === 'customer' ? CustomerInvoice::query() : SupplierInvoice::query();
        $query->whereIn('status', ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])->where('balance_amount', '>', 0);
        if ($companyId) {
            $query->where('company_id', $companyId);
        }
        $buckets = ['current' => 0.0, 'days_1_30' => 0.0, 'days_31_60' => 0.0, 'days_61_90' => 0.0, 'days_90_plus' => 0.0];
        foreach ($query->cursor() as $invoice) {
            $days = today()->diffInDays($invoice->due_date, false);
            $balance = (float) $invoice->balance_amount;
            if ($days >= 0) $buckets['current'] += $balance;
            elseif ($days >= -$thresholds[0]) $buckets['days_1_30'] += $balance;
            elseif ($days >= -$thresholds[1]) $buckets['days_31_60'] += $balance;
            elseif ($days >= -$thresholds[2]) $buckets['days_61_90'] += $balance;
            else $buckets['days_90_plus'] += $balance;
        }
        return $buckets;
    }

    private function allowsUnallocatedPayments(string $companyId): bool
    {
        $setting = SystemSetting::query()
            ->where('company_id', $companyId)
            ->where('group', 'finance')
            ->where('key', 'allow_unallocated_payments')
            ->first();

        return (bool) ($setting?->value ?? true);
    }

    private function assertCustomerPaymentContext(CustomerPayment $payment): void
    {
        $customer = $payment->customer()->lockForUpdate()->first();
        if ((float) $payment->amount <= 0 || ! $customer || $customer->company_id !== $payment->company_id) {
            throw ValidationException::withMessages(['payment' => __('billing.allocation_party_mismatch')]);
        }

        $this->assertFinancialAccountContext($payment->financial_account_id, $payment->company_id, $payment->currency_code);
    }

    private function assertSupplierPaymentContext(SupplierPayment $payment): void
    {
        $supplier = $payment->supplier()->lockForUpdate()->first();
        if ((float) $payment->amount <= 0 || ! $supplier || $supplier->company_id !== $payment->company_id) {
            throw ValidationException::withMessages(['payment' => __('billing.allocation_party_mismatch')]);
        }

        $this->assertFinancialAccountContext($payment->financial_account_id, $payment->company_id, $payment->currency_code);
    }

    private function assertFinancialAccountContext(?string $accountId, string $companyId, string $currencyCode): void
    {
        if (! $accountId) {
            return;
        }

        $account = FinancialAccount::query()->lockForUpdate()->find($accountId);
        if (! $account || ! $account->active || $account->company_id !== $companyId || $account->currency_code !== $currencyCode) {
            throw ValidationException::withMessages(['financial_account_id' => __('billing.account_currency_mismatch')]);
        }
    }

    private function ensureOpenInvoice(Model $invoice): void
    {
        if (! in_array($invoice->status, ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'], true) || (float) $invoice->balance_amount <= 0) {
            throw ValidationException::withMessages(['invoice' => __('billing.invoice_not_open')]);
        }
    }

    private function paymentStatus(string $current, float $balance, float $settled, Carbon|string|null $dueDate): string
    {
        if (in_array($current, ['DRAFT', 'PENDING_APPROVAL', 'REJECTED', 'CANCELLED'], true)) return $current;
        if ($balance <= 0.0001) return 'PAID';
        if ($dueDate && Carbon::parse($dueDate)->isBefore(today())) return 'OVERDUE';
        if ($settled > 0.0001) return 'PARTIALLY_PAID';
        return 'ISSUED';
    }

    private function matchingTolerance(string $companyId): float
    {
        $setting = SystemSetting::query()->where('company_id', $companyId)
            ->where('group', 'finance')->where('key', 'invoice_matching_tolerance')->first();

        return max(0, (float) ($setting?->value ?? 1));
    }

    private function agingThresholds(?string $companyId): array
    {
        if (! $companyId) {
            return [30, 60, 90];
        }

        $settings = SystemSetting::query()->where('company_id', $companyId)->where('group', 'finance')
            ->whereIn('key', ['aging_bucket_1_days', 'aging_bucket_2_days', 'aging_bucket_3_days'])
            ->get()->keyBy('key');

        $first = max(1, (int) ($settings->get('aging_bucket_1_days')?->value ?? 30));
        $second = max($first + 1, (int) ($settings->get('aging_bucket_2_days')?->value ?? 60));
        $third = max($second + 1, (int) ($settings->get('aging_bucket_3_days')?->value ?? 90));

        return [$first, $second, $third];
    }

    private function audit(string $event, Model $model, string $userId): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) Str::uuid(), 'user_id' => $userId, 'event' => $event,
            'auditable_type' => $model::class, 'auditable_id' => $model->getKey(),
            'old_values' => null, 'new_values' => json_encode($model->fresh()->toArray()),
            'ip_address' => app()->runningInConsole() ? null : request()->ip(),
            'user_agent' => app()->runningInConsole() ? null : request()->userAgent(),
            'created_at' => now(),
        ]);
    }
}
