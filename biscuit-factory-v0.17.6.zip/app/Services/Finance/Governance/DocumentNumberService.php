<?php

namespace App\Services\Finance\Governance;

use App\Models\Company;
use App\Models\DocumentNumberSequence;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DocumentNumberService
{
    public function next(string $companyId, string $documentType, Carbon|string|null $date = null): string
    {
        $date = Carbon::parse($date ?? now());
        $definition = FinancialDocumentCatalog::definition($documentType);

        return DB::transaction(function () use ($companyId, $documentType, $date, $definition): string {
            // A single deterministic row serializes numbering across companies because legacy
            // document-number columns are globally unique.
            Company::query()->orderBy('id')->lockForUpdate()->firstOrFail();
            $company = Company::query()->whereKey($companyId)->firstOrFail();

            $base = DocumentNumberSequence::query()
                ->where('company_id', $companyId)
                ->where('document_type', $documentType)
                ->where('active', true)
                ->orderByDesc('fiscal_year')
                ->orderByDesc('period')
                ->first();

            $policy = $base?->reset_policy ?? 'ANNUAL';
            [$year, $period] = match ($policy) {
                'MONTHLY' => [$date->year, $date->month],
                'NEVER' => [0, 0],
                default => [$date->year, 0],
            };

            $sequence = DocumentNumberSequence::query()
                ->where('company_id', $companyId)
                ->where('document_type', $documentType)
                ->where('fiscal_year', $year)
                ->where('period', $period)
                ->lockForUpdate()
                ->first();

            if (! $sequence) {
                $sequence = DocumentNumberSequence::create([
                    'company_id' => $companyId,
                    'document_type' => $documentType,
                    'prefix' => $base?->prefix ?? $definition['prefix'],
                    'pattern' => $base?->pattern ?? '{PREFIX}-{YEAR}-{NUMBER}',
                    'reset_policy' => $policy,
                    'fiscal_year' => $year,
                    'period' => $period,
                    'next_number' => 1,
                    'padding' => $base?->padding ?? 6,
                    'active' => true,
                ]);
            }

            $nextNumber = (int) $sequence->next_number;
            do {
                $number = str_pad((string) $nextNumber, $sequence->padding, '0', STR_PAD_LEFT);
                $rendered = strtr($sequence->pattern, [
                    '{COMPANY}' => $company->code,
                    '{PREFIX}' => $sequence->prefix,
                    '{YEAR}' => $date->format('Y'),
                    '{YY}' => $date->format('y'),
                    '{MONTH}' => $date->format('m'),
                    '{NUMBER}' => $number,
                ]);
                $nextNumber++;
            } while ($definition['model']::query()
                ->where($definition['number_attribute'], $rendered)
                ->exists());

            $sequence->update([
                'next_number' => $nextNumber,
                'last_issued_at' => now(),
            ]);

            return $rendered;
        }, 3);
    }
}
