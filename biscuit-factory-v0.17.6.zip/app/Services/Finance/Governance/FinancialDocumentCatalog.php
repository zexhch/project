<?php

namespace App\Services\Finance\Governance;

use App\Models\CustomerCreditNote;
use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\DeliveryNote;
use App\Models\GoodsReceipt;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\SupplierCreditNote;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use Illuminate\Database\Eloquent\Model;
use InvalidArgumentException;

final class FinancialDocumentCatalog
{
    public const SALES_QUOTATION = 'SALES_QUOTATION';
    public const SALES_ORDER = 'SALES_ORDER';
    public const DELIVERY_NOTE = 'DELIVERY_NOTE';
    public const PURCHASE_REQUISITION = 'PURCHASE_REQUISITION';
    public const PURCHASE_ORDER = 'PURCHASE_ORDER';
    public const GOODS_RECEIPT = 'GOODS_RECEIPT';
    public const CUSTOMER_INVOICE = 'CUSTOMER_INVOICE';
    public const SUPPLIER_INVOICE = 'SUPPLIER_INVOICE';
    public const CUSTOMER_CREDIT_NOTE = 'CUSTOMER_CREDIT_NOTE';
    public const SUPPLIER_CREDIT_NOTE = 'SUPPLIER_CREDIT_NOTE';
    public const CUSTOMER_PAYMENT = 'CUSTOMER_PAYMENT';
    public const SUPPLIER_PAYMENT = 'SUPPLIER_PAYMENT';

    /** @return array<string, array<string, mixed>> */
    public static function all(): array
    {
        return [
            self::SALES_QUOTATION => self::definitionOf('governance.document_type_sales_quotation', SalesQuotation::class, 'quotation_number', 'quotation_date', 'DEV'),
            self::SALES_ORDER => self::definitionOf('governance.document_type_sales_order', SalesOrder::class, 'order_number', 'order_date', 'CV'),
            self::DELIVERY_NOTE => self::definitionOf('governance.document_type_delivery_note', DeliveryNote::class, 'delivery_number', 'delivered_at', 'BL'),
            self::PURCHASE_REQUISITION => self::definitionOf('governance.document_type_purchase_requisition', PurchaseRequisition::class, 'requisition_number', 'request_date', 'DA'),
            self::PURCHASE_ORDER => self::definitionOf('governance.document_type_purchase_order', PurchaseOrder::class, 'order_number', 'order_date', 'BC'),
            self::GOODS_RECEIPT => self::definitionOf('governance.document_type_goods_receipt', GoodsReceipt::class, 'receipt_number', 'received_at', 'BR', false),
            self::CUSTOMER_INVOICE => self::definitionOf('governance.document_type_customer_invoice', CustomerInvoice::class, 'invoice_number', 'invoice_date', 'FC'),
            self::SUPPLIER_INVOICE => self::definitionOf('governance.document_type_supplier_invoice', SupplierInvoice::class, 'invoice_number', 'invoice_date', 'FF'),
            self::CUSTOMER_CREDIT_NOTE => self::definitionOf('governance.document_type_customer_credit_note', CustomerCreditNote::class, 'credit_note_number', 'credit_note_date', 'AC'),
            self::SUPPLIER_CREDIT_NOTE => self::definitionOf('governance.document_type_supplier_credit_note', SupplierCreditNote::class, 'credit_note_number', 'credit_note_date', 'AF'),
            self::CUSTOMER_PAYMENT => self::definitionOf('governance.document_type_customer_payment', CustomerPayment::class, 'payment_number', 'payment_date', 'RC'),
            self::SUPPLIER_PAYMENT => self::definitionOf('governance.document_type_supplier_payment', SupplierPayment::class, 'payment_number', 'payment_date', 'RF'),
        ];
    }

    /** @return array<string, array<string, mixed>> */
    public static function approvalTypes(): array
    {
        return array_intersect_key(self::all(), array_flip([
            self::CUSTOMER_INVOICE,
            self::SUPPLIER_INVOICE,
        ]));
    }

    public static function definition(string $type): array
    {
        return self::all()[$type] ?? throw new InvalidArgumentException("Unknown document type [{$type}].");
    }

    public static function typeFor(Model $model): string
    {
        foreach (self::all() as $type => $definition) {
            if ($model instanceof $definition['model']) {
                return $type;
            }
        }

        throw new InvalidArgumentException('Unsupported document model ['.$model::class.'].');
    }

    public static function number(Model $model, ?string $type = null): ?string
    {
        $definition = self::definition($type ?? self::typeFor($model));

        return $model->getAttribute($definition['number_attribute']);
    }

    /** @return array<string, mixed> */
    private static function definitionOf(
        string $label,
        string $model,
        string $numberAttribute,
        string $dateAttribute,
        string $prefix,
        bool $showAmounts = true,
    ): array {
        return [
            'label' => $label,
            'model' => $model,
            'number_attribute' => $numberAttribute,
            'date_attribute' => $dateAttribute,
            'prefix' => $prefix,
            'show_amounts' => $showAmounts,
        ];
    }
}
