<?php

namespace App\Services\Finance\Governance;

use App\Models\ApprovalRequest;
use App\Models\ApprovalRequestStep;
use App\Models\ApprovalWorkflow;
use App\Models\CustomerInvoice;
use App\Models\SupplierInvoice;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ApprovalService
{
    public function __construct(
        private readonly AccountingPeriodService $periods,
        private readonly DocumentRevisionService $revisions,
    ) {
    }

    public function workflowFor(string $companyId, string $documentType, float $amount, ?string $currencyCode): ?ApprovalWorkflow
    {
        return ApprovalWorkflow::query()
            ->with('levels')
            ->where('company_id', $companyId)
            ->where('document_type', $documentType)
            ->where('active', true)
            ->where('minimum_amount', '<=', $amount)
            ->where(fn ($query) => $query->whereNull('currency_code')->orWhere('currency_code', $currencyCode))
            ->orderByDesc('minimum_amount')
            ->first();
    }

    public function submit(Model $document, string $documentType, string $companyId, float $amount, ?string $currencyCode, string $userId): ?ApprovalRequest
    {
        $workflow = $this->workflowFor($companyId, $documentType, $amount, $currencyCode);
        if (! $workflow) {
            return null;
        }

        return DB::transaction(function () use ($document, $documentType, $companyId, $amount, $currencyCode, $userId, $workflow): ApprovalRequest {
            $document->newQuery()->whereKey($document->getKey())->lockForUpdate()->firstOrFail();

            $existing = ApprovalRequest::query()
                ->where('approvable_type', $document::class)
                ->where('approvable_id', $document->getKey())
                ->where('status', 'PENDING')
                ->lockForUpdate()
                ->first();
            if ($existing) {
                return $existing;
            }

            $levels = $workflow->levels->filter(function ($level) use ($amount): bool {
                return ($level->amount_from === null || $amount >= (float) $level->amount_from)
                    && ($level->amount_to === null || $amount <= (float) $level->amount_to);
            })->values();

            if ($levels->isEmpty()) {
                return ApprovalRequest::create([
                    'company_id' => $companyId,
                    'approval_workflow_id' => $workflow->id,
                    'approvable_type' => $document::class,
                    'approvable_id' => $document->getKey(),
                    'document_type' => $documentType,
                    'document_number' => FinancialDocumentCatalog::number($document, $documentType),
                    'amount' => $amount,
                    'currency_code' => $currencyCode,
                    'status' => 'APPROVED',
                    'current_level' => 0,
                    'submitted_by' => $userId,
                    'submitted_at' => now(),
                    'completed_at' => now(),
                ]);
            }

            $request = ApprovalRequest::create([
                'company_id' => $companyId,
                'approval_workflow_id' => $workflow->id,
                'approvable_type' => $document::class,
                'approvable_id' => $document->getKey(),
                'document_type' => $documentType,
                'document_number' => FinancialDocumentCatalog::number($document, $documentType),
                'amount' => $amount,
                'currency_code' => $currencyCode,
                'status' => 'PENDING',
                'current_level' => (int) $levels->first()->sequence,
                'submitted_by' => $userId,
                'submitted_at' => now(),
            ]);

            foreach ($levels as $index => $level) {
                $request->steps()->create([
                    'approval_workflow_level_id' => $level->id,
                    'sequence' => $level->sequence,
                    'name' => $level->name,
                    'permission_code' => $level->permission_code,
                    'role_code' => $level->role_code,
                    'required_approvals' => $level->minimum_approvals,
                    'approved_count' => 0,
                    'status' => $index === 0 ? 'PENDING' : 'WAITING',
                    'decisions' => [],
                ]);
            }

            return $request->fresh(['workflow', 'steps']);
        });
    }

    public function approve(ApprovalRequest $approvalRequest, User $user, ?string $comment = null): ApprovalRequest
    {
        return $this->decide($approvalRequest, $user, 'APPROVED', $comment);
    }

    public function reject(ApprovalRequest $approvalRequest, User $user, string $comment): ApprovalRequest
    {
        return $this->decide($approvalRequest, $user, 'REJECTED', $comment);
    }

    private function decide(ApprovalRequest $approvalRequest, User $user, string $decision, ?string $comment): ApprovalRequest
    {
        return DB::transaction(function () use ($approvalRequest, $user, $decision, $comment): ApprovalRequest {
            $request = ApprovalRequest::query()->with(['steps', 'approvable'])->lockForUpdate()->findOrFail($approvalRequest->id);
            if ($request->status !== 'PENDING') {
                throw ValidationException::withMessages(['approval' => __('governance.approval_already_completed')]);
            }

            $step = ApprovalRequestStep::query()
                ->where('approval_request_id', $request->id)
                ->where('sequence', $request->current_level)
                ->lockForUpdate()
                ->firstOrFail();

            if (! $this->canDecide($step, $user)) {
                throw ValidationException::withMessages(['approval' => __('governance.not_authorized_for_approval')]);
            }

            $decisions = $step->decisions ?? [];
            if (collect($decisions)->contains(fn (array $item): bool => ($item['user_id'] ?? null) === $user->id)) {
                throw ValidationException::withMessages(['approval' => __('governance.approval_duplicate_decision')]);
            }

            $decisions[] = [
                'user_id' => $user->id,
                'user_name' => $user->name,
                'decision' => $decision,
                'comment' => $comment,
                'decided_at' => now()->toISOString(),
            ];

            if ($decision === 'REJECTED') {
                $step->update(['status' => 'REJECTED', 'decisions' => $decisions, 'completed_at' => now()]);
                $request->update(['status' => 'REJECTED', 'completed_at' => now(), 'completion_comment' => $comment]);
                $this->applyRejectedState($request->approvable, $user->id);

                return $request->fresh(['workflow', 'steps', 'approvable']);
            }

            $approvedCount = $step->approved_count + 1;
            $stepCompleted = $approvedCount >= $step->required_approvals;
            $step->update([
                'approved_count' => $approvedCount,
                'decisions' => $decisions,
                'status' => $stepCompleted ? 'APPROVED' : 'PENDING',
                'completed_at' => $stepCompleted ? now() : null,
            ]);

            if (! $stepCompleted) {
                return $request->fresh(['workflow', 'steps', 'approvable']);
            }

            $next = $request->steps()->where('sequence', '>', $step->sequence)->orderBy('sequence')->first();
            if ($next) {
                $next->update(['status' => 'PENDING']);
                $request->update(['current_level' => $next->sequence]);
            } else {
                $request->update(['status' => 'APPROVED', 'completed_at' => now(), 'completion_comment' => $comment]);
                $this->applyApprovedState($request->approvable, $user->id);
            }

            return $request->fresh(['workflow', 'steps', 'approvable']);
        });
    }

    public function canDecide(ApprovalRequestStep $step, User $user): bool
    {
        if ($user->hasRole('ADMINISTRATOR')) {
            return true;
        }

        $permissionAllowed = $step->permission_code === '' || $user->hasPermission($step->permission_code);
        $roleAllowed = ! $step->role_code || $user->hasRole($step->role_code);

        return $permissionAllowed && $roleAllowed;
    }

    private function applyApprovedState(?Model $document, string $userId): void
    {
        if ($document instanceof CustomerInvoice) {
            $this->periods->assertOpen($document->company_id, $document->invoice_date, __('governance.operation_issue_invoice'));
            $document->update(['status' => 'ISSUED', 'issued_by' => $userId, 'issued_at' => now()]);
            $this->revisions->record($document->fresh(), 'APPROVED', $userId);
        } elseif ($document instanceof SupplierInvoice) {
            $this->periods->assertOpen($document->company_id, $document->invoice_date, __('governance.operation_approve_invoice'));
            $document->update(['status' => 'ISSUED', 'approved_by' => $userId, 'approved_at' => now()]);
            $this->revisions->record($document->fresh(), 'APPROVED', $userId);
        }
    }

    private function applyRejectedState(?Model $document, string $userId): void
    {
        if ($document instanceof CustomerInvoice || $document instanceof SupplierInvoice) {
            $document->update(['status' => 'REJECTED']);
            $this->revisions->record($document->fresh(), 'REJECTED', $userId);
        }
    }
}
