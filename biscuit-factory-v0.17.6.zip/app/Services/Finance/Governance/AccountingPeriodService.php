<?php

namespace App\Services\Finance\Governance;

use App\Models\AccountingPeriod;
use App\Models\CustomerCreditNote;
use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\SupplierCreditNote;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AccountingPeriodService
{
    public function generateYear(string $companyId, int $year): int
    {
        return DB::transaction(function () use ($companyId, $year): int {
            $created = 0;
            for ($month = 1; $month <= 12; $month++) {
                $start = Carbon::create($year, $month, 1)->startOfMonth();
                $period = AccountingPeriod::query()->firstOrCreate(
                    ['company_id' => $companyId, 'fiscal_year' => $year, 'period' => $month],
                    ['starts_on' => $start->toDateString(), 'ends_on' => $start->copy()->endOfMonth()->toDateString(), 'status' => 'OPEN'],
                );
                if ($period->wasRecentlyCreated) {
                    $created++;
                }
            }

            return $created;
        });
    }

    public function assertOpen(string $companyId, Carbon|string $date, string $operation = 'posting'): void
    {
        $date = Carbon::parse($date)->startOfDay();
        $period = AccountingPeriod::query()
            ->where('company_id', $companyId)
            ->whereDate('starts_on', '<=', $date)
            ->whereDate('ends_on', '>=', $date)
            ->first();

        $governanceEnabled = AccountingPeriod::query()->where('company_id', $companyId)->exists();
        if (! $period && $governanceEnabled) {
            throw ValidationException::withMessages([
                'period' => __('governance.period_missing_error', [
                    'date' => $date->format('d/m/Y'),
                    'operation' => $operation,
                ]),
            ]);
        }

        if ($period && $period->status !== 'OPEN') {
            throw ValidationException::withMessages([
                'period' => __('governance.period_closed_error', [
                    'period' => sprintf('%02d/%d', $period->period, $period->fiscal_year),
                    'operation' => $operation,
                ]),
            ]);
        }
    }

    public function close(AccountingPeriod $period, string $userId, string $reason, bool $force = false): AccountingPeriod
    {
        return DB::transaction(function () use ($period, $userId, $reason, $force): AccountingPeriod {
            $period = AccountingPeriod::query()->lockForUpdate()->findOrFail($period->id);
            if ($period->status === 'CLOSED') {
                return $period;
            }

            $blockers = $this->blockers($period);
            if (! $force && array_sum($blockers) > 0) {
                throw ValidationException::withMessages([
                    'period' => __('governance.period_has_blockers', ['count' => array_sum($blockers)]),
                ]);
            }

            $period->update([
                'status' => 'CLOSED',
                'closing_snapshot' => [...$this->snapshot($period), 'blockers' => $blockers, 'forced' => $force],
                'close_reason' => $reason,
                'closed_by' => $userId,
                'closed_at' => now(),
                'reopen_reason' => null,
                'reopened_by' => null,
                'reopened_at' => null,
            ]);

            return $period->fresh();
        });
    }

    public function reopen(AccountingPeriod $period, string $userId, string $reason): AccountingPeriod
    {
        return DB::transaction(function () use ($period, $userId, $reason): AccountingPeriod {
            $period = AccountingPeriod::query()->lockForUpdate()->findOrFail($period->id);
            if ($period->status !== 'CLOSED') {
                throw ValidationException::withMessages(['period' => __('governance.period_not_closed')]);
            }

            $period->update([
                'status' => 'OPEN',
                'reopen_reason' => $reason,
                'reopened_by' => $userId,
                'reopened_at' => now(),
            ]);

            return $period->fresh();
        });
    }

    /** @return array<string, int> */
    public function blockers(AccountingPeriod $period): array
    {
        return [
            'customer_invoices' => CustomerInvoice::query()->where('company_id', $period->company_id)->whereBetween('invoice_date', [$period->starts_on, $period->ends_on])->whereIn('status', ['DRAFT', 'PENDING_APPROVAL', 'REJECTED'])->count(),
            'supplier_invoices' => SupplierInvoice::query()->where('company_id', $period->company_id)->whereBetween('invoice_date', [$period->starts_on, $period->ends_on])->whereIn('status', ['DRAFT', 'PENDING_APPROVAL', 'REJECTED'])->count(),
            'customer_payments' => CustomerPayment::query()->where('company_id', $period->company_id)->whereBetween('payment_date', [$period->starts_on, $period->ends_on])->where('status', 'DRAFT')->count(),
            'supplier_payments' => SupplierPayment::query()->where('company_id', $period->company_id)->whereBetween('payment_date', [$period->starts_on, $period->ends_on])->where('status', 'DRAFT')->count(),
        ];
    }

    /** @return array<string, int|float> */
    public function snapshot(AccountingPeriod $period): array
    {
        $customerInvoices = CustomerInvoice::query()->where('company_id', $period->company_id)->whereBetween('invoice_date', [$period->starts_on, $period->ends_on])->whereNotIn('status', ['DRAFT', 'CANCELLED']);
        $supplierInvoices = SupplierInvoice::query()->where('company_id', $period->company_id)->whereBetween('invoice_date', [$period->starts_on, $period->ends_on])->whereNotIn('status', ['DRAFT', 'CANCELLED']);
        $customerCredits = CustomerCreditNote::query()->whereHas('invoice', fn ($q) => $q->where('company_id', $period->company_id))->whereBetween('credit_note_date', [$period->starts_on, $period->ends_on])->where('status', 'ISSUED');
        $supplierCredits = SupplierCreditNote::query()->whereHas('invoice', fn ($q) => $q->where('company_id', $period->company_id))->whereBetween('credit_note_date', [$period->starts_on, $period->ends_on])->where('status', 'APPROVED');

        return [
            'customer_invoice_count' => (clone $customerInvoices)->count(),
            'customer_invoice_total' => round((float) (clone $customerInvoices)->sum('total_amount'), 4),
            'supplier_invoice_count' => (clone $supplierInvoices)->count(),
            'supplier_invoice_total' => round((float) (clone $supplierInvoices)->sum('total_amount'), 4),
            'customer_credit_total' => round((float) $customerCredits->sum('applied_amount'), 4),
            'supplier_credit_total' => round((float) $supplierCredits->sum('applied_amount'), 4),
            'customer_payment_total' => round((float) CustomerPayment::query()->where('company_id', $period->company_id)->whereBetween('payment_date', [$period->starts_on, $period->ends_on])->where('status', 'POSTED')->sum('amount'), 4),
            'supplier_payment_total' => round((float) SupplierPayment::query()->where('company_id', $period->company_id)->whereBetween('payment_date', [$period->starts_on, $period->ends_on])->where('status', 'POSTED')->sum('amount'), 4),
        ];
    }
}
