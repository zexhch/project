<?php

namespace App\Services\Finance\Governance;

use App\Models\CustomerInvoice;
use App\Models\DocumentCancellation;
use App\Models\SupplierInvoice;
use App\Services\Finance\BillingService;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class DocumentCancellationService
{
    public function __construct(
        private readonly BillingService $billing,
        private readonly AccountingPeriodService $periods,
        private readonly DocumentRevisionService $revisions,
    ) {
    }

    public function cancelCustomerInvoice(CustomerInvoice $invoice, string $reason, string $userId): DocumentCancellation
    {
        return DB::transaction(function () use ($invoice, $reason, $userId): DocumentCancellation {
            $invoice = CustomerInvoice::query()->with('allocations.payment')->lockForUpdate()->findOrFail($invoice->id);
            $this->assertCancellable($invoice->status, (float) $invoice->paid_amount);
            $this->periods->assertOpen($invoice->company_id, today(), __('governance.operation_cancel_invoice'));

            $counter = null;
            if ((float) $invoice->balance_amount > 0.0001) {
                $counter = $this->billing->issueCustomerCredit(
                    $invoice,
                    (float) $invoice->balance_amount,
                    $reason,
                    'CANCELLATION',
                    $userId,
                );
            }

            $originalStatus = $invoice->status;
            $invoice->update(['status' => 'CANCELLED']);
            $cancellation = DocumentCancellation::create([
                'company_id' => $invoice->company_id,
                'document_type' => FinancialDocumentCatalog::CUSTOMER_INVOICE,
                'document_id' => $invoice->id,
                'document_number' => $invoice->invoice_number,
                'original_status' => $originalStatus,
                'cancellation_type' => 'CREDIT_NOTE',
                'reason' => $reason,
                'counter_document_type' => $counter ? FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE : null,
                'counter_document_id' => $counter?->id,
                'counter_document_number' => $counter?->credit_note_number,
                'cancelled_by' => $userId,
                'cancelled_at' => now(),
            ]);
            $this->revisions->record($invoice->fresh(), 'CANCELLED', $userId, $reason);

            return $cancellation;
        });
    }

    public function cancelSupplierInvoice(SupplierInvoice $invoice, string $reason, string $userId): DocumentCancellation
    {
        return DB::transaction(function () use ($invoice, $reason, $userId): DocumentCancellation {
            $invoice = SupplierInvoice::query()->with('allocations.payment')->lockForUpdate()->findOrFail($invoice->id);
            $this->assertCancellable($invoice->status, (float) $invoice->paid_amount);
            $this->periods->assertOpen($invoice->company_id, today(), __('governance.operation_cancel_invoice'));

            $counter = null;
            if ((float) $invoice->balance_amount > 0.0001) {
                $counter = $this->billing->approveSupplierCredit(
                    $invoice,
                    (float) $invoice->balance_amount,
                    $reason,
                    'CANCELLATION',
                    null,
                    $userId,
                );
            }

            $originalStatus = $invoice->status;
            $invoice->update(['status' => 'CANCELLED']);
            $cancellation = DocumentCancellation::create([
                'company_id' => $invoice->company_id,
                'document_type' => FinancialDocumentCatalog::SUPPLIER_INVOICE,
                'document_id' => $invoice->id,
                'document_number' => $invoice->invoice_number,
                'original_status' => $originalStatus,
                'cancellation_type' => 'CREDIT_NOTE',
                'reason' => $reason,
                'counter_document_type' => $counter ? FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE : null,
                'counter_document_id' => $counter?->id,
                'counter_document_number' => $counter?->credit_note_number,
                'cancelled_by' => $userId,
                'cancelled_at' => now(),
            ]);
            $this->revisions->record($invoice->fresh(), 'CANCELLED', $userId, $reason);

            return $cancellation;
        });
    }

    private function assertCancellable(string $status, float $paidAmount): void
    {
        if (! in_array($status, ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'], true)) {
            throw ValidationException::withMessages(['invoice' => __('governance.invoice_not_cancellable')]);
        }
        if ($paidAmount > 0.0001) {
            throw ValidationException::withMessages(['invoice' => __('governance.reverse_payments_before_cancellation')]);
        }
    }
}
