<?php

namespace App\Services\Finance\Governance;

use App\Models\Company;
use App\Models\CustomerCreditNote;
use App\Models\CustomerInvoice;
use App\Models\DeliveryNote;
use App\Models\DocumentRevision;
use App\Models\GoodsReceipt;
use App\Models\SupplierCreditNote;
use App\Models\SupplierInvoice;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class DocumentRevisionService
{
    public function record(Model $document, string $action, ?string $userId = null, ?string $reason = null, ?string $documentType = null): DocumentRevision
    {
        $documentType ??= FinancialDocumentCatalog::typeFor($document);

        return DB::transaction(function () use ($document, $action, $userId, $reason, $documentType): DocumentRevision {
            $companyId = $this->companyId($document);
            if ($companyId) {
                Company::query()->whereKey($companyId)->lockForUpdate()->first();
            } else {
                $document->newQuery()->whereKey($document->getKey())->lockForUpdate()->first();
            }

            $lastVersion = (int) DocumentRevision::query()
                ->where('document_type', $documentType)
                ->where('document_id', $document->getKey())
                ->max('version');

            return DocumentRevision::create([
                'company_id' => $companyId,
                'document_type' => $documentType,
                'document_id' => $document->getKey(),
                'document_number' => FinancialDocumentCatalog::number($document, $documentType),
                'version' => $lastVersion + 1,
                'action' => $action,
                'snapshot' => $this->snapshot($document, $documentType),
                'reason' => $reason,
                'user_id' => $userId,
                'created_at' => now(),
            ]);
        });
    }

    private function companyId(Model $document): ?string
    {
        if ($document->getAttribute('company_id')) {
            return (string) $document->getAttribute('company_id');
        }
        if ($document instanceof DeliveryNote) {
            return $document->salesOrder()->value('company_id');
        }
        if ($document instanceof GoodsReceipt) {
            return $document->purchaseOrder()->value('company_id');
        }
        if ($document instanceof CustomerCreditNote) {
            return CustomerInvoice::query()->whereKey($document->customer_invoice_id)->value('company_id');
        }
        if ($document instanceof SupplierCreditNote) {
            return SupplierInvoice::query()->whereKey($document->supplier_invoice_id)->value('company_id');
        }

        return null;
    }

    private function snapshot(Model $document, string $documentType): array
    {
        $document->loadMissing($this->relationsFor($documentType));

        return $document->toArray();
    }

    /** @return array<int, string> */
    private function relationsFor(string $type): array
    {
        return match ($type) {
            FinancialDocumentCatalog::SALES_QUOTATION => ['company', 'site', 'customer', 'lines.item', 'lines.unit', 'lines.taxRate'],
            FinancialDocumentCatalog::SALES_ORDER => ['company', 'site', 'customer', 'lines.item', 'lines.unit', 'lines.taxRate'],
            FinancialDocumentCatalog::DELIVERY_NOTE => ['salesOrder.company', 'customer', 'warehouse', 'lines.item', 'lines.unit', 'lines.salesOrderLine'],
            FinancialDocumentCatalog::PURCHASE_REQUISITION => ['company', 'site', 'requester', 'lines.item', 'lines.unit', 'lines.suggestedSupplier'],
            FinancialDocumentCatalog::PURCHASE_ORDER => ['company', 'site', 'supplier', 'lines.item', 'lines.unit', 'lines.taxRate'],
            FinancialDocumentCatalog::GOODS_RECEIPT => ['purchaseOrder.company', 'supplier', 'warehouse', 'destinationLocation', 'lines.item', 'lines.unit', 'lines.purchaseOrderLine'],
            FinancialDocumentCatalog::CUSTOMER_INVOICE => ['customer', 'company', 'site', 'lines.item', 'lines.unit', 'creditNotes', 'allocations.payment'],
            FinancialDocumentCatalog::SUPPLIER_INVOICE => ['supplier', 'company', 'site', 'lines.item', 'lines.unit', 'creditNotes', 'allocations.payment'],
            FinancialDocumentCatalog::CUSTOMER_CREDIT_NOTE => ['invoice', 'customer'],
            FinancialDocumentCatalog::SUPPLIER_CREDIT_NOTE => ['invoice', 'supplier'],
            FinancialDocumentCatalog::CUSTOMER_PAYMENT => ['company', 'customer', 'financialAccount', 'allocations.invoice'],
            FinancialDocumentCatalog::SUPPLIER_PAYMENT => ['company', 'supplier', 'financialAccount', 'allocations.invoice'],
        };
    }
}
