<?php

namespace App\Services\Finance\Governance;

use App\Models\DocumentTemplate;

class DocumentTemplateService
{
    public function resolve(string $documentType, ?string $companyId, ?string $locale = null): ?DocumentTemplate
    {
        $locale ??= app()->getLocale();

        return DocumentTemplate::query()
            ->where('document_type', $documentType)
            ->where('active', true)
            ->whereIn('locale', [$locale, 'fr'])
            ->where(fn ($query) => $query->where('company_id', $companyId)->orWhereNull('company_id'))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderByRaw('CASE WHEN locale = ? THEN 0 ELSE 1 END', [$locale])
            ->orderByDesc('is_default')
            ->first();
    }

    public function setDefault(DocumentTemplate $template): DocumentTemplate
    {
        DocumentTemplate::query()
            ->where('document_type', $template->document_type)
            ->where('locale', $template->locale)
            ->where(function ($query) use ($template): void {
                $template->company_id
                    ? $query->where('company_id', $template->company_id)
                    : $query->whereNull('company_id');
            })
            ->whereKeyNot($template->id)
            ->update(['is_default' => false]);

        $template->update(['is_default' => true, 'active' => true]);

        return $template->fresh();
    }
}
