<?php

namespace App\Services\Finance\Documents;

use NumberFormatter;

class MoneyToWordsService
{
    public function convert(float $amount, string $currencyCode = 'DZD', ?string $locale = null): string
    {
        $locale = $locale ?: app()->getLocale();
        $normalizedLocale = match ($locale) {
            'ar' => 'ar_DZ',
            'en' => 'en_US',
            default => 'fr_DZ',
        };

        $rounded = round(abs($amount), 2);
        $major = (int) floor($rounded);
        $minor = (int) round(($rounded - $major) * 100);

        if ($minor === 100) {
            $major++;
            $minor = 0;
        }

        $formatter = new NumberFormatter($normalizedLocale, NumberFormatter::SPELLOUT);
        $majorWords = $this->normalize((string) $formatter->format($major), $locale);
        $minorWords = $this->normalize((string) $formatter->format($minor), $locale);

        $majorUnit = $this->currencyUnit($currencyCode, 'major', $major, $locale);
        $minorUnit = $this->currencyUnit($currencyCode, 'minor', $minor, $locale);

        $result = trim($majorWords.' '.$majorUnit);
        if ($minor > 0) {
            $result .= ' '.__('governance.amount_words_connector').' '.trim($minorWords.' '.$minorUnit);
        }

        if ($amount < 0) {
            $result = __('governance.amount_words_negative').' '.$result;
        }

        return $this->ucfirst($result);
    }

    private function currencyUnit(string $currencyCode, string $part, int $count, string $locale): string
    {
        $code = strtolower($currencyCode);
        $key = "governance.currency_{$code}_{$part}";
        $translated = trans_choice($key, $count, ['count' => $count], $locale);

        if ($translated === $key) {
            return $part === 'major' ? strtoupper($currencyCode) : __('governance.currency_minor_generic');
        }

        return $translated;
    }

    private function normalize(string $words, string $locale): string
    {
        $words = trim(preg_replace('/\s+/u', ' ', $words) ?? $words);

        return $words;
    }

    private function ucfirst(string $value): string
    {
        if ($value === '') {
            return $value;
        }

        return mb_strtoupper(mb_substr($value, 0, 1)).mb_substr($value, 1);
    }
}
