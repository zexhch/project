<?php

namespace App\Services\Finance;

use App\Models\CustomerInvoice;
use App\Models\CustomerPayment;
use App\Models\SupplierInvoice;
use App\Models\SupplierPayment;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class BillingIntegrityService
{
    private const TOLERANCE = 0.0001;

    public function __construct(private readonly BillingService $billingService)
    {
    }

    /**
     * @return array{
     *     issue_count: int,
     *     truncated: bool,
     *     issues: array<int, array<string, mixed>>,
     *     checked: array<string, int>
     * }
     */
    public function audit(?string $companyId = null, int $maxIssues = 250): array
    {
        $issues = [];
        $issueCount = 0;
        $checked = [
            'customer_invoices' => 0,
            'supplier_invoices' => 0,
            'customer_payments' => 0,
            'supplier_payments' => 0,
        ];

        $customerInvoices = CustomerInvoice::query();
        $supplierInvoices = SupplierInvoice::query();
        $customerPayments = CustomerPayment::query();
        $supplierPayments = SupplierPayment::query();

        if ($companyId) {
            $customerInvoices->where('company_id', $companyId);
            $supplierInvoices->where('company_id', $companyId);
            $customerPayments->where('company_id', $companyId);
            $supplierPayments->where('company_id', $companyId);
        }

        $customerInvoices->chunkById(200, function ($invoices) use (&$checked, &$issues, &$issueCount, $maxIssues): void {
            foreach ($invoices as $invoice) {
                $checked['customer_invoices']++;
                $snapshot = $this->customerInvoiceSnapshot($invoice);
                $this->compareInvoice($invoice, $snapshot, 'customer_invoice', $issues, $issueCount, $maxIssues);
            }
        });

        $supplierInvoices->chunkById(200, function ($invoices) use (&$checked, &$issues, &$issueCount, $maxIssues): void {
            foreach ($invoices as $invoice) {
                $checked['supplier_invoices']++;
                $snapshot = $this->supplierInvoiceSnapshot($invoice);
                $this->compareInvoice($invoice, $snapshot, 'supplier_invoice', $issues, $issueCount, $maxIssues);
            }
        });

        $customerPayments->chunkById(200, function ($payments) use (&$checked, &$issues, &$issueCount, $maxIssues): void {
            foreach ($payments as $payment) {
                $checked['customer_payments']++;
                $this->comparePayment(
                    $payment,
                    (float) DB::table('customer_payment_allocations')->where('customer_payment_id', $payment->id)->sum('amount'),
                    'customer_payment',
                    $issues,
                    $issueCount,
                    $maxIssues,
                );
            }
        });

        $supplierPayments->chunkById(200, function ($payments) use (&$checked, &$issues, &$issueCount, $maxIssues): void {
            foreach ($payments as $payment) {
                $checked['supplier_payments']++;
                $this->comparePayment(
                    $payment,
                    (float) DB::table('supplier_payment_allocations')->where('supplier_payment_id', $payment->id)->sum('amount'),
                    'supplier_payment',
                    $issues,
                    $issueCount,
                    $maxIssues,
                );
            }
        });

        $customerContextQuery = DB::table('customer_payment_allocations as a')
            ->join('customer_payments as p', 'p.id', '=', 'a.customer_payment_id')
            ->join('customer_invoices as i', 'i.id', '=', 'a.customer_invoice_id')
            ->where(function ($query): void {
                $query->whereColumn('p.company_id', '!=', 'i.company_id')
                    ->orWhereColumn('p.customer_id', '!=', 'i.customer_id')
                    ->orWhereColumn('p.currency_code', '!=', 'i.currency_code');
            });
        $supplierContextQuery = DB::table('supplier_payment_allocations as a')
            ->join('supplier_payments as p', 'p.id', '=', 'a.supplier_payment_id')
            ->join('supplier_invoices as i', 'i.id', '=', 'a.supplier_invoice_id')
            ->where(function ($query): void {
                $query->whereColumn('p.company_id', '!=', 'i.company_id')
                    ->orWhereColumn('p.supplier_id', '!=', 'i.supplier_id')
                    ->orWhereColumn('p.currency_code', '!=', 'i.currency_code');
            });

        if ($companyId) {
            $customerContextQuery->where('p.company_id', $companyId);
            $supplierContextQuery->where('p.company_id', $companyId);
        }

        $this->appendContextIssue(
            'customer_allocation_context',
            $customerContextQuery->count(),
            $issues,
            $issueCount,
            $maxIssues,
        );

        $this->appendContextIssue(
            'supplier_allocation_context',
            $supplierContextQuery->count(),
            $issues,
            $issueCount,
            $maxIssues,
        );

        return [
            'issue_count' => $issueCount,
            'truncated' => $issueCount > count($issues),
            'issues' => $issues,
            'checked' => $checked,
        ];
    }

    /**
     * Rebuild derived totals. This method never creates, deletes or reallocates a payment.
     *
     * @return array<string, int>
     */
    public function repair(?string $companyId = null): array
    {
        $repaired = [
            'customer_invoices' => 0,
            'supplier_invoices' => 0,
            'customer_payments' => 0,
            'supplier_payments' => 0,
        ];

        $customerInvoices = CustomerInvoice::query();
        $supplierInvoices = SupplierInvoice::query();
        $customerPayments = CustomerPayment::query();
        $supplierPayments = SupplierPayment::query();

        if ($companyId) {
            $customerInvoices->where('company_id', $companyId);
            $supplierInvoices->where('company_id', $companyId);
            $customerPayments->where('company_id', $companyId);
            $supplierPayments->where('company_id', $companyId);
        }

        $customerInvoices->select('id')->chunkById(200, function ($invoices) use (&$repaired): void {
            DB::transaction(function () use ($invoices, &$repaired): void {
                $locked = CustomerInvoice::query()->whereKey($invoices->pluck('id'))->orderBy('id')->lockForUpdate()->get();
                foreach ($locked as $invoice) {
                    $this->billingService->recalculateCustomerInvoice($invoice);
                    $repaired['customer_invoices']++;
                }
            });
        });

        $supplierInvoices->select('id')->chunkById(200, function ($invoices) use (&$repaired): void {
            DB::transaction(function () use ($invoices, &$repaired): void {
                $locked = SupplierInvoice::query()->whereKey($invoices->pluck('id'))->orderBy('id')->lockForUpdate()->get();
                foreach ($locked as $invoice) {
                    $this->billingService->recalculateSupplierInvoice($invoice);
                    $repaired['supplier_invoices']++;
                }
            });
        });

        $customerPayments->select('id')->chunkById(200, function ($payments) use (&$repaired): void {
            DB::transaction(function () use ($payments, &$repaired): void {
                $locked = CustomerPayment::query()->whereKey($payments->pluck('id'))->orderBy('id')->lockForUpdate()->get();
                foreach ($locked as $payment) {
                    $this->repairPayment($payment, 'customer_payment_allocations', 'customer_payment_id');
                    $repaired['customer_payments']++;
                }
            });
        });

        $supplierPayments->select('id')->chunkById(200, function ($payments) use (&$repaired): void {
            DB::transaction(function () use ($payments, &$repaired): void {
                $locked = SupplierPayment::query()->whereKey($payments->pluck('id'))->orderBy('id')->lockForUpdate()->get();
                foreach ($locked as $payment) {
                    $this->repairPayment($payment, 'supplier_payment_allocations', 'supplier_payment_id');
                    $repaired['supplier_payments']++;
                }
            });
        });

        return $repaired;
    }

    /**
     * @return array<string, float|string>
     */
    private function customerInvoiceSnapshot(CustomerInvoice $invoice): array
    {
        $line = DB::table('customer_invoice_lines')
            ->where('customer_invoice_id', $invoice->id)
            ->selectRaw('COALESCE(SUM(line_subtotal), 0) AS subtotal, COALESCE(SUM(tax_amount), 0) AS tax_amount, COALESCE(SUM(line_total), 0) AS total_amount')
            ->first();
        $credits = (float) DB::table('customer_credit_notes')
            ->where('customer_invoice_id', $invoice->id)
            ->where('status', 'ISSUED')
            ->sum('applied_amount');
        $payments = (float) DB::table('customer_payment_allocations as a')
            ->join('customer_payments as p', 'p.id', '=', 'a.customer_payment_id')
            ->where('a.customer_invoice_id', $invoice->id)
            ->where('p.status', 'POSTED')
            ->sum('a.amount');

        return $this->invoiceSnapshot(
            $invoice,
            (float) $line->subtotal,
            (float) $line->tax_amount,
            (float) $line->total_amount,
            $credits,
            $payments,
        );
    }

    /**
     * @return array<string, float|string>
     */
    private function supplierInvoiceSnapshot(SupplierInvoice $invoice): array
    {
        $line = DB::table('supplier_invoice_lines')
            ->where('supplier_invoice_id', $invoice->id)
            ->selectRaw('COALESCE(SUM(line_subtotal), 0) AS subtotal, COALESCE(SUM(tax_amount), 0) AS tax_amount, COALESCE(SUM(line_total), 0) AS total_amount')
            ->first();
        $credits = (float) DB::table('supplier_credit_notes')
            ->where('supplier_invoice_id', $invoice->id)
            ->where('status', 'APPROVED')
            ->sum('applied_amount');
        $payments = (float) DB::table('supplier_payment_allocations as a')
            ->join('supplier_payments as p', 'p.id', '=', 'a.supplier_payment_id')
            ->where('a.supplier_invoice_id', $invoice->id)
            ->where('p.status', 'POSTED')
            ->sum('a.amount');

        return $this->invoiceSnapshot(
            $invoice,
            (float) $line->subtotal,
            (float) $line->tax_amount,
            (float) $line->total_amount,
            $credits,
            $payments,
        );
    }

    /**
     * @return array<string, float|string>
     */
    private function invoiceSnapshot(Model $invoice, float $subtotal, float $tax, float $total, float $credits, float $payments): array
    {
        $subtotal = round($subtotal, 4);
        $tax = round($tax, 4);
        $total = round($total, 4);
        $credits = round($credits, 4);
        $payments = round($payments, 4);
        $balance = max(0, round($total - $credits - $payments, 4));

        return [
            'subtotal' => $subtotal,
            'tax_amount' => $tax,
            'total_amount' => $total,
            'credit_amount' => $credits,
            'paid_amount' => $payments,
            'balance_amount' => $balance,
            'status' => $this->expectedStatus((string) $invoice->status, $balance, $credits + $payments, $invoice->due_date),
        ];
    }

    /**
     * @param  array<string, float|string>  $snapshot
     * @param  array<int, array<string, mixed>>  $issues
     */
    private function compareInvoice(Model $invoice, array $snapshot, string $entity, array &$issues, int &$issueCount, int $maxIssues): void
    {
        foreach ($snapshot as $field => $expected) {
            $stored = $invoice->{$field};
            $matches = is_numeric($expected)
                ? abs((float) $stored - (float) $expected) <= self::TOLERANCE
                : (string) $stored === (string) $expected;

            if (! $matches) {
                $this->appendIssue([
                    'type' => 'derived_value_mismatch',
                    'entity' => $entity,
                    'id' => $invoice->getKey(),
                    'number' => $invoice->invoice_number,
                    'field' => $field,
                    'stored' => $stored,
                    'expected' => $expected,
                ], $issues, $issueCount, $maxIssues);
            }
        }
    }

    /**
     * @param  array<int, array<string, mixed>>  $issues
     */
    private function comparePayment(Model $payment, float $allocationSum, string $entity, array &$issues, int &$issueCount, int $maxIssues): void
    {
        $allocationSum = round($allocationSum, 4);
        $expectedAllocated = $payment->status === 'DRAFT' ? 0.0 : $allocationSum;
        $expectedUnallocated = round((float) $payment->amount - $expectedAllocated, 4);

        foreach (['allocated_amount' => $expectedAllocated, 'unallocated_amount' => $expectedUnallocated] as $field => $expected) {
            if (abs((float) $payment->{$field} - $expected) > self::TOLERANCE) {
                $this->appendIssue([
                    'type' => 'derived_value_mismatch',
                    'entity' => $entity,
                    'id' => $payment->getKey(),
                    'number' => $payment->payment_number,
                    'field' => $field,
                    'stored' => $payment->{$field},
                    'expected' => $expected,
                ], $issues, $issueCount, $maxIssues);
            }
        }

        if ($allocationSum > (float) $payment->amount + self::TOLERANCE) {
            $this->appendIssue([
                'type' => 'allocation_exceeds_payment',
                'entity' => $entity,
                'id' => $payment->getKey(),
                'number' => $payment->payment_number,
                'field' => 'amount',
                'stored' => $payment->amount,
                'expected' => $allocationSum,
            ], $issues, $issueCount, $maxIssues);
        }
    }

    private function repairPayment(Model $payment, string $allocationTable, string $foreignKey): void
    {
        $allocationSum = round((float) DB::table($allocationTable)->where($foreignKey, $payment->id)->sum('amount'), 4);
        $allocated = $payment->status === 'DRAFT' ? 0.0 : $allocationSum;
        $payment->update([
            'allocated_amount' => $allocated,
            'unallocated_amount' => max(0, round((float) $payment->amount - $allocated, 4)),
        ]);
    }

    private function expectedStatus(string $current, float $balance, float $settled, Carbon|string|null $dueDate): string
    {
        if (in_array($current, ['DRAFT', 'CANCELLED'], true)) {
            return $current;
        }
        if ($balance <= self::TOLERANCE) {
            return 'PAID';
        }
        if ($dueDate && Carbon::parse($dueDate)->isBefore(today())) {
            return 'OVERDUE';
        }
        if ($settled > self::TOLERANCE) {
            return 'PARTIALLY_PAID';
        }

        return 'ISSUED';
    }

    /**
     * @param  array<string, mixed>  $issue
     * @param  array<int, array<string, mixed>>  $issues
     */
    private function appendIssue(array $issue, array &$issues, int &$issueCount, int $maxIssues): void
    {
        $issueCount++;
        if (count($issues) < $maxIssues) {
            $issues[] = $issue;
        }
    }

    /**
     * @param  array<int, array<string, mixed>>  $issues
     */
    private function appendContextIssue(string $type, int $count, array &$issues, int &$issueCount, int $maxIssues): void
    {
        if ($count === 0) {
            return;
        }

        $issueCount += $count;
        if (count($issues) < $maxIssues) {
            $issues[] = [
                'type' => $type,
                'entity' => 'allocation',
                'id' => null,
                'number' => null,
                'field' => 'context',
                'stored' => $count,
                'expected' => 0,
            ];
        }
    }
}
