<?php

namespace App\Services\Finance;

use App\Models\CostCalculation;
use App\Models\CostScenario;
use App\Models\CostScenarioLine;
use App\Models\MaintenanceWorkOrder;
use App\Models\ManagementBudget;
use App\Models\RecipeVersion;
use App\Models\SalesOrderLine;
use App\Services\Production\ProductionCostService;
use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

class ManagementControlService
{
    public function __construct(private readonly ProductionCostService $productionCosting) {}

    public function recalculateScenario(CostScenario $scenario, ?string $userId = null): CostScenario
    {
        $scenario->loadMissing(['lines.item', 'lines.recipeVersion.recipe']);

        foreach ($scenario->lines as $line) {
            $this->recalculateScenarioLine($line);
        }

        $scenario->refresh()->load('lines');
        $revenue = (float) $scenario->lines->sum('planned_revenue');
        $cost = (float) $scenario->lines->sum('planned_cost');
        $margin = $revenue - $cost;

        $scenario->update([
            'planned_revenue' => $revenue,
            'planned_cost' => $cost,
            'planned_margin' => $margin,
            'planned_margin_percentage' => $revenue > 0 ? ($margin / $revenue) * 100 : 0,
            'status' => 'CALCULATED',
            'calculated_by' => $userId,
            'calculated_at' => now(),
        ]);

        return $scenario->fresh(['lines.item', 'company']);
    }

    public function recalculateScenarioLine(CostScenarioLine $line): CostScenarioLine
    {
        $line->loadMissing(['item', 'recipeVersion', 'scenario.company']);
        $version = $line->recipeVersion ?: RecipeVersion::query()
            ->where('status', 'APPROVED')
            ->whereHas('recipe', fn ($query) => $query->where('finished_item_id', $line->item_id))
            ->latest('approved_at')
            ->first();

        $base = $version ? $this->productionCosting->theoretical($version) : null;
        if ($base && $base['currency_code'] !== $line->scenario->currency_code) {
            throw ValidationException::withMessages(['currency_code' => __('finance.currency_must_match_company')]);
        }
        $reference = max(0.000001, (float) ($base['reference_quantity'] ?? 1));
        $costs = collect($base['costs'] ?? [])->map(fn ($amount) => (float) $amount / $reference);

        $materialFactor = 1 + ((float) $line->material_adjustment_percentage / 100);
        $conversionFactor = 1 + ((float) $line->conversion_adjustment_percentage / 100);
        $overheadFactor = 1 + ((float) $line->overhead_adjustment_percentage / 100);

        $unitCosts = [
            'material_unit_cost' => ($costs->get('material_cost', 0) * $materialFactor),
            'packaging_unit_cost' => ($costs->get('packaging_cost', 0) * $materialFactor),
            'labor_unit_cost' => ($costs->get('labor_cost', 0) * $conversionFactor),
            'machine_unit_cost' => ($costs->get('machine_cost', 0) * $conversionFactor),
            'energy_unit_cost' => ($costs->get('energy_cost', 0) * $conversionFactor),
            'overhead_unit_cost' => ($costs->get('overhead_cost', 0) * $overheadFactor),
            'other_unit_cost' => (($costs->get('subcontracting_cost', 0) + $costs->get('other_cost', 0)) * $conversionFactor),
        ];

        $totalUnitCost = array_sum($unitCosts);
        $quantity = (float) $line->planned_quantity;
        $revenue = $quantity * (float) $line->sales_unit_price;
        $cost = $quantity * $totalUnitCost;
        $margin = $revenue - $cost;

        $line->update([
            'recipe_version_id' => $version?->id,
            ...$unitCosts,
            'total_unit_cost' => $totalUnitCost,
            'planned_revenue' => $revenue,
            'planned_cost' => $cost,
            'planned_margin' => $margin,
            'planned_margin_percentage' => $revenue > 0 ? ($margin / $revenue) * 100 : 0,
            'calculation_details' => [
                'source' => $version ? 'THEORETICAL_RECIPE' : 'NO_APPROVED_RECIPE',
                'recipe_version_id' => $version?->id,
                'base_warnings' => $base['warnings'] ?? [],
                'adjustments' => [
                    'material_percentage' => (float) $line->material_adjustment_percentage,
                    'conversion_percentage' => (float) $line->conversion_adjustment_percentage,
                    'overhead_percentage' => (float) $line->overhead_adjustment_percentage,
                ],
            ],
        ]);

        return $line->fresh(['item', 'recipeVersion']);
    }

    public function refreshBudget(ManagementBudget $budget): ManagementBudget
    {
        [$from, $to] = $this->periodBounds($budget->fiscal_year, $budget->period);
        $actual = $this->actualForCategory($budget->category_code, $budget->company_id, $budget->cost_center_id, $from, $to);
        $variance = (float) $budget->budget_amount - $actual;

        $budget->update([
            'actual_amount' => $actual,
            'variance_amount' => $variance,
            'variance_percentage' => (float) $budget->budget_amount !== 0.0
                ? ($variance / (float) $budget->budget_amount) * 100
                : 0,
            'refreshed_at' => now(),
        ]);

        return $budget->fresh(['costCenter', 'company']);
    }

    public function refreshBudgets(Collection $budgets): void
    {
        $budgets->each(fn (ManagementBudget $budget) => $this->refreshBudget($budget));
    }

    /**
     * Returns a margin estimate based on commercial quantities and the latest available manufacturing unit cost.
     */
    public function marginReport(?string $dateFrom = null, ?string $dateTo = null, ?string $companyId = null, ?string $siteId = null): array
    {
        $query = SalesOrderLine::query()
            ->with(['salesOrder.customer', 'item'])
            ->whereHas('salesOrder', function ($orderQuery) use ($dateFrom, $dateTo, $companyId, $siteId): void {
                $orderQuery->whereNotIn('status', ['DRAFT', 'CANCELLED']);
                if ($companyId) {
                    $orderQuery->where('company_id', $companyId);
                }
                if ($siteId) {
                    $orderQuery->where('site_id', $siteId);
                }
                if ($dateFrom) {
                    $orderQuery->whereDate('order_date', '>=', $dateFrom);
                }
                if ($dateTo) {
                    $orderQuery->whereDate('order_date', '<=', $dateTo);
                }
            })
            ->get();

        $costCache = [];
        $rows = $query->map(function (SalesOrderLine $line) use (&$costCache, $companyId): array {
            $quantity = (float) $line->delivered_quantity > 0
                ? max(0, (float) $line->delivered_quantity - (float) $line->returned_quantity)
                : (float) $line->ordered_quantity;
            $baseQuantity = $quantity * (float) $line->factor_to_base;
            $costData = $costCache[$line->item_id] ??= $this->latestCostData($line->item_id, $companyId);
            $unitCost = $costData['unit_cost'];
            $revenue = $quantity * (float) $line->net_unit_price * (float) $line->salesOrder->exchange_rate;
            $cost = $baseQuantity * $unitCost;
            $margin = $revenue - $cost;

            return [
                'order_id' => $line->sales_order_id,
                'order_number' => $line->salesOrder->order_number,
                'order_date' => $line->salesOrder->order_date,
                'customer_id' => $line->salesOrder->customer_id,
                'customer_name' => $line->salesOrder->customer->name,
                'item_id' => $line->item_id,
                'item_code' => $line->item->code,
                'item_name' => $line->item->name,
                'quantity' => $quantity,
                'revenue' => $revenue,
                'cost' => $cost,
                'margin' => $margin,
                'margin_percentage' => $revenue > 0 ? ($margin / $revenue) * 100 : 0,
                'unit_cost' => $unitCost,
                'cost_source' => $costData['source'],
            ];
        });

        $totals = $this->aggregateMargin($rows);

        return [
            'rows' => $rows->sortByDesc('margin')->values(),
            'by_customer' => $rows->groupBy('customer_id')->map(function (Collection $customerRows): array {
                $result = $this->aggregateMargin($customerRows);
                $result['customer_name'] = $customerRows->first()['customer_name'];

                return $result;
            })->sortByDesc('margin')->values(),
            'by_item' => $rows->groupBy('item_id')->map(function (Collection $itemRows): array {
                $result = $this->aggregateMargin($itemRows);
                $result['item_code'] = $itemRows->first()['item_code'];
                $result['item_name'] = $itemRows->first()['item_name'];
                $result['cost_source'] = $itemRows->pluck('cost_source')->contains('ACTUAL') ? 'ACTUAL' : ($itemRows->pluck('cost_source')->contains('THEORETICAL') ? 'THEORETICAL' : 'NONE');

                return $result;
            })->sortByDesc('margin')->values(),
            'totals' => $totals,
        ];
    }

    private function aggregateMargin(Collection $rows): array
    {
        $revenue = (float) $rows->sum('revenue');
        $cost = (float) $rows->sum('cost');
        $margin = $revenue - $cost;

        return [
            'revenue' => $revenue,
            'cost' => $cost,
            'margin' => $margin,
            'margin_percentage' => $revenue > 0 ? ($margin / $revenue) * 100 : 0,
            'line_count' => $rows->count(),
        ];
    }

    /** @return array{unit_cost: float, source: string} */
    private function latestCostData(string $itemId, ?string $companyId): array
    {
        $actualQuery = CostCalculation::query()
            ->where('calculation_type', 'ACTUAL')
            ->whereHas('productionOrder', function ($query) use ($itemId, $companyId): void {
                $query->where('finished_item_id', $itemId);
                if ($companyId) {
                    $query->whereHas('productionLine.site', fn ($site) => $site->where('company_id', $companyId));
                }
            });
        $actual = $actualQuery->latest('calculated_at')->value('unit_cost');

        if ($actual !== null) {
            return ['unit_cost' => (float) $actual, 'source' => 'ACTUAL'];
        }

        $theoretical = CostCalculation::query()
            ->where('calculation_type', 'THEORETICAL')
            ->whereHas('recipeVersion.recipe', fn ($query) => $query->where('finished_item_id', $itemId))
            ->latest('calculated_at')
            ->value('unit_cost');

        return $theoretical === null
            ? ['unit_cost' => 0.0, 'source' => 'NONE']
            : ['unit_cost' => (float) $theoretical, 'source' => 'THEORETICAL'];
    }

    private function actualForCategory(string $category, string $companyId, ?string $costCenterId, CarbonImmutable $from, CarbonImmutable $to): float
    {
        if ($category === 'MAINTENANCE') {
            return $this->maintenanceActual($companyId, $costCenterId, $from, $to);
        }

        $query = CostCalculation::query()
            ->where('calculation_type', 'ACTUAL')
            ->whereBetween('calculated_at', [$from, $to])
            ->whereHas('productionOrder.productionLine.site', fn ($site) => $site->where('company_id', $companyId));

        if ($costCenterId) {
            $query->whereHas('productionOrder.productionLine', fn ($line) => $line->where('cost_center_id', $costCenterId));
        }

        $columns = match ($category) {
            'MATERIAL' => ['material_cost', 'packaging_cost'],
            'LABOR' => ['labor_cost'],
            'MACHINE' => ['machine_cost'],
            'ENERGY' => ['energy_cost'],
            'OVERHEAD' => ['overhead_cost'],
            'OTHER' => ['subcontracting_cost', 'other_cost'],
            default => ['total_cost'],
        };

        $productionActual = (float) $query
            ->selectRaw('COALESCE(SUM('.implode(' + ', $columns).'), 0) AS total')
            ->value('total');

        return $category === 'TOTAL'
            ? $productionActual + $this->maintenanceActual($companyId, $costCenterId, $from, $to)
            : $productionActual;
    }

    private function maintenanceActual(string $companyId, ?string $costCenterId, CarbonImmutable $from, CarbonImmutable $to): float
    {
        $query = MaintenanceWorkOrder::query()
            ->where('status', 'COMPLETED')
            ->whereBetween('actual_end', [$from, $to]);

        $query->where(function ($scope) use ($companyId): void {
            $scope->whereHas('productionLine.site', fn ($site) => $site->where('company_id', $companyId))
                ->orWhereHas('machine.site', fn ($site) => $site->where('company_id', $companyId));
        });

        if ($costCenterId) {
            $query->where(function ($scope) use ($costCenterId): void {
                $scope->whereHas('productionLine', fn ($line) => $line->where('cost_center_id', $costCenterId))
                    ->orWhereHas('machine', fn ($machine) => $machine->where('cost_center_id', $costCenterId));
            });
        }

        return (float) $query
            ->selectRaw('COALESCE(SUM(labor_cost + parts_cost), 0) AS total')
            ->value('total');
    }

    /** @return array{0: CarbonImmutable, 1: CarbonImmutable} */
    private function periodBounds(int $year, int $period): array
    {
        if ($period >= 1 && $period <= 12) {
            $from = CarbonImmutable::create($year, $period, 1)->startOfDay();

            return [$from, $from->endOfMonth()->endOfDay()];
        }

        return [
            CarbonImmutable::create($year, 1, 1)->startOfDay(),
            CarbonImmutable::create($year, 12, 31)->endOfDay(),
        ];
    }
}
