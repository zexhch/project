<?php

namespace App\Services\Modules;

use Illuminate\Support\Facades\Route;

class ModuleRouteLoader
{
    public function __construct(private readonly ModuleRegistry $registry)
    {
    }

    public function loadWebRoutes(): void
    {
        foreach ($this->registry->definitions() as $definition) {
            foreach ($definition['routes'] as $relativePath) {
                $path = $definition['base_path'].'/'.$relativePath;

                Route::middleware(['auth', 'module:'.$definition['code']])
                    ->group($path);
            }
        }
    }

    /** @return array<int, string> */
    public function migrationPaths(): array
    {
        $paths = [];

        foreach ($this->registry->definitions() as $definition) {
            foreach ($definition['migrations'] as $relativePath) {
                $paths[] = $definition['base_path'].'/'.$relativePath;
            }
        }

        return array_values(array_unique($paths));
    }
}
