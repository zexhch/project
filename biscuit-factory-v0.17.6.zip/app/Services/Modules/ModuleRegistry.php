<?php

namespace App\Services\Modules;

use App\Models\ApplicationModule;
use App\Models\User;
use DomainException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use RuntimeException;

class ModuleRegistry
{
    /** @var array<string, array<string, mixed>>|null */
    private ?array $definitions = null;

    private const ENABLED_STATES_CACHE_KEY = 'application-modules:enabled:v1';

    /**
     * @return array<string, array<string, mixed>>
     */
    public function definitions(): array
    {
        if ($this->definitions !== null) {
            return $this->definitions;
        }

        $definitions = [];
        $manifests = glob(app_path('Modules/*/module.php')) ?: [];

        foreach ($manifests as $manifestPath) {
            $definition = require $manifestPath;
            $this->assertDefinition($definition, $manifestPath);

            $code = $definition['code'];
            if (isset($definitions[$code])) {
                throw new RuntimeException("Duplicate application module code [{$code}].");
            }

            $definition['base_path'] = dirname($manifestPath);
            $definition['manifest_path'] = $manifestPath;
            $definition['manifest_hash'] = hash_file('sha256', $manifestPath);
            $definitions[$code] = $definition;
        }

        uasort($definitions, fn (array $left, array $right): int => [$left['order'], $left['code']] <=> [$right['order'], $right['code']]);
        $this->validateDependencyGraph($definitions);

        return $this->definitions = $definitions;
    }

    public function definition(string $code): array
    {
        return $this->definitions()[$code] ?? throw new DomainException("Unknown application module [{$code}].");
    }

    public function enabled(string $code): bool
    {
        $definition = $this->definition($code);

        if ($definition['core']) {
            return true;
        }

        return $this->enabledStates()[$code] ?? (bool) $definition['default_enabled'];
    }

    public function sync(): Collection
    {
        if (! Schema::hasTable('application_modules')) {
            return collect();
        }

        return DB::transaction(function (): Collection {
            $models = collect();

            foreach ($this->definitions() as $code => $definition) {
                $module = ApplicationModule::query()->firstOrNew(['code' => $code]);
                $isNew = ! $module->exists;

                $module->fill([
                    'name_key' => $definition['name'],
                    'description_key' => $definition['description'],
                    'version' => $definition['version'],
                    'icon' => $definition['icon'],
                    'core' => (bool) $definition['core'],
                    'sort_order' => (int) $definition['order'],
                    'manifest_hash' => $definition['manifest_hash'],
                ]);

                if ($isNew) {
                    $module->enabled = (bool) ($definition['core'] || $definition['default_enabled']);
                    $module->installed_at = now();
                    $module->enabled_at = $module->enabled ? now() : null;
                }

                if ($definition['core']) {
                    $module->enabled = true;
                    $module->disabled_at = null;
                    $module->enabled_at ??= now();
                }

                $module->save();
                $models->put($code, $module);
            }

            if (Schema::hasTable('application_module_dependencies')) {
                DB::table('application_module_dependencies')->delete();
                $rows = [];

                foreach ($this->definitions() as $code => $definition) {
                    foreach ($definition['dependencies'] as $dependencyCode) {
                        $rows[] = [
                            'module_id' => $models[$code]->id,
                            'dependency_id' => $models[$dependencyCode]->id,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }

                if ($rows !== []) {
                    DB::table('application_module_dependencies')->insert($rows);
                }
            }

            $this->forgetStateCache();

            return $models->values();
        });
    }

    public function setEnabled(string $code, bool $enabled, ?User $actor = null): ApplicationModule
    {
        $definition = $this->definition($code);

        if (! Schema::hasTable('application_modules')) {
            throw new DomainException(__('modules.registry_not_installed'));
        }

        $this->sync();

        return DB::transaction(function () use ($code, $enabled, $actor, $definition): ApplicationModule {
            $lockedModules = ApplicationModule::query()
                ->whereIn('code', array_keys($this->definitions()))
                ->orderBy('code')
                ->lockForUpdate()
                ->get()
                ->keyBy('code');
            $module = $lockedModules->get($code) ?? throw new DomainException(__('modules.registry_not_installed'));
            $before = $module->enabled;

            if ($enabled === $before) {
                return $module;
            }

            if (! $enabled && $definition['core']) {
                throw new DomainException(__('modules.core_cannot_disable'));
            }

            if ($enabled) {
                $missingDependencies = collect($definition['dependencies'])
                    ->reject(fn (string $dependency): bool => (bool) $lockedModules->get($dependency)?->enabled)
                    ->values();

                if ($missingDependencies->isNotEmpty()) {
                    throw new DomainException(__('modules.enable_dependencies_first', [
                        'modules' => $missingDependencies->map(fn (string $dependency): string => __($this->definition($dependency)['name']))->join(', '),
                    ]));
                }
            } else {
                $activeDependents = $this->dependentsOf($code)
                    ->filter(fn (string $dependent): bool => (bool) $lockedModules->get($dependent)?->enabled);

                if ($activeDependents->isNotEmpty()) {
                    throw new DomainException(__('modules.disable_dependents_first', [
                        'modules' => $activeDependents->map(fn (string $dependent): string => __($this->definition($dependent)['name']))->join(', '),
                    ]));
                }
            }

            $module->enabled = $enabled;
            $module->enabled_at = $enabled ? now() : $module->enabled_at;
            $module->disabled_at = $enabled ? null : now();
            $module->updated_by = $actor?->id;
            $module->save();

            if (Schema::hasTable('audit_logs')) {
                DB::table('audit_logs')->insert([
                    'id' => (string) Str::uuid(),
                    'user_id' => $actor?->id,
                    'event' => $enabled ? 'module.enabled' : 'module.disabled',
                    'auditable_type' => ApplicationModule::class,
                    'auditable_id' => $module->id,
                    'old_values' => json_encode(['enabled' => $before], JSON_THROW_ON_ERROR),
                    'new_values' => json_encode(['enabled' => $enabled, 'code' => $code], JSON_THROW_ON_ERROR),
                    'ip_address' => app()->runningInConsole() ? null : request()->ip(),
                    'user_agent' => app()->runningInConsole() ? null : request()->userAgent(),
                    'created_at' => now(),
                ]);
            }

            $this->forgetStateCache();

            return $module->refresh();
        });
    }

    /** @return Collection<int, string> */
    public function dependentsOf(string $code): Collection
    {
        return collect($this->definitions())
            ->filter(fn (array $definition): bool => in_array($code, $definition['dependencies'], true))
            ->keys()
            ->values();
    }

    /** @return Collection<int, array<string, mixed>> */
    public function states(): Collection
    {
        $persisted = Schema::hasTable('application_modules')
            ? ApplicationModule::query()->get()->keyBy('code')
            : collect();

        return collect($this->definitions())->map(function (array $definition, string $code) use ($persisted): array {
            /** @var ApplicationModule|null $model */
            $model = $persisted->get($code);
            $dependencies = collect($definition['dependencies']);
            $dependents = $this->dependentsOf($code);

            return [
                ...$definition,
                'enabled' => $definition['core'] || ($model?->enabled ?? $definition['default_enabled']),
                'persisted' => $model !== null,
                'model' => $model,
                'dependencies_state' => $dependencies->map(fn (string $dependency): array => [
                    'code' => $dependency,
                    'label' => __($this->definition($dependency)['name']),
                    'enabled' => $this->enabled($dependency),
                ])->all(),
                'dependents_state' => $dependents->map(fn (string $dependent): array => [
                    'code' => $dependent,
                    'label' => __($this->definition($dependent)['name']),
                    'enabled' => $this->enabled($dependent),
                ])->all(),
            ];
        })->values();
    }

    public function diagnostics(): array
    {
        $issues = collect();
        $definitions = $this->definitions();
        $registryInstalled = Schema::hasTable('application_modules');
        $persisted = $registryInstalled
            ? ApplicationModule::query()->get()->keyBy('code')
            : collect();

        if (! $registryInstalled) {
            $issues->push(['module' => 'system', 'type' => 'registry_not_installed', 'value' => null]);
        } else {
            $persisted->keys()
                ->diff(array_keys($definitions))
                ->each(fn (string $code) => $issues->push([
                    'module' => $code,
                    'type' => 'orphaned_registry_record',
                    'value' => null,
                ]));
        }

        foreach ($definitions as $code => $definition) {
            foreach ($definition['routes'] as $routePath) {
                if (! is_file($definition['base_path'].'/'.$routePath)) {
                    $issues->push(['module' => $code, 'type' => 'missing_route_file', 'value' => $routePath]);
                }
            }

            foreach ($definition['migrations'] as $migrationPath) {
                if (! is_dir($definition['base_path'].'/'.$migrationPath)) {
                    $issues->push(['module' => $code, 'type' => 'missing_migration_path', 'value' => $migrationPath]);
                }
            }

            $model = $persisted->get($code);
            if ($registryInstalled && ! $model) {
                $issues->push(['module' => $code, 'type' => 'not_synchronized', 'value' => null]);
            } elseif ($model && $model->manifest_hash !== $definition['manifest_hash']) {
                $issues->push(['module' => $code, 'type' => 'manifest_out_of_sync', 'value' => null]);
            }

            if ($this->enabled($code)) {
                foreach ($definition['dependencies'] as $dependency) {
                    if (! $this->enabled($dependency)) {
                        $issues->push(['module' => $code, 'type' => 'disabled_dependency', 'value' => $dependency]);
                    }
                }
            }
        }

        return [
            'module_count' => count($definitions),
            'enabled_count' => collect(array_keys($definitions))->filter(fn (string $code): bool => $this->enabled($code))->count(),
            'issue_count' => $issues->count(),
            'issues' => $issues->values()->all(),
        ];
    }

    /** @return array<string, bool> */
    private function enabledStates(): array
    {
        if (! Schema::hasTable('application_modules')) {
            return [];
        }

        return Cache::remember(self::ENABLED_STATES_CACHE_KEY, now()->addSeconds(30), fn (): array => ApplicationModule::query()
            ->pluck('enabled', 'code')
            ->map(fn (mixed $enabled): bool => (bool) $enabled)
            ->all());
    }

    public function forgetStateCache(): void
    {
        Cache::forget(self::ENABLED_STATES_CACHE_KEY);
    }

    private function assertDefinition(mixed $definition, string $path): void
    {
        $required = ['code', 'name', 'description', 'version', 'icon', 'order', 'core', 'default_enabled', 'permissions', 'dependencies', 'routes', 'migrations'];

        if (! is_array($definition)) {
            throw new RuntimeException("Invalid module manifest [{$path}].");
        }

        foreach ($required as $key) {
            if (! array_key_exists($key, $definition)) {
                throw new RuntimeException("Missing module manifest key [{$key}] in [{$path}].");
            }
        }

        if (! preg_match('/^[a-z][a-z0-9-]*$/', (string) $definition['code'])) {
            throw new RuntimeException("Invalid module code [{$definition['code']}].");
        }
    }

    /** @param array<string, array<string, mixed>> $definitions */
    private function validateDependencyGraph(array $definitions): void
    {
        foreach ($definitions as $code => $definition) {
            foreach ($definition['dependencies'] as $dependency) {
                if (! isset($definitions[$dependency])) {
                    throw new RuntimeException("Module [{$code}] references missing dependency [{$dependency}].");
                }
                if ($dependency === $code) {
                    throw new RuntimeException("Module [{$code}] cannot depend on itself.");
                }
            }
        }

        $visiting = [];
        $visited = [];
        $visit = function (string $code) use (&$visit, &$visiting, &$visited, $definitions): void {
            if (isset($visited[$code])) {
                return;
            }
            if (isset($visiting[$code])) {
                throw new RuntimeException("Circular application module dependency detected at [{$code}].");
            }
            $visiting[$code] = true;
            foreach ($definitions[$code]['dependencies'] as $dependency) {
                $visit($dependency);
            }
            unset($visiting[$code]);
            $visited[$code] = true;
        };

        foreach (array_keys($definitions) as $code) {
            $visit($code);
        }
    }
}
