<?php

namespace App\Services\Stock;

use App\Models\InventoryCount;
use App\Models\StockBalance;
use App\Models\StockMovement;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class InventoryService
{
    public function freeze(InventoryCount $inventory): InventoryCount
    {
        return DB::transaction(function () use ($inventory): InventoryCount {
            $inventory = InventoryCount::query()->lockForUpdate()->findOrFail($inventory->id);
            if ($inventory->status !== 'DRAFT') throw ValidationException::withMessages(['inventory' => __('stock.invalid_inventory_status')]);
            $balances = StockBalance::query()->whereHas('location', fn ($q) => $q->where('warehouse_id', $inventory->warehouse_id))->get();
            foreach ($balances as $balance) {
                $inventory->lines()->create([
                    'item_id' => $balance->item_id, 'lot_id' => $balance->lot_id, 'location_id' => $balance->location_id,
                    'expected_quantity' => $balance->quantity,
                ]);
            }
            $inventory->update(['status' => 'COUNTING', 'frozen_at' => now()]);
            return $inventory->fresh('lines');
        });
    }

    public function post(InventoryCount $inventory, string $userId, StockPostingService $posting): InventoryCount
    {
        return DB::transaction(function () use ($inventory, $userId, $posting): InventoryCount {
            $inventory = InventoryCount::query()->with('lines.item')->lockForUpdate()->findOrFail($inventory->id);
            if ($inventory->status !== 'COUNTING' || $inventory->lines->contains(fn ($line) => $line->counted_quantity === null)) {
                throw ValidationException::withMessages(['inventory' => __('stock.count_all_lines')]);
            }
            $movement = StockMovement::create([
                'movement_number' => 'INV-'.now()->format('YmdHis').'-'.strtoupper(substr($inventory->id, 0, 4)),
                'movement_type' => 'ADJUSTMENT_IN', 'movement_at' => now(), 'source_type' => InventoryCount::class,
                'source_id' => $inventory->id, 'status' => 'DRAFT', 'created_by' => $userId,
            ]);
            foreach ($inventory->lines as $line) {
                $variance = (float) $line->counted_quantity - (float) $line->expected_quantity;
                $line->update(['variance_quantity' => $variance]);
                if ($variance == 0.0) continue;
                $movement->lines()->create([
                    'item_id' => $line->item_id, 'lot_id' => $line->lot_id,
                    'source_location_id' => $variance < 0 ? $line->location_id : null,
                    'destination_location_id' => $variance > 0 ? $line->location_id : null,
                    'quantity' => abs($variance), 'unit_id' => $line->item->base_unit_id,
                ]);
            }
            if ($movement->lines()->exists()) {
                $movement->update(['movement_type' => 'INVENTORY_ADJUSTMENT']);
                $posting->post($movement, $userId);
            } else $movement->delete();
            $inventory->update(['status' => 'POSTED', 'posted_at' => now(), 'posted_by' => $userId]);
            return $inventory->fresh('lines');
        });
    }
}
