<?php

namespace App\Services\Stock;

use App\Events\DashboardUpdated;
use App\Models\StockBalance;
use App\Models\StockMovement;
use App\Models\StockMovementLine;
use App\Models\Lot;
use App\Models\CustomerReturn;
use App\Services\Modules\ModuleRegistry;
use App\Services\Quality\QualityInspectionPlanner;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class StockPostingService
{
    public function __construct(private readonly ModuleRegistry $modules)
    {
    }

    public function post(StockMovement $movement, string $userId): StockMovement
    {
        return DB::transaction(function () use ($movement, $userId): StockMovement {
            $movement = StockMovement::query()->with('lines')->lockForUpdate()->findOrFail($movement->id);
            if ($movement->status !== 'DRAFT') {
                throw ValidationException::withMessages(['movement' => __('stock.already_posted')]);
            }
            if ($movement->lines->isEmpty()) {
                throw ValidationException::withMessages(['movement' => __('stock.line_required')]);
            }

            foreach ($movement->lines as $line) {
                $this->validateLine($movement->movement_type, $line);
                if ($line->source_location_id && $line->unit_cost === null) {
                    $line->unit_cost = StockBalance::query()->where([
                        'item_id' => $line->item_id, 'lot_id' => $line->lot_id,
                        'location_id' => $line->source_location_id,
                    ])->value('average_unit_cost');
                    $line->save();
                }
                if ($line->source_location_id) {
                    $this->changeBalance($line, $line->source_location_id, -(float) $line->quantity, false);
                }
                if ($line->destination_location_id) {
                    $this->changeBalance($line, $line->destination_location_id, (float) $line->quantity, true);
                }
            }

            $movement->update(['status' => 'POSTED', 'posted_at' => now(), 'posted_by' => $userId]);
            if ($movement->movement_type === 'RECEIPT' && $this->modules->enabled('quality')) {
                $controlStage = $movement->source_type === CustomerReturn::class ? 'CUSTOMER_RETURN' : 'RECEIVING';
                $movement->lines->whereNotNull('lot_id')->each(function (StockMovementLine $line) use ($movement, $userId, $controlStage): void {
                    $lot = Lot::find($line->lot_id);
                    if ($lot) {
                        app(QualityInspectionPlanner::class)->createForLot(
                            $lot,
                            $controlStage,
                            stockMovementId: $movement->id,
                            inspectorId: $userId,
                        );
                    }
                });
            }
            $this->audit('stock.movement.posted', $movement, $userId);
            DB::afterCommit(fn () => event(new DashboardUpdated(['stock_movement_id' => $movement->id])));
            return $movement->fresh('lines');
        }, 3);
    }

    private function validateLine(string $type, StockMovementLine $line): void
    {
        if ((float) $line->quantity <= 0) {
            throw ValidationException::withMessages(['quantity' => __('stock.positive_quantity')]);
        }
        $needsSource = in_array($type, ['ISSUE', 'TRANSFER'], true);
        $needsDestination = in_array($type, ['RECEIPT', 'TRANSFER', 'ADJUSTMENT_IN'], true);
        if ($needsSource && !$line->source_location_id) {
            throw ValidationException::withMessages(['source_location_id' => __('stock.source_required')]);
        }
        if ($needsDestination && !$line->destination_location_id) {
            throw ValidationException::withMessages(['destination_location_id' => __('stock.destination_required')]);
        }
        if ($type === 'TRANSFER' && $line->source_location_id === $line->destination_location_id) {
            throw ValidationException::withMessages(['destination_location_id' => __('stock.locations_must_differ')]);
        }
        if ($line->lot_id && !\App\Models\Lot::query()->whereKey($line->lot_id)->where('item_id', $line->item_id)->exists()) {
            throw ValidationException::withMessages(['lot_id' => __('stock.lot_item_mismatch')]);
        }
    }

    private function changeBalance(StockMovementLine $line, string $locationId, float $delta, bool $incoming): void
    {
        $balance = StockBalance::query()->where([
            'item_id' => $line->item_id,
            'lot_id' => $line->lot_id,
            'location_id' => $locationId,
        ])->lockForUpdate()->first();

        if (!$balance) {
            $balance = StockBalance::create([
                'item_id' => $line->item_id, 'lot_id' => $line->lot_id,
                'location_id' => $locationId, 'quantity' => 0, 'reserved_quantity' => 0,
            ]);
        }

        $current = (float) $balance->quantity;
        $newQuantity = $current + $delta;
        if ($newQuantity < 0 && !$this->negativeStockAllowed()) {
            throw ValidationException::withMessages(['quantity' => __('stock.insufficient_stock')]);
        }

        $values = ['quantity' => $newQuantity];
        if ($incoming && $line->unit_cost !== null) {
            $incomingValue = (float) $line->quantity * (float) $line->unit_cost;
            $currentValue = max(0, $current) * (float) ($balance->average_unit_cost ?? 0);
            $values['average_unit_cost'] = $newQuantity > 0 ? ($currentValue + $incomingValue) / $newQuantity : null;
        }
        $balance->update($values);
    }

    private function negativeStockAllowed(): bool
    {
        $raw = DB::table('system_settings')->where('group', 'stock')->where('key', 'allow_negative_stock')->value('value');
        return filter_var(json_decode((string) $raw, true), FILTER_VALIDATE_BOOL);
    }

    private function audit(string $event, StockMovement $movement, string $userId): void
    {
        DB::table('audit_logs')->insert([
            'id' => (string) \Illuminate\Support\Str::uuid(), 'user_id' => $userId, 'event' => $event,
            'auditable_type' => StockMovement::class, 'auditable_id' => $movement->id,
            'old_values' => json_encode(['status' => 'DRAFT']), 'new_values' => json_encode(['status' => 'POSTED']),
            'ip_address' => request()?->ip(), 'user_agent' => request()?->userAgent(), 'created_at' => now(),
        ]);
    }
}
