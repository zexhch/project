<?php

namespace App\Services\Stock;

use App\Models\StockBalance;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

class FefoService
{
    public function allocate(string $itemId, string $locationId, float $quantity): Collection
    {
        return $this->allocateFromQuery(
            StockBalance::query()->where('location_id', $locationId),
            $itemId,
            $quantity,
        );
    }

    public function allocateInWarehouse(string $itemId, string $warehouseId, float $quantity): Collection
    {
        return $this->allocateFromQuery(
            StockBalance::query()->whereHas('location', fn ($query) => $query
                ->where('warehouse_id', $warehouseId)->where('active', true)),
            $itemId,
            $quantity,
        );
    }

    private function allocateFromQuery($query, string $itemId, float $quantity): Collection
    {
        $remaining = $quantity;
        $allocations = collect();
        $balances = $query->with(['lot', 'location'])->where('item_id', $itemId)
            ->whereRaw('quantity > reserved_quantity')
            ->where(fn ($query) => $query
                ->whereNull('lot_id')
                ->orWhereHas('lot', fn ($lot) => $lot
                    ->where('status', 'RELEASED')
                    ->where(fn ($expiry) => $expiry->whereNull('expiry_date')->orWhereDate('expiry_date', '>=', today()))))
            ->orderByRaw('CASE WHEN lot_id IS NULL THEN 1 ELSE 0 END')
            ->get()->sortBy(fn (StockBalance $balance) => $balance->lot?->expiry_date?->format('Y-m-d') ?? '9999-12-31');

        foreach ($balances as $balance) {
            $available = (float) $balance->quantity - (float) $balance->reserved_quantity;
            $taken = min($remaining, $available);
            if ($taken > 0) {
                $allocations->push([
                    'balance_id' => $balance->id,
                    'lot_id' => $balance->lot_id,
                    'location_id' => $balance->location_id,
                    'quantity' => $taken,
                ]);
                $remaining -= $taken;
            }
            if ($remaining <= 0) {
                break;
            }
        }
        if ($remaining > 0) {
            throw ValidationException::withMessages(['quantity' => __('stock.insufficient_released_stock')]);
        }

        return $allocations;
    }
}
