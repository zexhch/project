<?php

namespace App\Services\Workflow;

use App\Models\WorkflowEvent;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;

class WorkflowTimelineService
{
    public function record(
        Model $subject,
        string $eventCode,
        ?string $fromStatus = null,
        ?string $toStatus = null,
        ?string $label = null,
        array $metadata = [],
        ?string $userId = null,
    ): WorkflowEvent {
        return WorkflowEvent::query()->create([
            'company_id' => $this->companyId($subject),
            'user_id' => $userId ?? auth()->id(),
            'event_code' => $eventCode,
            'subject_type' => $subject::class,
            'subject_id' => (string) $subject->getKey(),
            'from_status' => $fromStatus,
            'to_status' => $toStatus,
            'label' => $label,
            'metadata' => $metadata ?: null,
            'occurred_at' => now(),
        ]);
    }

    public function entries(Model $subject, int $limit = 30): Collection
    {
        $workflow = WorkflowEvent::query()
            ->with('user:id,name')
            ->where('subject_type', $subject::class)
            ->where('subject_id', $subject->getKey())
            ->latest('occurred_at')
            ->limit($limit)
            ->get()
            ->map(fn (WorkflowEvent $event): array => [
                'id' => $event->id,
                'code' => $event->event_code,
                'label' => $event->label ?: $event->event_code,
                'from_status' => $event->from_status,
                'to_status' => $event->to_status,
                'metadata' => $event->metadata ?? [],
                'user' => $event->user?->name,
                'occurred_at' => $event->occurred_at,
                'source' => 'workflow',
            ]);

        $audit = \App\Models\AuditLog::query()
            ->with('user:id,name')
            ->where('auditable_type', $subject::class)
            ->where('auditable_id', $subject->getKey())
            ->latest('created_at')
            ->limit($limit)
            ->get()
            ->map(fn ($entry): array => [
                'id' => $entry->id,
                'code' => $entry->event,
                'label' => $entry->event,
                'from_status' => data_get($entry->old_values, 'status'),
                'to_status' => data_get($entry->new_values, 'status'),
                'metadata' => $entry->new_values ?? [],
                'user' => $entry->user?->name,
                'occurred_at' => $entry->created_at,
                'source' => 'audit',
            ]);

        return $workflow
            ->concat($audit)
            ->sortByDesc(fn (array $entry) => $entry['occurred_at']?->getTimestamp() ?? 0)
            ->unique(fn (array $entry) => implode('|', [
                $entry['code'],
                $entry['from_status'],
                $entry['to_status'],
                $entry['occurred_at']?->format('Y-m-d H:i:s'),
            ]))
            ->take($limit)
            ->values();
    }

    private function companyId(Model $subject): ?string
    {
        if ($subject->getAttribute('company_id')) {
            return (string) $subject->getAttribute('company_id');
        }

        foreach (['salesOrder', 'purchaseOrder', 'customer', 'supplier'] as $relation) {
            if (method_exists($subject, $relation)) {
                $related = $subject->{$relation}()->first();
                if ($related?->getAttribute('company_id')) {
                    return (string) $related->getAttribute('company_id');
                }
            }
        }

        return null;
    }
}
