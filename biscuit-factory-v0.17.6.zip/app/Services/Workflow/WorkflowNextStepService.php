<?php

namespace App\Services\Workflow;

use App\Models\CustomerInvoice;
use App\Models\DeliveryNote;
use App\Models\GoodsReceipt;
use App\Models\MaintenanceWorkOrder;
use App\Models\ProductionOrder;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\QualityInspection;
use App\Models\QualityNonConformity;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\SupplierInvoice;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class WorkflowNextStepService
{
    public function resolve(Model $subject, User $user): ?array
    {
        $action = match (true) {
            $subject instanceof SalesQuotation => $this->salesQuotation($subject),
            $subject instanceof SalesOrder => $this->salesOrder($subject),
            $subject instanceof DeliveryNote => $this->delivery($subject),
            $subject instanceof PurchaseRequisition => $this->purchaseRequisition($subject),
            $subject instanceof PurchaseOrder => $this->purchaseOrder($subject),
            $subject instanceof GoodsReceipt => $this->receipt($subject),
            $subject instanceof ProductionOrder => $this->production($subject),
            $subject instanceof QualityInspection => $this->qualityInspection($subject),
            $subject instanceof QualityNonConformity => $this->nonConformity($subject),
            $subject instanceof MaintenanceWorkOrder => $this->maintenance($subject),
            $subject instanceof CustomerInvoice => $this->customerInvoice($subject),
            $subject instanceof SupplierInvoice => $this->supplierInvoice($subject),
            default => null,
        };

        if (! $action || ! $user->hasPermission($action['permission'])) {
            return null;
        }

        return $action;
    }

    private function form(string $label, string $route, array $parameters, string $permission, string $icon = 'ti-arrow-right'): array
    {
        return compact('label', 'route', 'parameters', 'permission', 'icon') + ['type' => 'form'];
    }

    private function link(string $label, string $url, string $permission, string $icon = 'ti-arrow-right'): array
    {
        return compact('label', 'url', 'permission', 'icon') + ['type' => 'link'];
    }

    private function salesQuotation(SalesQuotation $quotation): ?array
    {
        return match ($quotation->status) {
            'DRAFT' => $this->form('workflow.next_send_quotation', 'sales.quotations.send', [$quotation], 'sales.update', 'ti-send'),
            'SENT' => $this->form('workflow.next_accept_quotation', 'sales.quotations.accept', [$quotation], 'sales.approve', 'ti-check'),
            'ACCEPTED' => $this->form('workflow.next_convert_order', 'sales.quotations.convert', [$quotation], 'sales.create', 'ti-shopping-cart-plus'),
            default => null,
        };
    }

    private function salesOrder(SalesOrder $order): ?array
    {
        return match ($order->status) {
            'DRAFT' => $this->form('workflow.next_submit_order', 'sales.orders.submit', [$order], 'sales.update', 'ti-send'),
            'SUBMITTED' => $this->form('workflow.next_confirm_order', 'sales.orders.confirm', [$order], 'sales.approve', 'ti-circle-check'),
            'CONFIRMED', 'PARTIALLY_RESERVED' => $this->form('workflow.next_reserve_stock', 'sales.orders.reserve', [$order], 'sales.update', 'ti-package-export'),
            'RESERVED', 'PARTIALLY_DELIVERED' => $this->link('workflow.next_prepare_delivery', route('sales.orders.show', ['order' => $order, 'prepare' => 'delivery']).'#prepare-delivery', 'sales.update', 'ti-truck-delivery'),
            default => null,
        };
    }

    private function delivery(DeliveryNote $delivery): ?array
    {
        return $delivery->status === 'PICKED'
            ? $this->form('workflow.next_post_delivery', 'sales.deliveries.post', [$delivery], 'stocks.approve', 'ti-truck-delivery')
            : null;
    }

    private function purchaseRequisition(PurchaseRequisition $requisition): ?array
    {
        return match ($requisition->status) {
            'DRAFT' => $this->form('workflow.next_submit_requisition', 'purchasing.requisitions.submit', [$requisition], 'purchasing.update', 'ti-send'),
            'SUBMITTED' => $this->form('workflow.next_approve_requisition', 'purchasing.requisitions.approve', [$requisition], 'purchasing.approve', 'ti-circle-check'),
            'APPROVED' => $this->link('workflow.next_request_quotes', route('purchasing.requisitions.show', $requisition).'#quotation-form', 'purchasing.create', 'ti-building-store'),
            default => null,
        };
    }

    private function purchaseOrder(PurchaseOrder $order): ?array
    {
        return match ($order->status) {
            'DRAFT' => $this->form('workflow.next_submit_purchase_order', 'purchasing.orders.submit', [$order], 'purchasing.update', 'ti-send'),
            'SUBMITTED' => $this->form('workflow.next_approve_purchase_order', 'purchasing.orders.approve', [$order], 'purchasing.approve', 'ti-circle-check'),
            'APPROVED', 'PARTIALLY_RECEIVED' => $this->link('workflow.next_receive_goods', route('purchasing.orders.show', $order).'#receipt-form', 'purchasing.create', 'ti-package-import'),
            default => null,
        };
    }

    private function receipt(GoodsReceipt $receipt): ?array
    {
        return $receipt->status === 'DRAFT'
            ? $this->form('workflow.next_post_receipt', 'purchasing.receipts.post', [$receipt], 'stocks.approve', 'ti-package-import')
            : null;
    }

    private function production(ProductionOrder $order): ?array
    {
        return match ($order->status) {
            'PLANNED' => $this->link('workflow.next_start_production', route('production.show', ['order' => $order, 'open' => 'start']).'#start-order', 'production.update', 'ti-player-play'),
            'IN_PROGRESS' => $this->link('workflow.next_complete_production', route('production.show', ['order' => $order, 'open' => 'complete']).'#complete-order', 'production.update', 'ti-flag-check'),
            default => null,
        };
    }

    private function qualityInspection(QualityInspection $inspection): ?array
    {
        return match ($inspection->status) {
            'DRAFT', 'IN_PROGRESS' => $this->link('workflow.next_record_quality', route('quality.inspections.show', $inspection).'#results', 'quality.update', 'ti-clipboard-check'),
            'PENDING_DECISION' => $this->link('workflow.next_quality_decision', route('quality.inspections.show', $inspection).'#decision', 'quality.approve', 'ti-gavel'),
            default => null,
        };
    }

    private function nonConformity(QualityNonConformity $nonConformity): ?array
    {
        return in_array($nonConformity->status, ['OPEN', 'ANALYSIS', 'ACTION_PLAN', 'VERIFYING'], true)
            ? $this->link('workflow.next_resolve_non_conformity', route('quality.non-conformities.show', $nonConformity).'#actions', 'quality.update', 'ti-alert-triangle')
            : null;
    }

    private function maintenance(MaintenanceWorkOrder $order): ?array
    {
        return match ($order->status) {
            'DRAFT', 'PLANNED' => $this->form('workflow.next_start_maintenance', 'maintenance.start', [$order], 'maintenance.update', 'ti-player-play'),
            'IN_PROGRESS' => $this->link('workflow.next_complete_maintenance', route('maintenance.show', $order).'#complete-form', 'maintenance.update', 'ti-tool'),
            default => null,
        };
    }

    private function customerInvoice(CustomerInvoice $invoice): ?array
    {
        return match ($invoice->status) {
            'DRAFT', 'REJECTED' => $this->form('workflow.next_issue_invoice', 'finance.billing.customer-invoices.issue', [$invoice], 'finance.approve', 'ti-file-invoice'),
            'PENDING_APPROVAL' => $this->link('workflow.next_review_approval', route('finance.governance.index', ['company_id' => $invoice->company_id, 'tab' => 'approvals']).'#approvals', 'finance.view', 'ti-user-check'),
            'ISSUED', 'PARTIALLY_PAID', 'OVERDUE' => $this->link('workflow.next_record_payment', route('finance.billing.index', ['tab' => 'customer-payments', 'company_id' => $invoice->company_id, 'party_id' => $invoice->customer_id, 'invoice_id' => $invoice->id]).'#customer-payment-form', 'finance.create', 'ti-cash'),
            default => null,
        };
    }

    private function supplierInvoice(SupplierInvoice $invoice): ?array
    {
        return match ($invoice->status) {
            'DRAFT', 'REJECTED' => $this->form('workflow.next_approve_invoice', 'finance.billing.supplier-invoices.approve', [$invoice], 'finance.approve', 'ti-file-check'),
            'PENDING_APPROVAL' => $this->link('workflow.next_review_approval', route('finance.governance.index', ['company_id' => $invoice->company_id, 'tab' => 'approvals']).'#approvals', 'finance.view', 'ti-user-check'),
            'ISSUED', 'PARTIALLY_PAID', 'OVERDUE' => $this->link('workflow.next_record_supplier_payment', route('finance.billing.index', ['tab' => 'supplier-payments', 'company_id' => $invoice->company_id, 'party_id' => $invoice->supplier_id, 'invoice_id' => $invoice->id]).'#supplier-payment-form', 'finance.create', 'ti-cash'),
            default => null,
        };
    }
}
