<?php

namespace App\Services\Workflow;

use App\Models\ApprovalRequest;
use App\Models\CustomerInvoice;
use App\Models\DeliveryNote;
use App\Models\GoodsReceipt;
use App\Models\MaintenanceWorkOrder;
use App\Models\ManagementBudget;
use App\Models\PlanningConflict;
use App\Models\ProductionOrder;
use App\Models\ProductionPlan;
use App\Models\PurchaseOrder;
use App\Models\PurchaseRequisition;
use App\Models\QualityCorrectiveAction;
use App\Models\QualityInspection;
use App\Models\QualityNonConformity;
use App\Models\SalesOrder;
use App\Models\SalesQuotation;
use App\Models\SupplierInvoice;
use App\Models\User;
use App\Models\WorkflowTaskPreference;
use App\Services\Finance\Governance\ApprovalService;
use App\Services\Modules\ModuleRegistry;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class WorkflowInboxService
{
    public function __construct(
        private readonly ModuleRegistry $modules,
        private readonly ApprovalService $approvals,
    ) {
    }

    /** @var array<string, Collection> */
    private array $taskCache = [];

    /** @var array<string, Collection> */
    private array $alertCache = [];

    public function summary(User $user): array
    {
        $tasks = $this->tasks($user);
        $alerts = $this->alerts($user);

        return [
            'tasks' => $tasks->count(),
            'urgent' => $tasks->whereIn('priority', ['critical', 'high'])->count(),
            'alerts' => $alerts->count(),
            'unread_notifications' => $user->unreadNotifications()->count(),
        ];
    }

    public function tasks(User $user): Collection
    {
        if (isset($this->taskCache[$user->id])) {
            return $this->taskCache[$user->id];
        }

        $cacheKey = 'workflow:tasks:'.$user->id.':'.app()->getLocale();
        $cached = Cache::get($cacheKey);
        if ($cached instanceof Collection) {
            return $this->taskCache[$user->id] = $cached;
        }

        $permissions = $user->permissions()->pluck('code')->flip();
        $tasks = collect();

        if ($this->modules->enabled('sales') && $permissions->has('sales.view')) {
            SalesQuotation::query()->with('customer:id,name')->whereIn('status', ['DRAFT', 'SENT', 'ACCEPTED'])
                ->oldest('quotation_date')->limit(30)->get()->each(function (SalesQuotation $quotation) use ($tasks, $permissions): void {
                    $action = match ($quotation->status) {
                        'DRAFT' => $permissions->has('sales.update') ? 'send' : null,
                        'SENT' => $permissions->has('sales.approve') ? 'accept' : null,
                        'ACCEPTED' => $permissions->has('sales.create') ? 'convert' : null,
                        default => null,
                    };
                    if (! $action) return;
                    $tasks->push($this->task(
                        'sales-quotation', $quotation->id, $action, 'sales',
                        'workflow.task_sales_quotation_'.$action,
                        $quotation->quotation_number.' · '.($quotation->customer?->name ?? '—'),
                        $quotation->valid_until,
                        $quotation->valid_until?->isPast() ? 'high' : 'normal',
                        route('sales.quotations.show', $quotation),
                        $quotation->status,
                    ));
                });

            SalesOrder::query()->with('customer:id,name')->whereIn('status', ['DRAFT', 'SUBMITTED', 'CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED', 'PARTIALLY_DELIVERED'])
                ->oldest('requested_delivery_date')->limit(40)->get()->each(function (SalesOrder $order) use ($tasks, $permissions): void {
                    $action = match ($order->status) {
                        'DRAFT' => $permissions->has('sales.update') ? 'submit' : null,
                        'SUBMITTED' => $permissions->has('sales.approve') ? 'confirm' : null,
                        'CONFIRMED', 'PARTIALLY_RESERVED' => $permissions->has('sales.update') ? 'reserve' : null,
                        'RESERVED', 'PARTIALLY_DELIVERED' => $permissions->has('sales.update') ? 'deliver' : null,
                        default => null,
                    };
                    if (! $action) return;
                    $late = $order->requested_delivery_date?->isPast() && $order->status !== 'DELIVERED';
                    $tasks->push($this->task(
                        'sales-order', $order->id, $action, 'sales',
                        'workflow.task_sales_order_'.$action,
                        $order->order_number.' · '.($order->customer?->name ?? '—'),
                        $order->requested_delivery_date,
                        $late ? 'critical' : ($order->status === 'SUBMITTED' ? 'high' : 'normal'),
                        route('sales.orders.show', $order),
                        $order->status,
                    ));
                });

            if ($permissions->has('stocks.approve')) {
                DeliveryNote::query()->with('customer:id,name')->where('status', 'PICKED')->oldest('created_at')->limit(30)->get()
                    ->each(fn (DeliveryNote $delivery) => $tasks->push($this->task(
                        'delivery', $delivery->id, 'post', 'sales', 'workflow.task_delivery_post',
                        $delivery->delivery_number.' · '.($delivery->customer?->name ?? '—'),
                        $delivery->created_at, 'high', route('sales.deliveries.show', $delivery), $delivery->status,
                    )));
            }
        }

        if ($this->modules->enabled('purchasing') && $permissions->has('purchasing.view')) {
            PurchaseRequisition::query()->whereIn('status', ['DRAFT', 'SUBMITTED', 'APPROVED'])->oldest('required_date')->limit(30)->get()
                ->each(function (PurchaseRequisition $requisition) use ($tasks, $permissions): void {
                    $action = match ($requisition->status) {
                        'DRAFT' => $permissions->has('purchasing.update') ? 'submit' : null,
                        'SUBMITTED' => $permissions->has('purchasing.approve') ? 'approve' : null,
                        'APPROVED' => $permissions->has('purchasing.create') ? 'quote' : null,
                        default => null,
                    };
                    if (! $action) return;
                    $tasks->push($this->task(
                        'purchase-requisition', $requisition->id, $action, 'purchasing',
                        'workflow.task_purchase_requisition_'.$action,
                        $requisition->requisition_number,
                        $requisition->required_date,
                        $requisition->required_date?->isPast() ? 'critical' : ($requisition->priority === 'URGENT' ? 'high' : 'normal'),
                        route('purchasing.requisitions.show', $requisition),
                        $requisition->status,
                    ));
                });

            PurchaseOrder::query()->with('supplier:id,name')->whereIn('status', ['DRAFT', 'SUBMITTED', 'APPROVED', 'PARTIALLY_RECEIVED'])
                ->oldest('expected_date')->limit(40)->get()->each(function (PurchaseOrder $order) use ($tasks, $permissions): void {
                    $action = match ($order->status) {
                        'DRAFT' => $permissions->has('purchasing.update') ? 'submit' : null,
                        'SUBMITTED' => $permissions->has('purchasing.approve') ? 'approve' : null,
                        'APPROVED', 'PARTIALLY_RECEIVED' => $permissions->has('purchasing.create') ? 'receive' : null,
                        default => null,
                    };
                    if (! $action) return;
                    $tasks->push($this->task(
                        'purchase-order', $order->id, $action, 'purchasing',
                        'workflow.task_purchase_order_'.$action,
                        $order->order_number.' · '.($order->supplier?->name ?? '—'),
                        $order->expected_date,
                        $order->expected_date?->isPast() ? 'critical' : ($order->status === 'SUBMITTED' ? 'high' : 'normal'),
                        route('purchasing.orders.show', $order),
                        $order->status,
                    ));
                });

            if ($permissions->has('stocks.approve')) {
                GoodsReceipt::query()->with('supplier:id,name')->where('status', 'DRAFT')->oldest('received_at')->limit(30)->get()
                    ->each(fn (GoodsReceipt $receipt) => $tasks->push($this->task(
                        'goods-receipt', $receipt->id, 'post', 'purchasing', 'workflow.task_receipt_post',
                        $receipt->receipt_number.' · '.($receipt->supplier?->name ?? '—'),
                        $receipt->received_at, 'high', route('purchasing.receipts.show', $receipt), $receipt->status,
                    )));
            }
        }

        if ($this->modules->enabled('planning') && $permissions->has('planning.view')) {
            ProductionPlan::query()->whereIn('status', ['DRAFT', 'CALCULATED'])
                ->oldest('horizon_start')->limit(30)->get()->each(function (ProductionPlan $plan) use ($tasks, $permissions): void {
                    $action = $plan->status === 'DRAFT' ? 'calculate' : 'approve';
                    $requiredPermission = $action === 'calculate' ? 'planning.update' : 'planning.approve';
                    if (! $permissions->has($requiredPermission)) return;
                    $critical = (int) data_get($plan->metrics, 'critical_conflicts', 0);
                    $tasks->push($this->task(
                        'production-plan', $plan->id, $action, 'planning',
                        'workflow.task_planning_'.$action,
                        $plan->code.' · '.$plan->name,
                        $plan->horizon_start,
                        $critical > 0 ? 'critical' : ($action === 'approve' ? 'high' : 'normal'),
                        route('planning.show', $plan),
                        $plan->status,
                    ));
                });
        }

        if ($this->modules->enabled('production') && $permissions->has('production.view')) {
            ProductionOrder::query()->with('item:id,code,name')->whereIn('status', ['PLANNED', 'IN_PROGRESS'])
                ->oldest('planned_date')->limit(40)->get()->each(function (ProductionOrder $order) use ($tasks, $permissions): void {
                    $action = $order->status === 'PLANNED' ? 'start' : 'complete';
                    if (! $permissions->has('production.update')) return;
                    $tasks->push($this->task(
                        'production-order', $order->id, $action, 'production',
                        'workflow.task_production_'.$action,
                        $order->order_number.' · '.($order->item?->name ?? '—'),
                        $order->planned_date,
                        $order->planned_date?->isPast() ? 'high' : 'normal',
                        route('production.show', $order).'#next-step',
                        $order->status,
                    ));
                });
        }

        if ($this->modules->enabled('quality') && $permissions->has('quality.view')) {
            QualityInspection::query()->with(['item:id,code,name', 'lot:id,lot_number'])->whereIn('status', ['DRAFT', 'IN_PROGRESS', 'PENDING_DECISION'])
                ->oldest('created_at')->limit(40)->get()->each(function (QualityInspection $inspection) use ($tasks, $permissions): void {
                    $action = $inspection->status === 'PENDING_DECISION' ? 'decide' : 'inspect';
                    $requiredPermission = $action === 'decide' ? 'quality.approve' : 'quality.update';
                    if (! $permissions->has($requiredPermission)) return;
                    $tasks->push($this->task(
                        'quality-inspection', $inspection->id, $action, 'quality',
                        'workflow.task_quality_'.$action,
                        $inspection->inspection_number.' · '.($inspection->item?->name ?? '—').' / '.($inspection->lot?->lot_number ?? '—'),
                        $inspection->created_at,
                        $action === 'decide' ? 'high' : 'normal',
                        route('quality.inspections.show', $inspection),
                        $inspection->status,
                    ));
                });

            QualityNonConformity::query()->whereNotIn('status', ['CLOSED', 'CANCELLED'])->oldest('due_date')->limit(30)->get()
                ->each(function (QualityNonConformity $nonConformity) use ($tasks, $permissions, $user): void {
                    if (! $permissions->has('quality.update')) return;
                    if ($nonConformity->owner_id && $nonConformity->owner_id !== $user->id && ! $permissions->has('quality.approve')) return;
                    $tasks->push($this->task(
                        'quality-nc', $nonConformity->id, 'resolve', 'quality', 'workflow.task_non_conformity_resolve',
                        $nonConformity->non_conformity_number,
                        $nonConformity->due_date,
                        $nonConformity->due_date?->isPast() ? 'critical' : 'high',
                        route('quality.non-conformities.show', $nonConformity),
                        $nonConformity->status,
                    ));
                });

            QualityCorrectiveAction::query()->with('nonConformity:id,non_conformity_number')->whereIn('status', ['OPEN', 'IN_PROGRESS', 'COMPLETED'])
                ->oldest('due_date')->limit(40)->get()->each(function (QualityCorrectiveAction $action) use ($tasks, $permissions, $user): void {
                    if ($action->owner_id && $action->owner_id !== $user->id && ! $permissions->has('quality.approve')) return;
                    $verb = $action->status === 'COMPLETED' ? 'verify' : 'complete';
                    if (! $permissions->has($verb === 'verify' ? 'quality.approve' : 'quality.update')) return;
                    $tasks->push($this->task(
                        'quality-action', $action->id, $verb, 'quality', 'workflow.task_corrective_action_'.$verb,
                        ($action->nonConformity?->non_conformity_number ?? 'CAPA').' · '.mb_strimwidth((string) $action->description, 0, 70, '…'),
                        $action->due_date,
                        $action->due_date?->isPast() ? 'critical' : 'normal',
                        route('quality.non-conformities.show', $action->quality_non_conformity_id),
                        $action->status,
                    ));
                });
        }

        if ($this->modules->enabled('maintenance') && $permissions->has('maintenance.view')) {
            MaintenanceWorkOrder::query()->with(['machine:id,code,name', 'productionLine:id,code,name'])
                ->whereNotIn('status', ['COMPLETED', 'CANCELLED'])->oldest('planned_start')->limit(40)->get()
                ->each(function (MaintenanceWorkOrder $order) use ($tasks, $permissions, $user): void {
                    if ($order->assigned_to && $order->assigned_to !== $user->id && ! $permissions->has('maintenance.approve')) return;
                    if (! $permissions->has('maintenance.update')) return;
                    $action = in_array($order->status, ['DRAFT', 'PLANNED'], true) ? 'start' : 'complete';
                    $asset = $order->machine?->name ?? $order->productionLine?->name ?? '—';
                    $tasks->push($this->task(
                        'maintenance-order', $order->id, $action, 'maintenance', 'workflow.task_maintenance_'.$action,
                        $order->work_order_number.' · '.$asset,
                        $order->planned_start,
                        ($order->priority === 'CRITICAL' || $order->planned_start?->isPast()) ? 'critical' : ($order->priority === 'HIGH' ? 'high' : 'normal'),
                        route('maintenance.show', $order).'#next-step',
                        $order->status,
                    ));
                });
        }

        if ($this->modules->enabled('planning') && $permissions->has('planning.view')) {
            $criticalPlanning = PlanningConflict::query()
                ->where('severity', 'CRITICAL')
                ->where('status', 'OPEN')
                ->count();
            if ($criticalPlanning > 0) {
                $alerts->push($this->alert(
                    'planning-critical',
                    'planning',
                    'workflow.alert_planning_conflicts',
                    trans_choice('workflow.alert_planning_conflicts_count', $criticalPlanning, ['count' => $criticalPlanning]),
                    'danger',
                    route('planning.index')
                ));
            }
        }

        if ($this->modules->enabled('finance') && $permissions->has('finance.view')) {
            CustomerInvoice::query()->with('customer:id,name')->whereIn('status', ['DRAFT', 'REJECTED', 'ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])
                ->oldest('due_date')->limit(40)->get()->each(function (CustomerInvoice $invoice) use ($tasks, $permissions): void {
                    $action = in_array($invoice->status, ['DRAFT', 'REJECTED'], true) ? 'issue' : 'collect';
                    if (! $permissions->has($action === 'issue' ? 'finance.approve' : 'finance.create')) return;
                    $tasks->push($this->task(
                        'customer-invoice', $invoice->id, $action, 'finance', 'workflow.task_customer_invoice_'.$action,
                        $invoice->invoice_number.' · '.($invoice->customer?->name ?? '—'),
                        $invoice->due_date,
                        $invoice->status === 'OVERDUE' ? 'critical' : ($invoice->status === 'DRAFT' ? 'normal' : 'high'),
                        route('finance.billing.customer-invoices.show', $invoice),
                        $invoice->status,
                    ));
                });

            SupplierInvoice::query()->with('supplier:id,name')->whereIn('status', ['DRAFT', 'REJECTED', 'ISSUED', 'PARTIALLY_PAID', 'OVERDUE'])
                ->oldest('due_date')->limit(40)->get()->each(function (SupplierInvoice $invoice) use ($tasks, $permissions): void {
                    $action = in_array($invoice->status, ['DRAFT', 'REJECTED'], true) ? 'approve' : 'pay';
                    if (! $permissions->has($action === 'approve' ? 'finance.approve' : 'finance.create')) return;
                    $tasks->push($this->task(
                        'supplier-invoice', $invoice->id, $action, 'finance', 'workflow.task_supplier_invoice_'.$action,
                        $invoice->invoice_number.' · '.($invoice->supplier?->name ?? '—'),
                        $invoice->due_date,
                        $invoice->status === 'OVERDUE' ? 'critical' : 'normal',
                        route('finance.billing.supplier-invoices.show', $invoice),
                        $invoice->status,
                    ));
                });

            ApprovalRequest::query()->with(['steps', 'workflow'])
                ->where('status', 'PENDING')->oldest('submitted_at')->limit(50)->get()
                ->each(function (ApprovalRequest $request) use ($tasks, $user): void {
                    $step = $request->steps->firstWhere('sequence', $request->current_level);
                    if (! $step || ! $this->approvals->canDecide($step, $user)) return;
                    $tasks->push($this->task(
                        'approval-request', $request->id, 'decide', 'finance', 'workflow.task_financial_approval_decide',
                        ($request->document_number ?: '—').' · '.$request->workflow->name,
                        $request->submitted_at,
                        'high',
                        route('finance.governance.index', ['company_id' => $request->company_id, 'tab' => 'approvals']).'#approval-'.$request->id,
                        $request->status,
                    ));
                });
        }

        $resolvedTasks = $this->applyPreferences($user, $tasks)
            ->sortBy(fn (array $task): string => sprintf('%d-%s', $this->priorityOrder($task['priority']), $task['due_at']?->format('YmdHis') ?? '99999999999999'))
            ->values();
        Cache::put($cacheKey, $resolvedTasks, now()->addSeconds(30));

        return $this->taskCache[$user->id] = $resolvedTasks;
    }

    public function alerts(User $user): Collection
    {
        if (isset($this->alertCache[$user->id])) {
            return $this->alertCache[$user->id];
        }

        $cacheKey = 'workflow:alerts:'.$user->id.':'.app()->getLocale();
        $cached = Cache::get($cacheKey);
        if ($cached instanceof Collection) {
            return $this->alertCache[$user->id] = $cached;
        }

        $permissions = $user->permissions()->pluck('code')->flip();
        $alerts = collect();

        if ($this->modules->enabled('stocks') && $permissions->has('stocks.view')) {
            $expiryDays = (int) (json_decode((string) DB::table('system_settings')->where('group', 'stock')->where('key', 'expiry_alert_days')->value('value'), true) ?: 30);
            $expiring = DB::table('lots')->join('stock_balances', 'stock_balances.lot_id', '=', 'lots.id')
                ->where('stock_balances.quantity', '>', 0)->whereBetween('lots.expiry_date', [today(), today()->addDays($expiryDays)])
                ->distinct('lots.id')->count('lots.id');
            if ($expiring > 0) {
                $alerts->push($this->alert('stock-expiry', 'stocks', 'workflow.alert_expiring_lots', trans_choice('workflow.alert_lots_count', $expiring, ['count' => $expiring]), 'warning', route('stocks.index', ['expiry' => 'soon'])));
            }

            $lowStockQuery = DB::table('items')->leftJoin('stock_balances', 'stock_balances.item_id', '=', 'items.id')
                ->where('items.active', true)->where('items.minimum_stock', '>', 0)
                ->groupBy('items.id', 'items.minimum_stock')
                ->havingRaw('COALESCE(SUM(stock_balances.quantity - stock_balances.reserved_quantity), 0) <= items.minimum_stock')
                ->select('items.id');
            $lowStock = DB::query()->fromSub($lowStockQuery, 'low_stock_items')->count();
            if ($lowStock > 0) {
                $alerts->push($this->alert('low-stock', 'stocks', 'workflow.alert_low_stock', trans_choice('workflow.alert_items_count', $lowStock, ['count' => $lowStock]), 'danger', route('stocks.index')));
            }
        }

        if ($this->modules->enabled('planning') && $permissions->has('planning.view')) {
            $criticalPlanning = PlanningConflict::query()
                ->where('severity', 'CRITICAL')
                ->where('status', 'OPEN')
                ->count();
            if ($criticalPlanning > 0) {
                $alerts->push($this->alert(
                    'planning-critical',
                    'planning',
                    'workflow.alert_planning_conflicts',
                    trans_choice('workflow.alert_planning_conflicts_count', $criticalPlanning, ['count' => $criticalPlanning]),
                    'danger',
                    route('planning.index')
                ));
            }
        }

        if ($this->modules->enabled('finance') && $permissions->has('finance.view')) {
            $customerOverdue = CustomerInvoice::query()->where('status', 'OVERDUE')->count();
            $supplierOverdue = SupplierInvoice::query()->where('status', 'OVERDUE')->count();
            if ($customerOverdue > 0) {
                $alerts->push($this->alert('customer-overdue', 'finance', 'workflow.alert_customer_overdue', trans_choice('workflow.alert_invoices_count', $customerOverdue, ['count' => $customerOverdue]), 'danger', route('finance.billing.index', ['tab' => 'customer', 'status' => 'OVERDUE'])));
            }
            if ($supplierOverdue > 0) {
                $alerts->push($this->alert('supplier-overdue', 'finance', 'workflow.alert_supplier_overdue', trans_choice('workflow.alert_invoices_count', $supplierOverdue, ['count' => $supplierOverdue]), 'warning', route('finance.billing.index', ['tab' => 'supplier', 'status' => 'OVERDUE'])));
            }

            $budgetOverruns = ManagementBudget::query()->where('status', 'APPROVED')->where('variance_amount', '<', 0)->count();
            if ($budgetOverruns > 0) {
                $alerts->push($this->alert('budget-overrun', 'finance', 'workflow.alert_budget_overrun', trans_choice('workflow.alert_budgets_count', $budgetOverruns, ['count' => $budgetOverruns]), 'warning', route('finance.control.index', ['tab' => 'budgets'])));
            }
        }

        if ($this->modules->enabled('quality') && $permissions->has('quality.view')) {
            $overdue = QualityNonConformity::query()->whereNotIn('status', ['CLOSED', 'CANCELLED'])->whereDate('due_date', '<', today())->count()
                + QualityCorrectiveAction::query()->whereNotIn('status', ['VERIFIED', 'CANCELLED'])->whereDate('due_date', '<', today())->count();
            if ($overdue > 0) {
                $alerts->push($this->alert('quality-overdue', 'quality', 'workflow.alert_quality_overdue', trans_choice('workflow.alert_quality_count', $overdue, ['count' => $overdue]), 'danger', route('quality.non-conformities.index')));
            }
        }

        if ($this->modules->enabled('maintenance') && $permissions->has('maintenance.view')) {
            $lateMaintenance = MaintenanceWorkOrder::query()->whereNotIn('status', ['COMPLETED', 'CANCELLED'])->where('planned_start', '<', now())->count();
            if ($lateMaintenance > 0) {
                $alerts->push($this->alert('maintenance-overdue', 'maintenance', 'workflow.alert_maintenance_overdue', trans_choice('workflow.alert_maintenance_count', $lateMaintenance, ['count' => $lateMaintenance]), 'warning', route('maintenance.index')));
            }
        }

        $resolvedAlerts = $this->applyPreferences($user, $alerts)->values();
        Cache::put($cacheKey, $resolvedAlerts, now()->addSeconds(30));

        return $this->alertCache[$user->id] = $resolvedAlerts;
    }

    private function task(string $type, string $id, string $action, string $category, string $titleKey, string $description, mixed $dueAt, string $priority, string $url, string $status): array
    {
        $source = implode(':', [$type, $id, $action]);

        return [
            'key' => hash('sha256', $source),
            'source' => $source,
            'category' => $category,
            'title' => __($titleKey),
            'description' => $description,
            'priority' => $priority,
            'due_at' => $dueAt,
            'url' => $url,
            'status' => $status,
            'kind' => 'task',
        ];
    }

    private function alert(string $source, string $category, string $titleKey, string $description, string $severity, string $url): array
    {
        return [
            'key' => hash('sha256', 'alert:'.$source),
            'source' => 'alert:'.$source,
            'category' => $category,
            'title' => __($titleKey),
            'description' => $description,
            'priority' => $severity === 'danger' ? 'critical' : 'high',
            'severity' => $severity,
            'due_at' => now(),
            'url' => $url,
            'status' => 'OPEN',
            'kind' => 'alert',
        ];
    }

    private function applyPreferences(User $user, Collection $items): Collection
    {
        $preferences = WorkflowTaskPreference::query()->where('user_id', $user->id)->get()->keyBy('task_key');

        return $items->reject(function (array $item) use ($preferences): bool {
            $preference = $preferences->get($item['key']);
            if (! $preference) return false;
            if ($preference->state === 'DISMISSED') return true;

            return $preference->state === 'SNOOZED' && $preference->snoozed_until?->isFuture();
        });
    }

    private function priorityOrder(string $priority): int
    {
        return match ($priority) {
            'critical' => 1,
            'high' => 2,
            'normal' => 3,
            default => 4,
        };
    }
}
