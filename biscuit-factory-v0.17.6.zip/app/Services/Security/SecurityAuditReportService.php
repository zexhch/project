<?php

namespace App\Services\Security;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class SecurityAuditReportService
{
    public function run(): array
    {
        $issues = [];
        $defaultSecrets = [
            'DB_PASSWORD' => 'change_me_db',
            'REVERB_APP_SECRET' => 'change_me_reverb_secret',
            'AWS_SECRET_ACCESS_KEY' => 'change_me_minio',
            'MINIO_ROOT_PASSWORD' => 'change_me_minio',
            'ADMIN_PASSWORD' => 'ChangeMe123!',
        ];

        foreach ($defaultSecrets as $key => $default) {
            if ((string) env($key, '') === $default) {
                $issues[] = ['severity' => 'critical', 'code' => 'default_secret', 'message' => "{$key} utilise encore la valeur par défaut."];
            }
        }

        if ((bool) config('app.debug') && app()->environment('production')) {
            $issues[] = ['severity' => 'critical', 'code' => 'debug_in_production', 'message' => 'APP_DEBUG est actif en production.'];
        }
        if (! (bool) config('session.secure') && app()->environment('production')) {
            $issues[] = ['severity' => 'warning', 'code' => 'insecure_session_cookie', 'message' => 'SESSION_SECURE_COOKIE devrait être activé en production.'];
        }
        if (! (bool) config('session.encrypt')) {
            $issues[] = ['severity' => 'warning', 'code' => 'unencrypted_sessions', 'message' => 'Le chiffrement des sessions est désactivé.'];
        }

        if (Schema::hasColumn('users', 'force_password_change')) {
            $forced = User::query()->where('force_password_change', true)->count();
            if ($forced > 0) {
                $issues[] = ['severity' => 'warning', 'code' => 'forced_password_changes', 'message' => "{$forced} utilisateur(s) doivent changer leur mot de passe."];
            }
        }

        $inactiveSessions = Schema::hasTable('sessions')
            ? DB::table('sessions')->where('last_activity', '<', now()->subDays(30)->timestamp)->count()
            : 0;
        if ($inactiveSessions > 0) {
            $issues[] = ['severity' => 'warning', 'code' => 'stale_sessions', 'message' => "{$inactiveSessions} session(s) ont plus de 30 jours."];
        }

        $critical = collect($issues)->where('severity', 'critical')->count();
        $warnings = collect($issues)->where('severity', 'warning')->count();

        return [
            'status' => $critical > 0 ? 'failed' : ($warnings > 0 ? 'warning' : 'ok'),
            'critical' => $critical,
            'warnings' => $warnings,
            'issues' => $issues,
            'checked_at' => now()->toIso8601String(),
        ];
    }
}
