<?php

namespace App\Services\Security;

use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Validation\Rules\Password;

class SecurityPolicyService
{
    private const DEFAULTS = [
        'password_min_length' => 12,
        'password_require_uppercase' => true,
        'password_require_lowercase' => true,
        'password_require_number' => true,
        'password_require_symbol' => true,
        'password_max_age_days' => 90,
        'login_max_attempts' => 5,
        'login_lock_minutes' => 15,
        'session_idle_minutes' => 120,
        'audit_retention_days' => 365,
        'health_snapshot_retention_days' => 30,
    ];

    public function all(): array
    {
        $settings = SystemSetting::query()
            ->whereNull('company_id')
            ->where('group', 'security')
            ->get()
            ->keyBy('key');

        return collect(self::DEFAULTS)->mapWithKeys(function (mixed $default, string $key) use ($settings): array {
            $value = $settings->get($key)?->value;

            if (is_bool($default)) {
                $value = filter_var($value ?? $default, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE) ?? $default;
            } elseif (is_int($default)) {
                $value = (int) ($value ?? $default);
            }

            return [$key => $value];
        })->all();
    }

    public function get(string $key): mixed
    {
        return $this->all()[$key] ?? null;
    }

    public function update(array $values): void
    {
        foreach (self::DEFAULTS as $key => $default) {
            if (! array_key_exists($key, $values)) {
                continue;
            }

            $value = is_bool($default) ? (bool) $values[$key] : (int) $values[$key];
            $setting = SystemSetting::query()->firstOrNew([
                'company_id' => null,
                'group' => 'security',
                'key' => $key,
            ]);
            $setting->fill([
                'value' => $value,
                'value_type' => is_bool($default) ? 'boolean' : 'integer',
                'public' => false,
            ])->save();
        }
    }

    public function passwordRules(bool $confirmed = true): array
    {
        $policy = $this->all();
        $rules = ['required', 'string'];
        if ($confirmed) {
            $rules[] = 'confirmed';
        }
        $rules[] = Password::min($policy['password_min_length']);
        if ($policy['password_require_uppercase']) {
            $rules[] = 'regex:/[A-Z]/';
        }
        if ($policy['password_require_lowercase']) {
            $rules[] = 'regex:/[a-z]/';
        }
        if ($policy['password_require_number']) {
            $rules[] = 'regex:/[0-9]/';
        }
        if ($policy['password_require_symbol']) {
            $rules[] = 'regex:/[^A-Za-z0-9]/';
        }

        return $rules;
    }

    public function requiresPasswordChange(User $user): bool
    {
        if ($user->force_password_change) {
            return true;
        }

        $maxAgeDays = (int) $this->get('password_max_age_days');

        return $maxAgeDays > 0
            && $user->password_changed_at !== null
            && $user->password_changed_at->lte(now()->subDays($maxAgeDays));
    }

    public function lockoutThreshold(): int
    {
        return max(1, (int) $this->get('login_max_attempts'));
    }

    public function lockoutSeconds(): int
    {
        return max(1, (int) $this->get('login_lock_minutes')) * 60;
    }
}
