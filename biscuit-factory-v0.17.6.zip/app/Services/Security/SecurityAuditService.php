<?php

namespace App\Services\Security;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class SecurityAuditService
{
    public function record(
        string $event,
        ?User $user = null,
        string $severity = 'info',
        array $metadata = [],
        ?object $subject = null,
    ): void {
        if (! Schema::hasTable('audit_logs')) {
            return;
        }

        $request = app()->runningInConsole() ? null : request();
        $row = [
            'id' => (string) Str::uuid(),
            'user_id' => $user?->id,
            'event' => $event,
            'auditable_type' => $subject ? $subject::class : ($user ? User::class : null),
            'auditable_id' => $subject?->id ?? $user?->id,
            'old_values' => null,
            'new_values' => null,
            'ip_address' => $request?->ip(),
            'user_agent' => $request?->userAgent(),
            'created_at' => now(),
        ];

        if (Schema::hasColumn('audit_logs', 'severity')) {
            $row['severity'] = $severity;
            $row['correlation_id'] = app()->bound('request.correlation_id')
                ? app('request.correlation_id')
                : (string) Str::uuid();
            $row['metadata'] = $metadata === [] ? null : json_encode($this->sanitize($metadata), JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
        }

        DB::table('audit_logs')->insert($row);
    }

    private function sanitize(array $values): array
    {
        $sensitive = ['password', 'password_confirmation', 'current_password', 'token', 'secret', 'app_key'];

        return collect($values)->mapWithKeys(function (mixed $value, string|int $key) use ($sensitive): array {
            if (is_string($key) && in_array(strtolower($key), $sensitive, true)) {
                return [$key => '[REDACTED]'];
            }

            return [$key => is_array($value) ? $this->sanitize($value) : $value];
        })->all();
    }
}
