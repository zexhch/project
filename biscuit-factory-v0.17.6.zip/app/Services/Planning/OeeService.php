<?php

namespace App\Services\Planning;

use App\Models\LineProduct;
use App\Models\OeeSnapshot;
use App\Models\ProductionLine;
use App\Models\WorkShift;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class OeeService
{
    public function calculate(string $siteId, Carbon $start, Carbon $end): int
    {
        $count = 0;
        foreach (ProductionLine::query()->where('site_id', $siteId)->where('active', true)->get() as $line) {
            $this->calculateLine($line, $start, $end);
            $count++;
        }

        return $count;
    }

    public function calculateLine(ProductionLine $line, Carbon $start, Carbon $end): OeeSnapshot
    {
        $periodStart = $start->copy()->startOfDay();
        $periodEnd = $end->copy()->endOfDay();
        $scheduled = $this->scheduledMinutes($line->site_id, $periodStart, $periodEnd);
        $downtimes = DB::table('production_downtimes')
            ->where('production_line_id', $line->id)
            ->where('started_at', '<=', $periodEnd)
            ->where(function ($query) use ($periodStart): void {
                $query->whereNull('ended_at')->orWhere('ended_at', '>=', $periodStart);
            })
            ->get(['planned', 'started_at', 'ended_at', 'duration_seconds']);

        $planned = 0;
        $unplanned = 0;
        foreach ($downtimes as $downtime) {
            $from = Carbon::parse($downtime->started_at)->max($periodStart);
            $rawEnd = $downtime->ended_at
                ? Carbon::parse($downtime->ended_at)
                : now()->min($periodEnd);
            $to = $rawEnd->min($periodEnd);
            $seconds = $to->gt($from) ? $from->diffInSeconds($to) : 0;
            if ($downtime->duration_seconds !== null && $from->equalTo(Carbon::parse($downtime->started_at))) {
                $seconds = min($seconds, (int) $downtime->duration_seconds);
            }
            $minutes = (int) round($seconds / 60);
            if ((bool) $downtime->planned) {
                $planned += $minutes;
            } else {
                $unplanned += $minutes;
            }
        }

        $planned = min($scheduled, $planned);
        $operating = max(0, $scheduled - $planned);
        $unplanned = min($operating, $unplanned);
        $runtime = max(0, $operating - $unplanned);
        $outputs = DB::table('production_outputs as output')
            ->join('production_orders as orders', 'orders.id', '=', 'output.production_order_id')
            ->where('orders.production_line_id', $line->id)
            ->whereBetween('orders.actual_end', [$periodStart, $periodEnd])
            ->get([
                'orders.finished_item_id',
                'output.produced_quantity',
                'output.accepted_quantity',
            ]);

        $total = (float) $outputs->sum('produced_quantity');
        $accepted = (float) $outputs->sum('accepted_quantity');
        $rates = LineProduct::query()
            ->where('production_line_id', $line->id)
            ->where('active', true)
            ->pluck('production_rate_per_hour', 'item_id')
            ->map(fn ($rate): float => (float) $rate);
        $idealRunMinutes = $outputs->sum(function (object $output) use ($rates): float {
            $rate = (float) ($rates[$output->finished_item_id] ?? 0);

            return $rate > 0 ? ((float) $output->produced_quantity / $rate) * 60 : 0;
        });
        $defaultRate = (float) $rates->filter(fn (float $rate): bool => $rate > 0)->avg();
        $ideal = $idealRunMinutes > 0 && $total > 0
            ? $total * ($runtime / $idealRunMinutes)
            : ($runtime / 60) * $defaultRate;
        $availability = $operating > 0 ? min(100, $runtime / $operating * 100) : 0;
        $performance = $runtime > 0 ? min(100, $idealRunMinutes / $runtime * 100) : 0;
        $quality = $total > 0 ? min(100, $accepted / $total * 100) : 0;
        $oee = $availability * $performance * $quality / 10000;

        return OeeSnapshot::updateOrCreate(
            [
                'production_line_id' => $line->id,
                'period_start' => $start->toDateString(),
                'period_end' => $end->toDateString(),
            ],
            [
                'site_id' => $line->site_id,
                'scheduled_minutes' => $scheduled,
                'planned_downtime_minutes' => $planned,
                'unplanned_downtime_minutes' => $unplanned,
                'runtime_minutes' => $runtime,
                'ideal_output' => $ideal,
                'total_output' => $total,
                'accepted_output' => $accepted,
                'availability_percent' => $availability,
                'performance_percent' => $performance,
                'quality_percent' => $quality,
                'oee_percent' => $oee,
                'source_hash' => hash('sha256', implode('|', [
                    $scheduled,
                    $planned,
                    $unplanned,
                    round($total, 3),
                    round($accepted, 3),
                    round($idealRunMinutes, 3),
                ])),
                'calculated_at' => now(),
            ]
        );
    }

    private function scheduledMinutes(string $siteId, Carbon $start, Carbon $end): int
    {
        $shifts = WorkShift::query()
            ->where('site_id', $siteId)
            ->where('active', true)
            ->orderBy('starts_at')
            ->get();
        if ($shifts->isEmpty()) {
            return ((int) $start->copy()->startOfDay()->diffInDays($end->copy()->startOfDay()) + 1) * 480;
        }

        return (int) collect(CarbonPeriod::create($start->copy()->startOfDay(), $end->copy()->startOfDay()))
            ->sum(function (Carbon $date) use ($shifts): int {
                return (int) $shifts
                    ->filter(fn (WorkShift $shift): bool => $this->shiftApplies($shift, $date))
                    ->sum(function (WorkShift $shift): int {
                        $from = Carbon::parse($shift->starts_at);
                        $to = Carbon::parse($shift->ends_at);
                        if ($to->lte($from)) {
                            $to->addDay();
                        }

                        return $from->diffInMinutes($to);
                    });
            });
    }

    private function shiftApplies(WorkShift $shift, Carbon $date): bool
    {
        $days = collect($shift->work_days ?? [])->map(
            fn ($day): string => strtolower(trim((string) $day))
        );

        return $days->isEmpty()
            || $days->contains((string) $date->dayOfWeekIso)
            || $days->contains(strtolower($date->format('D')))
            || $days->contains(strtolower($date->locale('en')->dayName));
    }
}
