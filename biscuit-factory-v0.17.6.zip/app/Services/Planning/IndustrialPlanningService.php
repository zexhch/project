<?php

namespace App\Services\Planning;

use App\Models\CapacityRequirement;
use App\Models\LineProduct;
use App\Models\PlanningConflict;
use App\Models\PlanningScenario;
use App\Models\ProductionOrder;
use App\Models\ProductionPlan;
use App\Models\ProductionPlanDemand;
use App\Models\RecipeVersion;
use App\Models\SalesOrder;
use App\Models\WorkShift;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

class IndustrialPlanningService
{
    private const ACTIVE_ORDER_STATUSES = ['CONFIRMED', 'PARTIALLY_RESERVED', 'RESERVED', 'PARTIALLY_DELIVERED'];

    public function calculate(ProductionPlan $plan): ProductionPlan
    {
        return DB::transaction(function () use ($plan): ProductionPlan {
            $plan = ProductionPlan::query()->lockForUpdate()->findOrFail($plan->id);
            abort_if($plan->status === 'APPROVED', 409, __('planning.approved_plan_locked'));

            $plan->demands()->delete();
            $plan->materials()->delete();
            $plan->capacities()->delete();
            $plan->conflicts()->delete();
            $plan->scenarios()->delete();

            $stock = $this->stockByItem($plan);
            $receipts = $this->plannedReceiptsByItem($plan);
            $demandRows = $this->salesDemand($plan);
            $dailyAverages = $demandRows->groupBy('item_id')
                ->map(fn (Collection $rows): float => (float) $rows->sum('gross_demand') / max(1, $rows->count()));

            $finishedBalance = $stock->mapWithKeys(
                fn (array $row, string $itemId): array => [$itemId => (float) ($row['quantity'] ?? 0)]
            )->all();
            $finishedReceiptDates = [];
            $materialBalance = $finishedBalance;
            $materialReceiptDates = [];

            foreach ($demandRows as $row) {
                $itemId = (string) $row->item_id;
                $date = (string) $row->demand_date;
                $openingStock = (float) ($finishedBalance[$itemId] ?? 0);
                $reserved = (float) ($stock[$itemId]['reserved'] ?? 0);
                $plannedReceipt = $this->applyReceiptOnce($receipts, $itemId, $date, $finishedReceiptDates);
                $available = $openingStock + $plannedReceipt;
                $safety = (float) ($dailyAverages[$itemId] ?? 0) * (int) $plan->safety_stock_days;
                $projectedAfterDemand = $available - (float) $row->gross_demand;
                $net = max(0, $safety - $projectedAfterDemand);
                $finishedBalance[$itemId] = max(0, $projectedAfterDemand + $net);

                $demand = $plan->demands()->create([
                    'item_id' => $itemId,
                    'demand_date' => $date,
                    'source_type' => SalesOrder::class,
                    'gross_demand' => $row->gross_demand,
                    'stock_on_hand' => $openingStock,
                    'reserved_stock' => $reserved,
                    'planned_receipts' => $plannedReceipt,
                    'safety_stock' => $safety,
                    'net_requirement' => $net,
                    'unit_id' => $row->unit_id,
                    'priority' => $row->priority,
                    'metadata' => [
                        'sales_order_count' => (int) $row->order_count,
                        'projected_closing_stock' => round($finishedBalance[$itemId], 3),
                    ],
                ]);

                if ($net > 0) {
                    $this->explodeMaterials(
                        $plan,
                        $demand,
                        $receipts,
                        $materialBalance,
                        $materialReceiptDates
                    );
                    $this->scheduleCapacity($plan, $demand);
                }
            }

            $metrics = $this->metrics($plan->fresh());
            $plan->scenarios()->create([
                'code' => 'BASELINE',
                'name' => __('planning.baseline'),
                'parameters' => [
                    'demand_multiplier' => 1,
                    'capacity_multiplier' => 1,
                    'safety_stock_days' => $plan->safety_stock_days,
                ],
                'metrics' => $metrics,
                'is_baseline' => true,
                'created_by' => $plan->created_by,
                'calculated_at' => now(),
            ]);
            $plan->update([
                'status' => 'CALCULATED',
                'metrics' => $metrics,
                'calculated_at' => now(),
            ]);

            return $plan->fresh();
        }, 3);
    }

    public function approve(ProductionPlan $plan, string $userId): ProductionPlan
    {
        return DB::transaction(function () use ($plan, $userId): ProductionPlan {
            $locked = ProductionPlan::query()->lockForUpdate()->findOrFail($plan->id);
            abort_unless($locked->status === 'CALCULATED', 409, __('planning.calculate_before_approval'));
            abort_if(
                $locked->conflicts()->where('severity', 'CRITICAL')->where('status', 'OPEN')->exists(),
                409,
                __('planning.critical_conflicts_block_approval')
            );
            $locked->update([
                'status' => 'APPROVED',
                'approved_by' => $userId,
                'approved_at' => now(),
            ]);

            return $locked->fresh();
        }, 3);
    }

    public function createScenario(ProductionPlan $plan, array $data, string $userId): PlanningScenario
    {
        abort_unless(in_array($plan->status, ['CALCULATED', 'APPROVED'], true), 409);
        $demandMultiplier = max(.1, min(5, (float) $data['demand_multiplier']));
        $capacityMultiplier = max(.1, min(5, (float) $data['capacity_multiplier']));
        $capacities = $plan->capacities()->get();
        $shortages = $plan->materials()->get();
        $metrics = [
            'gross_demand' => round((float) $plan->demands()->sum('gross_demand') * $demandMultiplier, 3),
            'net_requirement' => round((float) $plan->demands()->sum('net_requirement') * $demandMultiplier, 3),
            'material_shortage' => round($shortages->sum(
                fn ($row): float => (float) $row->shortage_quantity * $demandMultiplier
            ), 3),
            'overloaded_slots' => $capacities->filter(
                fn ($row): bool => ((float) $row->required_minutes * $demandMultiplier)
                    > ((float) $row->available_minutes * $capacityMultiplier)
            )->count(),
            'max_load_percent' => round((float) ($capacities->map(
                fn ($row): float => $row->available_minutes > 0
                    ? ($row->required_minutes * $demandMultiplier / ($row->available_minutes * $capacityMultiplier)) * 100
                    : 999
            )->max() ?? 0), 2),
        ];

        return $plan->scenarios()->create([
            'code' => strtoupper((string) $data['code']),
            'name' => $data['name'],
            'parameters' => [
                'demand_multiplier' => $demandMultiplier,
                'capacity_multiplier' => $capacityMultiplier,
                'safety_stock_days' => (int) $data['safety_stock_days'],
            ],
            'metrics' => $metrics,
            'status' => 'CALCULATED',
            'created_by' => $userId,
            'calculated_at' => now(),
        ]);
    }

    public function generateOrders(ProductionPlan $plan, string $userId): int
    {
        abort_unless($plan->status === 'APPROVED', 409, __('planning.approve_before_generation'));
        $created = 0;

        DB::transaction(function () use ($plan, $userId, &$created): void {
            $requirements = CapacityRequirement::query()
                ->with(['item', 'demand'])
                ->where('production_plan_id', $plan->id)
                ->whereNull('production_order_id')
                ->whereNotNull('production_line_id')
                ->where('planned_quantity', '>', 0)
                ->orderBy('scheduled_start')
                ->lockForUpdate()
                ->get();

            foreach ($requirements as $requirement) {
                $version = RecipeVersion::query()
                    ->where('status', 'APPROVED')
                    ->whereHas('recipe', fn ($query) => $query->where('finished_item_id', $requirement->item_id))
                    ->with(['recipe.finishedItem', 'lines.ingredient'])
                    ->latest('version_number')
                    ->first();

                if (! $version) {
                    $this->conflict(
                        $plan,
                        $requirement,
                        'NO_APPROVED_RECIPE',
                        'CRITICAL',
                        'planning.conflict_no_recipe',
                        ['item' => $requirement->item->code]
                    );
                    continue;
                }

                $order = ProductionOrder::create([
                    'production_plan_id' => $plan->id,
                    'capacity_requirement_id' => $requirement->id,
                    'order_number' => 'OF-'.now()->format('YmdHis').'-'.strtoupper(Str::random(5)),
                    'finished_item_id' => $requirement->item_id,
                    'recipe_version_id' => $version->id,
                    'process_template_id' => $version->process_template_id,
                    'production_line_id' => $requirement->production_line_id,
                    'work_shift_id' => $requirement->work_shift_id,
                    'planned_quantity' => $requirement->planned_quantity,
                    'unit_id' => $version->reference_unit_id,
                    'planned_date' => $requirement->requirement_date,
                    'planned_start' => $requirement->scheduled_start,
                    'planned_end' => $requirement->scheduled_end,
                    'status' => 'PLANNED',
                    'priority' => $requirement->demand?->priority ?? 5,
                    'responsible_user_id' => $userId,
                ]);

                $expectedOutput = max(
                    .000001,
                    (float) $version->reference_quantity * ((float) $version->expected_yield_percent / 100)
                );
                foreach ($version->lines as $line) {
                    $factor = $line->unit_id === $line->ingredient->base_unit_id
                        ? 1.0
                        : (float) DB::table('item_unit_conversions')->where([
                            'item_id' => $line->ingredient_item_id,
                            'unit_id' => $line->unit_id,
                        ])->value('factor_to_base');
                    if ($factor <= 0) {
                        throw new RuntimeException(__('production.missing_conversion', [
                            'item' => $line->ingredient->code,
                        ]));
                    }
                    $quantity = (float) $line->quantity
                        * (1 + ((float) $line->loss_percentage / 100))
                        * ((float) $requirement->planned_quantity / $expectedOutput)
                        * $factor;
                    $order->consumptions()->create([
                        'item_id' => $line->ingredient_item_id,
                        'planned_quantity' => $quantity,
                        'consumed_quantity' => 0,
                        'unit_id' => $line->ingredient->base_unit_id,
                    ]);
                }

                $requirement->update([
                    'production_order_id' => $order->id,
                    'status' => 'ORDER_CREATED',
                ]);
                $created++;
            }
        }, 3);

        return $created;
    }

    private function salesDemand(ProductionPlan $plan): Collection
    {
        $rows = DB::table('sales_order_lines as sol')
            ->join('sales_orders as so', 'so.id', '=', 'sol.sales_order_id')
            ->join('items as i', 'i.id', '=', 'sol.item_id')
            ->where('so.company_id', $plan->company_id)
            ->whereIn('so.status', self::ACTIVE_ORDER_STATUSES)
            ->when($plan->site_id, fn ($query) => $query->where(
                fn ($nested) => $nested->where('so.site_id', $plan->site_id)->orWhereNull('so.site_id')
            ))
            ->get([
                'so.id as order_id',
                'so.order_date',
                'so.requested_delivery_date',
                'sol.item_id',
                'i.base_unit_id as unit_id',
                'sol.ordered_quantity',
                'sol.delivered_quantity',
                'sol.returned_quantity',
                'sol.factor_to_base',
            ]);

        return $rows
            ->map(function (object $row): object {
                $date = Carbon::parse($row->requested_delivery_date ?: $row->order_date)->toDateString();
                $open = max(
                    0,
                    (float) $row->ordered_quantity - (float) $row->delivered_quantity + (float) $row->returned_quantity
                );

                return (object) [
                    'order_id' => $row->order_id,
                    'item_id' => $row->item_id,
                    'unit_id' => $row->unit_id,
                    'demand_date' => $date,
                    'gross_demand' => $open * (float) $row->factor_to_base,
                    'priority' => Carbon::parse($date)->lt(today()) ? 1 : 5,
                ];
            })
            ->filter(fn (object $row): bool => $row->gross_demand > 0
                && $row->demand_date >= $plan->horizon_start->toDateString()
                && $row->demand_date <= $plan->horizon_end->toDateString())
            ->groupBy(fn (object $row): string => $row->item_id.'|'.$row->demand_date)
            ->map(function (Collection $group): object {
                $first = $group->first();

                return (object) [
                    'item_id' => $first->item_id,
                    'unit_id' => $first->unit_id,
                    'demand_date' => $first->demand_date,
                    'gross_demand' => $group->sum('gross_demand'),
                    'order_count' => $group->pluck('order_id')->unique()->count(),
                    'priority' => $group->min('priority'),
                ];
            })
            ->sortBy(fn (object $row): string => $row->demand_date.'|'.$row->item_id)
            ->values();
    }

    private function stockByItem(ProductionPlan $plan): Collection
    {
        return DB::table('stock_balances as sb')
            ->join('warehouse_locations as wl', 'wl.id', '=', 'sb.location_id')
            ->join('warehouses as w', 'w.id', '=', 'wl.warehouse_id')
            ->leftJoin('lots as lot', 'lot.id', '=', 'sb.lot_id')
            ->where('w.site_id', $plan->site_id)
            ->where(function ($query): void {
                $query->whereNull('sb.lot_id')
                    ->orWhere(function ($lotQuery): void {
                        $lotQuery->where('lot.status', 'RELEASED')
                            ->where(function ($expiryQuery): void {
                                $expiryQuery->whereNull('lot.expiry_date')
                                    ->orWhereDate('lot.expiry_date', '>=', today());
                            });
                    });
            })
            ->selectRaw('sb.item_id, SUM(sb.quantity) as quantity, SUM(sb.reserved_quantity) as reserved')
            ->groupBy('sb.item_id')
            ->get()
            ->keyBy('item_id')
            ->map(fn ($row): array => [
                'quantity' => (float) $row->quantity,
                'reserved' => (float) $row->reserved,
            ]);
    }

    private function plannedReceiptsByItem(ProductionPlan $plan): Collection
    {
        $receipts = collect();
        $productionReceipts = DB::table('production_orders')
            ->whereIn('status', ['PLANNED', 'IN_PROGRESS'])
            ->whereBetween('planned_date', [
                $plan->horizon_start->toDateString(),
                $plan->horizon_end->toDateString(),
            ])
            ->whereIn('production_line_id', DB::table('production_lines')
                ->where('site_id', $plan->site_id)
                ->select('id'))
            ->get(['finished_item_id as item_id', 'planned_date as receipt_date', 'planned_quantity as quantity']);

        $purchaseReceipts = DB::table('purchase_order_lines as line')
            ->join('purchase_orders as orders', 'orders.id', '=', 'line.purchase_order_id')
            ->where('orders.company_id', $plan->company_id)
            ->whereIn('orders.status', ['APPROVED', 'PARTIALLY_RECEIVED'])
            ->when($plan->site_id, fn ($query) => $query->where(
                fn ($nested) => $nested->where('orders.site_id', $plan->site_id)->orWhereNull('orders.site_id')
            ))
            ->get([
                'line.item_id',
                'line.expected_date as line_expected_date',
                'orders.expected_date as order_expected_date',
                'line.ordered_quantity',
                'line.received_quantity',
                'line.returned_quantity',
                'line.factor_to_base',
            ])
            ->map(function (object $row): object {
                $open = max(
                    0,
                    (float) $row->ordered_quantity - (float) $row->received_quantity + (float) $row->returned_quantity
                );

                return (object) [
                    'item_id' => $row->item_id,
                    'receipt_date' => Carbon::parse($row->line_expected_date ?: $row->order_expected_date ?: today())
                        ->toDateString(),
                    'quantity' => $open * (float) $row->factor_to_base,
                ];
            })
            ->filter(fn (object $row): bool => $row->quantity > 0
                && $row->receipt_date >= $plan->horizon_start->toDateString()
                && $row->receipt_date <= $plan->horizon_end->toDateString());

        return $receipts
            ->concat($productionReceipts)
            ->concat($purchaseReceipts)
            ->groupBy(fn (object $row): string => $row->item_id.'|'.Carbon::parse($row->receipt_date)->toDateString())
            ->map(function (Collection $group): object {
                $first = $group->first();

                return (object) [
                    'item_id' => $first->item_id,
                    'receipt_date' => Carbon::parse($first->receipt_date)->toDateString(),
                    'quantity' => (float) $group->sum('quantity'),
                ];
            })
            ->values()
            ->groupBy('item_id')
            ->map(fn (Collection $rows): Collection => $rows->mapWithKeys(
                fn (object $row): array => [$row->receipt_date => (float) $row->quantity]
            ));
    }

    private function applyReceiptOnce(
        Collection $receipts,
        string $itemId,
        string $date,
        array &$appliedDates
    ): float {
        if (isset($appliedDates[$itemId][$date])) {
            return 0;
        }
        $appliedDates[$itemId][$date] = true;

        return (float) data_get($receipts, $itemId.'.'.$date, 0);
    }

    private function explodeMaterials(
        ProductionPlan $plan,
        ProductionPlanDemand $demand,
        Collection $receipts,
        array &$materialBalance,
        array &$materialReceiptDates
    ): void {
        $demand->loadMissing('item');
        $version = RecipeVersion::query()
            ->where('status', 'APPROVED')
            ->whereHas('recipe', fn ($query) => $query->where('finished_item_id', $demand->item_id))
            ->with(['lines.ingredient'])
            ->latest('version_number')
            ->first();

        if (! $version) {
            $this->conflict(
                $plan,
                null,
                'NO_APPROVED_RECIPE',
                'CRITICAL',
                'planning.conflict_no_recipe',
                ['item' => $demand->item->code],
                $demand->demand_date,
                $demand->item
            );
            return;
        }

        $expectedOutput = max(
            .000001,
            (float) $version->reference_quantity * ((float) $version->expected_yield_percent / 100)
        );
        $date = $demand->demand_date->toDateString();

        foreach ($version->lines as $line) {
            $ingredientId = (string) $line->ingredient_item_id;
            $factor = $line->unit_id === $line->ingredient->base_unit_id
                ? 1.0
                : (float) DB::table('item_unit_conversions')->where([
                    'item_id' => $ingredientId,
                    'unit_id' => $line->unit_id,
                ])->value('factor_to_base');

            if ($factor <= 0) {
                $this->conflict(
                    $plan,
                    null,
                    'MISSING_UNIT_CONVERSION',
                    'CRITICAL',
                    'planning.conflict_missing_conversion',
                    ['item' => $line->ingredient->code],
                    $demand->demand_date,
                    $line->ingredient
                );
                continue;
            }

            $gross = (float) $line->quantity
                * (1 + ((float) $line->loss_percentage / 100))
                * ((float) $demand->net_requirement / $expectedOutput)
                * $factor;
            $openingStock = (float) ($materialBalance[$ingredientId] ?? 0);
            $plannedReceipt = $this->applyReceiptOnce(
                $receipts,
                $ingredientId,
                $date,
                $materialReceiptDates
            );
            $available = $openingStock + $plannedReceipt;
            $shortage = max(0, $gross - $available);
            $materialBalance[$ingredientId] = max(0, $available - $gross);

            $plan->materials()->create([
                'finished_item_id' => $demand->item_id,
                'ingredient_item_id' => $ingredientId,
                'recipe_version_id' => $version->id,
                'requirement_date' => $demand->demand_date,
                'gross_requirement' => $gross,
                'stock_on_hand' => $openingStock,
                'planned_receipts' => $plannedReceipt,
                'shortage_quantity' => $shortage,
                'unit_id' => $line->ingredient->base_unit_id,
                'status' => $shortage > 0 ? 'SHORTAGE' : 'COVERED',
                'metadata' => [
                    'demand_id' => $demand->id,
                    'projected_closing_stock' => round($materialBalance[$ingredientId], 3),
                ],
            ]);

            if ($shortage > 0) {
                $this->conflict(
                    $plan,
                    null,
                    'MATERIAL_SHORTAGE',
                    'WARNING',
                    'planning.conflict_material_shortage',
                    ['item' => $line->ingredient->code, 'quantity' => round($shortage, 3)],
                    $demand->demand_date,
                    $line->ingredient
                );
            }
        }
    }

    private function scheduleCapacity(ProductionPlan $plan, ProductionPlanDemand $demand): void
    {
        $demand->loadMissing('item');
        $candidates = LineProduct::query()
            ->where('item_id', $demand->item_id)
            ->where('active', true)
            ->where('production_rate_per_hour', '>', 0)
            ->whereHas('productionLine', fn ($query) => $query
                ->where('site_id', $plan->site_id)
                ->where('active', true))
            ->with('productionLine')
            ->get();

        if ($candidates->isEmpty()) {
            $capacity = $plan->capacities()->create([
                'production_plan_demand_id' => $demand->id,
                'item_id' => $demand->item_id,
                'requirement_date' => $demand->demand_date,
                'planned_quantity' => $demand->net_requirement,
                'status' => 'NO_CAPABLE_LINE',
                'conflict_codes' => ['NO_CAPABLE_LINE'],
            ]);
            $this->conflict(
                $plan,
                $capacity,
                'NO_CAPABLE_LINE',
                'CRITICAL',
                'planning.conflict_no_capable_line',
                ['item' => $demand->item->code],
                $demand->demand_date,
                $demand->item
            );
            return;
        }

        $options = $candidates->map(function (LineProduct $capability) use ($plan, $demand): array {
            $required = (int) ceil(
                ((float) $demand->net_requirement / (float) $capability->production_rate_per_hour) * 60
                + (int) $capability->setup_time_minutes
            );
            [$available, $shift, $shiftStart] = $this->availableMinutes(
                $plan,
                (string) $capability->production_line_id,
                $demand->demand_date
            );
            $already = (int) $plan->capacities()
                ->where('production_line_id', $capability->production_line_id)
                ->whereDate('requirement_date', $demand->demand_date)
                ->sum('required_minutes');
            $load = $available > 0 ? (($already + $required) / $available) * 100 : 999;

            return compact('capability', 'required', 'available', 'shift', 'shiftStart', 'already', 'load');
        })->sortBy(fn (array $option): string => sprintf('%012.4f|%012d', $option['load'], $option['required']))
            ->first();

        /** @var LineProduct $capability */
        $capability = $options['capability'];
        $required = (int) $options['required'];
        $available = (int) $options['available'];
        $already = (int) $options['already'];
        $load = (float) $options['load'];
        $shift = $options['shift'];
        /** @var Carbon $shiftStart */
        $shiftStart = $options['shiftStart'];
        $scheduledStart = $shiftStart->copy()->addMinutes($already);
        $scheduledEnd = $scheduledStart->copy()->addMinutes($required);
        $status = $load > 100 ? 'OVERLOAD' : 'AVAILABLE';

        $capacity = $plan->capacities()->create([
            'production_plan_demand_id' => $demand->id,
            'production_line_id' => $capability->production_line_id,
            'work_shift_id' => $shift?->id,
            'item_id' => $demand->item_id,
            'requirement_date' => $demand->demand_date,
            'planned_quantity' => $demand->net_requirement,
            'required_minutes' => $required,
            'available_minutes' => $available,
            'load_percent' => $load,
            'sequence_number' => $plan->capacities()
                ->where('production_line_id', $capability->production_line_id)
                ->whereDate('requirement_date', $demand->demand_date)
                ->count() + 1,
            'scheduled_start' => $scheduledStart,
            'scheduled_end' => $scheduledEnd,
            'status' => $status,
            'conflict_codes' => $status === 'OVERLOAD' ? ['CAPACITY_OVERLOAD'] : [],
        ]);

        if ($status === 'OVERLOAD') {
            $this->conflict(
                $plan,
                $capacity,
                'CAPACITY_OVERLOAD',
                'CRITICAL',
                'planning.conflict_capacity_overload',
                ['line' => $capability->productionLine->code, 'load' => round($load, 2)],
                $demand->demand_date,
                $capability->productionLine
            );
        }
    }

    private function availableMinutes(ProductionPlan $plan, string $lineId, Carbon $date): array
    {
        $shifts = WorkShift::query()
            ->where('site_id', $plan->site_id)
            ->where('active', true)
            ->orderBy('starts_at')
            ->get()
            ->filter(function (WorkShift $shift) use ($date): bool {
                $days = collect($shift->work_days ?? [])->map(
                    fn ($day): string => strtolower(trim((string) $day))
                );

                return $days->isEmpty()
                    || $days->contains((string) $date->dayOfWeekIso)
                    || $days->contains(strtolower($date->format('D')))
                    || $days->contains(strtolower($date->locale('en')->dayName));
            });

        if ($shifts->isEmpty()) {
            return [480, null, $date->copy()->setTime(8, 0)];
        }

        $minutes = (int) $shifts->sum(function (WorkShift $shift): int {
            $start = Carbon::parse($shift->starts_at);
            $end = Carbon::parse($shift->ends_at);
            if ($end->lte($start)) {
                $end->addDay();
            }

            return $start->diffInMinutes($end);
        });
        $first = $shifts->first();
        $start = Carbon::parse($date->format('Y-m-d').' '.$first->starts_at);
        $dayStart = $date->copy()->startOfDay();
        $dayEnd = $date->copy()->endOfDay();
        $maintenance = DB::table('maintenance_work_orders')
            ->where('production_line_id', $lineId)
            ->whereIn('status', ['PLANNED', 'IN_PROGRESS'])
            ->where('planned_start', '<=', $dayEnd)
            ->where(function ($query) use ($dayStart): void {
                $query->whereNull('planned_end')->orWhere('planned_end', '>=', $dayStart);
            })
            ->get(['planned_start', 'planned_end'])
            ->sum(function (object $workOrder) use ($dayStart, $dayEnd): int {
                if (! $workOrder->planned_start) {
                    return 0;
                }
                $from = Carbon::parse($workOrder->planned_start)->max($dayStart);
                $to = ($workOrder->planned_end ? Carbon::parse($workOrder->planned_end) : $dayEnd)->min($dayEnd);

                return $to->gt($from) ? $from->diffInMinutes($to) : 0;
            });

        return [max(0, $minutes - (int) $maintenance), $first, $start];
    }

    private function conflict(
        ProductionPlan $plan,
        ?CapacityRequirement $capacity,
        string $type,
        string $severity,
        string $key,
        array $context,
        ?Carbon $date = null,
        mixed $subject = null
    ): PlanningConflict {
        return $plan->conflicts()->create([
            'capacity_requirement_id' => $capacity?->id,
            'conflict_type' => $type,
            'severity' => $severity,
            'conflict_date' => $date,
            'subject_type' => $subject ? get_class($subject) : null,
            'subject_id' => $subject?->id,
            'message_key' => $key,
            'context' => $context,
            'status' => 'OPEN',
        ]);
    }

    private function metrics(ProductionPlan $plan): array
    {
        return [
            'gross_demand' => round((float) $plan->demands()->sum('gross_demand'), 3),
            'net_requirement' => round((float) $plan->demands()->sum('net_requirement'), 3),
            'material_shortage' => round((float) $plan->materials()->sum('shortage_quantity'), 3),
            'shortage_lines' => $plan->materials()->where('status', 'SHORTAGE')->count(),
            'capacity_overloads' => $plan->capacities()->where('status', 'OVERLOAD')->count(),
            'critical_conflicts' => $plan->conflicts()->where('severity', 'CRITICAL')->where('status', 'OPEN')->count(),
            'planned_orders' => $plan->capacities()->whereNotNull('production_order_id')->count(),
            'max_load_percent' => round((float) ($plan->capacities()->max('load_percent') ?? 0), 2),
        ];
    }
}
