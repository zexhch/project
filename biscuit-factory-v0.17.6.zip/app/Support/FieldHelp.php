<?php

namespace App\Support;

final class FieldHelp
{
    /** @return array<string, array<string, string>> */
    public static function fields(): array
    {
        $fields = __('help.fields');
        return is_array($fields) ? $fields : [];
    }

    /** @return array<string, array<string, string>> */
    public static function glossary(): array
    {
        $glossary = __('help.glossary');
        return is_array($glossary) ? $glossary : [];
    }
}
