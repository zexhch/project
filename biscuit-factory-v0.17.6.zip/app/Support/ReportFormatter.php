<?php

namespace App\Support;

final class ReportFormatter
{
    public static function value(mixed $value, string $format = 'number', ?string $currency = null): string
    {
        if ($value === null) {
            return '—';
        }

        return match ($format) {
            'currency' => number_format((float) $value, 2, ',', ' ').' '.($currency ?: 'DZD'),
            'percent' => number_format((float) $value, 1, ',', ' ').' %',
            'decimal' => number_format((float) $value, 2, ',', ' '),
            'duration' => self::duration((int) round((float) $value)),
            'integer' => number_format((int) $value, 0, ',', ' '),
            default => is_numeric($value) ? number_format((float) $value, 0, ',', ' ') : (string) $value,
        };
    }

    private static function duration(int $seconds): string
    {
        $hours = intdiv(max(0, $seconds), 3600);
        $minutes = intdiv(max(0, $seconds) % 3600, 60);

        return sprintf('%dh %02d', $hours, $minutes);
    }
}
