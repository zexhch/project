<?php

namespace App\Support;

use App\Models\AuditLog;
use App\Models\Company;
use App\Models\Currency;
use App\Models\Item;
use App\Models\ItemCategory;
use App\Models\Language;
use App\Models\Machine;
use App\Models\Permission;
use App\Models\ProductionLine;
use App\Models\ReferenceValue;
use App\Models\Role;
use App\Models\Site;
use App\Models\SystemSetting;
use App\Models\TaxRate;
use App\Models\Unit;
use App\Models\User;
use App\Models\Warehouse;
use App\Models\WarehouseLocation;
use App\Models\WorkShift;
use App\Models\DowntimeReason;
use App\Models\FinancialAccount;
use App\Models\MaintenancePlan;

final class MasterDataRegistry
{
    public static function exists(string $resource): bool
    {
        return array_key_exists($resource, self::resources());
    }

    public static function get(string $resource): array
    {
        abort_unless(self::exists($resource), 404);

        return self::resources()[$resource];
    }

    public static function applicationModule(string $resource, ?array $definition = null): string
    {
        $definition ??= self::get($resource);

        return match ($resource) {
            'financial-accounts' => 'finance',
            'production-lines', 'machines', 'work-shifts' => 'production',
            'maintenance-plans', 'downtime-reasons' => 'maintenance',
            'users', 'roles', 'permissions', 'audit-logs' => 'administration',
            default => 'master-data',
        };
    }

    public static function navigation(): array
    {
        return [
            [
                'label' => 'admin.organization',
                'items' => self::navigationItems([
                    'companies', 'sites', 'warehouses', 'warehouse-locations',
                ]),
            ],
            [
                'label' => 'admin.catalog',
                'items' => self::navigationItems(['units', 'item-categories', 'items']),
            ],
            [
                'label' => 'admin.production_resources',
                'items' => self::navigationItems(['production-lines', 'machines', 'work-shifts']),
            ],
            [
                'label' => 'maintenance.maintenance',
                'items' => self::navigationItems(['maintenance-plans', 'downtime-reasons']),
            ],
            [
                'label' => 'admin.access_control',
                'items' => self::navigationItems(['users', 'roles', 'permissions', 'audit-logs']),
            ],
            [
                'label' => 'admin.settings',
                'items' => self::navigationItems([
                    'languages', 'currencies', 'tax-rates', 'system-settings', 'reference-values',
                ]),
            ],
        ];
    }

    public static function resources(): array
    {
        return [
            'financial-accounts' => [
                'model' => FinancialAccount::class,
                'table' => 'financial_accounts',
                'label' => 'billing.financial_accounts',
                'singular' => 'billing.financial_account',
                'description' => 'billing.financial_accounts_description',
                'icon' => 'ti-building-bank',
                'module' => 'finance',
                'with' => ['company'],
                'search' => ['code', 'name', 'bank_name', 'account_number'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'company.name', 'label' => 'admin.company'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'account_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'currency_code', 'label' => 'admin.currency'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'company_id' => self::select('admin.company', self::modelOptions(Company::class), true),
                    'code' => self::text('admin.code', true, 80, unique: ['company_id']),
                    'name' => self::text('admin.name', true),
                    'account_type' => self::select('admin.type', self::referenceOptions('financial_account_type'), true, default: 'BANK'),
                    'currency_code' => self::select('admin.currency', self::modelOptions(Currency::class, 'code', 'name'), true, default: 'DZD'),
                    'bank_name' => self::text('billing.bank_name'),
                    'account_number' => self::text('billing.account_number', max: 120),
                    'iban' => self::text('billing.iban', max: 80),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'companies' => [
                'model' => Company::class,
                'table' => 'companies',
                'label' => 'admin.companies',
                'singular' => 'admin.company',
                'description' => 'admin.companies_description',
                'icon' => 'ti-building-factory-2',
                'module' => 'settings',
                'search' => ['code', 'name', 'legal_name', 'trade_register_number', 'tax_identification_number', 'statistical_identification_number', 'article_of_imposition_number'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'trade_register_number', 'label' => 'admin.trade_register_number'],
                    ['key' => 'tax_identification_number', 'label' => 'admin.tax_identification_number'],
                    ['key' => 'country_code', 'label' => 'admin.country'],
                    ['key' => 'currency_code', 'label' => 'admin.currency'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 50, unique: true),
                    'name' => self::text('admin.name', true),
                    'legal_name' => self::text('admin.legal_name'),
                    'business_activity' => self::text('admin.business_activity'),
                    'trade_register_number' => self::text('admin.trade_register_number', max: 120),
                    'tax_identification_number' => self::text('admin.tax_identification_number', max: 120),
                    'statistical_identification_number' => self::text('admin.statistical_identification_number', max: 120),
                    'article_of_imposition_number' => self::text('admin.article_of_imposition_number', max: 120),
                    'country_code' => self::select('admin.country', self::referenceOptions('country'), true, default: 'DZ'),
                    'currency_code' => self::select('admin.currency', self::modelOptions(Currency::class, 'code', 'name'), true, default: 'DZD'),
                    'timezone' => self::select('admin.timezone', self::referenceOptions('timezone'), true, default: 'Africa/Algiers'),
                    'phone' => self::text('admin.phone', max: 50),
                    'email' => self::email('admin.email'),
                    'address' => self::textarea('admin.address'),
                    'bank_name' => self::text('billing.bank_name'),
                    'bank_branch' => self::text('admin.bank_branch'),
                    'bank_account_number' => self::text('billing.account_number', max: 160),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'sites' => [
                'model' => Site::class,
                'table' => 'sites',
                'label' => 'admin.sites',
                'singular' => 'admin.site',
                'description' => 'admin.sites_description',
                'icon' => 'ti-map-pin',
                'module' => 'settings',
                'with' => ['company'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'company.name', 'label' => 'admin.company'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'site_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'company_id' => self::select('admin.company', self::modelOptions(Company::class), true),
                    'code' => self::text('admin.code', true, 50, unique: ['company_id']),
                    'name' => self::text('admin.name', true),
                    'site_type' => self::select('admin.type', self::referenceOptions('site_type'), true, default: 'FACTORY'),
                    'address' => self::textarea('admin.address'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'warehouses' => [
                'model' => Warehouse::class,
                'table' => 'warehouses',
                'label' => 'admin.warehouses',
                'singular' => 'admin.warehouse',
                'description' => 'admin.warehouses_description',
                'icon' => 'ti-building-warehouse',
                'module' => 'settings',
                'with' => ['site'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'site.name', 'label' => 'admin.site'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'warehouse_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'site_id' => self::select('admin.site', self::modelOptions(Site::class), true),
                    'code' => self::text('admin.code', true, 50, unique: ['site_id']),
                    'name' => self::text('admin.name', true),
                    'warehouse_type' => self::select('admin.type', self::referenceOptions('warehouse_type'), true, default: 'GENERAL'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'warehouse-locations' => [
                'model' => WarehouseLocation::class,
                'table' => 'warehouse_locations',
                'label' => 'admin.warehouse_locations',
                'singular' => 'admin.warehouse_location',
                'description' => 'admin.warehouse_locations_description',
                'icon' => 'ti-box',
                'module' => 'settings',
                'with' => ['warehouse'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'warehouse.name', 'label' => 'admin.warehouse'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'location_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'quarantine', 'label' => 'admin.quarantine', 'format' => 'boolean'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'warehouse_id' => self::select('admin.warehouse', self::modelOptions(Warehouse::class), true),
                    'code' => self::text('admin.code', true, 80, unique: ['warehouse_id']),
                    'name' => self::text('admin.name', true),
                    'location_type' => self::select('admin.type', self::referenceOptions('location_type'), true, default: 'STORAGE'),
                    'quarantine' => self::checkbox('admin.quarantine'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'units' => [
                'model' => Unit::class,
                'table' => 'units',
                'label' => 'admin.units',
                'singular' => 'admin.unit',
                'description' => 'admin.units_description',
                'icon' => 'ti-ruler-measure',
                'module' => 'catalog',
                'search' => ['code', 'name', 'symbol'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'symbol', 'label' => 'admin.symbol'],
                    ['key' => 'dimension', 'label' => 'admin.dimension', 'format' => 'code'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 20, unique: true),
                    'name' => self::text('admin.name', true),
                    'symbol' => self::text('admin.symbol', true, 20),
                    'dimension' => self::select('admin.dimension', self::referenceOptions('unit_dimension'), true, default: 'COUNT'),
                    'decimal_places' => self::number('admin.decimal_places', true, 0, 8, default: 3),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'item-categories' => [
                'model' => ItemCategory::class,
                'table' => 'item_categories',
                'label' => 'admin.item_categories',
                'singular' => 'admin.item_category',
                'description' => 'admin.item_categories_description',
                'icon' => 'ti-category-2',
                'module' => 'catalog',
                'with' => ['parent'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'parent.name', 'label' => 'admin.parent'],
                    ['key' => 'category_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'parent_id' => self::select('admin.parent', self::modelOptions(ItemCategory::class)),
                    'code' => self::text('admin.code', true, 50, unique: true),
                    'name' => self::text('admin.name', true),
                    'category_type' => self::select('admin.type', self::referenceOptions('item_type'), true, default: 'RAW_MATERIAL'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'items' => [
                'model' => Item::class,
                'table' => 'items',
                'label' => 'admin.items',
                'singular' => 'admin.item',
                'description' => 'admin.items_description',
                'icon' => 'ti-package',
                'module' => 'catalog',
                'with' => ['category', 'baseUnit'],
                'row_actions' => [
                    ['label' => 'packaging.manage_packaging', 'icon' => 'ti-packages', 'route' => 'admin.items.packaging', 'permission' => 'catalog.view'],
                ],
                'search' => ['code', 'name', 'barcode'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'main_image_thumbnail_path', 'label' => 'packaging.image', 'format' => 'image'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'category.name', 'label' => 'admin.category'],
                    ['key' => 'item_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'baseUnit.symbol', 'label' => 'admin.unit'],
                    ['key' => 'minimum_stock', 'label' => 'admin.minimum_stock', 'format' => 'number'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'category_id' => self::select('admin.category', self::modelOptions(ItemCategory::class)),
                    'base_unit_id' => self::select('admin.unit', self::modelOptions(Unit::class, 'id', 'name', 'symbol'), true),
                    'code' => self::text('admin.code', true, 80, unique: true),
                    'name' => self::text('admin.name', true),
                    'description' => self::textarea('admin.description'),
                    'item_type' => self::select('admin.type', self::referenceOptions('item_type'), true, default: 'RAW_MATERIAL'),
                    'barcode' => self::text('admin.barcode', max: 120, unique: true),
                    'minimum_stock' => self::number('admin.minimum_stock', true, 0, null, .001, 0),
                    'shelf_life_days' => self::number('admin.shelf_life_days', false, 0),
                    'lot_managed' => self::checkbox('admin.lot_managed', true),
                    'expiry_managed' => self::checkbox('admin.expiry_managed'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'production-lines' => [
                'model' => ProductionLine::class,
                'table' => 'production_lines',
                'label' => 'admin.production_lines',
                'singular' => 'admin.production_line',
                'description' => 'admin.production_lines_description',
                'icon' => 'ti-assembly',
                'module' => 'production',
                'with' => ['site', 'capacityUnit'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'site.name', 'label' => 'admin.site'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'capacity_per_hour', 'label' => 'admin.hourly_capacity', 'format' => 'number'],
                    ['key' => 'capacityUnit.symbol', 'label' => 'admin.unit'],
                    ['key' => 'status', 'label' => 'admin.status', 'format' => 'code'],
                ],
                'fields' => [
                    'site_id' => self::select('admin.site', self::modelOptions(Site::class), true),
                    'code' => self::text('admin.code', true, 50, unique: ['site_id']),
                    'name' => self::text('admin.name', true),
                    'description' => self::textarea('admin.description'),
                    'capacity_per_hour' => self::number('admin.hourly_capacity', false, 0, null, .001),
                    'capacity_unit_id' => self::select('admin.unit', self::modelOptions(Unit::class, 'id', 'name', 'symbol')),
                    'status' => self::select('admin.status', self::referenceOptions('line_status'), true, default: 'AVAILABLE'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'machines' => [
                'model' => Machine::class,
                'table' => 'machines',
                'label' => 'admin.machines',
                'singular' => 'admin.machine',
                'description' => 'admin.machines_description',
                'icon' => 'ti-settings-automation',
                'module' => 'production',
                'with' => ['site'],
                'search' => ['code', 'name', 'serial_number'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'site.name', 'label' => 'admin.site'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'machine_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'status', 'label' => 'admin.status', 'format' => 'code'],
                ],
                'fields' => [
                    'site_id' => self::select('admin.site', self::modelOptions(Site::class), true),
                    'code' => self::text('admin.code', true, 50, unique: ['site_id']),
                    'name' => self::text('admin.name', true),
                    'machine_type' => self::select('admin.type', self::referenceOptions('machine_type'), true),
                    'manufacturer' => self::text('admin.manufacturer'),
                    'model' => self::text('admin.model'),
                    'serial_number' => self::text('admin.serial_number'),
                    'commissioned_at' => self::date('admin.commissioned_at'),
                    'status' => self::select('admin.status', self::referenceOptions('line_status'), true, default: 'AVAILABLE'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'work-shifts' => [
                'model' => WorkShift::class,
                'table' => 'work_shifts',
                'label' => 'admin.work_shifts',
                'singular' => 'admin.work_shift',
                'description' => 'admin.work_shifts_description',
                'icon' => 'ti-clock-hour-4',
                'module' => 'production',
                'with' => ['site'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'site.name', 'label' => 'admin.site'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'starts_at', 'label' => 'admin.starts_at'],
                    ['key' => 'ends_at', 'label' => 'admin.ends_at'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'site_id' => self::select('admin.site', self::modelOptions(Site::class), true),
                    'code' => self::text('admin.code', true, 30, unique: ['site_id']),
                    'name' => self::text('admin.name', true),
                    'starts_at' => self::time('admin.starts_at', true),
                    'ends_at' => self::time('admin.ends_at', true),
                    'work_days' => self::multiCheckbox('admin.work_days', self::weekDayOptions()),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'maintenance-plans' => [
                'model' => MaintenancePlan::class,
                'table' => 'maintenance_plans',
                'label' => 'admin.maintenance_plans',
                'singular' => 'admin.maintenance_plan',
                'description' => 'admin.maintenance_plans_description',
                'icon' => 'ti-calendar-cog',
                'module' => 'maintenance',
                'with' => ['productionLine', 'machine'],
                'search' => ['code', 'name'],
                'order_by' => 'next_due_at',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'], ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'machine.name', 'label' => 'admin.machine'], ['key' => 'maintenance_type', 'label' => 'admin.type', 'format' => 'code'],
                    ['key' => 'next_due_at', 'label' => 'admin.next_due_at', 'format' => 'datetime'], ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 80, unique: true), 'name' => self::text('admin.name', true),
                    'production_line_id' => self::select('admin.production_line', self::modelOptions(ProductionLine::class)),
                    'machine_id' => self::select('admin.machine', self::modelOptions(Machine::class)),
                    'maintenance_type' => self::select('admin.type', self::referenceOptions('maintenance_type'), true, default: 'PREVENTIVE'),
                    'frequency_type' => self::select('admin.frequency_type', self::referenceOptions('maintenance_frequency'), true, default: 'WEEKS'),
                    'frequency_value' => self::number('admin.frequency_value', true, 1, null, 1, 1),
                    'estimated_duration_minutes' => self::number('admin.estimated_duration_minutes', false, 1),
                    'next_due_at' => self::date('admin.next_due_at'), 'active' => self::checkbox('admin.active', true),
                ],
            ],
            'downtime-reasons' => [
                'model' => DowntimeReason::class,
                'table' => 'downtime_reasons',
                'label' => 'admin.downtime_reasons', 'singular' => 'admin.downtime_reason',
                'description' => 'admin.downtime_reasons_description', 'icon' => 'ti-player-pause', 'module' => 'maintenance',
                'search' => ['code', 'name', 'category'], 'order_by' => 'name',
                'columns' => [['key' => 'code', 'label' => 'admin.code'], ['key' => 'name', 'label' => 'admin.name'], ['key' => 'category', 'label' => 'admin.category', 'format' => 'code'], ['key' => 'planned', 'label' => 'admin.planned', 'format' => 'boolean'], ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean']],
                'fields' => ['code' => self::text('admin.code', true, 80, unique: true), 'name' => self::text('admin.name', true), 'category' => self::select('admin.category', self::referenceOptions('downtime_category'), true), 'planned' => self::checkbox('admin.planned'), 'active' => self::checkbox('admin.active', true)],
            ],
            'users' => [
                'model' => User::class,
                'table' => 'users',
                'label' => 'admin.users',
                'singular' => 'admin.user',
                'description' => 'admin.users_description',
                'icon' => 'ti-users',
                'module' => 'users',
                'with' => ['roles'],
                'search' => ['name', 'email'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'email', 'label' => 'admin.email'],
                    ['key' => 'locale', 'label' => 'admin.language', 'format' => 'code'],
                    ['key' => 'roles', 'label' => 'admin.roles', 'format' => 'relation_list', 'list_key' => 'name'],
                    ['key' => 'force_password_change', 'label' => 'admin.force_password_change', 'format' => 'boolean'],
                    ['key' => 'locked_until', 'label' => 'admin.locked_until', 'format' => 'datetime'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'name' => self::text('admin.name', true),
                    'email' => self::email('admin.email', true, unique: true),
                    'password' => self::password('admin.password'),
                    'force_password_change' => self::checkbox('admin.force_password_change', true),
                    'locale' => self::select('admin.language', self::modelOptions(Language::class, 'code', 'native_name'), true, default: 'fr'),
                    'role_ids' => self::multiSelect('admin.roles', self::modelOptions(Role::class)),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'roles' => [
                'model' => Role::class,
                'table' => 'roles',
                'label' => 'admin.roles',
                'singular' => 'admin.role',
                'description' => 'admin.roles_description',
                'icon' => 'ti-shield-lock',
                'module' => 'users',
                'with' => ['permissions'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'permissions', 'label' => 'admin.permissions', 'format' => 'count'],
                    ['key' => 'system', 'label' => 'admin.system', 'format' => 'boolean'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 80, unique: true),
                    'name' => self::text('admin.name', true),
                    'description' => self::textarea('admin.description'),
                    'permission_ids' => self::multiSelect('admin.permissions', self::modelOptions(Permission::class, 'id', 'code', 'name', 'module')),
                    'system' => self::checkbox('admin.system') + ['readonly' => true],
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'permissions' => [
                'model' => Permission::class,
                'table' => 'permissions',
                'label' => 'admin.permissions',
                'singular' => 'admin.permission',
                'description' => 'admin.permissions_description',
                'icon' => 'ti-key',
                'module' => 'users',
                'search' => ['code', 'module', 'name'],
                'order_by' => 'module',
                'columns' => [
                    ['key' => 'module', 'label' => 'admin.module', 'format' => 'code'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'system', 'label' => 'admin.system', 'format' => 'boolean'],
                ],
                'fields' => [
                    'module' => self::text('admin.module', true, 80),
                    'code' => self::text('admin.code', true, 120, unique: true),
                    'name' => self::text('admin.name', true),
                    'description' => self::textarea('admin.description'),
                    'system' => self::checkbox('admin.system') + ['readonly' => true],
                ],
            ],
            'audit-logs' => [
                'model' => AuditLog::class,
                'table' => 'audit_logs',
                'label' => 'admin.audit_logs',
                'singular' => 'admin.audit_log',
                'description' => 'admin.audit_logs_description',
                'icon' => 'ti-history',
                'module' => 'users',
                'read_only' => true,
                'with' => ['user'],
                'search' => ['event', 'auditable_type', 'ip_address'],
                'order_by' => 'created_at',
                'order_direction' => 'desc',
                'columns' => [
                    ['key' => 'created_at', 'label' => 'admin.date', 'format' => 'datetime'],
                    ['key' => 'user.name', 'label' => 'admin.user'],
                    ['key' => 'severity', 'label' => 'admin.severity', 'format' => 'code'],
                    ['key' => 'event', 'label' => 'admin.event', 'format' => 'code'],
                    ['key' => 'auditable_type', 'label' => 'admin.entity', 'format' => 'class'],
                    ['key' => 'auditable_id', 'label' => 'admin.identifier'],
                    ['key' => 'ip_address', 'label' => 'admin.ip_address'],
                    ['key' => 'correlation_id', 'label' => 'admin.correlation_id', 'format' => 'code'],
                ],
                'fields' => [],
            ],
            'languages' => [
                'model' => Language::class,
                'table' => 'languages',
                'label' => 'admin.languages',
                'singular' => 'admin.language',
                'description' => 'admin.languages_description',
                'icon' => 'ti-language',
                'module' => 'settings',
                'search' => ['code', 'name', 'native_name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'native_name', 'label' => 'admin.native_name'],
                    ['key' => 'direction', 'label' => 'admin.direction', 'format' => 'code'],
                    ['key' => 'is_default', 'label' => 'admin.default', 'format' => 'boolean'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 5, unique: true),
                    'name' => self::text('admin.name', true),
                    'native_name' => self::text('admin.native_name', true),
                    'direction' => self::select('admin.direction', self::staticOptions(['ltr' => 'LTR', 'rtl' => 'RTL']), true, default: 'ltr'),
                    'is_default' => self::checkbox('admin.default'),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'currencies' => [
                'model' => Currency::class,
                'table' => 'currencies',
                'label' => 'admin.currencies',
                'singular' => 'admin.currency',
                'description' => 'admin.currencies_description',
                'icon' => 'ti-currency-dinar',
                'module' => 'settings',
                'search' => ['code', 'name', 'symbol'],
                'order_by' => 'code',
                'columns' => [
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'symbol', 'label' => 'admin.symbol'],
                    ['key' => 'decimal_places', 'label' => 'admin.decimal_places'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'code' => self::text('admin.code', true, 3, unique: true),
                    'name' => self::text('admin.name', true),
                    'symbol' => self::text('admin.symbol', true, 10),
                    'decimal_places' => self::number('admin.decimal_places', true, 0, 8, default: 2),
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
            'tax-rates' => [
                'model' => TaxRate::class,
                'table' => 'tax_rates',
                'label' => 'admin.tax_rates',
                'singular' => 'admin.tax_rate',
                'description' => 'admin.tax_rates_description',
                'icon' => 'ti-percentage',
                'module' => 'settings',
                'with' => ['company'],
                'search' => ['code', 'name'],
                'order_by' => 'name',
                'columns' => [
                    ['key' => 'company.name', 'label' => 'admin.company'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'name', 'label' => 'admin.name'],
                    ['key' => 'rate', 'label' => 'admin.rate', 'format' => 'percentage'],
                    ['key' => 'is_default', 'label' => 'admin.default', 'format' => 'boolean'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'company_id' => self::select('admin.company', self::modelOptions(Company::class)),
                    'code' => self::text('admin.code', true, 50, unique: ['company_id']),
                    'name' => self::text('admin.name', true),
                    'rate' => self::number('admin.rate', true, 0, 100, .0001, 0),
                    'valid_from' => self::date('admin.valid_from'),
                    'valid_to' => self::date('admin.valid_to'),
                    'is_default' => self::checkbox('admin.default'),
                    'active' => self::checkbox('admin.active'),
                ],
            ],
            'system-settings' => [
                'model' => SystemSetting::class,
                'table' => 'system_settings',
                'label' => 'admin.system_settings',
                'singular' => 'admin.system_setting',
                'description' => 'admin.system_settings_description',
                'icon' => 'ti-adjustments',
                'module' => 'settings',
                'with' => ['company'],
                'search' => ['group', 'key'],
                'order_by' => 'group',
                'columns' => [
                    ['key' => 'company.name', 'label' => 'admin.company'],
                    ['key' => 'group', 'label' => 'admin.group', 'format' => 'code'],
                    ['key' => 'key', 'label' => 'admin.key'],
                    ['key' => 'value', 'label' => 'admin.value', 'format' => 'json'],
                    ['key' => 'value_type', 'label' => 'admin.value_type', 'format' => 'code'],
                    ['key' => 'public', 'label' => 'admin.public', 'format' => 'boolean'],
                ],
                'fields' => [
                    'company_id' => self::select('admin.company', self::modelOptions(Company::class)),
                    'group' => self::text('admin.group', true, 80, unique: ['company_id', 'key']),
                    'key' => self::text('admin.key', true, 120),
                    'value' => self::textarea('admin.value', true),
                    'value_type' => self::select('admin.value_type', self::staticOptions([
                        'string' => 'admin.string', 'integer' => 'admin.integer', 'decimal' => 'admin.decimal',
                        'boolean' => 'admin.boolean', 'json' => 'JSON',
                    ]), true, default: 'string'),
                    'public' => self::checkbox('admin.public'),
                ],
            ],
            'reference-values' => [
                'model' => ReferenceValue::class,
                'table' => 'reference_values',
                'label' => 'admin.reference_values',
                'singular' => 'admin.reference_value',
                'description' => 'admin.reference_values_description',
                'icon' => 'ti-list-details',
                'module' => 'settings',
                'search' => ['domain', 'code'],
                'order_by' => 'domain',
                'columns' => [
                    ['key' => 'domain', 'label' => 'admin.domain', 'format' => 'code'],
                    ['key' => 'code', 'label' => 'admin.code'],
                    ['key' => 'localized_label', 'label' => 'admin.label'],
                    ['key' => 'sort_order', 'label' => 'admin.sort_order'],
                    ['key' => 'system', 'label' => 'admin.system', 'format' => 'boolean'],
                    ['key' => 'active', 'label' => 'admin.status', 'format' => 'boolean'],
                ],
                'fields' => [
                    'domain' => self::text('admin.domain', true, 100, unique: ['code']),
                    'code' => self::text('admin.code', true, 100),
                    'label_fr' => self::text('admin.label_fr', true),
                    'label_ar' => self::text('admin.label_ar', true),
                    'label_en' => self::text('admin.label_en', true),
                    'sort_order' => self::number('admin.sort_order', true, 0, default: 0),
                    'system' => self::checkbox('admin.system') + ['readonly' => true],
                    'active' => self::checkbox('admin.active', true),
                ],
            ],
        ];
    }

    private static function navigationItems(array $resources): array
    {
        $definitions = self::resources();

        return array_map(fn (string $resource): array => [
            'resource' => $resource,
            'label' => $definitions[$resource]['label'],
            'icon' => $definitions[$resource]['icon'],
            'module' => $definitions[$resource]['module'],
        ], $resources);
    }

    private static function text(string $label, bool $required = false, int $max = 255, bool|array $unique = false): array
    {
        return compact('label', 'required', 'max', 'unique') + ['type' => 'text'];
    }

    private static function email(string $label, bool $required = false, bool|array $unique = false): array
    {
        return compact('label', 'required', 'unique') + ['type' => 'email', 'max' => 255];
    }

    private static function password(string $label): array
    {
        return ['label' => $label, 'type' => 'password', 'required_on_create' => true, 'min' => 8, 'max' => 255];
    }

    private static function textarea(string $label, bool $required = false): array
    {
        return compact('label', 'required') + ['type' => 'textarea'];
    }

    private static function checkbox(string $label, bool $default = false): array
    {
        return compact('label', 'default') + ['type' => 'checkbox'];
    }

    private static function select(string $label, array $options, bool $required = false, mixed $default = null): array
    {
        return compact('label', 'options', 'required', 'default') + ['type' => 'select'];
    }

    private static function multiSelect(string $label, array $options): array
    {
        return compact('label', 'options') + ['type' => 'multiselect', 'default' => []];
    }

    private static function multiCheckbox(string $label, array $options): array
    {
        return compact('label', 'options') + ['type' => 'multicheckbox', 'default' => []];
    }

    private static function number(
        string $label,
        bool $required = false,
        int|float|null $min = null,
        int|float|null $max = null,
        int|float $step = 1,
        int|float|null $default = null,
    ): array {
        return compact('label', 'required', 'min', 'max', 'step', 'default') + ['type' => 'number'];
    }

    private static function date(string $label): array
    {
        return ['label' => $label, 'type' => 'date'];
    }

    private static function time(string $label, bool $required = false): array
    {
        return compact('label', 'required') + ['type' => 'time'];
    }

    private static function staticOptions(array $values): array
    {
        return ['source' => 'static', 'values' => $values];
    }

    private static function modelOptions(
        string $model,
        string $value = 'id',
        string $label = 'name',
        ?string $suffix = null,
        ?string $group = null,
    ): array {
        return compact('model', 'value', 'label', 'suffix', 'group') + [
            'source' => 'model',
            'active_only' => $model !== Permission::class,
        ];
    }

    private static function referenceOptions(string $domain): array
    {
        return compact('domain') + ['source' => 'reference'];
    }

    private static function weekDayOptions(): array
    {
        return self::staticOptions([
            1 => 'admin.monday', 2 => 'admin.tuesday', 3 => 'admin.wednesday',
            4 => 'admin.thursday', 5 => 'admin.friday', 6 => 'admin.saturday', 7 => 'admin.sunday',
        ]);
    }
}
