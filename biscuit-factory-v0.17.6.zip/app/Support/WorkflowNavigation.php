<?php

namespace App\Support;

use App\Services\Modules\ModuleRegistry;
use Illuminate\Support\Collection;

final class WorkflowNavigation
{
    /**
     * Build the workflow-oriented sidebar while keeping permission and module checks centralized.
     *
     * @param  Collection<string, mixed>  $grantedPermissions
     * @return array<int, array<string, mixed>>
     */
    public static function groups(Collection $grantedPermissions, array $badges = []): array
    {
        $groups = [
            self::group('navigation.pilotage', 'ti-layout-dashboard', [
                self::routeItem('navigation.dashboard', 'ti-dashboard', 'dashboard', ['dashboard'], 'dashboard.view', 'core'),
                self::routeItem('workflow.my_tasks', 'ti-list-check', 'workflow.tasks', ['workflow.tasks'], 'dashboard.view', 'core', $badges['tasks'] ?? null),
                self::routeItem('workflow.alert_center', 'ti-bell-ringing', 'workflow.alerts', ['workflow.alerts'], 'dashboard.view', 'core', $badges['alerts'] ?? null),
                self::routeItem('help.title', 'ti-help-circle', 'help.glossary', ['help.glossary'], 'dashboard.view', 'core'),
            ]),
            self::group('navigation.sales_customers', 'ti-shopping-bag', [
                self::routeItem('sales.customers', 'ti-users', 'sales.customers.index', ['sales.customers.*'], 'sales.view', 'sales'),
                self::routeItem('sales.quotations', 'ti-file-invoice', 'sales.quotations.index', ['sales.quotations.*'], 'sales.view', 'sales'),
                self::routeItem('sales.sales_orders', 'ti-shopping-cart', 'sales.index', ['sales.index', 'sales.orders.*'], 'sales.view', 'sales'),
                self::routeItem('sales.deliveries', 'ti-truck-delivery', 'sales.deliveries.index', ['sales.deliveries.*', 'sales.returns.*'], 'sales.view', 'sales'),
                self::routeItem('sales.sales_price_lists', 'ti-tags', 'sales.price-lists.index', ['sales.price-lists.*'], 'sales.view', 'sales'),
            ]),
            self::group('navigation.procurement', 'ti-building-store', [
                self::routeItem('purchasing.requisitions', 'ti-file-description', 'purchasing.requisitions.index', ['purchasing.requisitions.*', 'purchasing.quotations.*'], 'purchasing.view', 'purchasing'),
                self::routeItem('purchasing.purchase_orders', 'ti-shopping-cart', 'purchasing.index', ['purchasing.index', 'purchasing.orders.*'], 'purchasing.view', 'purchasing'),
                self::routeItem('purchasing.goods_receipts', 'ti-package-import', 'purchasing.receipts.index', ['purchasing.receipts.*', 'purchasing.returns.*'], 'purchasing.view', 'purchasing'),
                self::routeItem('purchasing.suppliers', 'ti-building-factory-2', 'purchasing.suppliers.index', ['purchasing.suppliers.*'], 'purchasing.view', 'purchasing'),
                self::routeItem('purchasing.purchase_price_lists', 'ti-list-details', 'purchasing.price-lists.index', ['purchasing.price-lists.*'], 'purchasing.view', 'purchasing'),
            ]),
            self::group('navigation.stock_logistics', 'ti-packages', [
                self::routeItem('stock.stocks', 'ti-packages', 'stocks.index', ['stocks.*'], 'stocks.view', 'stocks'),
                self::routeItem('stock.inventories', 'ti-clipboard-check', 'inventories.index', ['inventories.*'], 'stocks.view', 'stocks'),
            ]),
            self::group('navigation.production', 'ti-settings-automation', [
                self::routeItem('planning.title', 'ti-calendar-stats', 'planning.index', ['planning.*'], 'planning.view', 'planning'),
                self::routeItem('production.production_orders', 'ti-settings-automation', 'production.index', ['production.*'], 'production.view', 'production'),
                self::routeItem('production.recipes', 'ti-book-2', 'recipes.index', ['recipes.*'], 'production.view', 'production'),
            ]),
            self::group('navigation.quality', 'ti-shield-check', [
                self::routeItem('quality.inspections', 'ti-clipboard-check', 'quality.index', ['quality.index', 'quality.inspections.*'], 'quality.view', 'quality'),
                self::routeItem('quality.non_conformities', 'ti-alert-triangle', 'quality.non-conformities.index', ['quality.non-conformities.*'], 'quality.view', 'quality'),
                self::routeItem('quality.control_plans', 'ti-shield-check', 'quality.plans', ['quality.plans', 'quality.plans.*', 'quality.haccp.*'], 'quality.view', 'quality'),
            ]),
            self::group('navigation.maintenance', 'ti-tool', [
                self::routeItem('maintenance.work_orders', 'ti-tool', 'maintenance.index', ['maintenance.*'], 'maintenance.view', 'maintenance'),
            ]),
            self::group('navigation.finance_controlling', 'ti-chart-histogram', [
                self::routeItem('billing.billing', 'ti-file-invoice', 'finance.billing.index', ['finance.billing.*'], 'finance.view', 'finance'),
                ...self::resourceItems(['financial-accounts']),
                self::routeItem('production.costing', 'ti-calculator', 'costing.index', ['costing.*'], 'finance.view', 'finance'),
                self::routeItem('finance.management_control', 'ti-chart-bar', 'finance.control.index', ['finance.control.*'], 'finance.view', 'finance'),
                self::routeItem('governance.title', 'ti-scale', 'finance.governance.index', ['finance.governance.*', 'finance.documents.*'], 'finance.view', 'finance'),
            ]),
            self::group('navigation.reports', 'ti-report-analytics', [
                self::routeItem('reports.reporting', 'ti-report-analytics', 'reports.index', ['reports.*'], 'reports.view', 'reports'),
            ]),
            self::group('navigation.productivity', 'ti-bolt', [
                self::routeItem('productivity.title', 'ti-bolt', 'productivity.index', ['productivity.*'], 'productivity.view', 'productivity'),
            ]),
            self::group('navigation.settings', 'ti-adjustments', [
                ...self::resourceItems([
                    'companies', 'sites', 'warehouses', 'warehouse-locations',
                    'units', 'item-categories', 'items',
                    'production-lines', 'machines', 'work-shifts',
                    'maintenance-plans', 'downtime-reasons',
                    'languages', 'currencies', 'tax-rates', 'system-settings', 'reference-values',
                ]),
            ]),
            self::group('navigation.administration', 'ti-lock-access', [
                self::routeItem('operations.title', 'ti-activity-heartbeat', 'admin.operations.index', ['admin.operations.*'], 'operations.view', 'operations'),
                self::routeItem('modules.module_management', 'ti-apps', 'admin.modules.index', ['admin.modules.*'], 'modules.view', 'administration'),
                ...self::resourceItems(['users', 'roles', 'permissions', 'audit-logs']),
            ]),
        ];

        $modules = app(ModuleRegistry::class);

        return collect($groups)
            ->map(function (array $group) use ($grantedPermissions, $modules): array {
                $group['items'] = collect($group['items'])
                    ->filter(fn (array $item): bool => $grantedPermissions->has($item['permission']))
                    ->filter(fn (array $item): bool => $modules->enabled($item['application_module']))
                    ->values()
                    ->all();
                $group['active'] = collect($group['items'])->contains(fn (array $item): bool => self::isActive($item));

                return $group;
            })
            ->filter(fn (array $group): bool => $group['items'] !== [])
            ->values()
            ->all();
    }

    private static function group(string $label, string $icon, array $items): array
    {
        return compact('label', 'icon', 'items');
    }

    private static function routeItem(string $label, string $icon, string $route, array $patterns, string $permission, string $applicationModule, ?int $badge = null): array
    {
        return [
            'type' => 'route',
            'label' => $label,
            'icon' => $icon,
            'route' => $route,
            'patterns' => $patterns,
            'permission' => $permission,
            'application_module' => $applicationModule,
            'badge' => $badge,
        ];
    }

    private static function resourceItems(array $resources): array
    {
        return collect($resources)->map(function (string $resource): array {
            $definition = MasterDataRegistry::get($resource);

            return [
                'type' => 'resource',
                'resource' => $resource,
                'label' => $definition['label'],
                'icon' => $definition['icon'],
                'route' => 'admin.master-data',
                'permission' => $definition['module'].'.view',
                'application_module' => MasterDataRegistry::applicationModule($resource, $definition),
            ];
        })->all();
    }

    public static function isActive(array $item): bool
    {
        if ($item['type'] === 'resource') {
            return request()->routeIs('admin.master-data') && request()->route('resource') === $item['resource'];
        }

        return request()->routeIs(...$item['patterns']);
    }
}
