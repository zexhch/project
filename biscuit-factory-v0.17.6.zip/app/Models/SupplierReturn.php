<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierReturn extends Model
{
    use UsesUuid;

    protected $fillable = [
        'supplier_id', 'goods_receipt_id', 'warehouse_id', 'source_location_id', 'return_number',
        'return_date', 'status', 'reason_code', 'notes', 'created_by', 'approved_by',
        'approved_at', 'stock_movement_id',
    ];

    protected function casts(): array
    {
        return ['return_date' => 'date', 'approved_at' => 'datetime'];
    }

    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function goodsReceipt() { return $this->belongsTo(GoodsReceipt::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function sourceLocation() { return $this->belongsTo(WarehouseLocation::class, 'source_location_id'); }
    public function lines() { return $this->hasMany(SupplierReturnLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
    public function stockMovement() { return $this->belongsTo(StockMovement::class); }
}
