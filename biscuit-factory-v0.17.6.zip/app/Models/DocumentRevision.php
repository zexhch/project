<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DocumentRevision extends Model
{
    use UsesUuid;

    public $timestamps = false;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['version' => 'integer', 'snapshot' => 'array', 'created_at' => 'datetime'];
    }

    protected static function booted(): void
    {
        static::updating(static fn () => throw new \LogicException('Document revisions are immutable.'));
        static::deleting(static fn () => throw new \LogicException('Document revisions are immutable.'));
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function user() { return $this->belongsTo(User::class); }
}
