<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DeliveryAllocation extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array { return ['quantity' => 'decimal:3', 'unit_cost' => 'decimal:6']; }
    public function deliveryNoteLine() { return $this->belongsTo(DeliveryNoteLine::class); }
    public function reservation() { return $this->belongsTo(StockReservation::class, 'stock_reservation_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function sourceLocation() { return $this->belongsTo(WarehouseLocation::class, 'source_location_id'); }
    public function stockMovementLine() { return $this->belongsTo(StockMovementLine::class); }
}
