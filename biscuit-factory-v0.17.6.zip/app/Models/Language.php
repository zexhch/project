<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    use UsesUuid;

    protected $fillable = ['code', 'name', 'native_name', 'direction', 'active', 'is_default'];

    protected function casts(): array
    {
        return [
            'active' => 'boolean',
            'is_default' => 'boolean',
        ];
    }
}
