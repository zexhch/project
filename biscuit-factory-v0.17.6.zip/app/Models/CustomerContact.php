<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CustomerContact extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array { return ['is_primary' => 'boolean', 'active' => 'boolean']; }
    public function customer() { return $this->belongsTo(Customer::class); }
}
