<?php
namespace App\Models; use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class ProductionConsumption extends Model { use UsesUuid; protected $guarded=[]; public function item(){return $this->belongsTo(Item::class);} public function lot(){return $this->belongsTo(Lot::class);} }
