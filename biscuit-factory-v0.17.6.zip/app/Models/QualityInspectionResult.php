<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityInspectionResult extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'value_numeric' => 'decimal:6',
            'value_boolean' => 'boolean',
            'deviation' => 'decimal:6',
            'measured_at' => 'datetime',
        ];
    }

    public function inspection() { return $this->belongsTo(QualityInspection::class, 'quality_inspection_id'); }
    public function parameter() { return $this->belongsTo(QualityControlPlanParameter::class, 'quality_control_plan_parameter_id'); }
    public function measuredBy() { return $this->belongsTo(User::class, 'measured_by'); }
}
