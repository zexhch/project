<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class BackupSchedule extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'include_files' => 'boolean',
            'active' => 'boolean',
            'next_run_at' => 'datetime',
            'last_run_at' => 'datetime',
        ];
    }

    public function notificationUser() { return $this->belongsTo(User::class, 'notification_user_id'); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function runs() { return $this->hasMany(BackupRun::class)->latest(); }
}
