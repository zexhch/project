<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class HaccpControlPoint extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['active' => 'boolean', 'frequency_value' => 'integer'];
    }

    public function processStep() { return $this->belongsTo(ProcessStep::class); }
    public function productionLine() { return $this->belongsTo(ProductionLine::class); }
    public function controlPlans() { return $this->hasMany(QualityControlPlan::class); }
}
