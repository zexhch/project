<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class QualityControlPlan extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'sample_size' => 'decimal:3',
            'frequency_value' => 'integer',
            'version' => 'integer',
            'valid_from' => 'date',
            'valid_to' => 'date',
            'approved_at' => 'datetime',
            'active' => 'boolean',
        ];
    }

    public function scopeApprovedAndActive(Builder $query): Builder
    {
        return $query->where('status', 'APPROVED')->where('active', true)
            ->where(fn (Builder $q) => $q->whereNull('valid_from')->orWhereDate('valid_from', '<=', today()))
            ->where(fn (Builder $q) => $q->whereNull('valid_to')->orWhereDate('valid_to', '>=', today()));
    }

    public function item() { return $this->belongsTo(Item::class); }
    public function itemCategory() { return $this->belongsTo(ItemCategory::class); }
    public function productionLine() { return $this->belongsTo(ProductionLine::class); }
    public function haccpControlPoint() { return $this->belongsTo(HaccpControlPoint::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
    public function parameters() { return $this->hasMany(QualityControlPlanParameter::class)->orderBy('sequence'); }
    public function inspections() { return $this->hasMany(QualityInspection::class); }
}
