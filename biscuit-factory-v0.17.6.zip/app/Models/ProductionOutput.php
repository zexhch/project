<?php
namespace App\Models; use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class ProductionOutput extends Model { use UsesUuid; protected $guarded=[]; public function lot(){return $this->belongsTo(Lot::class);} }
