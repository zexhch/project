<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class CapacityRequirement extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['requirement_date'=>'date','planned_quantity'=>'decimal:3','load_percent'=>'decimal:2','scheduled_start'=>'datetime','scheduled_end'=>'datetime','conflict_codes'=>'array']; } public function plan(){return $this->belongsTo(ProductionPlan::class,'production_plan_id');} public function demand(){return $this->belongsTo(ProductionPlanDemand::class,'production_plan_demand_id');} public function productionLine(){return $this->belongsTo(ProductionLine::class);} public function workShift(){return $this->belongsTo(WorkShift::class);} public function item(){return $this->belongsTo(Item::class);} public function productionOrder(){return $this->belongsTo(ProductionOrder::class);} public function conflicts(){return $this->hasMany(PlanningConflict::class);} }
