<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class MaintenancePlan extends Model { use UsesUuid; protected $guarded=[]; protected function casts():array{return ['next_due_at'=>'datetime','active'=>'boolean'];} public function machine(){return $this->belongsTo(Machine::class);} public function productionLine(){return $this->belongsTo(ProductionLine::class);} public function workOrders(){return $this->hasMany(MaintenanceWorkOrder::class);} }
