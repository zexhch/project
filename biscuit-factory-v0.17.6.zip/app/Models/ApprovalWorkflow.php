<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ApprovalWorkflow extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['minimum_amount' => 'decimal:4', 'active' => 'boolean'];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function levels() { return $this->hasMany(ApprovalWorkflowLevel::class)->orderBy('sequence'); }
    public function requests() { return $this->hasMany(ApprovalRequest::class); }
}
