<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Warehouse extends Model
{
    use UsesUuid;

    protected $fillable = ['site_id', 'code', 'name', 'warehouse_type', 'active'];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function locations()
    {
        return $this->hasMany(WarehouseLocation::class);
    }

    public function purchaseOrders() { return $this->hasMany(PurchaseOrder::class); }
    public function goodsReceipts() { return $this->hasMany(GoodsReceipt::class); }
}
