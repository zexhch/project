<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class RecipeVersion extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'reference_quantity' => 'decimal:3',
            'expected_yield_percent' => 'decimal:3',
            'valid_from' => 'date',
            'valid_to' => 'date',
            'approved_at' => 'datetime',
        ];
    }

    public function recipe() { return $this->belongsTo(Recipe::class); }
    public function referenceUnit() { return $this->belongsTo(Unit::class, 'reference_unit_id'); }
    public function lines() { return $this->hasMany(RecipeLine::class); }
    public function processTemplate() { return $this->belongsTo(ProcessTemplate::class); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
    public function costComponents() { return $this->hasMany(RecipeCostComponent::class); }
    public function costCalculations() { return $this->hasMany(CostCalculation::class); }
    public function productionOrders() { return $this->hasMany(ProductionOrder::class); }
}
