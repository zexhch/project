<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ReferenceValue extends Model
{
    use UsesUuid;

    protected $fillable = [
        'domain', 'code', 'labels', 'sort_order', 'metadata', 'system', 'active',
    ];

    protected function casts(): array
    {
        return [
            'labels' => 'array',
            'metadata' => 'array',
            'sort_order' => 'integer',
            'system' => 'boolean',
            'active' => 'boolean',
        ];
    }

    public function getLocalizedLabelAttribute(): string
    {
        return $this->labels[app()->getLocale()]
            ?? $this->labels['fr']
            ?? $this->code;
    }
}
