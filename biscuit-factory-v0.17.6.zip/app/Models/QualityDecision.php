<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityDecision extends Model
{
    use UsesUuid;

    public $timestamps = false;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['decided_at' => 'datetime', 'created_at' => 'datetime'];
    }

    public function inspection() { return $this->belongsTo(QualityInspection::class, 'quality_inspection_id'); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function decisionMaker() { return $this->belongsTo(User::class, 'decided_by'); }
}
