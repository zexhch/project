<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class WarehouseLocation extends Model
{
    use UsesUuid;

    protected $fillable = [
        'warehouse_id', 'code', 'name', 'location_type', 'quarantine', 'active',
    ];

    protected function casts(): array
    {
        return [
            'quarantine' => 'boolean',
            'active' => 'boolean',
        ];
    }

    public function warehouse()
    {
        return $this->belongsTo(Warehouse::class);
    }
}
