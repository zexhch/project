<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class PurchasePriceList extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'supplier_id', 'code', 'name', 'currency_code', 'tax_included',
        'priority', 'valid_from', 'valid_to', 'status', 'created_by', 'approved_by', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'tax_included' => 'boolean',
            'priority' => 'integer',
            'valid_from' => 'date',
            'valid_to' => 'date',
            'approved_at' => 'datetime',
        ];
    }

    public function scopeActiveOn(Builder $query, mixed $date): Builder
    {
        return $query->where('status', 'APPROVED')
            ->whereDate('valid_from', '<=', $date)
            ->where(fn (Builder $nested) => $nested->whereNull('valid_to')->orWhereDate('valid_to', '>=', $date));
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function lines() { return $this->hasMany(PurchasePriceListLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
}
