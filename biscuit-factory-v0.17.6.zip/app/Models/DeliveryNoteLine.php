<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DeliveryNoteLine extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return ['quantity' => 'decimal:3', 'base_quantity' => 'decimal:3', 'factor_to_base' => 'decimal:8'];
    }
    public function deliveryNote() { return $this->belongsTo(DeliveryNote::class); }
    public function salesOrderLine() { return $this->belongsTo(SalesOrderLine::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function allocations() { return $this->hasMany(DeliveryAllocation::class); }
    public function returnLines() { return $this->hasMany(CustomerReturnLine::class); }
}
