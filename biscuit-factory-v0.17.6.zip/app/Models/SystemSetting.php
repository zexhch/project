<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    use UsesUuid;

    protected $fillable = ['company_id', 'group', 'key', 'value', 'value_type', 'public'];

    protected function casts(): array
    {
        return ['public' => 'boolean'];
    }

    protected function value(): Attribute
    {
        return Attribute::make(
            get: fn (mixed $value): mixed => is_string($value) ? json_decode($value, true) : $value,
            set: fn (mixed $value): string => json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
        );
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
