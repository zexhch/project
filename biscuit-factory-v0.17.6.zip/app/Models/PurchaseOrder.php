<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'site_id', 'warehouse_id', 'supplier_id', 'purchase_requisition_id',
        'supplier_quotation_id', 'order_number', 'order_date', 'expected_date', 'currency_code',
        'exchange_rate', 'tax_included', 'status', 'payment_terms_days', 'incoterm', 'supplier_reference',
        'subtotal', 'discount_amount', 'tax_amount', 'total_amount', 'notes', 'cancellation_reason',
        'created_by', 'submitted_by', 'submitted_at', 'approved_by', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'order_date' => 'date',
            'expected_date' => 'date',
            'exchange_rate' => 'decimal:8',
            'tax_included' => 'boolean',
            'payment_terms_days' => 'integer',
            'subtotal' => 'decimal:4',
            'discount_amount' => 'decimal:4',
            'tax_amount' => 'decimal:4',
            'total_amount' => 'decimal:4',
            'submitted_at' => 'datetime',
            'approved_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function site() { return $this->belongsTo(Site::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function requisition() { return $this->belongsTo(PurchaseRequisition::class, 'purchase_requisition_id'); }
    public function quotation() { return $this->belongsTo(SupplierQuotation::class, 'supplier_quotation_id'); }
    public function lines() { return $this->hasMany(PurchaseOrderLine::class); }
    public function receipts() { return $this->hasMany(GoodsReceipt::class); }
    public function invoices() { return $this->hasMany(SupplierInvoice::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
}
