<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ProcessStep extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['parameters' => 'array', 'quality_gate' => 'boolean', 'active' => 'boolean'];
    }

    public function processTemplate() { return $this->belongsTo(ProcessTemplate::class); }
    public function defaultMachine() { return $this->belongsTo(Machine::class, 'default_machine_id'); }
    public function haccpControlPoints() { return $this->hasMany(HaccpControlPoint::class); }
}
