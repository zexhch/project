<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierEvaluation extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'supplier_id', 'evaluation_number', 'period_from', 'period_to',
        'quality_score', 'delivery_score', 'commercial_score', 'service_score', 'total_score',
        'status', 'comments', 'evaluated_by', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'period_from' => 'date',
            'period_to' => 'date',
            'quality_score' => 'decimal:2',
            'delivery_score' => 'decimal:2',
            'commercial_score' => 'decimal:2',
            'service_score' => 'decimal:2',
            'total_score' => 'decimal:2',
            'completed_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function evaluator() { return $this->belongsTo(User::class, 'evaluated_by'); }
}
