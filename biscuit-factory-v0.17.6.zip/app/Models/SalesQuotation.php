<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SalesQuotation extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'quotation_date' => 'date', 'valid_until' => 'date', 'requested_delivery_date' => 'date',
            'exchange_rate' => 'decimal:8', 'tax_included' => 'boolean', 'subtotal' => 'decimal:4',
            'discount_amount' => 'decimal:4', 'tax_amount' => 'decimal:4', 'total_amount' => 'decimal:4',
            'sent_at' => 'datetime', 'accepted_at' => 'datetime',
        ];
    }
    public function company() { return $this->belongsTo(Company::class); }
    public function site() { return $this->belongsTo(Site::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function lines() { return $this->hasMany(SalesQuotationLine::class); }
    public function salesOrder() { return $this->hasOne(SalesOrder::class); }
}
