<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierContact extends Model
{
    use UsesUuid;

    protected $fillable = ['supplier_id', 'name', 'job_title', 'email', 'phone', 'mobile', 'is_primary', 'active'];

    protected function casts(): array
    {
        return ['is_primary' => 'boolean', 'active' => 'boolean'];
    }

    public function supplier() { return $this->belongsTo(Supplier::class); }
}
