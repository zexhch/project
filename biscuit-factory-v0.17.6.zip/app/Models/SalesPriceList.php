<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Carbon\CarbonInterface;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class SalesPriceList extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'tax_included' => 'boolean', 'priority' => 'integer', 'valid_from' => 'date',
            'valid_to' => 'date', 'approved_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function lines() { return $this->hasMany(SalesPriceListLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }

    public function scopeActiveOn(Builder $query, CarbonInterface $date): Builder
    {
        return $query->where('status', 'APPROVED')
            ->whereDate('valid_from', '<=', $date)
            ->where(fn (Builder $validity) => $validity
                ->whereNull('valid_to')
                ->orWhereDate('valid_to', '>=', $date));
    }
}
