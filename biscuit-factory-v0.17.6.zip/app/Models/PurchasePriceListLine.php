<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class PurchasePriceListLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'purchase_price_list_id', 'supplier_item_id', 'item_id', 'unit_id',
        'minimum_quantity', 'unit_price', 'discount_percentage', 'tax_rate_id', 'lead_time_days',
    ];

    protected function casts(): array
    {
        return [
            'minimum_quantity' => 'decimal:3',
            'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4',
            'lead_time_days' => 'integer',
        ];
    }

    public function priceList() { return $this->belongsTo(PurchasePriceList::class, 'purchase_price_list_id'); }
    public function supplierItem() { return $this->belongsTo(SupplierItem::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
}
