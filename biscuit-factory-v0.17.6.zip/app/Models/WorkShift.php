<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class WorkShift extends Model
{
    use UsesUuid;

    protected $fillable = ['site_id', 'code', 'name', 'starts_at', 'ends_at', 'work_days', 'active'];

    protected function casts(): array
    {
        return [
            'work_days' => 'array',
            'active' => 'boolean',
        ];
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }
}
