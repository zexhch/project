<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityControlPlanParameter extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'minimum_value' => 'decimal:6',
            'maximum_value' => 'decimal:6',
            'target_value' => 'decimal:6',
            'options' => 'array',
            'required' => 'boolean',
            'critical' => 'boolean',
            'sequence' => 'integer',
        ];
    }

    public function plan() { return $this->belongsTo(QualityControlPlan::class, 'quality_control_plan_id'); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function results() { return $this->hasMany(QualityInspectionResult::class); }
}
