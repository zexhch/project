<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ProcessTemplate extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function finishedItem() { return $this->belongsTo(Item::class, 'finished_item_id'); }
    public function steps() { return $this->hasMany(ProcessStep::class)->orderBy('sequence_number'); }
}
