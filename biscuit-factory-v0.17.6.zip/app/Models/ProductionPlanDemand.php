<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class ProductionPlanDemand extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['demand_date'=>'date','gross_demand'=>'decimal:3','stock_on_hand'=>'decimal:3','reserved_stock'=>'decimal:3','planned_receipts'=>'decimal:3','safety_stock'=>'decimal:3','net_requirement'=>'decimal:3','metadata'=>'array']; } public function plan(){return $this->belongsTo(ProductionPlan::class,'production_plan_id');} public function item(){return $this->belongsTo(Item::class);} public function unit(){return $this->belongsTo(Unit::class);} public function capacities(){return $this->hasMany(CapacityRequirement::class);} }
