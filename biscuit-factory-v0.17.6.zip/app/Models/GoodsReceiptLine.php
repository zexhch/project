<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class GoodsReceiptLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'goods_receipt_id', 'purchase_order_line_id', 'item_id', 'lot_id', 'lot_number',
        'manufacturing_date', 'expiry_date', 'accepted_quantity', 'rejected_quantity',
        'unit_id', 'factor_to_base', 'base_quantity', 'unit_cost', 'base_unit_cost',
        'rejection_reason', 'stock_movement_line_id',
    ];

    protected function casts(): array
    {
        return [
            'manufacturing_date' => 'date',
            'expiry_date' => 'date',
            'accepted_quantity' => 'decimal:3',
            'rejected_quantity' => 'decimal:3',
            'factor_to_base' => 'decimal:8',
            'base_quantity' => 'decimal:3',
            'unit_cost' => 'decimal:6',
            'base_unit_cost' => 'decimal:6',
        ];
    }

    public function receipt() { return $this->belongsTo(GoodsReceipt::class, 'goods_receipt_id'); }
    public function purchaseOrderLine() { return $this->belongsTo(PurchaseOrderLine::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function stockMovementLine() { return $this->belongsTo(StockMovementLine::class); }
}
