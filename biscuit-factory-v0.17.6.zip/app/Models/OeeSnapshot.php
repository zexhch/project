<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class OeeSnapshot extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['period_start'=>'date','period_end'=>'date','availability_percent'=>'decimal:2','performance_percent'=>'decimal:2','quality_percent'=>'decimal:2','oee_percent'=>'decimal:2','calculated_at'=>'datetime']; } public function site(){return $this->belongsTo(Site::class);} public function productionLine(){return $this->belongsTo(ProductionLine::class);} }
