<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DocumentNumberSequence extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'fiscal_year' => 'integer',
            'period' => 'integer',
            'next_number' => 'integer',
            'padding' => 'integer',
            'active' => 'boolean',
            'last_issued_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
}
