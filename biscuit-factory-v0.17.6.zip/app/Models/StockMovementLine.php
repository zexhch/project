<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class StockMovementLine extends Model
{
    use UsesUuid;
    protected $fillable = ['stock_movement_id', 'reference', 'item_id', 'lot_id', 'source_location_id', 'destination_location_id', 'quantity', 'unit_id', 'unit_cost', 'notes'];
    protected function casts(): array { return ['quantity' => 'decimal:3', 'unit_cost' => 'decimal:4']; }
    public function movement() { return $this->belongsTo(StockMovement::class, 'stock_movement_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function sourceLocation() { return $this->belongsTo(WarehouseLocation::class, 'source_location_id'); }
    public function destinationLocation() { return $this->belongsTo(WarehouseLocation::class, 'destination_location_id'); }
}
