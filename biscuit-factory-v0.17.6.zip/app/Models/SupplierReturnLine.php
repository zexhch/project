<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierReturnLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'supplier_return_id', 'goods_receipt_line_id', 'item_id', 'lot_id', 'quantity',
        'unit_id', 'factor_to_base', 'base_quantity', 'unit_cost', 'reason',
    ];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3',
            'factor_to_base' => 'decimal:8',
            'base_quantity' => 'decimal:3',
            'unit_cost' => 'decimal:6',
        ];
    }

    public function supplierReturn() { return $this->belongsTo(SupplierReturn::class); }
    public function goodsReceiptLine() { return $this->belongsTo(GoodsReceiptLine::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
}
