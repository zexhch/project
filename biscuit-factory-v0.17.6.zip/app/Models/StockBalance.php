<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class StockBalance extends Model
{
    use UsesUuid;
    protected $fillable = ['item_id', 'lot_id', 'location_id', 'quantity', 'reserved_quantity', 'average_unit_cost'];
    protected function casts(): array { return ['quantity' => 'decimal:3', 'reserved_quantity' => 'decimal:3', 'average_unit_cost' => 'decimal:4']; }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function location() { return $this->belongsTo(WarehouseLocation::class); }
}
