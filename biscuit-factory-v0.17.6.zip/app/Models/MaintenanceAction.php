<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class MaintenanceAction extends Model { use UsesUuid; protected $guarded=[]; protected function casts():array{return ['performed_at'=>'datetime'];} public function performer(){return $this->belongsTo(User::class,'performed_by');} }
