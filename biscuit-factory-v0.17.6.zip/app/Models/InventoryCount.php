<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class InventoryCount extends Model
{
    use UsesUuid;
    protected $fillable = ['inventory_number', 'warehouse_id', 'status', 'count_date', 'blind_count', 'notes', 'created_by', 'frozen_at', 'posted_at', 'posted_by'];
    protected function casts(): array { return ['count_date' => 'date', 'blind_count' => 'boolean', 'frozen_at' => 'datetime', 'posted_at' => 'datetime']; }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function lines() { return $this->hasMany(InventoryCountLine::class); }
}
