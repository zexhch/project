<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class PlanningConflict extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['conflict_date'=>'date','context'=>'array','resolved_at'=>'datetime']; } public function plan(){return $this->belongsTo(ProductionPlan::class,'production_plan_id');} public function capacity(){return $this->belongsTo(CapacityRequirement::class,'capacity_requirement_id');} }
