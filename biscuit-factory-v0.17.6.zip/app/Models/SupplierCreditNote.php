<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class SupplierCreditNote extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['credit_note_date'=>'date','total_amount'=>'decimal:4','applied_amount'=>'decimal:4','approved_at'=>'datetime']; } public function invoice(){return $this->belongsTo(SupplierInvoice::class,'supplier_invoice_id');} public function supplier(){return $this->belongsTo(Supplier::class);} public function creator(){return $this->belongsTo(User::class,'created_by');} public function approver(){return $this->belongsTo(User::class,'approved_by');} }
