<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class ProductionDowntime extends Model { use UsesUuid; protected $guarded=[]; protected function casts():array{return ['started_at'=>'datetime','ended_at'=>'datetime','planned'=>'boolean','duration_seconds'=>'integer'];} public function reason(){return $this->belongsTo(DowntimeReason::class,'downtime_reason_id');} public function machine(){return $this->belongsTo(Machine::class);} public function productionLine(){return $this->belongsTo(ProductionLine::class);} public function workOrder(){return $this->belongsTo(MaintenanceWorkOrder::class,'maintenance_work_order_id');} }
