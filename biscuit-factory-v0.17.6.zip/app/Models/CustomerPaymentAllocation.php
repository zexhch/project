<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class CustomerPaymentAllocation extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['amount'=>'decimal:4']; } public function payment(){return $this->belongsTo(CustomerPayment::class,'customer_payment_id');} public function invoice(){return $this->belongsTo(CustomerInvoice::class,'customer_invoice_id');} }
