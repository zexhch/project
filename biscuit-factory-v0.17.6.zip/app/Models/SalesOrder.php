<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SalesOrder extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'order_date' => 'date', 'requested_delivery_date' => 'date', 'exchange_rate' => 'decimal:8',
            'tax_included' => 'boolean', 'subtotal' => 'decimal:4', 'discount_amount' => 'decimal:4',
            'tax_amount' => 'decimal:4', 'total_amount' => 'decimal:4', 'submitted_at' => 'datetime',
            'confirmed_at' => 'datetime',
        ];
    }
    public function company() { return $this->belongsTo(Company::class); }
    public function site() { return $this->belongsTo(Site::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function quotation() { return $this->belongsTo(SalesQuotation::class, 'sales_quotation_id'); }
    public function lines() { return $this->hasMany(SalesOrderLine::class); }
    public function reservations() { return $this->hasMany(StockReservation::class); }
    public function deliveries() { return $this->hasMany(DeliveryNote::class); }
    public function invoices() { return $this->hasMany(CustomerInvoice::class); }
}
