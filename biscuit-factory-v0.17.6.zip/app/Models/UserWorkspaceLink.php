<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class UserWorkspaceLink extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['route_parameters' => 'array'];
    }

    public function user() { return $this->belongsTo(User::class); }
}
