<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CostCalculation extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'reference_quantity' => 'decimal:6',
            'yield_percent' => 'decimal:3',
            'material_cost' => 'decimal:6',
            'packaging_cost' => 'decimal:6',
            'labor_cost' => 'decimal:6',
            'machine_cost' => 'decimal:6',
            'energy_cost' => 'decimal:6',
            'subcontracting_cost' => 'decimal:6',
            'overhead_cost' => 'decimal:6',
            'other_cost' => 'decimal:6',
            'total_cost' => 'decimal:6',
            'unit_cost' => 'decimal:6',
            'details' => 'array',
            'calculated_at' => 'datetime',
        ];
    }

    public function recipeVersion() { return $this->belongsTo(RecipeVersion::class); }
    public function productionOrder() { return $this->belongsTo(ProductionOrder::class); }
    public function calculator() { return $this->belongsTo(User::class, 'calculated_by'); }
}
