<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierQuotationLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'supplier_quotation_id', 'purchase_requisition_line_id', 'item_id', 'description',
        'quantity', 'unit_id', 'unit_price', 'discount_percentage', 'tax_rate_id',
        'line_subtotal', 'tax_amount', 'line_total',
    ];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3',
            'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4',
            'line_subtotal' => 'decimal:4',
            'tax_amount' => 'decimal:4',
            'line_total' => 'decimal:4',
        ];
    }

    public function quotation() { return $this->belongsTo(SupplierQuotation::class, 'supplier_quotation_id'); }
    public function requisitionLine() { return $this->belongsTo(PurchaseRequisitionLine::class, 'purchase_requisition_line_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
}
