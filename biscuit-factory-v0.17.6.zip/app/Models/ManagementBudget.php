<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ManagementBudget extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'budget_amount' => 'decimal:4',
            'actual_amount' => 'decimal:4',
            'variance_amount' => 'decimal:4',
            'variance_percentage' => 'decimal:4',
            'approved_at' => 'datetime',
            'refreshed_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function costCenter() { return $this->belongsTo(CostCenter::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
}
