<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CostCenterRate extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'hourly_rate' => 'decimal:6',
            'valid_from' => 'date',
            'valid_to' => 'date',
            'active' => 'boolean',
        ];
    }

    public function costCenter() { return $this->belongsTo(CostCenter::class); }
    public function currency() { return $this->belongsTo(Currency::class, 'currency_code', 'code'); }
}
