<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class AccountingPeriod extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'fiscal_year' => 'integer',
            'period' => 'integer',
            'starts_on' => 'date',
            'ends_on' => 'date',
            'closing_snapshot' => 'array',
            'closed_at' => 'datetime',
            'reopened_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function closer() { return $this->belongsTo(User::class, 'closed_by'); }
    public function reopener() { return $this->belongsTo(User::class, 'reopened_by'); }
}
