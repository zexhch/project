<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SalesPriceListLine extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'factor_to_base' => 'decimal:8', 'minimum_quantity' => 'decimal:3', 'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4', 'target_margin_percentage' => 'decimal:4',
        ];
    }
    public function priceList() { return $this->belongsTo(SalesPriceList::class, 'sales_price_list_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
}
