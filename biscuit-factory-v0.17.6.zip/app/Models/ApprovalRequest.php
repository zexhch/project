<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ApprovalRequest extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:4',
            'current_level' => 'integer',
            'submitted_at' => 'datetime',
            'completed_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function workflow() { return $this->belongsTo(ApprovalWorkflow::class, 'approval_workflow_id'); }
    public function approvable() { return $this->morphTo(); }
    public function steps() { return $this->hasMany(ApprovalRequestStep::class)->orderBy('sequence'); }
    public function submitter() { return $this->belongsTo(User::class, 'submitted_by'); }
}
