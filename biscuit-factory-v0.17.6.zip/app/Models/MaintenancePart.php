<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class MaintenancePart extends Model { use UsesUuid; protected $guarded=[]; public function item(){return $this->belongsTo(Item::class);} }
