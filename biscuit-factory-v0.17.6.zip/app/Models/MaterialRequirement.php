<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class MaterialRequirement extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['requirement_date'=>'date','gross_requirement'=>'decimal:3','stock_on_hand'=>'decimal:3','planned_receipts'=>'decimal:3','shortage_quantity'=>'decimal:3','metadata'=>'array']; } public function plan(){return $this->belongsTo(ProductionPlan::class,'production_plan_id');} public function finishedItem(){return $this->belongsTo(Item::class,'finished_item_id');} public function ingredient(){return $this->belongsTo(Item::class,'ingredient_item_id');} public function unit(){return $this->belongsTo(Unit::class);} public function recipeVersion(){return $this->belongsTo(RecipeVersion::class);} }
