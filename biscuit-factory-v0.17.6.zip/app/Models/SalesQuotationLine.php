<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SalesQuotationLine extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3', 'factor_to_base' => 'decimal:8', 'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4', 'net_unit_price' => 'decimal:6',
            'line_subtotal' => 'decimal:4', 'tax_amount' => 'decimal:4', 'line_total' => 'decimal:4',
        ];
    }
    public function quotation() { return $this->belongsTo(SalesQuotation::class, 'sales_quotation_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
}
