<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class StockMovement extends Model
{
    use UsesUuid;
    protected $fillable = ['movement_number', 'movement_type', 'movement_at', 'source_type', 'source_id', 'status', 'notes', 'created_by', 'posted_at', 'posted_by'];
    protected function casts(): array { return ['movement_at' => 'datetime', 'posted_at' => 'datetime']; }
    public function lines() { return $this->hasMany(StockMovementLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
}
