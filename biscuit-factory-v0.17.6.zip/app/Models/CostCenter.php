<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CostCenter extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function site() { return $this->belongsTo(Site::class); }
    public function responsibleUser() { return $this->belongsTo(User::class, 'responsible_user_id'); }
    public function rates() { return $this->hasMany(CostCenterRate::class); }
    public function budgets() { return $this->hasMany(ManagementBudget::class); }
    public function productionLines() { return $this->hasMany(ProductionLine::class); }
    public function machines() { return $this->hasMany(Machine::class); }
}
