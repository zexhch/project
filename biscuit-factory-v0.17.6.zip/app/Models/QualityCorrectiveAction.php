<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityCorrectiveAction extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'due_date' => 'date',
            'completed_at' => 'datetime',
            'verified_at' => 'datetime',
        ];
    }

    public function nonConformity() { return $this->belongsTo(QualityNonConformity::class, 'quality_non_conformity_id'); }
    public function owner() { return $this->belongsTo(User::class, 'owner_id'); }
    public function completedBy() { return $this->belongsTo(User::class, 'completed_by'); }
    public function verifiedBy() { return $this->belongsTo(User::class, 'verified_by'); }
}
