<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DocumentTemplate extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'show_company_details' => 'boolean',
            'show_logo' => 'boolean',
            'show_legal_identifiers' => 'boolean',
            'show_bank_details' => 'boolean',
            'show_line_numbers' => 'boolean',
            'show_tax_rate' => 'boolean',
            'show_amount_in_words' => 'boolean',
            'show_internal_references' => 'boolean',
            'show_status' => 'boolean',
            'show_amounts' => 'boolean',
            'show_signature_blocks' => 'boolean',
            'is_default' => 'boolean',
            'active' => 'boolean',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
}
