<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    use UsesUuid;

    protected $fillable = ['code', 'name', 'symbol', 'dimension', 'decimal_places', 'active'];

    protected function casts(): array
    {
        return [
            'decimal_places' => 'integer',
            'active' => 'boolean',
        ];
    }
}
