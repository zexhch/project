<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class SupplierPayment extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['payment_date'=>'date','amount'=>'decimal:4','allocated_amount'=>'decimal:4','unallocated_amount'=>'decimal:4','posted_at'=>'datetime','reversed_at'=>'datetime']; } public function company(){return $this->belongsTo(Company::class);} public function supplier(){return $this->belongsTo(Supplier::class);} public function financialAccount(){return $this->belongsTo(FinancialAccount::class);} public function allocations(){return $this->hasMany(SupplierPaymentAllocation::class);} public function creator(){return $this->belongsTo(User::class,'created_by');} public function poster(){return $this->belongsTo(User::class,'posted_by');} public function reverser(){return $this->belongsTo(User::class,'reversed_by');} }
