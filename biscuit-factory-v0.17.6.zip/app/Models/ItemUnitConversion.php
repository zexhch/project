<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ItemUnitConversion extends Model
{
    use UsesUuid;

    protected $fillable = [
        'item_id', 'unit_id', 'parent_unit_id', 'factor_to_parent', 'factor_to_base', 'barcode',
        'net_weight_kg', 'gross_weight_kg', 'tare_weight_kg', 'length_cm', 'width_cm', 'height_cm',
        'volume_m3', 'purchasing_unit', 'sales_unit', 'production_unit', 'inventory_unit',
        'fractional_allowed', 'rounding_mode', 'valid_from', 'valid_to', 'active', 'image_path',
    ];

    protected function casts(): array
    {
        return [
            'factor_to_parent' => 'decimal:8',
            'factor_to_base' => 'decimal:8',
            'net_weight_kg' => 'decimal:6',
            'gross_weight_kg' => 'decimal:6',
            'tare_weight_kg' => 'decimal:6',
            'length_cm' => 'decimal:3',
            'width_cm' => 'decimal:3',
            'height_cm' => 'decimal:3',
            'volume_m3' => 'decimal:9',
            'purchasing_unit' => 'boolean',
            'sales_unit' => 'boolean',
            'production_unit' => 'boolean',
            'inventory_unit' => 'boolean',
            'fractional_allowed' => 'boolean',
            'valid_from' => 'date',
            'valid_to' => 'date',
            'active' => 'boolean',
        ];
    }

    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function parentUnit() { return $this->belongsTo(Unit::class, 'parent_unit_id'); }
}
