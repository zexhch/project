<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class PlanningScenario extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['parameters'=>'array','metrics'=>'array','is_baseline'=>'boolean','calculated_at'=>'datetime']; } public function plan(){return $this->belongsTo(ProductionPlan::class,'production_plan_id');} }
