<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class BulkOperationRun extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['errors' => 'array'];
    }

    public function user() { return $this->belongsTo(User::class); }
}
