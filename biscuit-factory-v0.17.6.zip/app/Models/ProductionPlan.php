<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class ProductionPlan extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['horizon_start'=>'date','horizon_end'=>'date','parameters'=>'array','metrics'=>'array','calculated_at'=>'datetime','approved_at'=>'datetime']; } public function company(){return $this->belongsTo(Company::class);} public function site(){return $this->belongsTo(Site::class);} public function demands(){return $this->hasMany(ProductionPlanDemand::class);} public function materials(){return $this->hasMany(MaterialRequirement::class);} public function capacities(){return $this->hasMany(CapacityRequirement::class);} public function conflicts(){return $this->hasMany(PlanningConflict::class);} public function scenarios(){return $this->hasMany(PlanningScenario::class);} public function productionOrders(){return $this->hasMany(ProductionOrder::class);} }
