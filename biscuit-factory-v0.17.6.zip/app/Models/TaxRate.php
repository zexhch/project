<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class TaxRate extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'code', 'name', 'rate', 'valid_from', 'valid_to',
        'active', 'is_default',
    ];

    protected function casts(): array
    {
        return [
            'rate' => 'decimal:4',
            'valid_from' => 'immutable_date',
            'valid_to' => 'immutable_date',
            'active' => 'boolean',
            'is_default' => 'boolean',
        ];
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
