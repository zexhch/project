<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class RecipeCostComponent extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:6',
            'unit_cost' => 'decimal:6',
            'percentage' => 'decimal:3',
        ];
    }

    public function recipeVersion() { return $this->belongsTo(RecipeVersion::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
}
