<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    use UsesUuid;

    protected $fillable = ['code', 'name', 'finished_item_id', 'description', 'active'];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }
    public function finishedItem(){return $this->belongsTo(Item::class,'finished_item_id');}
    public function versions(){return $this->hasMany(RecipeVersion::class);}
    public function latestVersion(){return $this->hasOne(RecipeVersion::class)->ofMany('version_number', 'max');}
    public function approvedVersion(){return $this->hasOne(RecipeVersion::class)->ofMany(['version_number' => 'max'], fn ($query) => $query->where('status', 'APPROVED'));}
}
