<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class PurchaseRequisitionLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'purchase_requisition_id', 'item_id', 'description', 'quantity', 'quantity_ordered',
        'unit_id', 'suggested_supplier_id', 'estimated_unit_price', 'currency_code', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3',
            'quantity_ordered' => 'decimal:3',
            'estimated_unit_price' => 'decimal:6',
        ];
    }

    public function requisition() { return $this->belongsTo(PurchaseRequisition::class, 'purchase_requisition_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function suggestedSupplier() { return $this->belongsTo(Supplier::class, 'suggested_supplier_id'); }
}
