<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityInspection extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'sample_size' => 'decimal:3',
            'inspected_at' => 'datetime',
            'decided_at' => 'datetime',
        ];
    }

    public function plan() { return $this->belongsTo(QualityControlPlan::class, 'quality_control_plan_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function productionOrder() { return $this->belongsTo(ProductionOrder::class); }
    public function stockMovement() { return $this->belongsTo(StockMovement::class); }
    public function productionLine() { return $this->belongsTo(ProductionLine::class); }
    public function inspector() { return $this->belongsTo(User::class, 'inspector_id'); }
    public function decisionMaker() { return $this->belongsTo(User::class, 'decided_by'); }
    public function results() { return $this->hasMany(QualityInspectionResult::class); }
    public function decisions() { return $this->hasMany(QualityDecision::class); }
    public function nonConformities() { return $this->hasMany(QualityNonConformity::class); }
    public function attachments() { return $this->hasMany(QualityAttachment::class); }
}
