<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DocumentCancellation extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['cancelled_at' => 'datetime'];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function canceller() { return $this->belongsTo(User::class, 'cancelled_by'); }
}
