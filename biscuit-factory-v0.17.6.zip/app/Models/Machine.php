<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Machine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'site_id', 'code', 'name', 'machine_type', 'manufacturer',
        'model', 'serial_number', 'commissioned_at', 'cost_center_id', 'status', 'active',
    ];

    protected function casts(): array
    {
        return [
            'commissioned_at' => 'immutable_date',
            'active' => 'boolean',
        ];
    }

    public function costCenter()
    {
        return $this->belongsTo(CostCenter::class);
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }
}
