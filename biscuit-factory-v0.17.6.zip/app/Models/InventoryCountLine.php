<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class InventoryCountLine extends Model
{
    use UsesUuid;
    protected $fillable = ['inventory_count_id', 'item_id', 'lot_id', 'location_id', 'expected_quantity', 'counted_quantity', 'variance_quantity', 'notes'];
    protected function casts(): array { return ['expected_quantity' => 'decimal:3', 'counted_quantity' => 'decimal:3', 'variance_quantity' => 'decimal:3']; }
    public function inventory() { return $this->belongsTo(InventoryCount::class, 'inventory_count_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function location() { return $this->belongsTo(WarehouseLocation::class); }
}
