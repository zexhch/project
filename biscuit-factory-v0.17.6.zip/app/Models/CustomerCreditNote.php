<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class CustomerCreditNote extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['credit_note_date'=>'date','total_amount'=>'decimal:4','applied_amount'=>'decimal:4','issued_at'=>'datetime']; } public function invoice(){return $this->belongsTo(CustomerInvoice::class,'customer_invoice_id');} public function customer(){return $this->belongsTo(Customer::class);} public function creator(){return $this->belongsTo(User::class,'created_by');} public function issuer(){return $this->belongsTo(User::class,'issued_by');} }
