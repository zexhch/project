<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CustomerReturn extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array { return ['return_date' => 'date', 'posted_at' => 'datetime']; }
    public function deliveryNote() { return $this->belongsTo(DeliveryNote::class); }
    public function salesOrder() { return $this->belongsTo(SalesOrder::class); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function destinationLocation() { return $this->belongsTo(WarehouseLocation::class, 'destination_location_id'); }
    public function lines() { return $this->hasMany(CustomerReturnLine::class); }
    public function stockMovement() { return $this->belongsTo(StockMovement::class); }
}
