<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Site extends Model
{
    use UsesUuid;

    protected $fillable = ['company_id', 'code', 'name', 'site_type', 'address', 'active'];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function warehouses()
    {
        return $this->hasMany(Warehouse::class);
    }

    public function productionLines()
    {
        return $this->hasMany(ProductionLine::class);
    }

    public function machines()
    {
        return $this->hasMany(Machine::class);
    }
}
