<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Lot extends Model
{
    use UsesUuid;
    protected $fillable = ['item_id', 'lot_number', 'manufacturing_date', 'expiry_date', 'status', 'attributes'];
    protected function casts(): array { return ['manufacturing_date' => 'date', 'expiry_date' => 'date', 'attributes' => 'array']; }
    public function item() { return $this->belongsTo(Item::class); }
    public function balances() { return $this->hasMany(StockBalance::class); }
    public function qualityInspections() { return $this->hasMany(QualityInspection::class); }
    public function qualityDecisions() { return $this->hasMany(QualityDecision::class); }
    public function nonConformities() { return $this->hasMany(QualityNonConformity::class); }
    public function goodsReceiptLines() { return $this->hasMany(GoodsReceiptLine::class); }
    public function supplierReturnLines() { return $this->hasMany(SupplierReturnLine::class); }
}
