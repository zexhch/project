<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityNonConformity extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'detected_at' => 'datetime',
            'due_date' => 'date',
            'closed_at' => 'datetime',
        ];
    }

    public function inspection() { return $this->belongsTo(QualityInspection::class, 'quality_inspection_id'); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function productionOrder() { return $this->belongsTo(ProductionOrder::class); }
    public function detector() { return $this->belongsTo(User::class, 'detected_by'); }
    public function owner() { return $this->belongsTo(User::class, 'owner_id'); }
    public function closedBy() { return $this->belongsTo(User::class, 'closed_by'); }
    public function actions() { return $this->hasMany(QualityCorrectiveAction::class); }
    public function attachments() { return $this->hasMany(QualityAttachment::class); }
}
