<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrderLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'purchase_order_id', 'purchase_requisition_line_id', 'item_id', 'description',
        'ordered_quantity', 'received_quantity', 'returned_quantity', 'unit_id', 'factor_to_base',
        'unit_price', 'discount_percentage', 'tax_rate_id', 'net_unit_price', 'line_subtotal',
        'tax_amount', 'line_total', 'expected_date', 'status', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'ordered_quantity' => 'decimal:3',
            'received_quantity' => 'decimal:3',
            'returned_quantity' => 'decimal:3',
            'factor_to_base' => 'decimal:8',
            'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4',
            'net_unit_price' => 'decimal:6',
            'line_subtotal' => 'decimal:4',
            'tax_amount' => 'decimal:4',
            'line_total' => 'decimal:4',
            'expected_date' => 'date',
        ];
    }

    public function purchaseOrder() { return $this->belongsTo(PurchaseOrder::class); }
    public function requisitionLine() { return $this->belongsTo(PurchaseRequisitionLine::class, 'purchase_requisition_line_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
    public function receiptLines() { return $this->hasMany(GoodsReceiptLine::class); }
}
