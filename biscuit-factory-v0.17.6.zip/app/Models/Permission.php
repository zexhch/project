<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    use UsesUuid;

    protected $fillable = ['code', 'module', 'name', 'description', 'system'];

    protected function casts(): array
    {
        return ['system' => 'boolean'];
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class)->withTimestamps();
    }
}
