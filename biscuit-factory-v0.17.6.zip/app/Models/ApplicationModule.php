<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ApplicationModule extends Model
{
    use UsesUuid;

    protected $fillable = [
        'code', 'name_key', 'description_key', 'version', 'icon', 'core', 'enabled',
        'sort_order', 'manifest_hash', 'installed_at', 'enabled_at', 'disabled_at', 'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'core' => 'boolean',
            'enabled' => 'boolean',
            'installed_at' => 'immutable_datetime',
            'enabled_at' => 'immutable_datetime',
            'disabled_at' => 'immutable_datetime',
        ];
    }

    public function dependencies()
    {
        return $this->belongsToMany(
            self::class,
            'application_module_dependencies',
            'module_id',
            'dependency_id'
        )->withTimestamps();
    }

    public function dependents()
    {
        return $this->belongsToMany(
            self::class,
            'application_module_dependencies',
            'dependency_id',
            'module_id'
        )->withTimestamps();
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
