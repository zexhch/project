<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Collection;

class User extends Authenticatable
{
    use HasFactory, Notifiable, UsesUuid;

    private ?Collection $resolvedPermissions = null;

    private ?Collection $resolvedRoles = null;

    protected $fillable = [
        'name',
        'email',
        'password',
        'locale',
        'active',
        'force_password_change',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'immutable_datetime',
            'password' => 'hashed',
            'active' => 'boolean',
            'failed_login_attempts' => 'integer',
            'locked_until' => 'immutable_datetime',
            'password_changed_at' => 'immutable_datetime',
            'force_password_change' => 'boolean',
            'last_login_at' => 'immutable_datetime',
        ];
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class)->withTimestamps();
    }

    public function workspaceLinks()
    {
        return $this->hasMany(UserWorkspaceLink::class);
    }

    public function hasRole(string $roleCode): bool
    {
        $this->resolvedRoles ??= $this->roles()->get(['roles.id', 'roles.code']);

        return $this->resolvedRoles->contains('code', $roleCode);
    }

    public function permissions(): Collection
    {
        if ($this->resolvedPermissions !== null) {
            return $this->resolvedPermissions;
        }

        return $this->resolvedPermissions = $this->roles()
            ->with('permissions:id,code')
            ->get()
            ->flatMap->permissions
            ->unique('id')
            ->values();
    }

    public function hasPermission(string $permissionCode): bool
    {
        return $this->permissions()->contains('code', $permissionCode);
    }
}
