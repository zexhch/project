<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierItem extends Model
{
    use UsesUuid;

    protected $fillable = [
        'supplier_id', 'item_id', 'purchasing_unit_id', 'supplier_reference',
        'factor_to_base', 'minimum_order_quantity', 'pack_quantity', 'lead_time_days',
        'preferred', 'active',
    ];

    protected function casts(): array
    {
        return [
            'factor_to_base' => 'decimal:8',
            'minimum_order_quantity' => 'decimal:3',
            'pack_quantity' => 'decimal:3',
            'lead_time_days' => 'integer',
            'preferred' => 'boolean',
            'active' => 'boolean',
        ];
    }

    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function purchasingUnit() { return $this->belongsTo(Unit::class, 'purchasing_unit_id'); }
}
