<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class WorkflowTaskPreference extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['snoozed_until' => 'immutable_datetime'];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
