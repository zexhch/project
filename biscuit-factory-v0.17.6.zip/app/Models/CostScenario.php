<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CostScenario extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'valid_from' => 'date',
            'planned_revenue' => 'decimal:4',
            'planned_cost' => 'decimal:4',
            'planned_margin' => 'decimal:4',
            'planned_margin_percentage' => 'decimal:4',
            'calculated_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function lines() { return $this->hasMany(CostScenarioLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function calculator() { return $this->belongsTo(User::class, 'calculated_by'); }
}
