<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class StockReservation extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3', 'allocated_quantity' => 'decimal:3',
            'consumed_quantity' => 'decimal:3', 'released_at' => 'datetime',
        ];
    }
    public function salesOrder() { return $this->belongsTo(SalesOrder::class); }
    public function salesOrderLine() { return $this->belongsTo(SalesOrderLine::class); }
    public function stockBalance() { return $this->belongsTo(StockBalance::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function location() { return $this->belongsTo(WarehouseLocation::class); }
    public function deliveryAllocations() { return $this->hasMany(DeliveryAllocation::class); }
}
