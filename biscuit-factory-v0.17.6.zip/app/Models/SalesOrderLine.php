<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SalesOrderLine extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'ordered_quantity' => 'decimal:3', 'reserved_quantity' => 'decimal:3',
            'delivered_quantity' => 'decimal:3', 'returned_quantity' => 'decimal:3',
            'factor_to_base' => 'decimal:8', 'unit_price' => 'decimal:6',
            'discount_percentage' => 'decimal:4', 'net_unit_price' => 'decimal:6',
            'line_subtotal' => 'decimal:4', 'tax_amount' => 'decimal:4', 'line_total' => 'decimal:4',
        ];
    }
    public function salesOrder() { return $this->belongsTo(SalesOrder::class); }
    public function quotationLine() { return $this->belongsTo(SalesQuotationLine::class, 'sales_quotation_line_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
    public function taxRate() { return $this->belongsTo(TaxRate::class); }
    public function reservations() { return $this->hasMany(StockReservation::class); }
    public function deliveryLines() { return $this->hasMany(DeliveryNoteLine::class); }
}
