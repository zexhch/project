<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ApprovalWorkflowLevel extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'sequence' => 'integer',
            'minimum_approvals' => 'integer',
            'amount_from' => 'decimal:4',
            'amount_to' => 'decimal:4',
        ];
    }

    public function workflow() { return $this->belongsTo(ApprovalWorkflow::class, 'approval_workflow_id'); }
}
