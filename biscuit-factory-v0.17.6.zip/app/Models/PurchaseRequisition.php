<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class PurchaseRequisition extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'site_id', 'requisition_number', 'request_date', 'required_date',
        'priority', 'status', 'notes', 'rejection_reason', 'requested_by', 'submitted_by',
        'submitted_at', 'approved_by', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'request_date' => 'date',
            'required_date' => 'date',
            'submitted_at' => 'datetime',
            'approved_at' => 'datetime',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function site() { return $this->belongsTo(Site::class); }
    public function lines() { return $this->hasMany(PurchaseRequisitionLine::class); }
    public function requester() { return $this->belongsTo(User::class, 'requested_by'); }
    public function approver() { return $this->belongsTo(User::class, 'approved_by'); }
    public function quotations() { return $this->hasMany(SupplierQuotation::class); }
    public function purchaseOrders() { return $this->hasMany(PurchaseOrder::class); }
}
