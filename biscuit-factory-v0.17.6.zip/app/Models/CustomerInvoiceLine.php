<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class CustomerInvoiceLine extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['quantity'=>'decimal:3','unit_price'=>'decimal:6','discount_percentage'=>'decimal:4','line_subtotal'=>'decimal:4','tax_amount'=>'decimal:4','line_total'=>'decimal:4']; } public function invoice(){return $this->belongsTo(CustomerInvoice::class,'customer_invoice_id');} public function deliveryNoteLine(){return $this->belongsTo(DeliveryNoteLine::class);} public function salesOrderLine(){return $this->belongsTo(SalesOrderLine::class);} public function item(){return $this->belongsTo(Item::class);} public function unit(){return $this->belongsTo(Unit::class);} public function taxRate(){return $this->belongsTo(TaxRate::class);} }
