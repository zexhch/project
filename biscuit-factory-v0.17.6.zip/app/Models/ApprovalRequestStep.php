<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ApprovalRequestStep extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'sequence' => 'integer',
            'required_approvals' => 'integer',
            'approved_count' => 'integer',
            'decisions' => 'array',
            'completed_at' => 'datetime',
        ];
    }

    public function request() { return $this->belongsTo(ApprovalRequest::class, 'approval_request_id'); }
    public function level() { return $this->belongsTo(ApprovalWorkflowLevel::class, 'approval_workflow_level_id'); }
}
