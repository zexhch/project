<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ItemCategory extends Model
{
    use UsesUuid;

    protected $fillable = ['parent_id', 'code', 'name', 'category_type', 'active'];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id');
    }
}
