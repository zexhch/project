<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use UsesUuid;

    protected $fillable = [
        'code', 'name', 'legal_name', 'business_activity',
        'trade_register_number', 'tax_identification_number',
        'statistical_identification_number', 'article_of_imposition_number',
        'country_code', 'currency_code', 'timezone', 'phone', 'email', 'address',
        'bank_name', 'bank_branch', 'bank_account_number', 'logo_path', 'active',
    ];

    protected function casts(): array
    {
        return ['active' => 'boolean'];
    }

    public function sites()
    {
        return $this->hasMany(Site::class);
    }

    public function taxRates()
    {
        return $this->hasMany(TaxRate::class);
    }

    public function suppliers() { return $this->hasMany(Supplier::class); }
    public function purchaseRequisitions() { return $this->hasMany(PurchaseRequisition::class); }
    public function purchaseOrders() { return $this->hasMany(PurchaseOrder::class); }
    public function financialAccounts() { return $this->hasMany(FinancialAccount::class); }
    public function customerInvoices() { return $this->hasMany(CustomerInvoice::class); }
    public function supplierInvoices() { return $this->hasMany(SupplierInvoice::class); }
}
