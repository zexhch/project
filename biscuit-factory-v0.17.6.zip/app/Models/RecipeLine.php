<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class RecipeLine extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:6',
            'loss_percentage' => 'decimal:3',
            'optional' => 'boolean',
        ];
    }

    public function recipeVersion() { return $this->belongsTo(RecipeVersion::class); }
    public function ingredient() { return $this->belongsTo(Item::class, 'ingredient_item_id'); }
    public function unit() { return $this->belongsTo(Unit::class); }
}
