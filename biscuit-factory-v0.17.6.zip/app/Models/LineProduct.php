<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class LineProduct extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['production_rate_per_hour'=>'decimal:3','active'=>'boolean']; } public function productionLine(){return $this->belongsTo(ProductionLine::class);} public function item(){return $this->belongsTo(Item::class);} public function rateUnit(){return $this->belongsTo(Unit::class,'rate_unit_id');} }
