<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DeliveryNote extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array { return ['delivered_at' => 'datetime', 'posted_at' => 'datetime']; }
    public function salesOrder() { return $this->belongsTo(SalesOrder::class); }
    public function customer() { return $this->belongsTo(Customer::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function lines() { return $this->hasMany(DeliveryNoteLine::class); }
    public function returns() { return $this->hasMany(CustomerReturn::class); }
    public function stockMovement() { return $this->belongsTo(StockMovement::class); }
    public function customerInvoice() { return $this->hasOne(CustomerInvoice::class); }
}
