<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class SupplierQuotation extends Model
{
    use UsesUuid;

    protected $fillable = [
        'company_id', 'purchase_requisition_id', 'supplier_id', 'quotation_number',
        'supplier_reference', 'quotation_date', 'valid_until', 'currency_code', 'exchange_rate',
        'tax_included', 'status', 'payment_terms_days', 'delivery_lead_time_days', 'subtotal', 'discount_amount',
        'tax_amount', 'total_amount', 'notes', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'quotation_date' => 'date',
            'valid_until' => 'date',
            'exchange_rate' => 'decimal:8',
            'tax_included' => 'boolean',
            'payment_terms_days' => 'integer',
            'delivery_lead_time_days' => 'integer',
            'subtotal' => 'decimal:4',
            'discount_amount' => 'decimal:4',
            'tax_amount' => 'decimal:4',
            'total_amount' => 'decimal:4',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function requisition() { return $this->belongsTo(PurchaseRequisition::class, 'purchase_requisition_id'); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function lines() { return $this->hasMany(SupplierQuotationLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function purchaseOrders() { return $this->hasMany(PurchaseOrder::class); }
}
