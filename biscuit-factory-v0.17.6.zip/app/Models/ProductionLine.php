<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ProductionLine extends Model
{
    use UsesUuid;

    protected $fillable = [
        'site_id', 'code', 'name', 'description', 'capacity_per_hour',
        'capacity_unit_id', 'cost_center_id', 'status', 'active',
    ];

    protected function casts(): array
    {
        return [
            'capacity_per_hour' => 'decimal:3',
            'active' => 'boolean',
        ];
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function capacityUnit()
    {
        return $this->belongsTo(Unit::class, 'capacity_unit_id');
    }

    public function costCenter()
    {
        return $this->belongsTo(CostCenter::class);
    }

    public function machines()
    {
        return $this->belongsToMany(Machine::class, 'production_line_machines')
            ->withPivot(['sequence_number', 'critical'])
            ->withTimestamps();
    }

    public function products()
    {
        return $this->hasMany(LineProduct::class);
    }

    public function oeeSnapshots()
    {
        return $this->hasMany(OeeSnapshot::class);
    }
}
