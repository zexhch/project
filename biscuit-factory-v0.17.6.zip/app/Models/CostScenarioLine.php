<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CostScenarioLine extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'planned_quantity' => 'decimal:6',
            'sales_unit_price' => 'decimal:6',
            'material_adjustment_percentage' => 'decimal:4',
            'conversion_adjustment_percentage' => 'decimal:4',
            'overhead_adjustment_percentage' => 'decimal:4',
            'material_unit_cost' => 'decimal:6',
            'packaging_unit_cost' => 'decimal:6',
            'labor_unit_cost' => 'decimal:6',
            'machine_unit_cost' => 'decimal:6',
            'energy_unit_cost' => 'decimal:6',
            'overhead_unit_cost' => 'decimal:6',
            'other_unit_cost' => 'decimal:6',
            'total_unit_cost' => 'decimal:6',
            'planned_revenue' => 'decimal:4',
            'planned_cost' => 'decimal:4',
            'planned_margin' => 'decimal:4',
            'planned_margin_percentage' => 'decimal:4',
            'calculation_details' => 'array',
        ];
    }

    public function scenario() { return $this->belongsTo(CostScenario::class, 'cost_scenario_id'); }
    public function item() { return $this->belongsTo(Item::class); }
    public function recipeVersion() { return $this->belongsTo(RecipeVersion::class); }
}
