<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class Item extends Model
{
    use SoftDeletes, UsesUuid;

    protected $fillable = [
        'category_id', 'base_unit_id', 'code', 'name', 'description',
        'item_type', 'barcode', 'main_image_path', 'main_image_thumbnail_path', 'lot_managed', 'expiry_managed',
        'minimum_stock', 'shelf_life_days', 'active',
    ];

    protected static function booted(): void
    {
        static::saved(function (Item $item): void {
            if (! Schema::hasTable('item_unit_conversions') || ! Schema::hasColumn('item_unit_conversions', 'parent_unit_id')) {
                return;
            }

            $existing = DB::table('item_unit_conversions')
                ->where('item_id', $item->id)
                ->where('unit_id', $item->base_unit_id)
                ->first();

            $otherProductionUnitExists = DB::table('item_unit_conversions')
                ->where('item_id', $item->id)
                ->where('unit_id', '!=', $item->base_unit_id)
                ->where('active', true)
                ->where('production_unit', true)
                ->exists();
            $otherInventoryUnitExists = DB::table('item_unit_conversions')
                ->where('item_id', $item->id)
                ->where('unit_id', '!=', $item->base_unit_id)
                ->where('active', true)
                ->where('inventory_unit', true)
                ->exists();

            $values = [
                'parent_unit_id' => null,
                'factor_to_parent' => 1,
                'factor_to_base' => 1,
                'barcode' => $item->barcode,
                'production_unit' => ! $otherProductionUnitExists,
                'inventory_unit' => ! $otherInventoryUnitExists,
                'active' => true,
                'updated_at' => now(),
            ];

            if ($existing) {
                DB::table('item_unit_conversions')->where('id', $existing->id)->update($values);
            } else {
                DB::table('item_unit_conversions')->insert([
                    'id' => (string) Str::uuid(),
                    'item_id' => $item->id,
                    'unit_id' => $item->base_unit_id,
                    'purchasing_unit' => false,
                    'sales_unit' => false,
                    'fractional_allowed' => false,
                    'rounding_mode' => 'NONE',
                    'created_at' => now(),
                    ...$values,
                ]);
            }
        });
    }

    protected function casts(): array
    {
        return [
            'lot_managed' => 'boolean',
            'expiry_managed' => 'boolean',
            'minimum_stock' => 'decimal:3',
            'active' => 'boolean',
        ];
    }

    public function category()
    {
        return $this->belongsTo(ItemCategory::class, 'category_id');
    }

    public function baseUnit()
    {
        return $this->belongsTo(Unit::class, 'base_unit_id');
    }

    public function unitConversions() { return $this->hasMany(ItemUnitConversion::class)->with(['unit', 'parentUnit']); }
    public function images() { return $this->hasMany(ItemImage::class)->orderBy('position'); }
    public function lots() { return $this->hasMany(Lot::class); }
    public function balances() { return $this->hasMany(StockBalance::class); }
    public function qualityControlPlans() { return $this->hasMany(QualityControlPlan::class); }
    public function qualityInspections() { return $this->hasMany(QualityInspection::class); }
    public function nonConformities() { return $this->hasMany(QualityNonConformity::class); }
    public function supplierItems() { return $this->hasMany(SupplierItem::class); }
    public function purchaseOrderLines() { return $this->hasMany(PurchaseOrderLine::class); }
    public function goodsReceiptLines() { return $this->hasMany(GoodsReceiptLine::class); }
}
