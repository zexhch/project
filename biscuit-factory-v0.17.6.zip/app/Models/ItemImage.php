<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ItemImage extends Model
{
    use UsesUuid;

    protected $fillable = [
        'item_id', 'path', 'thumbnail_path', 'original_name', 'position',
        'size_bytes', 'width_px', 'height_px', 'uploaded_by',
    ];

    protected function casts(): array
    {
        return [
            'position' => 'integer',
            'size_bytes' => 'integer',
            'width_px' => 'integer',
            'height_px' => 'integer',
        ];
    }

    public function item() { return $this->belongsTo(Item::class); }
    public function uploader() { return $this->belongsTo(User::class, 'uploaded_by'); }
}
