<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ProductionOrder extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['planned_date' => 'date', 'planned_start' => 'datetime', 'planned_end' => 'datetime', 'actual_start' => 'datetime', 'actual_end' => 'datetime'];
    }

    public function productionPlan() { return $this->belongsTo(ProductionPlan::class); }
    public function capacityRequirement() { return $this->belongsTo(CapacityRequirement::class); }
    public function workShift() { return $this->belongsTo(WorkShift::class); }
    public function item() { return $this->belongsTo(Item::class, 'finished_item_id'); }
    public function recipeVersion() { return $this->belongsTo(RecipeVersion::class); }
    public function productionLine() { return $this->belongsTo(ProductionLine::class); }
    public function consumptions() { return $this->hasMany(ProductionConsumption::class); }
    public function outputs() { return $this->hasMany(ProductionOutput::class); }
    public function losses() { return $this->hasMany(ProductionLoss::class); }
    public function qualityInspections() { return $this->hasMany(QualityInspection::class); }
    public function nonConformities() { return $this->hasMany(QualityNonConformity::class); }
    public function costEntries() { return $this->hasMany(ProductionCostEntry::class); }
    public function costCalculations() { return $this->hasMany(CostCalculation::class); }
}
