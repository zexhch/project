<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class ReportRun extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'filters' => 'array',
            'period_from' => 'date',
            'period_to' => 'date',
            'started_at' => 'datetime',
            'completed_at' => 'datetime',
        ];
    }

    public function schedule() { return $this->belongsTo(ReportSchedule::class, 'report_schedule_id'); }
    public function user() { return $this->belongsTo(User::class); }
}
