<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class DataImportRow extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'payload' => 'array',
            'normalized_payload' => 'array',
            'errors' => 'array',
        ];
    }

    public function job() { return $this->belongsTo(DataImportJob::class, 'data_import_job_id'); }
}
