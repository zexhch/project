<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class BackupRun extends Model
{
    use UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'started_at' => 'datetime',
            'completed_at' => 'datetime',
        ];
    }

    public function schedule() { return $this->belongsTo(BackupSchedule::class, 'backup_schedule_id'); }
    public function initiator() { return $this->belongsTo(User::class, 'initiated_by'); }
}
