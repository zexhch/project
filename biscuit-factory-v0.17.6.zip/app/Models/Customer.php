<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use SoftDeletes, UsesUuid;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['credit_limit' => 'decimal:4', 'tax_exempt' => 'boolean', 'active' => 'boolean'];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function contacts() { return $this->hasMany(CustomerContact::class); }
    public function priceLists() { return $this->hasMany(SalesPriceList::class); }
    public function quotations() { return $this->hasMany(SalesQuotation::class); }
    public function salesOrders() { return $this->hasMany(SalesOrder::class); }
    public function deliveries() { return $this->hasMany(DeliveryNote::class); }
    public function invoices() { return $this->hasMany(CustomerInvoice::class); }
    public function payments() { return $this->hasMany(CustomerPayment::class); }
}
