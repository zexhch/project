<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Supplier extends Model
{
    use SoftDeletes, UsesUuid;

    protected $fillable = [
        'company_id', 'code', 'name', 'legal_name', 'supplier_type', 'tax_identifier',
        'registration_number', 'statistical_identification_number',
        'article_of_imposition_number', 'country_code', 'currency_code', 'payment_terms_days',
        'incoterm', 'lead_time_days', 'minimum_order_value', 'status', 'preferred',
        'email', 'phone', 'address', 'notes', 'active',
    ];

    protected function casts(): array
    {
        return [
            'payment_terms_days' => 'integer',
            'lead_time_days' => 'integer',
            'minimum_order_value' => 'decimal:4',
            'preferred' => 'boolean',
            'active' => 'boolean',
        ];
    }

    public function company() { return $this->belongsTo(Company::class); }
    public function contacts() { return $this->hasMany(SupplierContact::class); }
    public function items() { return $this->hasMany(SupplierItem::class); }
    public function priceLists() { return $this->hasMany(PurchasePriceList::class); }
    public function quotations() { return $this->hasMany(SupplierQuotation::class); }
    public function purchaseOrders() { return $this->hasMany(PurchaseOrder::class); }
    public function receipts() { return $this->hasMany(GoodsReceipt::class); }
    public function returns() { return $this->hasMany(SupplierReturn::class); }
    public function evaluations() { return $this->hasMany(SupplierEvaluation::class); }
    public function invoices() { return $this->hasMany(SupplierInvoice::class); }
    public function payments() { return $this->hasMany(SupplierPayment::class); }
}
