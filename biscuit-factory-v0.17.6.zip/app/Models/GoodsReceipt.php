<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class GoodsReceipt extends Model
{
    use UsesUuid;

    protected $fillable = [
        'purchase_order_id', 'supplier_id', 'warehouse_id', 'destination_location_id',
        'receipt_number', 'received_at', 'supplier_delivery_note', 'status', 'notes',
        'created_by', 'posted_by', 'posted_at', 'stock_movement_id',
    ];

    protected function casts(): array
    {
        return ['received_at' => 'datetime', 'posted_at' => 'datetime'];
    }

    public function purchaseOrder() { return $this->belongsTo(PurchaseOrder::class); }
    public function supplier() { return $this->belongsTo(Supplier::class); }
    public function warehouse() { return $this->belongsTo(Warehouse::class); }
    public function destinationLocation() { return $this->belongsTo(WarehouseLocation::class, 'destination_location_id'); }
    public function lines() { return $this->hasMany(GoodsReceiptLine::class); }
    public function creator() { return $this->belongsTo(User::class, 'created_by'); }
    public function poster() { return $this->belongsTo(User::class, 'posted_by'); }
    public function stockMovement() { return $this->belongsTo(StockMovement::class); }
    public function supplierInvoice() { return $this->hasOne(SupplierInvoice::class); }
}
