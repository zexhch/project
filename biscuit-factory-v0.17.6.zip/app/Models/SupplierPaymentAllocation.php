<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class SupplierPaymentAllocation extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['amount'=>'decimal:4']; } public function payment(){return $this->belongsTo(SupplierPayment::class,'supplier_payment_id');} public function invoice(){return $this->belongsTo(SupplierInvoice::class,'supplier_invoice_id');} }
