<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class CustomerReturnLine extends Model
{
    use UsesUuid;

    protected $guarded = [];
    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:3', 'base_quantity' => 'decimal:3',
            'factor_to_base' => 'decimal:8', 'unit_cost' => 'decimal:6',
        ];
    }
    public function customerReturn() { return $this->belongsTo(CustomerReturn::class); }
    public function deliveryNoteLine() { return $this->belongsTo(DeliveryNoteLine::class); }
    public function deliveryAllocation() { return $this->belongsTo(DeliveryAllocation::class); }
    public function item() { return $this->belongsTo(Item::class); }
    public function lot() { return $this->belongsTo(Lot::class); }
    public function unit() { return $this->belongsTo(Unit::class); }
}
