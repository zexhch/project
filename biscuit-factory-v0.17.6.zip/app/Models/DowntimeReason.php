<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid; use Illuminate\Database\Eloquent\Model;
class DowntimeReason extends Model { use UsesUuid; protected $guarded=[]; protected function casts():array{return ['planned'=>'boolean','active'=>'boolean'];} }
