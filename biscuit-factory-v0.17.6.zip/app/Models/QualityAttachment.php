<?php

namespace App\Models;

use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;

class QualityAttachment extends Model
{
    use UsesUuid;

    public $timestamps = false;

    protected $guarded = [];

    protected function casts(): array
    {
        return ['size_bytes' => 'integer', 'created_at' => 'datetime'];
    }

    public function inspection() { return $this->belongsTo(QualityInspection::class, 'quality_inspection_id'); }
    public function nonConformity() { return $this->belongsTo(QualityNonConformity::class, 'quality_non_conformity_id'); }
    public function uploader() { return $this->belongsTo(User::class, 'uploaded_by'); }
}
