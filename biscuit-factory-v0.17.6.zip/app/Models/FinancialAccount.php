<?php
namespace App\Models;
use App\Models\Concerns\UsesUuid;
use Illuminate\Database\Eloquent\Model;
class FinancialAccount extends Model { use UsesUuid; protected $guarded=[]; protected function casts(): array { return ['active'=>'boolean']; } public function company(){return $this->belongsTo(Company::class);} public function customerPayments(){return $this->hasMany(CustomerPayment::class);} public function supplierPayments(){return $this->hasMany(SupplierPayment::class);} }
