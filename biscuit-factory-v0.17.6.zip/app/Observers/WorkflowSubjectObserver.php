<?php

namespace App\Observers;

use App\Events\DashboardUpdated;
use App\Services\Workflow\WorkflowTimelineService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class WorkflowSubjectObserver
{
    public function __construct(private readonly WorkflowTimelineService $timeline)
    {
    }

    public function created(Model $subject): void
    {
        $status = $subject->getAttribute('status');
        if (! is_string($status) || $status === '') {
            return;
        }

        $this->timeline->record(
            $subject,
            'workflow.'.Str::snake(class_basename($subject)).'.created',
            null,
            $status,
            'workflow.document_created',
            ['reference' => $this->reference($subject)],
        );

        event(new DashboardUpdated(['workflow_subject' => $subject::class, 'subject_id' => $subject->getKey()]));
    }

    public function updated(Model $subject): void
    {
        if (! $subject->wasChanged('status')) {
            return;
        }

        $this->timeline->record(
            $subject,
            'workflow.'.Str::snake(class_basename($subject)).'.status_changed',
            (string) $subject->getRawOriginal('status'),
            (string) $subject->getAttribute('status'),
            'workflow.status_transition',
            ['reference' => $this->reference($subject)],
        );

        event(new DashboardUpdated(['workflow_subject' => $subject::class, 'subject_id' => $subject->getKey()]));
    }

    private function reference(Model $subject): ?string
    {
        foreach (['order_number', 'quotation_number', 'requisition_number', 'receipt_number', 'delivery_number', 'inspection_number', 'non_conformity_number', 'work_order_number', 'invoice_number'] as $column) {
            if ($subject->getAttribute($column)) {
                return (string) $subject->getAttribute($column);
            }
        }

        return null;
    }
}
