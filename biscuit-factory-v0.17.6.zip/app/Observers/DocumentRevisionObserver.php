<?php

namespace App\Observers;

use App\Services\Finance\Governance\DocumentRevisionService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class DocumentRevisionObserver
{
    public function created(Model $document): void
    {
        $this->record($document, 'CREATED');
    }

    public function updated(Model $document): void
    {
        $this->record($document, 'UPDATED');
    }

    public function deleted(Model $document): void
    {
        $this->record($document, 'DELETED');
    }

    private function record(Model $document, string $action): void
    {
        if (! Schema::hasTable('document_revisions')) {
            return;
        }

        $actorId = auth()->id()
            ?? $document->getAttribute('updated_by')
            ?? $document->getAttribute('created_by')
            ?? $document->getAttribute('submitted_by');

        app(DocumentRevisionService::class)->record($document, $action, $actorId);
    }
}
