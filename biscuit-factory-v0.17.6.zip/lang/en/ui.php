<?php

return [
    'select_placeholder' => 'Select…',
    'select2' => [
        'error_loading' => 'The results could not be loaded.',
        'input_too_long' => 'Please delete some characters.',
        'input_too_short' => 'Please enter more characters.',
        'loading_more' => 'Loading more results…',
        'maximum_selected' => 'Maximum number of items selected.',
        'no_results' => 'No results found.',
        'searching' => 'Searching…',
        'remove_all' => 'Remove all items',
    ],
    'datatables' => [
        'emptyTable' => 'No data available.',
        'info' => 'Showing _START_ to _END_ of _TOTAL_ entries',
        'infoEmpty' => 'No entries',
        'infoFiltered' => '(filtered from _MAX_ entries)',
        'lengthMenu' => 'Show _MENU_ entries',
        'loadingRecords' => 'Loading…',
        'processing' => 'Processing…',
        'search' => 'Search:',
        'searchPlaceholder' => 'Search this table…',
        'zeroRecords' => 'No matching records found.',
        'paginate' => [
            'first' => 'First',
            'last' => 'Last',
            'next' => 'Next',
            'previous' => 'Previous',
        ],
    ],
    'help_format' => 'Format',
    'help_example' => 'Example',
    'search_no_result' => 'No results.',
];
