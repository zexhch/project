<?php
return [
    'pilotage' => 'Management',
    'dashboard' => 'Dashboard',
    'sales_customers' => 'Sales and customers',
    'procurement' => 'Procurement and purchasing',
    'stock_logistics' => 'Inventory and logistics',
    'production' => 'Production',
    'quality' => 'Quality',
    'maintenance' => 'Maintenance',
    'finance_controlling' => 'Finance and management control',
    'reports' => 'Reports',
    'settings' => 'Settings',
    'operations' => 'Security and operations',
    'administration' => 'Administration',
    'productivity' => 'Productivity',
];
