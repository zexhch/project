<?php
return [
    'pilotage' => 'القيادة',
    'dashboard' => 'لوحة القيادة',
    'sales_customers' => 'المبيعات والعملاء',
    'procurement' => 'التموين والمشتريات',
    'stock_logistics' => 'المخزون واللوجستيك',
    'production' => 'الإنتاج',
    'quality' => 'الجودة',
    'maintenance' => 'الصيانة',
    'finance_controlling' => 'المالية ومراقبة التسيير',
    'reports' => 'التقارير',
    'settings' => 'الإعدادات',
    'operations' => 'الأمان والتشغيل',
    'administration' => 'الإدارة',
    'productivity' => 'الإنتاجية',
];
