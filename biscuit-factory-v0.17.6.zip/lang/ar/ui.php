<?php

return [
    'select_placeholder' => 'اختر…',
    'select2' => [
        'error_loading' => 'تعذر تحميل النتائج.',
        'input_too_long' => 'يرجى حذف بعض الأحرف.',
        'input_too_short' => 'يرجى إدخال المزيد من الأحرف.',
        'loading_more' => 'جارٍ تحميل نتائج إضافية…',
        'maximum_selected' => 'تم بلوغ الحد الأقصى للعناصر.',
        'no_results' => 'لم يتم العثور على نتائج.',
        'searching' => 'جارٍ البحث…',
        'remove_all' => 'إزالة الكل',
    ],
    'datatables' => [
        'emptyTable' => 'لا توجد بيانات متاحة.',
        'info' => 'عرض _START_ إلى _END_ من أصل _TOTAL_',
        'infoEmpty' => 'لا توجد عناصر',
        'infoFiltered' => '(تمت التصفية من أصل _MAX_)',
        'lengthMenu' => 'عرض _MENU_ عناصر',
        'loadingRecords' => 'جارٍ التحميل…',
        'processing' => 'جارٍ المعالجة…',
        'search' => 'بحث:',
        'searchPlaceholder' => 'البحث في الجدول…',
        'zeroRecords' => 'لا توجد نتائج مطابقة.',
        'paginate' => [
            'first' => 'الأول',
            'last' => 'الأخير',
            'next' => 'التالي',
            'previous' => 'السابق',
        ],
    ],
    'help_format' => 'الصيغة',
    'help_example' => 'مثال',
    'search_no_result' => 'لا توجد نتائج.',
];
