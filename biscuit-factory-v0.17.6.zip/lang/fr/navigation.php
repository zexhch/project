<?php
return [
    'pilotage' => 'Pilotage',
    'dashboard' => 'Tableau de bord',
    'sales_customers' => 'Ventes et clients',
    'procurement' => 'Approvisionnement et achats',
    'stock_logistics' => 'Stocks et logistique',
    'production' => 'Production',
    'quality' => 'Qualité',
    'maintenance' => 'Maintenance',
    'finance_controlling' => 'Finance et contrôle de gestion',
    'reports' => 'Rapports',
    'settings' => 'Paramétrage',
    'operations' => 'Sécurité et exploitation',
    'administration' => 'Administration',
    'productivity' => 'Productivité',
];
