<?php

return [
    'select_placeholder' => 'Sélectionner…',
    'select2' => [
        'error_loading' => 'Impossible de charger les résultats.',
        'input_too_long' => 'Supprimez quelques caractères.',
        'input_too_short' => 'Saisissez davantage de caractères.',
        'loading_more' => 'Chargement de résultats supplémentaires…',
        'maximum_selected' => 'Le nombre maximal d’éléments est atteint.',
        'no_results' => 'Aucun résultat trouvé.',
        'searching' => 'Recherche…',
        'remove_all' => 'Tout supprimer',
    ],
    'datatables' => [
        'emptyTable' => 'Aucune donnée disponible.',
        'info' => 'Éléments _START_ à _END_ sur _TOTAL_',
        'infoEmpty' => 'Aucun élément',
        'infoFiltered' => '(filtrés parmi _MAX_ éléments)',
        'lengthMenu' => 'Afficher _MENU_ éléments',
        'loadingRecords' => 'Chargement…',
        'processing' => 'Traitement…',
        'search' => 'Rechercher :',
        'searchPlaceholder' => 'Rechercher dans le tableau…',
        'zeroRecords' => 'Aucun résultat correspondant.',
        'paginate' => [
            'first' => 'Premier',
            'last' => 'Dernier',
            'next' => 'Suivant',
            'previous' => 'Précédent',
        ],
    ],
    'help_format' => 'Format',
    'help_example' => 'Exemple',
    'search_no_result' => 'Aucun résultat.',
];
