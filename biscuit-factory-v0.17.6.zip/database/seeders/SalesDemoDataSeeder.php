<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SalesDemoDataSeeder extends Seeder
{
    public function run(): void
    {
        DB::transaction(function (): void {
            $companyId = DB::table('companies')->where('code', 'COMP-DEMO')->value('id');
            $siteId = DB::table('sites')->where('code', 'USINE-01')->value('id');
            $warehouseId = DB::table('warehouses')->where('code', 'MAG-PRINCIPAL')->value('id');
            $itemId = DB::table('items')->where('code', 'PF-BIS-CHOC')->value('id');
            $unitId = DB::table('units')->where('code', 'KG')->value('id');
            $adminId = DB::table('users')->where('email', env('ADMIN_EMAIL', 'admin@biscuit-factory.local'))->value('id');

            if (! $companyId || ! $siteId || ! $warehouseId || ! $itemId || ! $unitId) {
                return;
            }

            foreach ([
                ['sales', 'default_payment_terms_days', 30, 'integer'],
                ['sales', 'reservation_strategy', 'FEFO', 'string'],
                ['sales', 'allow_partial_delivery', true, 'boolean'],
                ['sales', 'customer_return_quarantine', true, 'boolean'],
            ] as [$group, $key, $value, $type]) {
                $this->upsert('system_settings', ['company_id' => $companyId, 'group' => $group, 'key' => $key], [
                    'value' => json_encode($value, JSON_THROW_ON_ERROR),
                    'value_type' => $type,
                    'public' => false,
                ]);
            }

            $customerId = $this->upsert('customers', ['company_id' => $companyId, 'code' => 'CLI-DIST-001'], [
                'name' => 'Distribution El Bahja',
                'legal_name' => 'Distribution El Bahja SARL',
                'customer_group_code' => 'DISTRIBUTOR',
                'sales_channel_code' => 'DISTRIBUTION',
                'tax_identifier' => 'NIF-DEMO-CLIENT-001',
                'registration_number' => 'RC-DEMO-CLIENT-001',
                'statistical_identification_number' => 'NIS-DEMO-CLIENT-001',
                'article_of_imposition_number' => 'AI-DEMO-CLIENT-001',
                'country_code' => 'DZ',
                'currency_code' => 'DZD',
                'payment_terms_days' => 30,
                'credit_limit' => 500000,
                'tax_exempt' => false,
                'status' => 'APPROVED',
                'email' => 'commandes@el-bahja.example',
                'phone' => '+213 555 200 200',
                'billing_address' => 'Alger — adresse de démonstration',
                'shipping_address' => 'Zone logistique, Alger — adresse de démonstration',
                'notes' => 'Client utilisé dans les exemples du manuel Ventes.',
                'active' => true,
                'deleted_at' => null,
            ]);
            $this->upsert('customer_contacts', ['customer_id' => $customerId, 'email' => 'achats@el-bahja.example'], [
                'name' => 'Nadia Benali', 'job_title' => 'Responsable achats', 'phone' => '+213 555 200 201',
                'mobile' => '+213 555 200 202', 'is_primary' => true, 'active' => true,
            ]);

            $priceListId = $this->upsert('sales_price_lists', ['company_id' => $companyId, 'code' => 'TV-DIST-2026'], [
                'customer_id' => null,
                'customer_group_code' => 'DISTRIBUTOR',
                'sales_channel_code' => null,
                'name' => 'Tarif distributeurs 2026',
                'price_type' => 'WHOLESALE',
                'currency_code' => 'DZD',
                'tax_included' => false,
                'priority' => 20,
                'valid_from' => today()->startOfYear(),
                'valid_to' => today()->endOfYear(),
                'status' => 'APPROVED',
                'created_by' => $adminId,
                'approved_by' => $adminId,
                'approved_at' => now(),
            ]);
            foreach ([[0, 420, 0, 25], [100, 395, 0, 22]] as [$minimum, $price, $discount, $margin]) {
                $this->upsert('sales_price_list_lines', [
                    'sales_price_list_id' => $priceListId,
                    'item_id' => $itemId,
                    'unit_id' => $unitId,
                    'minimum_quantity' => $minimum,
                ], [
                    'factor_to_base' => 1,
                    'unit_price' => $price,
                    'discount_percentage' => $discount,
                    'tax_rate_id' => null,
                    'target_margin_percentage' => $margin,
                ]);
            }

            $quotationId = $this->upsert('sales_quotations', ['quotation_number' => 'DEV-DEMO-001'], [
                'company_id' => $companyId, 'site_id' => $siteId, 'warehouse_id' => $warehouseId,
                'customer_id' => $customerId, 'quotation_date' => today(), 'valid_until' => today()->addDays(30),
                'requested_delivery_date' => today()->addDays(5), 'currency_code' => 'DZD', 'exchange_rate' => 1,
                'tax_included' => false, 'status' => 'SENT', 'subtotal' => 25200, 'discount_amount' => 0,
                'tax_amount' => 0, 'total_amount' => 25200,
                'delivery_address' => 'Zone logistique, Alger — adresse de démonstration',
                'notes' => 'Devis exemple prêt à être accepté.', 'created_by' => $adminId,
                'sent_by' => $adminId, 'sent_at' => now(), 'accepted_by' => null, 'accepted_at' => null,
            ]);
            $this->upsert('sales_quotation_lines', ['sales_quotation_id' => $quotationId, 'item_id' => $itemId], [
                'description' => 'Biscuit chocolat', 'quantity' => 60, 'unit_id' => $unitId, 'factor_to_base' => 1,
                'unit_price' => 420, 'discount_percentage' => 0, 'tax_rate_id' => null,
                'net_unit_price' => 420, 'line_subtotal' => 25200, 'tax_amount' => 0, 'line_total' => 25200,
                'notes' => null,
            ]);

            $orderId = $this->upsert('sales_orders', ['order_number' => 'CV-DEMO-001'], [
                'company_id' => $companyId, 'site_id' => $siteId, 'warehouse_id' => $warehouseId,
                'customer_id' => $customerId, 'sales_quotation_id' => null, 'customer_reference' => 'BC-CLIENT-4587',
                'order_date' => today(), 'requested_delivery_date' => today()->addDays(3),
                'currency_code' => 'DZD', 'exchange_rate' => 1, 'tax_included' => false, 'status' => 'SUBMITTED',
                'payment_terms_days' => 30, 'subtotal' => 25200, 'discount_amount' => 0, 'tax_amount' => 0,
                'total_amount' => 25200, 'delivery_address' => 'Zone logistique, Alger — adresse de démonstration',
                'notes' => 'Commande exemple à confirmer pour démontrer la réservation FEFO.',
                'cancellation_reason' => null, 'created_by' => $adminId, 'submitted_by' => $adminId,
                'submitted_at' => now(), 'confirmed_by' => null, 'confirmed_at' => null,
            ]);
            $this->upsert('sales_order_lines', ['sales_order_id' => $orderId, 'item_id' => $itemId], [
                'sales_quotation_line_id' => null, 'description' => 'Biscuit chocolat',
                'ordered_quantity' => 60, 'reserved_quantity' => 0, 'delivered_quantity' => 0,
                'returned_quantity' => 0, 'unit_id' => $unitId, 'factor_to_base' => 1,
                'unit_price' => 420, 'discount_percentage' => 0, 'tax_rate_id' => null,
                'net_unit_price' => 420, 'line_subtotal' => 25200, 'tax_amount' => 0,
                'line_total' => 25200, 'status' => 'OPEN', 'notes' => null,
            ]);

            $returnPlanId = $this->upsert('quality_control_plans', ['code' => 'PCQ-RETOUR-CLIENT', 'version' => 1], [
                'name' => 'Contrôle des retours clients', 'control_stage' => 'CUSTOMER_RETURN',
                'item_id' => null, 'item_category_id' => null, 'production_line_id' => null,
                'haccp_control_point_id' => null, 'sampling_method' => 'RANDOM', 'sample_size' => 3,
                'frequency_type' => 'BATCH', 'frequency_value' => 1,
                'instructions' => 'Contrôler l’intégrité, la traçabilité, la date et les conditions de conservation.',
                'valid_from' => today(), 'valid_to' => null, 'status' => 'APPROVED', 'active' => true,
                'created_by' => $adminId, 'approved_by' => $adminId, 'approved_at' => now(),
            ]);
            foreach ([
                ['INTEGRITE', 'Emballage et produit intègres', 'BOOLEAN', 'true', 10, true],
                ['TRACABILITE', 'Lot et date lisibles', 'BOOLEAN', 'true', 20, true],
                ['ODEUR-ASPECT', 'Odeur et aspect conformes', 'BOOLEAN', 'true', 30, true],
            ] as [$code, $name, $type, $expected, $sequence, $critical]) {
                $this->upsert('quality_control_plan_parameters', [
                    'quality_control_plan_id' => $returnPlanId, 'code' => $code,
                ], [
                    'name' => $name, 'data_type' => $type, 'unit_id' => null,
                    'minimum_value' => null, 'maximum_value' => null, 'target_value' => null,
                    'expected_value' => $expected, 'options' => null, 'method' => 'Contrôle visuel',
                    'required' => true, 'critical' => $critical, 'sequence' => $sequence,
                ]);
            }
        });
    }

    private function upsert(string $table, array $keys, array $values): string
    {
        $query = DB::table($table);
        foreach ($keys as $column => $value) {
            $query->where($column, $value);
        }
        $id = $query->value('id') ?: (string) Str::uuid();
        DB::table($table)->updateOrInsert($keys, array_merge($values, [
            'id' => $id, 'updated_at' => now(), 'created_at' => now(),
        ]));

        return $id;
    }
}
