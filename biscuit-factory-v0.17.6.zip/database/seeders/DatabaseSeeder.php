<?php

namespace Database\Seeders;

use App\Modules\Administration\Database\Seeders\ApplicationModuleSeeder;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            ApplicationModuleSeeder::class,
            ReferenceDataSeeder::class,
            DemoDataSeeder::class,
            SalesDemoDataSeeder::class,
            ManagementControlDemoSeeder::class,
            BillingDemoSeeder::class,
            FinancialGovernanceSeeder::class,
        ]);
    }
}
