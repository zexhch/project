<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        DB::transaction(function (): void {
            $modules = collect(app(\App\Services\Modules\ModuleRegistry::class)->definitions())
                ->pluck('permissions')
                ->flatten()
                ->push('reports')
                ->unique()
                ->values()
                ->all();

            $actions = ['view', 'create', 'update', 'delete', 'approve', 'export'];

            $permissionIds = [];

            foreach ($modules as $module) {
                foreach ($actions as $action) {
                    $code = "{$module}.{$action}";
                    $permissionIds[$code] = $this->upsertPermission(
                        code: $code,
                        module: $module,
                        name: ucfirst($action).' '.ucfirst($module),
                    );
                }
            }

            $roles = [
                'ADMINISTRATOR' => [
                    'name' => 'Administrateur',
                    'description' => 'Accès complet et paramétrage.',
                    'permissions' => array_keys($permissionIds),
                ],
                'MANAGEMENT' => [
                    'name' => 'Direction / Gérant',
                    'description' => 'Pilotage, validation et reporting.',
                    'permissions' => $this->forModules($permissionIds, [
                        'dashboard', 'catalog', 'purchasing', 'stocks', 'production',
                        'maintenance', 'quality', 'sales', 'finance', 'reports', 'operations',
                    ], ['view', 'approve', 'export']),
                ],
                'PRODUCTION_MANAGER' => [
                    'name' => 'Responsable production',
                    'description' => 'Planification et supervision de la production.',
                    'permissions' => $this->forModules($permissionIds, [
                        'dashboard', 'catalog', 'stocks', 'production', 'maintenance', 'quality', 'reports',
                    ], ['view', 'create', 'update', 'approve', 'export']),
                ],
                'PRODUCTION_OPERATOR' => [
                    'name' => 'Opérateur de production',
                    'description' => 'Exécution et saisie des opérations de production.',
                    'permissions' => $this->specific($permissionIds, [
                        'dashboard.view',
                        'catalog.view',
                        'stocks.view',
                        'production.view',
                        'production.update',
                        'maintenance.view',
                        'maintenance.create',
                        'maintenance.update',
                        'quality.view',
                        'quality.create',
                    ]),
                ],
                'PURCHASING_MANAGER' => [
                    'name' => 'Responsable achats',
                    'description' => 'Fournisseurs, tarifs, consultations, commandes et validations achats.',
                    'permissions' => array_merge(
                        $this->forModules($permissionIds, ['purchasing'], ['view', 'create', 'update', 'delete', 'approve', 'export']),
                        $this->specific($permissionIds, [
                            'dashboard.view', 'catalog.view', 'stocks.view', 'quality.view', 'reports.view', 'reports.export',
                        ]),
                    ),
                ],
                'BUYER' => [
                    'name' => 'Acheteur',
                    'description' => 'Demandes, consultations, tarifs et préparation des commandes d’achat.',
                    'permissions' => array_merge(
                        $this->forModules($permissionIds, ['purchasing'], ['view', 'create', 'update', 'export']),
                        $this->specific($permissionIds, [
                            'dashboard.view', 'catalog.view', 'stocks.view', 'quality.view',
                        ]),
                    ),
                ],
                'WAREHOUSE_KEEPER' => [
                    'name' => 'Magasinier',
                    'description' => 'Réceptions, stocks, lots et inventaires.',
                    'permissions' => array_merge(
                        $this->forModules($permissionIds, [
                            'dashboard', 'catalog', 'purchasing', 'stocks', 'production', 'sales', 'reports',
                        ], ['view', 'create', 'update', 'export']),
                        $this->specific($permissionIds, ['stocks.approve']),
                    ),
                ],
                'MAINTENANCE_MANAGER' => [
                    'name' => 'Responsable maintenance',
                    'description' => 'Plans, interventions, arrêts, coûts et indicateurs maintenance.',
                    'permissions' => $this->forModules($permissionIds, [
                        'dashboard', 'catalog', 'stocks', 'production', 'maintenance', 'reports',
                    ], ['view', 'create', 'update', 'approve', 'export']),
                ],
                'MAINTENANCE_TECHNICIAN' => [
                    'name' => 'Technicien maintenance',
                    'description' => 'Exécution des interventions, actions et consommation de pièces.',
                    'permissions' => $this->specific($permissionIds, [
                        'dashboard.view', 'catalog.view', 'stocks.view', 'production.view',
                        'maintenance.view', 'maintenance.create', 'maintenance.update',
                    ]),
                ],
                'QUALITY_MANAGER' => [
                    'name' => 'Responsable qualité',
                    'description' => 'Contrôles, conformité, libération et blocage des lots.',
                    'permissions' => $this->forModules($permissionIds, [
                        'dashboard', 'catalog', 'purchasing', 'stocks', 'production', 'quality', 'reports',
                    ], ['view', 'create', 'update', 'approve', 'export']),
                ],
                'SALES_MANAGER' => [
                    'name' => 'Responsable commercial',
                    'description' => 'Clients, tarifs, devis, commandes, réservations et validations commerciales.',
                    'permissions' => array_merge(
                        $this->forModules($permissionIds, ['sales'], ['view', 'create', 'update', 'delete', 'approve', 'export']),
                        $this->specific($permissionIds, [
                            'dashboard.view', 'catalog.view', 'stocks.view', 'reports.view', 'reports.export',
                        ]),
                    ),
                ],
                'SALES' => [
                    'name' => 'Commercial',
                    'description' => 'Clients, devis, commandes et suivi commercial.',
                    'permissions' => $this->forModules($permissionIds, [
                        'dashboard', 'catalog', 'stocks', 'sales', 'reports',
                    ], ['view', 'create', 'update', 'export']),
                ],
                'FINANCE' => [
                    'name' => 'Comptable / Finance',
                    'description' => 'Facturation, règlements, coûts et reporting financier.',
                    'permissions' => array_merge(
                        $this->forModules($permissionIds, [
                            'dashboard', 'purchasing', 'stocks', 'sales', 'finance', 'reports',
                        ], ['view', 'create', 'update', 'approve', 'export']),
                        $this->specific($permissionIds, ['catalog.view', 'production.view']),
                    ),
                ],
                'DELIVERY_DRIVER' => [
                    'name' => 'Livreur',
                    'description' => 'Consultation et confirmation des livraisons affectées.',
                    'permissions' => $this->specific($permissionIds, [
                        'dashboard.view',
                        'sales.view',
                        'sales.update',
                    ]),
                ],
            ];

            $planningGrants = [
                'MANAGEMENT' => ['view', 'approve', 'export'],
                'PRODUCTION_MANAGER' => ['view', 'create', 'update', 'approve', 'export'],
                'PRODUCTION_OPERATOR' => ['view'],
                'WAREHOUSE_KEEPER' => ['view', 'export'],
                'MAINTENANCE_MANAGER' => ['view', 'update', 'export'],
                'QUALITY_MANAGER' => ['view', 'export'],
                'FINANCE' => ['view', 'export'],
            ];
            foreach ($planningGrants as $roleCode => $allowedActions) {
                $roles[$roleCode]['permissions'] = array_merge(
                    $roles[$roleCode]['permissions'],
                    $this->forModules($permissionIds, ['planning'], $allowedActions),
                );
            }

            $productivityGrants = [
                'MANAGEMENT' => ['view', 'approve', 'export'],
                'PRODUCTION_MANAGER' => ['view', 'create', 'update', 'approve', 'export'],
                'PURCHASING_MANAGER' => ['view', 'create', 'update', 'approve', 'export'],
                'BUYER' => ['view', 'create', 'update', 'export'],
                'WAREHOUSE_KEEPER' => ['view', 'create', 'update', 'export'],
                'QUALITY_MANAGER' => ['view', 'create', 'update', 'export'],
                'MAINTENANCE_MANAGER' => ['view', 'create', 'update', 'export'],
                'SALES_MANAGER' => ['view', 'create', 'update', 'approve', 'export'],
                'SALES' => ['view', 'create', 'update', 'export'],
                'FINANCE' => ['view', 'create', 'update', 'approve', 'export'],
            ];
            foreach ($productivityGrants as $roleCode => $allowedActions) {
                $roles[$roleCode]['permissions'] = array_merge(
                    $roles[$roleCode]['permissions'],
                    $this->forModules($permissionIds, ['productivity'], $allowedActions),
                );
            }

            $roleIds = [];

            foreach ($roles as $code => $definition) {
                $roleId = $this->upsertRole($code, $definition['name'], $definition['description']);
                $roleIds[$code] = $roleId;

                DB::table('permission_role')->where('role_id', $roleId)->delete();

                $rows = collect($definition['permissions'])
                    ->unique()
                    ->map(fn (string $permissionCode): array => [
                        'role_id' => $roleId,
                        'permission_id' => $permissionIds[$permissionCode],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ])
                    ->all();

                DB::table('permission_role')->insert($rows);
            }

            $email = Str::lower((string) env('ADMIN_EMAIL', 'admin@biscuit-factory.local'));
            $userId = DB::table('users')->where('email', $email)->value('id') ?: (string) Str::uuid();

            DB::table('users')->updateOrInsert(
                ['email' => $email],
                [
                    'id' => $userId,
                    'name' => 'Administrateur',
                    'password' => Hash::make((string) env('ADMIN_PASSWORD', 'ChangeMe123!')),
                    'locale' => 'fr',
                    'active' => true,
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );

            DB::table('role_user')->updateOrInsert(
                [
                    'role_id' => $roleIds['ADMINISTRATOR'],
                    'user_id' => $userId,
                ],
                [
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        });
    }

    private function upsertPermission(string $code, string $module, string $name): string
    {
        $id = DB::table('permissions')->where('code', $code)->value('id') ?: (string) Str::uuid();

        DB::table('permissions')->updateOrInsert(
            ['code' => $code],
            [
                'id' => $id,
                'module' => $module,
                'name' => $name,
                'description' => null,
                'system' => true,
                'updated_at' => now(),
                'created_at' => now(),
            ]
        );

        return $id;
    }

    private function upsertRole(string $code, string $name, string $description): string
    {
        $id = DB::table('roles')->where('code', $code)->value('id') ?: (string) Str::uuid();

        DB::table('roles')->updateOrInsert(
            ['code' => $code],
            [
                'id' => $id,
                'name' => $name,
                'description' => $description,
                'system' => true,
                'active' => true,
                'updated_at' => now(),
                'created_at' => now(),
            ]
        );

        return $id;
    }

    private function forModules(array $permissionIds, array $modules, array $actions): array
    {
        return collect($permissionIds)
            ->keys()
            ->filter(function (string $code) use ($modules, $actions): bool {
                [$module, $action] = explode('.', $code);

                return in_array($module, $modules, true) && in_array($action, $actions, true);
            })
            ->values()
            ->all();
    }

    private function specific(array $permissionIds, array $codes): array
    {
        return array_values(array_filter(
            $codes,
            fn (string $code): bool => array_key_exists($code, $permissionIds)
        ));
    }
}
