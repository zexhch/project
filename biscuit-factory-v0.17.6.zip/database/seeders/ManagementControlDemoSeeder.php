<?php

namespace Database\Seeders;

use App\Models\Company;
use App\Models\CostCenter;
use App\Models\CostScenario;
use App\Models\Item;
use App\Models\Machine;
use App\Models\ManagementBudget;
use App\Models\ProductionLine;
use App\Models\RecipeVersion;
use App\Models\SalesPriceListLine;
use App\Models\Site;
use App\Models\User;
use App\Services\Finance\ManagementControlService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ManagementControlDemoSeeder extends Seeder
{
    public function run(): void
    {
        $company = Company::query()->where('code', 'COMP-DEMO')->first();
        $site = Site::query()->where('code', 'USINE-01')->first();
        $user = User::query()->orderBy('created_at')->first();

        if (! $company) {
            return;
        }

        DB::transaction(function () use ($company, $site, $user): void {
            $production = CostCenter::query()->updateOrCreate(
                ['company_id' => $company->id, 'code' => 'CC-PROD'],
                [
                    'site_id' => $site?->id,
                    'name' => 'Production principale',
                    'center_type' => 'PRODUCTION',
                    'allocation_method' => 'MACHINE_HOURS',
                    'responsible_user_id' => $user?->id,
                    'description' => 'Centre de démonstration pour les coûts de fabrication.',
                    'active' => true,
                ]
            );

            $maintenance = CostCenter::query()->updateOrCreate(
                ['company_id' => $company->id, 'code' => 'CC-MAINT'],
                [
                    'site_id' => $site?->id,
                    'name' => 'Maintenance usine',
                    'center_type' => 'MAINTENANCE',
                    'allocation_method' => 'DIRECT',
                    'responsible_user_id' => $user?->id,
                    'description' => 'Centre de démonstration pour les interventions de maintenance.',
                    'active' => true,
                ]
            );

            ProductionLine::query()->where('code', 'LIGNE-01')->update(['cost_center_id' => $production->id]);
            Machine::query()->where('code', 'FOUR-01')->update(['cost_center_id' => $maintenance->id]);

            $production->rates()->updateOrCreate(
                ['rate_type' => 'LABOR', 'valid_from' => now()->startOfYear()->toDateString()],
                ['hourly_rate' => 550, 'currency_code' => $company->currency_code, 'active' => true]
            );
            $production->rates()->updateOrCreate(
                ['rate_type' => 'MACHINE', 'valid_from' => now()->startOfYear()->toDateString()],
                ['hourly_rate' => 1200, 'currency_code' => $company->currency_code, 'active' => true]
            );

            ManagementBudget::query()->updateOrCreate(
                [
                    'company_id' => $company->id,
                    'cost_center_id' => $production->id,
                    'fiscal_year' => now()->year,
                    'period' => 0,
                    'category_code' => 'TOTAL',
                ],
                [
                    'budget_amount' => 25000000,
                    'actual_amount' => 0,
                    'variance_amount' => 25000000,
                    'variance_percentage' => 100,
                    'currency_code' => $company->currency_code,
                    'status' => 'DRAFT',
                    'notes' => 'Budget annuel de démonstration.',
                    'created_by' => $user?->id,
                ]
            );
        });

        $item = Item::query()->where('code', 'PF-BIS-CHOC')->first();
        $version = RecipeVersion::query()->where('status', 'APPROVED')
            ->whereHas('recipe', fn ($query) => $query->where('finished_item_id', $item?->id))
            ->latest('approved_at')->first();

        if (! $item || ! $version) {
            return;
        }

        $scenario = CostScenario::query()->updateOrCreate(
            ['company_id' => $company->id, 'code' => 'SCN-BASE'],
            [
                'name' => 'Scénario de référence',
                'status' => 'DRAFT',
                'currency_code' => $company->currency_code,
                'valid_from' => now()->startOfMonth()->toDateString(),
                'notes' => 'Simulation initiale modifiable.',
                'created_by' => $user?->id,
            ]
        );

        $salesPrice = (float) (SalesPriceListLine::query()->where('item_id', $item->id)->latest()->value('unit_price') ?? 180);
        $line = $scenario->lines()->updateOrCreate(
            ['item_id' => $item->id],
            [
                'recipe_version_id' => $version->id,
                'planned_quantity' => 10000,
                'sales_unit_price' => $salesPrice,
                'material_adjustment_percentage' => 0,
                'conversion_adjustment_percentage' => 0,
                'overhead_adjustment_percentage' => 0,
            ]
        );

        app(ManagementControlService::class)->recalculateScenarioLine($line);
        app(ManagementControlService::class)->recalculateScenario($scenario, $user?->id);
    }
}
