<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class BillingDemoSeeder extends Seeder
{
    public function run(): void
    {
        $companyId = DB::table('companies')->where('code', 'COMP-DEMO')->value('id');
        if (! $companyId) {
            return;
        }

        DB::transaction(function () use ($companyId): void {
            $accountId = DB::table('financial_accounts')->where('company_id', $companyId)->where('code', 'BANQUE-PRINCIPALE')->value('id') ?: (string) Str::uuid();
            DB::table('financial_accounts')->updateOrInsert(
                ['company_id' => $companyId, 'code' => 'BANQUE-PRINCIPALE'],
                [
                    'id' => $accountId,
                    'name' => 'Compte bancaire principal',
                    'account_type' => 'BANK',
                    'currency_code' => 'DZD',
                    'bank_name' => 'Banque de démonstration',
                    'account_number' => 'À CONFIGURER',
                    'iban' => null,
                    'active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );

            foreach ([
                ['invoice_matching_tolerance', 1, 'decimal'],
                ['aging_bucket_1_days', 30, 'integer'],
                ['aging_bucket_2_days', 60, 'integer'],
                ['aging_bucket_3_days', 90, 'integer'],
                ['allow_unallocated_payments', true, 'boolean'],
            ] as [$key, $value, $type]) {
                $id = DB::table('system_settings')->where('company_id', $companyId)->where('group', 'finance')->where('key', $key)->value('id') ?: (string) Str::uuid();
                DB::table('system_settings')->updateOrInsert(
                    ['company_id' => $companyId, 'group' => 'finance', 'key' => $key],
                    [
                        'id' => $id,
                        'value' => json_encode($value, JSON_THROW_ON_ERROR),
                        'value_type' => $type,
                        'public' => false,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]
                );
            }
        });
    }
}
