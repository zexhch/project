<?php

namespace Database\Seeders;

use App\Models\ApprovalWorkflow;
use App\Models\Company;
use App\Models\DocumentNumberSequence;
use App\Models\DocumentTemplate;
use App\Services\Finance\Governance\AccountingPeriodService;
use App\Services\Finance\Governance\FinancialDocumentCatalog;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FinancialGovernanceSeeder extends Seeder
{
    public function run(AccountingPeriodService $periods): void
    {
        foreach (Company::query()->where('active', true)->get() as $company) {
            $periods->generateYear($company->id, now()->year);
            $periods->generateYear($company->id, now()->year + 1);

            foreach (FinancialDocumentCatalog::all() as $type => $definition) {
                DocumentNumberSequence::query()->firstOrCreate(
                    [
                        'company_id' => $company->id,
                        'document_type' => $type,
                        'fiscal_year' => now()->year,
                        'period' => 0,
                    ],
                    [
                        'prefix' => $definition['prefix'],
                        'pattern' => '{PREFIX}-{YEAR}-{NUMBER}',
                        'reset_policy' => 'ANNUAL',
                        'next_number' => 1,
                        'padding' => 6,
                        'active' => true,
                    ],
                );

                DocumentTemplate::query()->firstOrCreate(
                    ['company_id' => $company->id, 'code' => $type.'_FR'],
                    [
                        'name' => __($definition['label'], [], 'fr'),
                        'document_type' => $type,
                        'locale' => 'fr',
                        'title' => __($definition['label'], [], 'fr'),
                        'footer_text' => $company->legal_name ?: $company->name,
                        'show_company_details' => true,
                        'show_logo' => true,
                        'show_legal_identifiers' => true,
                        'show_bank_details' => true,
                        'show_line_numbers' => true,
                        'show_tax_rate' => true,
                        'show_amount_in_words' => true,
                        'show_internal_references' => true,
                        'show_status' => true,
                        'show_amounts' => $type === FinancialDocumentCatalog::DELIVERY_NOTE ? true : null,
                        'show_signature_blocks' => true,
                        'is_default' => true,
                        'active' => true,
                    ],
                );
            }

            $supplierWorkflow = ApprovalWorkflow::query()->firstOrCreate(
                ['company_id' => $company->id, 'code' => 'SUPPLIER_INVOICE_STANDARD'],
                [
                    'name' => 'Validation des factures fournisseurs',
                    'document_type' => FinancialDocumentCatalog::SUPPLIER_INVOICE,
                    'minimum_amount' => 500000,
                    'currency_code' => $company->currency_code,
                    'description' => 'Exemple désactivé : double validation Finance puis Direction au-delà du seuil.',
                    'active' => false,
                ],
            );
            $supplierWorkflow->levels()->updateOrCreate(['sequence' => 1], [
                'name' => 'Contrôle Finance', 'permission_code' => 'finance.approve', 'role_code' => 'FINANCE', 'minimum_approvals' => 1,
            ]);
            $supplierWorkflow->levels()->updateOrCreate(['sequence' => 2], [
                'name' => 'Validation Direction', 'permission_code' => 'finance.approve', 'role_code' => 'MANAGEMENT', 'minimum_approvals' => 1,
            ]);

            $customerWorkflow = ApprovalWorkflow::query()->firstOrCreate(
                ['company_id' => $company->id, 'code' => 'CUSTOMER_INVOICE_EXCEPTIONAL'],
                [
                    'name' => 'Validation des factures clients exceptionnelles',
                    'document_type' => FinancialDocumentCatalog::CUSTOMER_INVOICE,
                    'minimum_amount' => 1000000,
                    'currency_code' => $company->currency_code,
                    'description' => 'Exemple désactivé : validation Direction pour les montants élevés.',
                    'active' => false,
                ],
            );
            $customerWorkflow->levels()->updateOrCreate(['sequence' => 1], [
                'name' => 'Validation Direction', 'permission_code' => 'finance.approve', 'role_code' => 'MANAGEMENT', 'minimum_approvals' => 1,
            ]);
        }
    }
}
