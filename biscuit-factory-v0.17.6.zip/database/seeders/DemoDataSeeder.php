<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        DB::transaction(function (): void {
            $fr = $this->upsert('languages', ['code' => 'fr'], [
                'name' => 'Français',
                'native_name' => 'Français',
                'direction' => 'ltr',
                'active' => true,
                'is_default' => true,
            ]);

            $this->upsert('languages', ['code' => 'ar'], [
                'name' => 'Arabe',
                'native_name' => 'العربية',
                'direction' => 'rtl',
                'active' => true,
                'is_default' => false,
            ]);

            $this->upsert('languages', ['code' => 'en'], [
                'name' => 'Anglais',
                'native_name' => 'English',
                'direction' => 'ltr',
                'active' => true,
                'is_default' => false,
            ]);

            $this->upsert('currencies', ['code' => 'DZD'], [
                'name' => 'Dinar algérien',
                'symbol' => 'DA',
                'decimal_places' => 2,
                'active' => true,
            ]);
            $this->upsert('currencies', ['code' => 'EUR'], [
                'name' => 'Euro',
                'symbol' => '€',
                'decimal_places' => 2,
                'active' => true,
            ]);
            $this->upsert('currencies', ['code' => 'USD'], [
                'name' => 'Dollar américain',
                'symbol' => '$',
                'decimal_places' => 2,
                'active' => true,
            ]);

            $companyId = $this->upsert('companies', ['code' => 'COMP-DEMO'], [
                'name' => 'Fabrique de Biscuits Démo',
                'legal_name' => 'Fabrique de Biscuits Démo EURL',
                'business_activity' => 'Production et distribution de biscuits',
                'trade_register_number' => '16/00-1234567 B 26',
                'tax_identification_number' => '001626123456789',
                'statistical_identification_number' => '001626123456700',
                'article_of_imposition_number' => '16012345678',
                'country_code' => 'DZ',
                'currency_code' => 'DZD',
                'timezone' => 'Africa/Algiers',
                'phone' => '+213 21 00 00 00',
                'email' => 'contact@biscuit-factory.dz',
                'address' => 'Zone industrielle de Rouiba, Alger',
                'bank_name' => 'BDL',
                'bank_branch' => 'Agence Rouiba',
                'bank_account_number' => '00500138400237212012',
                'logo_path' => null,
                'active' => true,
            ]);

            $this->upsert('tax_rates', [
                'company_id' => $companyId,
                'code' => 'TVA-DEMO',
            ], [
                'name' => 'Taux de démonstration à configurer',
                'rate' => 19,
                'valid_from' => null,
                'valid_to' => null,
                'active' => false,
                'is_default' => false,
            ]);

            $settings = [
                ['general', 'default_language', 'fr', 'string', true],
                ['general', 'default_currency', 'DZD', 'string', true],
                ['stock', 'allow_negative_stock', false, 'boolean', false],
                ['stock', 'issue_strategy', 'FEFO', 'string', false],
                ['stock', 'expiry_alert_days', 30, 'integer', false],
                ['production', 'auto_generate_lot_number', true, 'boolean', false],
                ['notifications', 'realtime_enabled', true, 'boolean', false],
                ['dashboard', 'polling_seconds', 30, 'integer', true],
                ['maintenance', 'metrics_period_days', 30, 'integer', false],
                ['maintenance', 'due_alert_days', 7, 'integer', false],
                ['quality', 'default_due_days', 7, 'integer', false],
                ['quality', 'attachment_max_mb', 10, 'integer', false],
                ['purchasing', 'default_payment_terms_days', 30, 'integer', false],
                ['purchasing', 'allow_over_receipt', false, 'boolean', false],
                ['purchasing', 'supplier_minimum_score', 60, 'integer', false],
            ];

            foreach ($settings as [$group, $key, $value, $type, $public]) {
                $this->upsert('system_settings', [
                    'company_id' => $companyId,
                    'group' => $group,
                    'key' => $key,
                ], [
                    'value' => json_encode($value, JSON_THROW_ON_ERROR),
                    'value_type' => $type,
                    'public' => $public,
                ]);
            }

            $siteId = $this->upsert('sites', [
                'company_id' => $companyId,
                'code' => 'USINE-01',
            ], [
                'name' => 'Usine principale',
                'site_type' => 'FACTORY',
                'address' => 'Algérie',
                'active' => true,
            ]);

            $warehouseId = $this->upsert('warehouses', [
                'site_id' => $siteId,
                'code' => 'MAG-PRINCIPAL',
            ], [
                'name' => 'Magasin principal',
                'warehouse_type' => 'GENERAL',
                'active' => true,
            ]);

            $locations = [];
            foreach ([
                ['RECEPTION', 'Zone de réception', 'RECEIVING', false],
                ['MP', 'Matières premières', 'STORAGE', false],
                ['EMB', 'Emballages', 'STORAGE', false],
                ['QUARANTAINE', 'Zone de quarantaine', 'QUARANTINE', true],
                ['PF', 'Produits finis', 'STORAGE', false],
                ['PIECES', 'Pièces de rechange', 'STORAGE', false],
            ] as [$code, $name, $type, $quarantine]) {
                $locations[$code] = $this->upsert('warehouse_locations', [
                    'warehouse_id' => $warehouseId,
                    'code' => $code,
                ], [
                    'name' => $name,
                    'location_type' => $type,
                    'quarantine' => $quarantine,
                    'active' => true,
                ]);
            }

            $units = [];
            foreach ([
                ['KG', 'Kilogramme', 'kg', 'MASS', 3],
                ['G', 'Gramme', 'g', 'MASS', 3],
                ['L', 'Litre', 'L', 'VOLUME', 3],
                ['UN', 'Unité', 'u', 'COUNT', 0],
                ['PAQ', 'Paquet', 'paq', 'COUNT', 0],
                ['SACHET', 'Sachet', 'sachet', 'COUNT', 0],
                ['CARTON', 'Carton', 'carton', 'COUNT', 0],
                ['PALETTE', 'Palette', 'palette', 'COUNT', 0],
                ['H', 'Heure', 'h', 'TIME', 2],
                ['KWH', 'Kilowatt-heure', 'kWh', 'ENERGY', 3],
            ] as [$code, $name, $symbol, $dimension, $decimals]) {
                $units[$code] = $this->upsert('units', ['code' => $code], [
                    'name' => $name,
                    'symbol' => $symbol,
                    'dimension' => $dimension,
                    'decimal_places' => $decimals,
                    'active' => true,
                ]);
            }

            $this->upsert('unit_conversions', [
                'from_unit_id' => $units['KG'],
                'to_unit_id' => $units['G'],
            ], ['factor' => 1000]);

            $categories = [];
            foreach ([
                ['MAT-PREM', 'Matières premières', 'RAW_MATERIAL'],
                ['EMBALLAGE', 'Emballages', 'PACKAGING'],
                ['PROD-FINI', 'Produits finis', 'FINISHED_GOOD'],
                ['PIECE', 'Pièces de rechange', 'SPARE_PART'],
            ] as [$code, $name, $type]) {
                $categories[$code] = $this->upsert('item_categories', ['code' => $code], [
                    'parent_id' => null,
                    'name' => $name,
                    'category_type' => $type,
                    'active' => true,
                ]);
            }

            $items = [];
            foreach ([
                ['MP-FARINE', 'Farine de blé', 'RAW_MATERIAL', 'MAT-PREM', 'KG', true, true, 500, 180],
                ['MP-SUCRE', 'Sucre', 'RAW_MATERIAL', 'MAT-PREM', 'KG', true, true, 200, 365],
                ['MP-GRAISSE', 'Matière grasse végétale', 'RAW_MATERIAL', 'MAT-PREM', 'KG', true, true, 100, 365],
                ['MP-CACAO', 'Poudre de cacao', 'RAW_MATERIAL', 'MAT-PREM', 'KG', true, true, 50, 365],
                ['MP-SEL', 'Sel', 'RAW_MATERIAL', 'MAT-PREM', 'KG', true, true, 20, 730],
                ['EMB-FILM', 'Film d’emballage', 'PACKAGING', 'EMBALLAGE', 'KG', true, false, 50, null],
                ['EMB-CARTON', 'Carton de conditionnement', 'PACKAGING', 'EMBALLAGE', 'UN', true, false, 100, null],
                ['PF-BIS-CHOC', 'Biscuit chocolat', 'FINISHED_GOOD', 'PROD-FINI', 'KG', true, true, 100, 180],
                ['PF-BIS-180', 'Biscuit cacao 180 g', 'FINISHED_GOOD', 'PROD-FINI', 'PAQ', true, true, 240, 180],
                ['PR-ROULEMENT', 'Roulement standard', 'SPARE_PART', 'PIECE', 'UN', true, false, 2, null],
            ] as [$code, $name, $type, $category, $unit, $lot, $expiry, $minimum, $shelfLife]) {
                $items[$code] = $this->upsert('items', ['code' => $code], [
                    'category_id' => $categories[$category],
                    'base_unit_id' => $units[$unit],
                    'name' => $name,
                    'description' => 'Donnée de démonstration modifiable.',
                    'item_type' => $type,
                    'barcode' => null,
                    'lot_managed' => $lot,
                    'expiry_managed' => $expiry,
                    'minimum_stock' => $minimum,
                    'shelf_life_days' => $shelfLife,
                    'active' => true,
                ]);
            }

            foreach ($items as $itemCode => $itemId) {
                $baseUnitId = DB::table('items')->where('id', $itemId)->value('base_unit_id');
                $this->upsert('item_unit_conversions', [
                    'item_id' => $itemId,
                    'unit_id' => $baseUnitId,
                ], [
                    'parent_unit_id' => null,
                    'factor_to_parent' => 1,
                    'factor_to_base' => 1,
                    'purchasing_unit' => false,
                    'sales_unit' => false,
                    'production_unit' => true,
                    'inventory_unit' => true,
                    'fractional_allowed' => false,
                    'rounding_mode' => 'NONE',
                    'active' => true,
                ]);
            }

            $this->upsert('item_unit_conversions', [
                'item_id' => $items['PF-BIS-180'], 'unit_id' => $units['CARTON'],
            ], [
                'parent_unit_id' => $units['PAQ'], 'factor_to_parent' => 24, 'factor_to_base' => 24,
                'barcode' => '6130000000029', 'net_weight_kg' => 4.320, 'gross_weight_kg' => 4.600,
                'tare_weight_kg' => 0.280, 'purchasing_unit' => false, 'sales_unit' => true,
                'production_unit' => false, 'inventory_unit' => false, 'fractional_allowed' => false,
                'rounding_mode' => 'NONE', 'active' => true,
            ]);
            $this->upsert('item_unit_conversions', [
                'item_id' => $items['PF-BIS-180'], 'unit_id' => $units['PALETTE'],
            ], [
                'parent_unit_id' => $units['CARTON'], 'factor_to_parent' => 36, 'factor_to_base' => 864,
                'net_weight_kg' => 155.520, 'gross_weight_kg' => 175.000, 'tare_weight_kg' => 19.480,
                'purchasing_unit' => false, 'sales_unit' => false, 'production_unit' => false,
                'inventory_unit' => false, 'fractional_allowed' => false, 'rounding_mode' => 'NONE', 'active' => true,
            ]);

            $demoLots = [
                ['LOT-FARINE-DEMO', 'MP-FARINE', 'MP', 850, 0.065, 120, 'KG'],
                ['LOT-SUCRE-DEMO', 'MP-SUCRE', 'MP', 320, 0.11, 240, 'KG'],
                ['LOT-GRAISSE-DEMO', 'MP-GRAISSE', 'MP', 250, 0.35, 240, 'KG'],
                ['LOT-CACAO-DEMO', 'MP-CACAO', 'MP', 35, 0.72, 90, 'KG'],
                ['LOT-SEL-DEMO', 'MP-SEL', 'MP', 80, 0.04, 600, 'KG'],
                ['LOT-FILM-DEMO', 'EMB-FILM', 'EMB', 120, 1.10, null, 'KG'],
                ['LOT-CARTON-DEMO', 'EMB-CARTON', 'EMB', 1000, 0.08, null, 'UN'],
                ['LOT-BISCUIT-DEMO', 'PF-BIS-CHOC', 'PF', 180, 1.35, 60, 'KG'],
                ['LOT-BIS-180-DEMO', 'PF-BIS-180', 'PF', 1800, 45, 90, 'PAQ'],
                ['LOT-ROULEMENT-DEMO', 'PR-ROULEMENT', 'PIECES', 8, 2200, null, 'UN'],
            ];
            $openingMovementId = $this->upsert('stock_movements', ['movement_number' => 'REC-DEMO-OUVERTURE'], [
                'movement_type' => 'RECEIPT', 'movement_at' => now()->subDay(), 'source_type' => 'DEMO',
                'source_id' => null, 'status' => 'POSTED', 'notes' => 'Stock initial de démonstration.',
                'created_by' => null, 'posted_at' => now()->subDay(), 'posted_by' => null,
            ]);
            foreach ($demoLots as [$lotNumber, $itemCode, $locationCode, $quantity, $cost, $expiryDays, $unitCode]) {
                $lotId = $this->upsert('lots', ['item_id' => $items[$itemCode], 'lot_number' => $lotNumber], [
                    'manufacturing_date' => today()->subDays(5), 'expiry_date' => $expiryDays ? today()->addDays($expiryDays) : null,
                    'status' => 'RELEASED', 'attributes' => json_encode(['demo' => true]),
                ]);
                $this->upsert('stock_balances', [
                    'item_id' => $items[$itemCode], 'lot_id' => $lotId, 'location_id' => $locations[$locationCode],
                ], ['quantity' => $quantity, 'reserved_quantity' => 0, 'average_unit_cost' => $cost]);
                $this->upsert('stock_movement_lines', [
                    'stock_movement_id' => $openingMovementId, 'item_id' => $items[$itemCode],
                    'lot_id' => $lotId, 'destination_location_id' => $locations[$locationCode],
                ], [
                    'reference' => 'DEMO', 'source_location_id' => null, 'quantity' => $quantity,
                    'unit_id' => $units[$unitCode], 'unit_cost' => $cost, 'notes' => 'Solde initial de démonstration.',
                ]);
            }

            $lineId = $this->upsert('production_lines', [
                'site_id' => $siteId,
                'code' => 'LIGNE-01',
            ], [
                'name' => 'Ligne biscuits 01',
                'description' => 'Ligne de démonstration évolutive.',
                'capacity_per_hour' => 500,
                'capacity_unit_id' => $units['KG'],
                'status' => 'AVAILABLE',
                'active' => true,
            ]);

            $machines = [];
            foreach ([
                ['BALANCE-01', 'Poste de pesée', 'WEIGHING', 10],
                ['PETRIN-01', 'Pétrin principal', 'MIXER', 20],
                ['FORMEUSE-01', 'Façonneuse', 'FORMING', 30],
                ['FOUR-01', 'Four tunnel', 'OVEN', 40],
                ['REFROID-01', 'Convoyeur de refroidissement', 'COOLING', 50],
                ['EMBALLEUSE-01', 'Conditionneuse', 'PACKAGING', 60],
            ] as [$code, $name, $type, $sequence]) {
                $machineId = $this->upsert('machines', [
                    'site_id' => $siteId,
                    'code' => $code,
                ], [
                    'name' => $name,
                    'machine_type' => $type,
                    'manufacturer' => null,
                    'model' => null,
                    'serial_number' => null,
                    'commissioned_at' => null,
                    'status' => 'AVAILABLE',
                    'active' => true,
                ]);
                $machines[$code] = $machineId;

                DB::table('production_line_machines')->updateOrInsert(
                    [
                        'production_line_id' => $lineId,
                        'machine_id' => $machineId,
                    ],
                    [
                        'sequence_number' => $sequence,
                        'critical' => in_array($type, ['MIXER', 'OVEN', 'PACKAGING'], true),
                        'updated_at' => now(),
                        'created_at' => now(),
                    ]
                );
            }

            $shiftId = $this->upsert('work_shifts', [
                'site_id' => $siteId,
                'code' => 'EQUIPE-A',
            ], [
                'name' => 'Équipe A',
                'starts_at' => '08:00:00',
                'ends_at' => '16:00:00',
                'work_days' => json_encode([1, 2, 3, 4, 5, 6], JSON_THROW_ON_ERROR),
                'active' => true,
            ]);

            $recipeId = $this->upsert('recipes', ['code' => 'REC-BIS-CHOC'], [
                'name' => 'Recette biscuit chocolat',
                'finished_item_id' => $items['PF-BIS-CHOC'],
                'description' => 'Recette initiale de démonstration.',
                'active' => true,
            ]);

            $recipeVersionId = $this->upsert('recipe_versions', [
                'recipe_id' => $recipeId,
                'version_number' => 1,
            ], [
                'reference_quantity' => 100,
                'reference_unit_id' => $units['KG'],
                'expected_yield_percent' => 96,
                'valid_from' => now()->toDateString(),
                'valid_to' => null,
                'status' => 'APPROVED',
                'approved_by' => DB::table('users')->where('email', env('ADMIN_EMAIL', 'admin@biscuit-factory.local'))->value('id'),
                'approved_at' => now(),
            ]);

            foreach ([
                ['MP-FARINE', 55, 'KG'],
                ['MP-SUCRE', 20, 'KG'],
                ['MP-GRAISSE', 12, 'KG'],
                ['MP-CACAO', 10, 'KG'],
                ['MP-SEL', 3, 'KG'],
                ['EMB-FILM', 2, 'KG'],
                ['EMB-CARTON', 50, 'UN'],
            ] as [$itemCode, $quantity, $unitCode]) {
                $this->upsert('recipe_lines', [
                    'recipe_version_id' => $recipeVersionId,
                    'ingredient_item_id' => $items[$itemCode],
                ], [
                    'quantity' => $quantity,
                    'unit_id' => $units[$unitCode],
                    'loss_percentage' => 0,
                    'optional' => false,
                ]);
            }

            $processId = $this->upsert('process_templates', ['code' => 'PROC-BIS-STD'], [
                'name' => 'Processus standard biscuits',
                'finished_item_id' => $items['PF-BIS-CHOC'],
                'description' => 'Gamme initiale entièrement modifiable.',
                'active' => true,
            ]);

            DB::table('recipe_versions')->where('id', $recipeVersionId)->update([
                'process_template_id' => $processId,
                'notes' => 'Version de référence documentée dans le guide Recettes et prix de revient.',
                'updated_at' => now(),
            ]);

            foreach ([
                ['LABOR', 'Équipe de fabrication', 'QUANTITY', 8, $units['H'], 600, null],
                ['MACHINE', 'Utilisation de la ligne', 'QUANTITY', 3, $units['H'], 1200, null],
                ['ENERGY', 'Énergie du lot', 'QUANTITY', 120, $units['KWH'], 15, null],
                ['OVERHEAD', 'Frais indirects usine', 'PERCENTAGE', 1, null, 0, 5],
            ] as [$type, $label, $basis, $quantity, $unitId, $unitCost, $percentage]) {
                $this->upsert('recipe_cost_components', [
                    'recipe_version_id' => $recipeVersionId,
                    'cost_type' => $type,
                    'label' => $label,
                ], [
                    'calculation_basis' => $basis,
                    'quantity' => $quantity,
                    'unit_id' => $unitId,
                    'unit_cost' => $unitCost,
                    'percentage' => $percentage,
                    'currency_code' => 'DZD',
                    'notes' => 'Charge de démonstration modifiable.',
                ]);
            }

            foreach ([
                [10, 'PESEE', 'Pesée des matières', 'PREPARATION', 'BALANCE-01', 20, false],
                [20, 'PETRISSAGE', 'Préparation et pétrissage', 'PRODUCTION', 'PETRIN-01', 30, false],
                [30, 'FACONNAGE', 'Façonnage', 'PRODUCTION', 'FORMEUSE-01', 20, false],
                [40, 'CUISSON', 'Cuisson', 'PRODUCTION', 'FOUR-01', 25, true],
                [50, 'REFROIDISSEMENT', 'Refroidissement', 'PRODUCTION', 'REFROID-01', 20, false],
                [60, 'CONTROLE', 'Contrôle qualité', 'QUALITY', null, 15, true],
                [70, 'CONDITIONNEMENT', 'Conditionnement', 'PACKAGING', 'EMBALLEUSE-01', 30, true],
                [80, 'STOCKAGE', 'Mise en stock', 'STORAGE', null, 10, false],
            ] as [$sequence, $code, $name, $type, $machineCode, $duration, $qualityGate]) {
                $this->upsert('process_steps', [
                    'process_template_id' => $processId,
                    'sequence_number' => $sequence,
                ], [
                    'code' => $code,
                    'name' => $name,
                    'step_type' => $type,
                    'default_machine_id' => $machineCode ? $machines[$machineCode] : null,
                    'planned_duration_minutes' => $duration,
                    'parameters' => null,
                    'quality_gate' => $qualityGate,
                    'active' => true,
                ]);
            }

            $adminId = DB::table('users')->where('email', env('ADMIN_EMAIL', 'admin@biscuit-factory.local'))->value('id');
            $cookingStepId = DB::table('process_steps')
                ->where('process_template_id', $processId)
                ->where('code', 'CUISSON')
                ->value('id');
            $haccpPointId = $this->upsert('haccp_control_points', ['code' => 'CCP-CUISSON-01'], [
                'name' => 'Maîtrise de la cuisson',
                'process_step_id' => $cookingStepId,
                'production_line_id' => $lineId,
                'hazard_type' => 'BIOLOGICAL',
                'hazard_description' => 'Survie de micro-organismes en cas de cuisson insuffisante.',
                'control_measure' => 'Surveiller la température et le temps de cuisson du four.',
                'critical_limits' => 'Température à cœur ≥ 85 °C pendant au moins 2 minutes.',
                'monitoring_method' => 'Sonde étalonnée et enregistrement par lot.',
                'frequency_type' => 'BATCH',
                'frequency_value' => 1,
                'corrective_action' => 'Bloquer le lot, corriger les réglages et effectuer un nouveau contrôle.',
                'verification_method' => 'Revue quotidienne des enregistrements et étalonnage mensuel.',
                'responsible_role_code' => 'QUALITY_MANAGER',
                'active' => true,
            ]);
            $qualityPlanId = $this->upsert('quality_control_plans', [
                'code' => 'PCQ-PF-BIS-CHOC',
                'version' => 1,
            ], [
                'name' => 'Libération biscuit chocolat',
                'control_stage' => 'FINISHED_GOOD',
                'item_id' => $items['PF-BIS-CHOC'],
                'item_category_id' => null,
                'production_line_id' => $lineId,
                'haccp_control_point_id' => $haccpPointId,
                'sampling_method' => 'RANDOM',
                'sample_size' => 10,
                'frequency_type' => 'BATCH',
                'frequency_value' => 1,
                'instructions' => 'Prélever dix biscuits répartis entre le début, le milieu et la fin du lot.',
                'valid_from' => today(),
                'valid_to' => null,
                'status' => 'APPROVED',
                'active' => true,
                'created_by' => $adminId,
                'approved_by' => $adminId,
                'approved_at' => now(),
            ]);
            $qualityParameters = [];
            foreach ([
                ['HUMIDITE', 'Humidité', 'NUMERIC', null, 2, 5, 3.5, null, 'Dessiccation', true, true, 10],
                ['POIDS', 'Poids unitaire', 'NUMERIC', 'G', 9.5, 10.5, 10, null, 'Balance étalonnée', true, false, 20],
                ['ASPECT', 'Aspect visuel conforme', 'BOOLEAN', null, null, null, null, 'true', 'Contrôle visuel', true, false, 30],
            ] as [$code, $name, $type, $unit, $minimum, $maximum, $target, $expected, $method, $required, $critical, $sequence]) {
                $qualityParameters[$code] = $this->upsert('quality_control_plan_parameters', [
                    'quality_control_plan_id' => $qualityPlanId,
                    'code' => $code,
                ], [
                    'name' => $name,
                    'data_type' => $type,
                    'unit_id' => $unit ? $units[$unit] : null,
                    'minimum_value' => $minimum,
                    'maximum_value' => $maximum,
                    'target_value' => $target,
                    'expected_value' => $expected,
                    'options' => null,
                    'method' => $method,
                    'required' => $required,
                    'critical' => $critical,
                    'sequence' => $sequence,
                ]);
            }
            $finishedLotId = DB::table('lots')->where('lot_number', 'LOT-BISCUIT-DEMO')->value('id');
            $inspectionId = $this->upsert('quality_inspections', ['inspection_number' => 'CQ-DEMO-001'], [
                'quality_control_plan_id' => $qualityPlanId,
                'control_stage' => 'FINISHED_GOOD',
                'item_id' => $items['PF-BIS-CHOC'],
                'lot_id' => $finishedLotId,
                'production_order_id' => null,
                'stock_movement_id' => null,
                'production_line_id' => $lineId,
                'sample_reference' => 'ECH-DEMO-001',
                'sample_size' => 10,
                'status' => 'CONFORMING',
                'inspected_at' => now()->subDay(),
                'inspector_id' => $adminId,
                'decision' => 'RELEASE',
                'decision_reason' => 'Tous les critères de démonstration sont conformes.',
                'decided_by' => $adminId,
                'decided_at' => now()->subDay(),
                'overall_notes' => 'Exemple décrit dans le manuel utilisateur du module Qualité.',
            ]);
            foreach ([
                ['HUMIDITE', 3.4, null, null],
                ['POIDS', 10.1, null, null],
                ['ASPECT', null, null, true],
            ] as [$code, $numeric, $text, $boolean]) {
                $this->upsert('quality_inspection_results', [
                    'quality_inspection_id' => $inspectionId,
                    'quality_control_plan_parameter_id' => $qualityParameters[$code],
                ], [
                    'value_numeric' => $numeric,
                    'value_text' => $text,
                    'value_boolean' => $boolean,
                    'result_status' => 'PASS',
                    'deviation' => null,
                    'notes' => 'Résultat de démonstration.',
                    'measured_by' => $adminId,
                    'measured_at' => now()->subDay(),
                ]);
            }
            $decisionId = DB::table('quality_decisions')
                ->where('quality_inspection_id', $inspectionId)
                ->where('decision', 'RELEASE')
                ->value('id') ?: (string) Str::uuid();
            DB::table('quality_decisions')->updateOrInsert(
                ['quality_inspection_id' => $inspectionId, 'decision' => 'RELEASE'],
                [
                    'id' => $decisionId,
                    'lot_id' => $finishedLotId,
                    'previous_lot_status' => 'QUARANTINE',
                    'new_lot_status' => 'RELEASED',
                    'reason' => 'Tous les critères de démonstration sont conformes.',
                    'decided_by' => $adminId,
                    'decided_at' => now()->subDay(),
                    'created_at' => now()->subDay(),
                ],
            );
            $nonConformityId = $this->upsert('quality_non_conformities', ['non_conformity_number' => 'NC-DEMO-001'], [
                'quality_inspection_id' => null,
                'lot_id' => null,
                'item_id' => $items['PF-BIS-CHOC'],
                'production_order_id' => null,
                'severity' => 'MINOR',
                'category' => 'DOCUMENTATION',
                'title' => 'Étiquette interne incomplète',
                'description' => 'Le numéro d’équipe manquait sur une étiquette de suivi interne.',
                'immediate_action' => 'Étiquette corrigée et contrôle des étiquettes restantes.',
                'root_cause' => 'Instruction de travail insuffisamment précise.',
                'disposition' => 'Produit conforme, aucune incidence sur la sécurité alimentaire.',
                'status' => 'ACTION_PLAN',
                'detected_by' => $adminId,
                'detected_at' => now()->subHours(12),
                'owner_id' => $adminId,
                'due_date' => today()->addDays(5),
                'closed_by' => null,
                'closed_at' => null,
            ]);
            $this->upsert('quality_corrective_actions', ['action_number' => 'AC-DEMO-001'], [
                'quality_non_conformity_id' => $nonConformityId,
                'action_type' => 'CORRECTIVE',
                'description' => 'Mettre à jour l’instruction d’étiquetage et former les opérateurs.',
                'owner_id' => $adminId,
                'due_date' => today()->addDays(5),
                'status' => 'OPEN',
                'completion_notes' => null,
                'completed_by' => null,
                'completed_at' => null,
                'effectiveness_criteria' => 'Zéro étiquette incomplète pendant cinq jours consécutifs.',
                'effectiveness_result' => null,
                'verified_by' => null,
                'verified_at' => null,
            ]);

            $receivingPlanId = $this->upsert('quality_control_plans', [
                'code' => 'PCQ-MP-FARINE',
                'version' => 1,
            ], [
                'name' => 'Contrôle de réception de la farine',
                'control_stage' => 'RECEIVING',
                'item_id' => $items['MP-FARINE'],
                'item_category_id' => null,
                'production_line_id' => null,
                'haccp_control_point_id' => null,
                'sampling_method' => 'RANDOM',
                'sample_size' => 3,
                'frequency_type' => 'BATCH',
                'frequency_value' => 1,
                'instructions' => 'Prélever trois échantillons répartis dans le lot livré.',
                'valid_from' => today(),
                'valid_to' => null,
                'status' => 'APPROVED',
                'active' => true,
                'created_by' => $adminId,
                'approved_by' => $adminId,
                'approved_at' => now(),
            ]);
            foreach ([
                ['HUMIDITE-FARINE', 'Humidité farine', 'NUMERIC', null, 0, 15, 13, null, 'Humidimètre', true, true, 10],
                ['CERTIFICAT-ANALYSE', 'Certificat d’analyse présent', 'BOOLEAN', null, null, null, null, 'true', 'Contrôle documentaire', true, true, 20],
            ] as [$code, $name, $type, $unitId, $minimum, $maximum, $target, $expected, $method, $required, $critical, $sequence]) {
                $this->upsert('quality_control_plan_parameters', [
                    'quality_control_plan_id' => $receivingPlanId,
                    'code' => $code,
                ], [
                    'name' => $name,
                    'data_type' => $type,
                    'unit_id' => $unitId,
                    'minimum_value' => $minimum,
                    'maximum_value' => $maximum,
                    'target_value' => $target,
                    'expected_value' => $expected,
                    'options' => null,
                    'method' => $method,
                    'required' => $required,
                    'critical' => $critical,
                    'sequence' => $sequence,
                ]);
            }

            $supplierIds = [];
            foreach ([
                ['FOU-MINO-DZ', 'Minoterie Atlas', 'Minoterie Atlas SPA', 'contact@minoterie-atlas.example', 5, true],
                ['FOU-AGRO-DZ', 'Agro Distribution Centre', 'Agro Distribution Centre SARL', 'achats@agro-centre.example', 7, false],
            ] as [$code, $name, $legalName, $email, $leadTime, $preferred]) {
                $supplierIds[$code] = $this->upsert('suppliers', [
                    'company_id' => $companyId,
                    'code' => $code,
                ], [
                    'name' => $name,
                    'legal_name' => $legalName,
                    'supplier_type' => 'LOCAL',
                    'tax_identifier' => 'NIF-DEMO-'.$code,
                    'registration_number' => 'RC-DEMO-'.$code,
                    'statistical_identification_number' => 'NIS-DEMO-'.$code,
                    'article_of_imposition_number' => 'AI-DEMO-'.$code,
                    'country_code' => 'DZ',
                    'currency_code' => 'DZD',
                    'payment_terms_days' => 30,
                    'incoterm' => null,
                    'lead_time_days' => $leadTime,
                    'minimum_order_value' => 25000,
                    'status' => 'APPROVED',
                    'preferred' => $preferred,
                    'email' => $email,
                    'phone' => '+213 555 000 000',
                    'address' => 'Algérie — donnée de démonstration',
                    'notes' => 'Fournisseur de démonstration utilisé dans le manuel Achats.',
                    'active' => true,
                    'deleted_at' => null,
                ]);
            }
            $this->upsert('supplier_contacts', [
                'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                'email' => 'commercial@minoterie-atlas.example',
            ], [
                'name' => 'Contact commercial Démo',
                'job_title' => 'Responsable grands comptes',
                'phone' => '+213 555 100 100',
                'mobile' => '+213 555 100 101',
                'is_primary' => true,
                'active' => true,
            ]);
            foreach (['MP-FARINE', 'MP-SUCRE'] as $itemCode) {
                foreach ($supplierIds as $supplierCode => $supplierId) {
                    $this->upsert('supplier_items', [
                        'supplier_id' => $supplierId,
                        'item_id' => $items[$itemCode],
                        'purchasing_unit_id' => $units['KG'],
                    ], [
                        'supplier_reference' => $supplierCode.'-'.$itemCode,
                        'factor_to_base' => 1,
                        'minimum_order_quantity' => 100,
                        'pack_quantity' => 25,
                        'lead_time_days' => $supplierCode === 'FOU-MINO-DZ' ? 5 : 7,
                        'preferred' => $supplierCode === 'FOU-MINO-DZ',
                        'active' => true,
                    ]);
                }
            }

            $priceListId = $this->upsert('purchase_price_lists', [
                'company_id' => $companyId,
                'code' => 'TA-MINO-2026',
            ], [
                'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                'name' => 'Tarif Minoterie Atlas 2026',
                'currency_code' => 'DZD',
                'tax_included' => false,
                'priority' => 10,
                'valid_from' => today()->startOfYear(),
                'valid_to' => today()->endOfYear(),
                'status' => 'APPROVED',
                'created_by' => $adminId,
                'approved_by' => $adminId,
                'approved_at' => now(),
            ]);
            foreach ([
                ['MP-FARINE', 0, 62], ['MP-FARINE', 1000, 60], ['MP-SUCRE', 0, 108], ['MP-SUCRE', 500, 105],
            ] as [$itemCode, $minimumQuantity, $unitPrice]) {
                $supplierItemId = DB::table('supplier_items')->where([
                    'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                    'item_id' => $items[$itemCode],
                    'purchasing_unit_id' => $units['KG'],
                ])->value('id');
                $this->upsert('purchase_price_list_lines', [
                    'purchase_price_list_id' => $priceListId,
                    'item_id' => $items[$itemCode],
                    'unit_id' => $units['KG'],
                    'minimum_quantity' => $minimumQuantity,
                ], [
                    'supplier_item_id' => $supplierItemId,
                    'unit_price' => $unitPrice,
                    'discount_percentage' => 0,
                    'tax_rate_id' => null,
                    'lead_time_days' => 5,
                ]);
            }

            $requisitionId = $this->upsert('purchase_requisitions', ['requisition_number' => 'DA-DEMO-001'], [
                'company_id' => $companyId,
                'site_id' => $siteId,
                'request_date' => today()->subDays(5),
                'required_date' => today()->addDays(7),
                'priority' => 'NORMAL',
                'status' => 'ORDERED',
                'notes' => 'Réapprovisionnement matières premières — exemple du manuel Achats.',
                'rejection_reason' => null,
                'requested_by' => $adminId,
                'submitted_by' => $adminId,
                'submitted_at' => now()->subDays(5),
                'approved_by' => $adminId,
                'approved_at' => now()->subDays(4),
            ]);
            $requisitionLines = [];
            foreach ([['MP-FARINE', 1000, 60], ['MP-SUCRE', 500, 105]] as [$itemCode, $quantity, $estimatedPrice]) {
                $requisitionLines[$itemCode] = $this->upsert('purchase_requisition_lines', [
                    'purchase_requisition_id' => $requisitionId,
                    'item_id' => $items[$itemCode],
                ], [
                    'description' => DB::table('items')->where('id', $items[$itemCode])->value('name'),
                    'quantity' => $quantity,
                    'quantity_ordered' => $quantity,
                    'unit_id' => $units['KG'],
                    'suggested_supplier_id' => $supplierIds['FOU-MINO-DZ'],
                    'estimated_unit_price' => $estimatedPrice,
                    'currency_code' => 'DZD',
                    'notes' => null,
                ]);
            }

            $quotationIds = [];
            foreach ([
                ['OFF-DEMO-ATLAS', 'FOU-MINO-DZ', 'SELECTED', 60000, 52500, 5],
                ['OFF-DEMO-AGRO', 'FOU-AGRO-DZ', 'RECEIVED', 64000, 55000, 7],
            ] as [$number, $supplierCode, $status, $flourTotal, $sugarTotal, $deliveryDays]) {
                $quotationIds[$number] = $this->upsert('supplier_quotations', ['quotation_number' => $number], [
                    'company_id' => $companyId,
                    'purchase_requisition_id' => $requisitionId,
                    'supplier_id' => $supplierIds[$supplierCode],
                    'supplier_reference' => 'DEVIS-'.$number,
                    'quotation_date' => today()->subDays(3),
                    'valid_until' => today()->addDays(20),
                    'currency_code' => 'DZD',
                    'exchange_rate' => 1,
                    'tax_included' => false,
                    'status' => $status,
                    'payment_terms_days' => 30,
                    'delivery_lead_time_days' => $deliveryDays,
                    'subtotal' => $flourTotal + $sugarTotal,
                    'discount_amount' => 0,
                    'tax_amount' => 0,
                    'total_amount' => $flourTotal + $sugarTotal,
                    'notes' => 'Offre de démonstration pour comparaison.',
                    'created_by' => $adminId,
                ]);
                foreach ([
                    ['MP-FARINE', 1000, $flourTotal / 1000],
                    ['MP-SUCRE', 500, $sugarTotal / 500],
                ] as [$itemCode, $quantity, $unitPrice]) {
                    $this->upsert('supplier_quotation_lines', [
                        'supplier_quotation_id' => $quotationIds[$number],
                        'purchase_requisition_line_id' => $requisitionLines[$itemCode],
                    ], [
                        'item_id' => $items[$itemCode],
                        'description' => DB::table('items')->where('id', $items[$itemCode])->value('name'),
                        'quantity' => $quantity,
                        'unit_id' => $units['KG'],
                        'unit_price' => $unitPrice,
                        'discount_percentage' => 0,
                        'tax_rate_id' => null,
                        'line_subtotal' => $quantity * $unitPrice,
                        'tax_amount' => 0,
                        'line_total' => $quantity * $unitPrice,
                    ]);
                }
            }

            $purchaseOrderId = $this->upsert('purchase_orders', ['order_number' => 'BC-DEMO-001'], [
                'company_id' => $companyId,
                'site_id' => $siteId,
                'warehouse_id' => $warehouseId,
                'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                'purchase_requisition_id' => $requisitionId,
                'supplier_quotation_id' => $quotationIds['OFF-DEMO-ATLAS'],
                'order_date' => today()->subDays(2),
                'expected_date' => today()->addDays(3),
                'currency_code' => 'DZD',
                'exchange_rate' => 1,
                'tax_included' => false,
                'status' => 'APPROVED',
                'payment_terms_days' => 30,
                'incoterm' => null,
                'supplier_reference' => null,
                'subtotal' => 112500,
                'discount_amount' => 0,
                'tax_amount' => 0,
                'total_amount' => 112500,
                'notes' => 'Commande exemple prête à être réceptionnée.',
                'cancellation_reason' => null,
                'created_by' => $adminId,
                'submitted_by' => $adminId,
                'submitted_at' => now()->subDays(2),
                'approved_by' => $adminId,
                'approved_at' => now()->subDay(),
            ]);
            $purchaseOrderLines = [];
            foreach ([['MP-FARINE', 1000, 60], ['MP-SUCRE', 500, 105]] as [$itemCode, $quantity, $unitPrice]) {
                $purchaseOrderLines[$itemCode] = $this->upsert('purchase_order_lines', [
                    'purchase_order_id' => $purchaseOrderId,
                    'item_id' => $items[$itemCode],
                ], [
                    'purchase_requisition_line_id' => $requisitionLines[$itemCode],
                    'description' => DB::table('items')->where('id', $items[$itemCode])->value('name'),
                    'ordered_quantity' => $quantity,
                    'received_quantity' => 0,
                    'returned_quantity' => 0,
                    'unit_id' => $units['KG'],
                    'factor_to_base' => 1,
                    'unit_price' => $unitPrice,
                    'discount_percentage' => 0,
                    'tax_rate_id' => null,
                    'net_unit_price' => $unitPrice,
                    'line_subtotal' => $quantity * $unitPrice,
                    'tax_amount' => 0,
                    'line_total' => $quantity * $unitPrice,
                    'expected_date' => today()->addDays(3),
                    'status' => 'OPEN',
                    'notes' => null,
                ]);
            }
            $goodsReceiptId = $this->upsert('goods_receipts', ['receipt_number' => 'BR-DEMO-001'], [
                'purchase_order_id' => $purchaseOrderId,
                'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                'warehouse_id' => $warehouseId,
                'destination_location_id' => $locations['QUARANTAINE'],
                'received_at' => now(),
                'supplier_delivery_note' => 'BL-DEMO-001',
                'status' => 'DRAFT',
                'notes' => 'Réception exemple à comptabiliser pour générer le contrôle qualité.',
                'created_by' => $adminId,
                'posted_by' => null,
                'posted_at' => null,
                'stock_movement_id' => null,
            ]);
            $this->upsert('goods_receipt_lines', [
                'goods_receipt_id' => $goodsReceiptId,
                'purchase_order_line_id' => $purchaseOrderLines['MP-FARINE'],
            ], [
                'item_id' => $items['MP-FARINE'],
                'lot_id' => null,
                'lot_number' => 'LOT-FARINE-ACHAT-DEMO',
                'manufacturing_date' => today()->subDays(7),
                'expiry_date' => today()->addDays(173),
                'accepted_quantity' => 250,
                'rejected_quantity' => 0,
                'unit_id' => $units['KG'],
                'factor_to_base' => 1,
                'base_quantity' => 250,
                'unit_cost' => 60,
                'base_unit_cost' => 60,
                'rejection_reason' => null,
                'stock_movement_line_id' => null,
            ]);
            $this->upsert('supplier_evaluations', ['evaluation_number' => 'EVF-DEMO-001'], [
                'company_id' => $companyId,
                'supplier_id' => $supplierIds['FOU-MINO-DZ'],
                'period_from' => today()->subMonth()->startOfMonth(),
                'period_to' => today()->subMonth()->endOfMonth(),
                'quality_score' => 92,
                'delivery_score' => 88,
                'commercial_score' => 85,
                'service_score' => 90,
                'total_score' => 88.75,
                'status' => 'COMPLETED',
                'comments' => 'Évaluation de démonstration : fournisseur recommandé.',
                'evaluated_by' => $adminId,
                'completed_at' => now()->subMonth(),
            ]);

            $this->upsert('line_products', [
                'production_line_id' => $lineId,
                'item_id' => $items['PF-BIS-CHOC'],
            ], [
                'production_rate_per_hour' => 500,
                'rate_unit_id' => $units['KG'],
                'setup_time_minutes' => 45,
                'active' => true,
            ]);

            foreach ([
                ['PANNE', 'Panne machine', 'BREAKDOWN', false],
                ['PREVENTIF', 'Maintenance préventive', 'PREVENTIVE_MAINTENANCE', true],
                ['NETTOYAGE', 'Nettoyage', 'CLEANING', true],
                ['CHANGEMENT', 'Changement de format', 'CHANGEOVER', true],
                ['MATIERE', 'Manque de matière', 'MATERIAL_SHORTAGE', false],
                ['QUALITE', 'Incident qualité', 'QUALITY_ISSUE', false],
                ['ENERGIE', 'Coupure d’énergie', 'POWER_FAILURE', false],
                ['PERSONNEL', 'Manque de personnel', 'STAFF_SHORTAGE', false],
                ['AUTRE', 'Autre cause', 'OTHER', false],
            ] as [$code, $name, $category, $planned]) {
                $this->upsert('downtime_reasons', ['code' => $code], [
                    'name' => $name,
                    'category' => $category,
                    'planned' => $planned,
                    'active' => true,
                ]);
            }

            $planId = $this->upsert('maintenance_plans', ['code' => 'MP-FOUR-HEBDO'], [
                'name' => 'Inspection hebdomadaire du four',
                'production_line_id' => $lineId,
                'machine_id' => $machines['FOUR-01'],
                'maintenance_type' => 'PREVENTIVE',
                'frequency_type' => 'WEEKS',
                'frequency_value' => 1,
                'estimated_duration_minutes' => 60,
                'next_due_at' => now()->addWeek(),
                'active' => true,
            ]);

            $workOrderId = $this->upsert('maintenance_work_orders', ['work_order_number' => 'OT-DEMO-001'], [
                'maintenance_plan_id' => $planId, 'production_line_id' => $lineId, 'machine_id' => $machines['FOUR-01'],
                'maintenance_type' => 'CORRECTIVE', 'priority' => 'HIGH', 'description' => 'Contrôle du brûleur principal (démonstration).',
                'planned_start' => now()->subDays(3), 'planned_end' => now()->subDays(3)->addHour(),
                'actual_start' => now()->subDays(3), 'actual_end' => now()->subDays(3)->addMinutes(45),
                'status' => 'COMPLETED', 'assigned_to' => null, 'labor_cost' => 1500, 'parts_cost' => 0,
                'observations' => 'Nettoyage et réglage effectués.',
            ]);
            $reasonId = DB::table('downtime_reasons')->where('code', 'PANNE')->value('id');
            $this->upsert('production_downtimes', ['maintenance_work_order_id' => $workOrderId], [
                'production_line_id' => $lineId, 'machine_id' => $machines['FOUR-01'], 'production_order_id' => null,
                'downtime_reason_id' => $reasonId, 'started_at' => now()->subDays(3), 'ended_at' => now()->subDays(3)->addMinutes(45), 'duration_seconds' => 2700,
                'planned' => false, 'impact_level' => 'LINE_STOP', 'description' => 'Arrêt de démonstration.', 'recorded_by' => null,
            ]);
        });
    }

    private function upsert(string $table, array $keys, array $values): string
    {
        $query = DB::table($table);

        foreach ($keys as $column => $value) {
            $query->where($column, $value);
        }

        $id = $query->value('id') ?: (string) Str::uuid();

        DB::table($table)->updateOrInsert(
            $keys,
            array_merge($values, [
                'id' => $id,
                'updated_at' => now(),
                'created_at' => now(),
            ])
        );

        return $id;
    }
}
