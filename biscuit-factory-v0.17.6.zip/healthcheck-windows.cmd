@echo off
call "%~dp0scripts\windows\healthcheck.cmd" %*
exit /b %errorlevel%
