# Licence

Projet privé. Tous droits réservés au propriétaire du projet.

Aucune redistribution ou utilisation en production n'est autorisée sans validation du propriétaire.
Les dépendances tierces conservent leurs licences respectives.
