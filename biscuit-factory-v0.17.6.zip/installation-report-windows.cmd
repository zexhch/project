@echo off
call "%~dp0scripts\windows\installation-report.cmd" %*
exit /b %errorlevel%
