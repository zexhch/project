#!/usr/bin/env bash
set -euo pipefail

cd /var/www/html

mkdir -p \
    storage/app/private \
    storage/app/public \
    storage/framework/cache/data \
    storage/framework/sessions \
    storage/framework/testing \
    storage/framework/views \
    storage/logs \
    bootstrap/cache

if [ ! -f vendor/autoload.php ] && [ "${1:-}" != "composer" ]; then
    echo "[entrypoint] Installation des dépendances Composer..."
    composer install --no-interaction --prefer-dist
fi

if [ -f artisan ]; then
    php artisan package:discover --ansi >/dev/null 2>&1 || true

    # The public storage link is a runtime artifact. It is deliberately excluded
    # from the Docker build context to avoid BuildKit errors on host symlinks.
    if [ ! -e public/storage ] && [ ! -L public/storage ]; then
        php artisan storage:link --no-interaction >/dev/null 2>&1 || true
    fi

    if [ "${APP_AUTO_MIGRATE:-false}" = "true" ]; then
        php artisan migrate --force
    fi
fi

chmod -R ug+rwX storage bootstrap/cache 2>/dev/null || true

exec "$@"
